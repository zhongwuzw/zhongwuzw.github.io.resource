//
//  PlayerIconPreviewView.swift
//  YKChannelComponent
//
//  Created by CC on 2021/4/6.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import SDWebImage
import YKResponsiveLayout
import YoukuResource

public protocol PlayerIconViewable: NSObjectProtocol {
    func didClickPlayerIcon()
    
}

class PlayerIconPreviewView: UIView {

    weak var playerDelegate:PlayerIconViewable?
    //MARK: Property
    lazy var playIconView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.image = UIImage.init(named: "st_player_plugin_icon_play")
        return view
    }()
    
    //MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        createSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        createSubviews()
    }
    
    //MARK: -
    func createSubviews() {
        
        addSubview(playIconView)
//        self.ykn_(whenTapped: {
//            self.playerDelegate?.didClickPlayerIcon()
//        })
        
        self.customLayout()
    }
    
    func customLayout() {
        
        let sizeW = CGFloat(45.0)
        playIconView.frame = CGRect.init(x: (self.width - sizeW) / 2.0, y: (self.height - sizeW) / 2.0, width: sizeW, height: sizeW)
    }
    
    override var frame: CGRect {
        didSet {
            super.frame = frame
            self.customLayout()
        }
    }
    
}
