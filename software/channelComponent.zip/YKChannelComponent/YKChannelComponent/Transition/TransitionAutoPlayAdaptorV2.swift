//
//  TransitionAutoPlayAdaptorV2.swift
//  YKChannelComponent
//
//  Created by Kenneth on 2022/2/24.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneTransition
import OneTransitionCore
import OneArch
import OneArchSupport4Youku
import UIKit

class TransitionAutoPlayAdaptorV2: NSObject, OTTransitionBackDelegate {
    internal weak var item: IItem?
    private var playLineY: CGFloat {
        return UIScreen.main.bounds.height / 2.0
    }
    private weak var targetPlayer: PlayerModel?
    
    func willStartTransitionBackAnimation(item: OTTransitionItem) {
        if item.transitionType == .player {
            // 播放无缝返场，提前隐藏截图
            let tag = PlayerControlManagerV2.instance.stopCaptureViewTag()
            let imageView = self.targetPlayer?.itemView?.viewWithTag(tag) as? UIImageView
            imageView?.isHidden = true
        }
    }
    
    func didFinishTransitionBackAnimation(item: OTTransitionItem) {
        self.targetPlayer = nil
    }

    func shouldTransitionBack(item: OTTransitionItem) -> Bool {
        guard item.transitionType == .player,
              let transitionPlayId = item.playId
        else { return true }
        
        // 封图无缝允许返场
        if item.isVideoCoverTransition() {
            return true
        }
        
        var playerModels: [PlayerModel] = []
        
        guard let components = self.item?.getPage()?.pageContext?.getVisibleComponents()
        else { return false }
        for component in components {
            guard let items = component.getItems() else { continue }
            let type = component.tag ?? ""
            // 12094 卡片特殊处理
            if type == "12094" {
                
            } else {
                for mItem in items {
                    guard let model = mItem.itemModel?.playerModel else { continue }
                    playerModels.append(model)
                }
            }
        }
                
        guard let targetPlayer = self.findTargetPlayer(playerArray: playerModels),
              let playerId = targetPlayer.playerId
        else { return false }
        
        if OTPlayerHelper.getUnionFormVid(vid: playerId) == OTPlayerHelper.getUnionFormVid(vid: transitionPlayId) {
            self.targetPlayer = targetPlayer
            return true
        }
        return false
    }
    
    func itemViewWithPlayer(_ player: PlayerModel?) -> UIView? {
        return player?.itemView
    }

    func findTargetPlayer(playerArray: [PlayerModel]) -> PlayerModel? {
        var newPlayers: [PlayerModel] = [PlayerModel]()

        for player in playerArray {
            //处理过区间问题,选择最适合播放的
            let itemView = self.itemViewWithPlayer(player)

            //1.1 优先选择全部露出的播放view
            if self.isViewVisibleFull(itemView, player: player) {
                newPlayers.append(player)
            }
        }

        var midPlayers = [PlayerModel]()

        for player in playerArray {
            if self.itemViewPosition(player) {
                //1.2 选择经过中线的卡片
                midPlayers.append(player)
            }
        }

        var targetPlayer: PlayerModel?
        if midPlayers.count > 0 {
            newPlayers = midPlayers

            if newPlayers.count == 0 {
                //2.0 有处于中线的卡片 优先选择
                newPlayers.append(contentsOf: playerArray)
            }

            //2.1播放线偏上、中时 优先选择Y大的，这样能保证封面露出更多 视频区域露出更多
            if newPlayers.count == 1 {
                //2.2播放线偏下时 优先选择Y小的
                //没有完全露出的，那所有的player都进行Y坐标判断
                return newPlayers.first
            }

            var maxY: CGFloat = 0
            var minX: CGFloat = 1111111110
            for player in newPlayers.reversed() {
                let itemView = self.itemViewWithPlayer(player)
                //只有一个 直接播放
                let frame = itemView?.superview?.convert(itemView?.frame ?? CGRect(), to: nil) ?? CGRect()

                if maxY < frame.minY {
                    maxY = frame.minY
                    //2 开始Y坐标判断
                    targetPlayer = player
                    minX = min(minX, frame.minX)
                } else if maxY == frame.minY {
                    if minX > frame.minX {
                        minX = frame.minX
                        targetPlayer = player
                    }
                }
            }
        } else {
            var minSpacing: CGFloat = 1111111110
            let playerModel = newPlayers.first
            let pageModel = playerModel?.item?.getPage()?.pageModel
            let playLineY = self.realPlayLineY(pageModel)

            for player in newPlayers.reversed() {
                //Y相同 取X小的
                let itemView = self.itemViewWithPlayer(player)
                var frame = itemView?.superview?.convert(itemView?.frame ?? CGRect(), to: nil) ?? CGRect()
                if itemView?.window == nil, let currentWindow = UIApplication.shared.delegate?.window {
                    frame = itemView?.superview?.convert(itemView?.frame ?? CGRect(), to: currentWindow) ?? CGRect()
                }

                if frame.maxY < playLineY {
                    //2.选择距离中线最近的
                    if minSpacing > abs(playLineY - frame.maxY) {
                        minSpacing = abs(playLineY - frame.maxY)
                        targetPlayer = player
                    }
                } else if frame.minY > playLineY {
                    if minSpacing > abs(playLineY - frame.minY) {
                        //底部在中线上面
                        minSpacing = abs(playLineY - frame.minY)
                        targetPlayer = player
                    }
                }
            }
        }
        return targetPlayer
    }
    
    func realPlayLineY(_ model: BasePageModel?) -> CGFloat {
        guard let model = model else { return self.playLineY }
        if let playLineY = model.extraExtend["player.PlayLineY"] as? CGFloat, playLineY > 0 {
            return playLineY
        }
        return self.playLineY
    }

    func itemViewPosition(_ player: PlayerModel?) -> Bool {
        let itemView = self.itemViewWithPlayer(player)
        var willPlayFrame = itemView?.superview?.convert(itemView?.frame ?? CGRect(), to: nil) ?? CGRect()
        if itemView?.window == nil, let currentWindow = UIApplication.shared.delegate?.window {
            willPlayFrame = itemView?.superview?.convert(itemView?.frame ?? CGRect(), to: currentWindow) ?? CGRect()
        }

        let playLineY = self.realPlayLineY(player?.item?.getPage()?.pageModel)

        if willPlayFrame.minY <= playLineY && willPlayFrame.maxY > playLineY {
            return true
        }

        return false
    }

    func isViewVisibleFull(_ view: UIView?, player: PlayerModel?) -> Bool {
        let pageContext = player?.item?.pageContext
        let containerView = pageContext?.getContainerView()

        let page = player?.item?.getPage()
        var min = CGFloat(page?.containerPaddingTop(page) ?? 60)

        let max = UIScreen.main.bounds.height - 95
        let width = CGFloat(containerView?.width ?? 0)
        var frame = view?.superview?.convert(view?.frame ?? CGRect(), to: nil) ?? CGRect()
        if view?.window == nil, let currentWindow = UIApplication.shared.delegate?.window {
            frame = view?.superview?.convert(view?.frame ?? CGRect(), to: currentWindow) ?? CGRect()
        }

        let minY = frame.minY
        let maxY = frame.maxY

        if maxY <= min || minY >= max {
            return false
        }

        let viewRect = CGRect(x: 0, y: minY, width: frame.size.width, height: frame.size.height)
        let visileRect = CGRect(x: 0, y: min, width: width, height: max - min)
        let intersectionRect = viewRect.intersection(visileRect)

        if intersectionRect.size.height <= 0 {
            return false
        }

        if intersectionRect.size.height < viewRect.size.height * 0.5 {
            return false
        }

        return true
    }
}
