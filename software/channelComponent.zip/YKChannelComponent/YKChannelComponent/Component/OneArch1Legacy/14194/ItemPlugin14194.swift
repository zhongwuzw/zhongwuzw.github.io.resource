//
//  ItemPlugin14194.swift
//  YKChannelComponent
//
//  Created by CC on 2022/2/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKSCBase
import YoukuResource
import OneArchCore
import YKOneConfig
import YoukuAnalytics
import YKChannel
import OneArchSupport
import OneArchSupport4Youku

@objcMembers
class ItemPlugin14194: YKSCItemPlugin {
    
    
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventParseData,
                "selector":     "receiveParseDataEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemCount,
                "selector":     "receiveQueryItemCountEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemHeight,
                "selector":     "receiveQueryItemHeightEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemReuseId,
                "selector":     "receiveQueryItemReuseIdEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemView,
                "selector":     "receiveQueryItemViewEvent:",
            ],
            [
                "event":        YKSCItemEventReuseItemView,
                "selector":     "receiveReuseItemViewEvent:",
                "priority":     600,
            ],
            [
                "event":        YKSCItemEventItemEnterDisplayArea,
                "selector":     "receiveItemEnterDisplayAreaEvent:",
            ],
            [
                "event":        YKSCItemEventItemExitDisplayArea,
                "selector":     "receiveItemExitDisplayAreaEvent:",
            ],
            [
                "event":        YKSCItemEventItemDidActivate,
                "selector":     "receiveItemDidActivateEvent:",
            ],
            [
                "event":        YKSCItemEventItemWillDeactivate,
                "selector":     "receiveItemWillDeactivateEvent:",
            ],
            [
                "event":        YKSCItemEventItemDidDeactivate,
                "selector":     "receiveItemDidDeactivateEvent:",
            ],
        ]
    }
    
    func receiveParseDataEvent(_ event: YKSCEvent) {
  
        guard let scItemContext = scItemContext,
              let itemInfo = event.params?["itemInfo"] as? [String: Any]
        else {
            return
        }
        
        let homeModel = HomeItemModelV1()
        if let data = itemInfo["data"] as? [String: Any],
           let ex = data["extraExtend"] as? [String : Any] {
            homeModel.extraExtend = ex
        }
        scItemContext.modelV2.extModelHome = homeModel
        if let attachModel = self.parseCalendarData(itemInfo) {
            homeModel.extraExtend?["attachModel"] = attachModel
            parseAttachModel(attachModel)
        }
        if let superViewController = self.superViewController() {
            homeModel.extraExtend?["superViewController"] = superViewController
        }
    }
        
    func receiveQueryItemCountEvent(_ event: YKSCEvent) {
        event.responseInfo.setValue(NSNumber(value: 1), forKey: "itemCount")
    }

    func receiveQueryItemHeightEvent(_ event: YKSCEvent) {
        let itemWidth: CGFloat = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let aspectRatio: CGFloat = 16 / 9.0
        let itemHeight: CGFloat = itemWidth * aspectRatio
        
        estimatedLayout(CGSize.init(width: itemWidth, height: itemHeight))
        event.responseInfo.setValue(NSNumber(value: itemHeight), forKey: "itemHeight")
    }
    
    func receiveQueryItemReuseIdEvent(_ event: YKSCEvent) {
        guard let scComponentContext = scComponentContext else {
            return
        }
        
        let componentTag = scComponentContext.scString(forKey: YKSCComponentDataTemplateTag) ?? "unknown"
        let reuseId = String("reuseId_14194_" + componentTag)
        event.responseInfo.setValue(reuseId, forKey: "reuseId")
    }
    
    func receiveQueryItemViewEvent(_ event: YKSCEvent) {
        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let itemHeight: Double = (event.params?["itemHeight"] as? NSNumber)?.doubleValue ?? 0
        let itemView = ItemPlugin14194ContentView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        event.responseInfo.setValue(itemView, forKey:"itemView")
    }

    func receiveReuseItemViewEvent(_ event: YKSCEvent) {
        guard let scItemContext = scItemContext else {
            return
        }
        
        guard let itemView = event.params?["itemView"] as? ItemPlugin14194ContentView else {
            return
        }
        
        itemView.fillData(scItemContext.modelV2, layout: scItemContext.layoutModelV2)
    }
    
    func receiveItemEnterDisplayAreaEvent(_ event: YKSCEvent) {
    }
    
    func receiveItemExitDisplayAreaEvent(_ event: YKSCEvent) {
    }
    
    func receiveItemDidActivateEvent(_ event: YKSCEvent) {
    }
    
    func receiveItemWillDeactivateEvent(_ event: YKSCEvent) {
    }
    
    func receiveItemDidDeactivateEvent(_ event: YKSCEvent) {
    }
    
    
    func isPageInPreload() -> Bool {
        guard let scPageContext = self.scItemContext?.scPageContext else {
            return false
        }
        let state = scPageContext.scString(forKey: YKSCPageDataDataState)
        if state == "preload" || state == "cache" {
            return true
        }
        return false
    }

    func parseCalendarData(_ itemInfo: [String: Any]) -> YKSCCalendarHeaderAttachmentModel? {
        
        guard let subNodeData = itemInfo["data"] as? [String: Any], subNodeData.keys.count > 0 else {
            return nil
        }
        
        let attachModel = YKSCCalendarHeaderAttachmentModel.init()
        attachModel.scModule = self.scModule
        
        if let l2ActionInfo = itemInfo["action"] as? [String: Any], l2ActionInfo.keys.count > 0 {
            attachModel.listActionInfo = l2ActionInfo
        }
        
        if let title = subNodeData["title"] as? String, title.isEmpty == false {
            attachModel.title = title
        }
        
        if let titleIcon = subNodeData["titleIcon"] as? String, titleIcon.isEmpty == false {
            attachModel.titleIcon = titleIcon
        }
        
        if let img = subNodeData["imgV2"] as? String, img.isEmpty == false {
            attachModel.img = img
        }
        
        if let playVideoId = subNodeData["playVideoId"] as? NSNumber {
            attachModel.playVideoId = playVideoId.stringValue
        } else if let playVideoId = subNodeData["playVideoId"] as? String {
            attachModel.playVideoId = playVideoId
        }
        
        // extraExtend
        if let extraExtend = subNodeData["extraExtend"] as? [String: Any], extraExtend.keys.count > 0 {
            
            if let year = extraExtend["year"] as? String, year.isEmpty == false {
                attachModel.year = year
            }
            
            if let month = extraExtend["month"] as? String, month.isEmpty == false {
                attachModel.month = month
            }
            
            if let day = extraExtend["day"] as? String, day.isEmpty == false {
                attachModel.day = day
            }
            
            if let returnVal = extraExtend["returnVal"] as? String, returnVal.isEmpty == false {
                attachModel.dateString = returnVal
            }
            
            if let movieTitle = extraExtend["title"] as? String, movieTitle.isEmpty == false {
                attachModel.movieTitle = movieTitle
            }
            
            if let subtitle = extraExtend["anniversary"] as? String, subtitle.isEmpty == false {
                attachModel.subtitle = subtitle
            }
            
            if let desc = extraExtend["desc"] as? String, desc.isEmpty == false {
                attachModel.desc = desc
            }
        }
        
        if let l3ActionInfo = subNodeData["action"] as? [String: Any], l3ActionInfo.keys.count > 0 {
            attachModel.playActionInfo = l3ActionInfo
        }
        return attachModel
        // 解析路由、埋点
    }
    
    
    
    func parseAttachModel(_ attachModel : YKSCCalendarHeaderAttachmentModel) {
        
        //解析跳转、埋点
        //播放
        let playInfo = attachModel.playActionInfo
        let playReportInfo = playInfo["report"] as? [String : Any]
        
        var params = [String : Any]()
        params["actionInfo"] = playInfo
        params["viewTag"] = "play"
        self.scFireEvent(YKSCItemEventParseAction, params: params)
        
        params = [String : Any]()
        params["statisInfo"] = playReportInfo
        params["viewTag"] = "play"
        self.scFireEvent(YKSCItemEventParseStatis, params: params)
        
        //分享

        let shareReportInfo = CMSStatisticsHelper.statisInfo(playReportInfo, replaceSpmD: "share", replaceScmD: nil)
        params = [String : Any]()
        params["statisInfo"] = shareReportInfo
        params["viewTag"] = "share"
        self.scFireEvent(YKSCItemEventParseStatis, params: params)
        
        //关闭
        let closeReportInfo = CMSStatisticsHelper.statisInfo(playReportInfo, replaceSpmD: "close", replaceScmD: nil)
        params = [String : Any]()
        params["statisInfo"] = closeReportInfo
        params["viewTag"] = "close"
        self.scFireEvent(YKSCItemEventParseStatis, params: params)

        //下载
        let downloadReportInfo = CMSStatisticsHelper.statisInfo(playReportInfo, replaceSpmD: "download", replaceScmD: nil)
        params = [String : Any]()
        params["statisInfo"] = downloadReportInfo
        params["viewTag"] = "download"
        self.scFireEvent(YKSCItemEventParseStatis, params: params)
    
    }
    
    func superViewController() -> UIViewController? {
        let superVC = self.scPageContext?.scData(forKey: YKSCPageDataController) as? UIViewController
        return superVC
    }
    
    func estimatedLayout(_ itemSize: CGSize) {
        guard let scItemContext = scItemContext,
              let homeModel = scItemContext.modelV2.homeModel,
              let extraExtend = homeModel.extraExtend
        else {
            return
        }
        
        let itemHeight = itemSize.height
        var textYCursor: CGFloat = max(itemHeight - 9.0 - 30.0 - 5.0, 0) // formula = 坑位总高 - bottompadding - 播放按钮高度 - gap
        let textLeft: CGFloat = 12
        let textWidthMax = max(itemSize.width - textLeft * 2, 0)
        
        if scItemContext.layoutModelV2.extendExtra == nil {
            scItemContext.layoutModelV2.extendExtra = [String: Any]()
        }
        
        if let t3Text = extraExtend["title"] as? String, !t3Text.isEmpty {
            let layout = TextLayoutModel.init()
            let font = ItemPlugin14194ContentView.t3LabelFont()
            let singleLineHeight = font.lineHeight
            
            textYCursor = textYCursor - singleLineHeight
            layout.renderRect = CGRect.init(x: textLeft, y: textYCursor, width: textWidthMax, height: singleLineHeight)
            
            scItemContext.layoutModelV2.extendExtra?["t3"] = layout
            
            textYCursor = textYCursor - 6.0
        }
        
        if let t2Text = extraExtend["desc"] as? String, !t2Text.isEmpty {
            let layout = TextLayoutModel.init()
            let font = ItemPlugin14194ContentView.t2LabelFont()
            let singleLineHeight = font.lineHeight
            let textHeightMax = singleLineHeight * 3.5 // 最多3行，小数点为行间距约数。
            let textFitHeight = calcStringHeight(t2Text, font: font, limitSize: CGSize.init(width: textWidthMax, height: textHeightMax))//(t2Text, font: font, size: CGSize.init(width: textWidthMax, height: textHeightMax))
            
            textYCursor = textYCursor - textFitHeight
            layout.renderRect = CGRect.init(x: textLeft, y: textYCursor, width: textWidthMax, height: textFitHeight)
            
            scItemContext.layoutModelV2.extendExtra?["t2"] = layout
            
            textYCursor = textYCursor - 9.0
        }
        
        if let t1Text = extraExtend["anniversary"] as? String, !t1Text.isEmpty {
            let layout = TextLayoutModel.init()
            let font = ItemPlugin14194ContentView.t1LabelFont()
            let singleLineHeight = font.lineHeight
            
            textYCursor = textYCursor - singleLineHeight
            layout.renderRect = CGRect.init(x: textLeft, y: textYCursor, width: textWidthMax, height: singleLineHeight)
            
            scItemContext.layoutModelV2.extendExtra?["t1"] = layout
        }
    }

}
