//
//  ItemPlugin14194ContentView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/3/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import SDWebImage
import YoukuResource
import YKChannel
import OneArchSupport
import OneArchSupport4Youku

class ItemPlugin14194ContentView:AccessibilityView {
    let monthArray = ["JAN", "FEB", "MAR", "APR", "MAY", "JUNE", "JULY", "AUG", "SEPT", "OCT", "NOV", "DEC"]
    
    var model:BaseItemModel?
    
    lazy var dayLabel: UILabel = {
        let view = UILabel()
        view.textColor = .white
        view.font = YKNFont.akrobatExtraBoldFont(ofSize: 29)
        return view
    }()
    
    lazy var monthLabel: UILabel = {
        let view = UILabel()
        view.textColor = .white.withAlphaComponent(0.7)
        view.font = YKNFont.akrobatExtraBoldFont(ofSize: 11)
        return view
    }()
    
    lazy var t1Label: UILabel = {
        let view = UILabel()
        view.textColor = .white.withAlphaComponent(0.7)
        view.font = ItemPlugin14194ContentView.t1LabelFont()
        return view
    }()
    
    lazy var t2Label: UILabel = {
        let view = UILabel()
        view.textColor = .white
        view.font = ItemPlugin14194ContentView.t2LabelFont()
        view.numberOfLines = 3
        return view
    }()
    
    lazy var t3Label: UILabel = {
        let view = UILabel()
        view.textColor = .white.withAlphaComponent(0.7)
        view.font = ItemPlugin14194ContentView.t3LabelFont()
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.isUserInteractionEnabled = true
        return view
    }()
    
    lazy var playImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.image = UIImage.init(named: "movie_poster_play")
        view.isUserInteractionEnabled = true
        return view
    }()
    
    //MARK:
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        self.backgroundColor = UIColor.ykn_primaryBackground
        self.addSubview(self.videoImageView)
        self.addSubview(self.dayLabel)
        self.addSubview(self.monthLabel)
        self.addSubview(self.t1Label)
        self.addSubview(self.t2Label)
        self.addSubview(self.t3Label)
        self.addSubview(self.playImageView)
    }
    
    func fillData(_ itemModel: OneArchSupport4Youku.BaseItemModel, layout: OneArchSupport4Youku.LayoutModel) {
        self.model = itemModel
        if let h = itemModel.extModelHome as? HomeItemModelV1,
           let extraExtend = h.extraExtend as? [String : Any] {
            
            if let coverImage = extraExtend["harmonyImg"] as? String {
                var w = Double(self.frame.width);
                var h = ceil(w * 16.0/9.0)
                videoImageView.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
                videoImageView.ykn_setImage(withURLString: coverImage ?? "",
                                            module: "home",
                                            imageSize: CGSize.zero,
                                            parameters: nil,
                                            completed: nil)
            }
            
            dayLabel.text = extraExtend["day"] as? String
            if let m = extraExtend["month"] as? String,
               let month = ((Int(m) ?? 0) - 1) as? Int,
               month < monthArray.count,
               month >= 0,
               let year = extraExtend["year"] as? String {
                monthLabel.text = monthArray[month] + " \(year)"
            }
            
            t1Label.text = extraExtend["anniversary"] as? String
            t2Label.text = extraExtend["desc"] as? String
            t3Label.text = extraExtend["title"] as? String
        }
        
        Service.action.bind(itemModel.action, playImageView, .Defalut)
        
        weak var weakSelf = self
        videoImageView.whenTapped  {
            weakSelf?.showCalendarWindow()
        }
        
        self.relayoutSubviews(layout)
    }
    
    func relayoutSubviews(_ layout: OneArchSupport4Youku.LayoutModel) {
        videoImageView.frame = self.bounds
        
        dayLabel.frame = CGRect.init(x: 12, y: 12, width: 40, height: 29)
        monthLabel.frame = CGRect.init(x: 12, y: dayLabel.bottom, width: 60, height: 13)
        
        if let t1Layout = layout.extendExtra?["t1"] as? TextLayoutModel {
            t1Label.frame = t1Layout.renderRect
        } else {
            t1Label.frame = .zero
        }
        
        if let t2Layout = layout.extendExtra?["t2"] as? TextLayoutModel {
            t2Label.frame = t2Layout.renderRect
        } else {
            t2Label.frame = .zero
        }
        
        if let t3Layout = layout.extendExtra?["t3"] as? TextLayoutModel {
            t3Label.frame = t3Layout.renderRect
        } else {
            t3Label.frame = .zero
        }
        
        playImageView.frame = CGRect.init(x: 0, y: 0, width: 30, height: 30)
        playImageView.right = self.width - 9
        playImageView.bottom = self.height - 9
    }
    
    func showCalendarWindow() {
        if let attachModel = self.model?.homeModel?.extraExtend?["attachModel"] as? YKSCCalendarHeaderAttachmentModel {
            let calVc = YKCCalCardViewController.init()
            calVc.attachmentModel = attachModel
            if let superViewController = self.model?.homeModel?.extraExtend?["superViewController"] as? UIViewController {
                calVc.superViewController = superViewController
            }
            calVc.animSize = CGSize.zero
            calVc.hideHistoryBtn = true

            // 计算动画位置
//            var animateCenter
//            if animateCenter == nil || animateCenter!.equalTo(CGPoint.zero) {
//                let screenSize = UIScreen.main.bounds.size
//                animateCenter = CGPoint.init(x: screenSize.width / 2, y: screenSize.height / 2)
//            }
//            var animateCenter = CGPoint.init(x: UIScreen.main.bounds.size.width / 2, y: UIScreen.main.bounds.size.height / 2)
//
//            if let animateCenter = animateCenter as ? CGPoint{
//            }
            let screenSize = UIScreen.main.bounds.size
            calVc.animCenter = CGPoint.init(x: screenSize.width/2.0, y: screenSize.height/2.0)

            calVc.show()
        }
    }
    
    static func t1LabelFont() -> UIFont {
        return YKNFont.posteritem_auxiliary_text()
    }
    
    static func t2LabelFont() -> UIFont {
        return YKNFont.content_text()
    }
    
    static func t3LabelFont() -> UIFont {
        return t1LabelFont()
    }
    
}
