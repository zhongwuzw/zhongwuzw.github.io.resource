//
//  CompPlugin14194Adaptor.swift
//  YKChannelComponent
//
//  Created by CC on 2022/2/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKSCBase
import YKSCConst
import YoukuResource
import YKChannel

@objcMembers
class CompPlugin14194Adaptor: YKSCComponentPlugin {
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCComponentEventParseData,
                "selector":     "receiveParseData:",
            ],
            [
                "event":        YKSCComponentEventUpdateLayoutCacheBefore,
                "selector":     "receiveUpdateLayoutCacheBeforeEvent:",
            ],
        ]
    }
    
    func receiveParseData(_ event: YKSCEvent) {
        scSetData(NSNumber(value: Double(9.0)), forKey: YKSCComponentDataLayoutRowSpacing)
        scSetData(NSNumber(value: Double(YKNGap.youku_margin_left())), forKey: YKSCComponentDataLayoutPaddingLeft)
        scSetData(NSNumber(value: Double(YKNGap.youku_margin_right())), forKey: YKSCComponentDataLayoutPaddingRight)
        scSetData(NSNumber(value: Double(YKNGap.youku_column_spacing())), forKey: YKSCComponentDataLayoutColumnSpacing)
        
        scSetData(NSNumber(2), forKey: YKSCComponentDataLayoutColumnCount)

        guard let scComponentContext = scComponentContext,
              let compInfo = event.params?["componentInfo"] as? [String: Any],
              let dataInfo = compInfo["data"] as? [String: Any]
        else {
            return
        }
    }
    
    func receiveUpdateLayoutCacheBeforeEvent(_ event: YKSCEvent) {
        scSetData(NSNumber(value: Double(9.0)), forKey: YKSCComponentDataLayoutRowSpacing)
    }
}
