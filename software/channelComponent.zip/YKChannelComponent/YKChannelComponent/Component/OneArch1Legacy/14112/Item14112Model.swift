//
//  Item14112Model.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/2/24.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YoukuResource

struct Item14112Const {
    struct Data {
        static let Model = "yksc.data.item.14112.dataModel"
    }
    
    struct Event {
    }
}

class Item14112Model: NSObject {
    var title = ""
    var subtitle = ""
    var imageURLString = ""
    var recommendTagTitle = ""
    var recommendTagTitleColor = UIColor.ykn_brandInfo
    var uiCache = Item14112UICache()
    
    init(v2Json: [String: Any]) {
        title = v2Json["title"] as? String ?? ""
        
        if let uploaderInfo = v2Json["uploader"] as? [String: Any],
           let uploaderName = uploaderInfo["name"] as? String
        {
            subtitle = uploaderName
        }
        
        imageURLString = v2Json["img"] as? String ?? ""
        
        if let recommendTagInfo = v2Json["recommendTag"] as? [String: Any] {
            if let title = recommendTagInfo["title"] as? String {
                recommendTagTitle = title
            }
            
            if let titleColorString = recommendTagInfo["color"] as? String,
               let titleColor = UIColor.wvColor(withHexString: titleColorString)
            {
                recommendTagTitleColor = titleColor
            }
        }
    }
}

class Item14112UICache: NSObject {
    var textWidth: Double = 0
    var titleNumberOfLine: Int = 0
    var attributedTitle = NSAttributedString()
    
    func makeAttributedText(text: String, color: UIColor? = .ykn_primaryInfo, firstLineHeadIndent: Double) -> NSAttributedString {
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.lineSpacing = 3
        paragraphStyle.firstLineHeadIndent = CGFloat(firstLineHeadIndent)
        paragraphStyle.lineBreakMode = .byTruncatingTail
        
        var attributes = [NSAttributedString.Key: Any]()
        attributes[.font] = YKNFont.posteritem_maintitle()
        attributes[.paragraphStyle] = paragraphStyle
        attributes[.foregroundColor] = color
        
        return NSAttributedString(string: text, attributes: attributes)
    }
    
    func calcFitTextSize(text: String, font: UIFont, limit: CGSize) -> CGSize {
        var fitSize = NSString(string: text).boundingRect(with: limit,
                                                          options: [.usesLineFragmentOrigin, .truncatesLastVisibleLine],
                                                          attributes: [.font: font],
                                                          context: nil).size
        fitSize = CGSize(width: ceil(fitSize.width), height: ceil(fitSize.height))
        return fitSize
    }
    
    func resetCache(_ textWidthLimit: Double, firstLineHeadIndent: Double, title: String, tagText: String?, tagTextColor: UIColor?) {
        if textWidth == textWidthLimit {
            return
        }
        
        guard title.isEmpty == false else {
            return
        }
        
        // 文本宽度限制
        textWidth = textWidthLimit
        
        // 总富文本声明
        let attributedString = NSMutableAttributedString()
        
        // 富文本标签
        if let nnTagText = tagText,
           let nnTagColor = tagTextColor
        {
            let dot = "·"
            let attributedTagText = makeAttributedText(text: nnTagText + dot,
                                                       color: nnTagColor,
                                                       firstLineHeadIndent: firstLineHeadIndent)
            attributedString.append(attributedTagText)
        }
        
        // 富文本主标题
        let attributedTitle = makeAttributedText(text: title,
                                                 firstLineHeadIndent: firstLineHeadIndent)
        attributedString.append(attributedTitle)
        
        self.attributedTitle = attributedString
        
        // 行数计算
        let fitTextSize = calcFitTextSize(text: attributedString.string, font: YKNFont.posteritem_maintitle(), limit: CGSize(width: 1000, height: 30))
        let width = firstLineHeadIndent + Double(fitTextSize.width)
        let numberOfLine = min(2,Int(ceil(width / textWidthLimit)))
        titleNumberOfLine = numberOfLine
    }
}
