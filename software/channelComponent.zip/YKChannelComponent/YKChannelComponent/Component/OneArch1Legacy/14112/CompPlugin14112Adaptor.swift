//
//  CompPlugin14112Adaptor.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/2/24.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YoukuResource

@objcMembers
class CompPlugin14112Adaptor: YKSCComponentPlugin {
    
    
    //MARK:事件映射定义
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCComponentEventParseData,
                "selector":     "receiveParseDataWithEvent:",
            ],
        ]
    }
    
    func receiveParseData(event: YKSCEvent) {
        scSetData(1, forKey: YKSCComponentDataLayoutColumnCount)
        scSetData(NSNumber(value: Double(YKNGap.youku_margin_left())), forKey: YKSCComponentDataLayoutPaddingLeft)
        scSetData(NSNumber(value: Double(YKNGap.youku_margin_right())), forKey: YKSCComponentDataLayoutPaddingRight)
    }
}
