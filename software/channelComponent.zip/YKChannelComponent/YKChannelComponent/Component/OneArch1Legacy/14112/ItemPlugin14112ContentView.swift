//
//  ItemPlugin14112ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/2/24.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YoukuResource
import YKNodePage
import YKChannel

class ItemPlugin14112ContentView: AccessibilityView {
    
    //MARK: - Property
    lazy var posterImageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFill
        imageView.layer.cornerRadius = YKNCorner.radius_medium()
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    lazy var rankLabel: YKNPRankView = {
        let label = YKNPRankView()
        return label
    }()
    
    lazy var titleLabel: MarginLabel = {
        let label = MarginLabel()
        label.font = YKNFont.posteritem_maintitle()
        label.textAlignment = .left
        label.verticalAlignment = .top
        label.textColor = .ykn_primaryInfo
        label.numberOfLines = 2
        label.lineBreakMode = .byTruncatingTail
        return label
    }()
    
    lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .ykn_tertiaryInfo
        label.font = YKNFont.tertiary_auxiliary_text()
        label.textAlignment = .left
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var popularityView: YKNPPopularityView = {
        let view = YKNPPopularityView()
        view.titleLabel.font = YKNFont.tertiary_auxiliary_text()
        view.titleLabel.textColor = .ykn_brandInfo
        view.isV2 = true
        return view
    }()

    //MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        createSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        createSubviews()
    }
    
    //MARK: -
    func createSubviews() {
        addSubview(posterImageView)
        addSubview(rankLabel)
        addSubview(titleLabel)
        addSubview(subtitleLabel)
        addSubview(popularityView)
        
        let scale = YKNSize.yk_icon_size_scale()
        posterImageView.frame = CGRect(x: 0, y: 0, width: 144.0 * scale, height: 80.0 * scale)
    }
    
    func fillItemContext(itemContext: YKSCItemContext) {
        guard let model = itemContext.scData(forKey: Item14112Const.Data.Model) as? Item14112Model else {
            return
        }
        
        posterImageView.ykn_setImage(withURLString: model.imageURLString,
                                     module: "nodepage",
                                     imageSize: .zero,
                                     parameters: ["fade":true],
                                     completed: nil)
        
        let textLeft = posterImageView.right + YKNGap.dim_6()
        let textWidth = width - textLeft
        
        // 排行标记
        rankLabel.reuse(with: itemContext)
        let rankWidth = rankLabel.bounds.size.width
        let rankHeight = rankLabel.bounds.size.height
        rankLabel.frame = CGRect(x: textLeft, y: 2, width: rankWidth, height: rankHeight)
        
        model.uiCache.resetCache(Double(textWidth),
                                 firstLineHeadIndent: rankWidth > 0 ? Double(rankWidth + 3) : 0,
                                 title: model.title,
                                 tagText: model.recommendTagTitle.isEmpty ? nil : model.recommendTagTitle,
                                 tagTextColor: model.recommendTagTitle.isEmpty ? nil : model.recommendTagTitleColor)
        
        // 主标题
        let titleX = textLeft
        let titleY = rankLabel.top
        let titleWidth = textWidth
        var titleHeight = YKNFont.height(with: titleLabel.font, lineNumber: model.uiCache.titleNumberOfLine)
        if model.uiCache.titleNumberOfLine >= 2 {
            titleHeight += 6
        }
        titleLabel.frame = CGRect(x: titleX, y: titleY, width: titleWidth, height: titleHeight)
        titleLabel.attributedText = model.uiCache.attributedTitle
        
        var secondTextY = YKNFont.height(with: titleLabel.font, lineNumber: model.uiCache.titleNumberOfLine)
        if model.uiCache.titleNumberOfLine >= 2 {
            secondTextY += 13
        } else {
            secondTextY += 9
        }
        var subtitleX = textLeft
        var subtitleWidth = textWidth
        let subtitleHeight = YKNFont.height(with: subtitleLabel.font, lineNumber: 1)
        
        // 热度
        if let popularityInfo = itemContext.scData(forKey: YKSCItemDataPopularity) as? [String: Any],
           let popularityText = popularityInfo["text"] as? String,
           popularityText.isEmpty == false
        {
            let popularityFitSize = popularityView.calcFitSizeModel(popularityInfo, font: YKNFont.tertiary_auxiliary_text())
            popularityView.frame = CGRect(x: textLeft,
                                          y: secondTextY,
                                          width: popularityFitSize.width,
                                          height: YKNFont.height(with: YKNFont.tertiary_auxiliary_text(), lineNumber: 1))
            popularityView.reuse(with: itemContext)
            popularityView.isHidden = false
            
            subtitleX = popularityView.frame.maxX + 6
            subtitleWidth = textWidth - (subtitleX - textLeft)
        } else {
            popularityView.isHidden = true
        }
        
        // 副标题
        subtitleLabel.text = model.subtitle
        subtitleLabel.frame = CGRect(x: subtitleX, y: secondTextY, width: subtitleWidth, height: subtitleHeight)
        
        // 绑定坑位数据
        var params = [String: Any]()
        params["view"] = self
        params["tag"] = "root"
        params["action"] = "tap"
        itemContext.scFireEvent(YKSCItemEventBindItemView, params: params)
        
        // 绑定角标数据,摘要数据
        params = [String: Any]()
        params["view"] = posterImageView
        params["tag"] = "imageView"
        itemContext.scFireEvent(YKSCItemEventBindItemView, params: params)
    }
}
