//
//  ItemPlugin14112.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/2/24.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YKChannel
import YKNodePage
import YoukuResource

@objcMembers
class ItemPlugin14112: YKSCItemPlugin {
    
    //MARK:事件映射定义
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventParseData,
                "selector":     "receiveParseDataWithEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemCount,
                "selector":     "receiveQueryItemCountWithEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemHeight,
                "selector":     "receiveQueryItemHeightWithEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemReuseId,
                "selector":     "receiveQueryItemReuseIdWithEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemView,
                "selector":     "receiveQueryItemViewWithEvent:",
            ],
            [
                "event":        YKSCItemEventReuseItemView,
                "selector":     "receiveReuseItemViewWithEvent:",
            ],
        ]
    }
    
    func receiveParseData(event:YKSCEvent) {
        guard let itemInfo = event.params?.scDictionary(forKey: "itemInfo") as? Dictionary<String, Any> else { return }
        guard let itemData = itemInfo["data"] as? Dictionary<String, Any> else { return }
        guard let scItemContext = scItemContext else { return }
        
        // 摘要评分
        scFireEvent(YKSCItemEventParseSummary, params: ["itemInfo": itemData,
                                                        "viewTag": "imageView",])
        
        // 排行角标
        scFireEvent(YKSCItemEventParseRank, params: ["itemInfo": itemData,
                                                     "viewTag": "posterImageView",])
        
        let rvm = YKNPRankViewModel(itemContext: scItemContext)
        scSetData(rvm, forKey: YKSCItemDataNPRankViewModel)
        if let rankInfo = itemData["rankInfo"] as? [String: Any] {
            scSetData(rankInfo, forKey: YKSCItemDataNPRankInfo)
        }
        
        if let popularityInfo = itemData["popularity"] as? [String: Any] {
            scSetData(popularityInfo, forKey: YKSCItemDataPopularity)
        }
        
        let model = Item14112Model(v2Json: itemData)
        scSetData(model, forKey: Item14112Const.Data.Model)
    }
    
    func receiveQueryItemCount(event:YKSCEvent) {
        event.responseInfo.setValue(1, forKey: "itemCount")
    }
    
    func receiveQueryItemHeight(event:YKSCEvent) {
        event.responseInfo.setValue(80 * YKNSize.yk_icon_size_scale(), forKeyPath: "itemHeight")
    }
    
    func receiveQueryItemReuseId(event:YKSCEvent) {
        event.responseInfo.setValue(String(describing: ItemPlugin14112.self), forKey: "reuseId")
    }
    
    func receiveQueryItemView(event:YKSCEvent) {
        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let itemHeight: Double = (event.params?["itemHeight"] as? NSNumber)?.doubleValue ?? 0
        let itemView = ItemPlugin14112ContentView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        event.responseInfo.setValue(itemView, forKeyPath: "itemView")
    }
    
    func receiveReuseItemView(event:YKSCEvent) {
        guard let itemView = event.params?["itemView"] as? ItemPlugin14112ContentView else {
            return
        }
        
        guard let scItemContext = scItemContext else {
            return
        }
        
        itemView.fillItemContext(itemContext: scItemContext)
    }
}
