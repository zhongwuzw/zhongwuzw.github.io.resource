//
//  ItemPlugin14112SceneAdaptor.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/2/24.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YKSCScene

@objcMembers
class ItemPlugin14112SceneAdaptor: YKSCItemPlugin {
    
    //MARK:事件映射定义
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventInit,
                "selector":     "receiveItemInitWithEvent:",
                "priority":     400,
            ],
            [
                "event":        YKSCItemEventReuseItemView,
                "selector":     "receiveReuseItemViewWithEvent:",
                "priority":     400,
            ],
        ]
    }
    
    func receiveItemInit(event: YKSCEvent) {
        scFireEvent(YKSCItemEventSceneTagParse, params: ["tag":"title",
                                                         "sceneTag":"YKSCSceneDataTitle"])
    }
    
    func receiveReuseItemView(event: YKSCEvent) {
        guard let itemView = event.params?["itemView"] as? ItemPlugin14112ContentView else {
            return
        }
        
        var params = [String: Any]()
        params["view"] = itemView
        params["tag"] = "title"
        scFireEvent(YKSCItemEventBindItemView, params: params)
    }
}
