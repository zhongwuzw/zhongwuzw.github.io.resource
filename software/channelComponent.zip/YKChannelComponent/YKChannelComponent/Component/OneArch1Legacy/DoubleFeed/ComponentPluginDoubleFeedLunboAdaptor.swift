//
//  ComponentPluginDoubleFeedLunboAdaptor.swift
//  YKChannelComponent
//
//  Created by 黄少华 on 2020/12/21.
//  Copyright © 2020 Youku. All rights reserved.
//

//import Foundation
//import YKSCBase
//import YKSCConst
//import YKSCiPhoneService
//
//@objcMembers
//class ComponentPluginDoubleFeedLunboAdaptor: YKSCComponentPlugin {
//
//    var images = [String]()
//    var lunboView : ComponentDoubleFeedLunboView?
//
//    //MARK:事件映射定义
//    override class func scEventHandlerInfo() -> [Any]! {
//        return [
//            [
//                "event":        YKSCComponentEventParseData,
//                "selector":     "receiveComponentEventParseDataWithEvent:",
//            ],
//            [
//                "event":        YKSCComponentEventQueryItemView,
//                "selector":     "receiveContainerQueryItemViewEventWithEvent:",
//                "priority":     250
//            ],
//            [
//                "event":        YKSCComponentEventQueryItemReuseId,
//                "selector":     "receiveComponentEventQueryItemReuseIdWithEvent:",
//                "priority":     250
//            ],
//            [
//                "event":        YKSCComponentEventReuseItemView,
//                "selector":     "receiveComponentEventReuseItemViewWithEvent:",
//                "priority":     250
//            ],
//            [
//                "event":        YKSCComponentEventItemEnterDisplayArea,
//                "selector":     "receiveComponentEventItemEnterDisplayAreaWithEvent:",
//                "priority":     250
//            ],
//            [
//                "event":        YKSCComponentEventItemExitDisplayArea,
//                "selector":     "receiveComponentEventItemExitDisplayAreaWithEvent:",
//                "priority":     250
//            ],
//        ]
//    }
//
//    func receiveComponentEventParseData(event:YKSCEvent) {
//        guard let scComponentContext = scComponentContext else {
//            return
//        }
//
//        guard let itemsInfo = event.params?.scArray(forKey: "itemsInfo") as? Array<Dictionary<String, Any>> else { return }
//        guard let itemData = itemsInfo.first?["data"] as? Dictionary<String, Any> else { return }
//
//        if let imgs = itemData["imgs"] as? [String] {
//            images = imgs
//            scComponentContext.scSetData("hidden", forKey: "yksc.data.comp.videoImageDisplayFlag")
//        }else{
//            images.removeAll()
//            scComponentContext.scSetData("show", forKey: "yksc.data.comp.videoImageDisplayFlag")
//        }
//    }
//
//    func receiveComponentEventQueryItemReuseId(event:YKSCEvent) {
//        if images.count > 0 {
//            if let reuseId = event.responseInfo["reuseId"] as? String {
//                let reuseID = reuseId + "_mutable_images"
//                event.responseInfo.setValue(reuseID, forKey: "reuseId")
//            }
//        }
//    }
//
//    func receiveContainerQueryItemViewEvent(event:YKSCEvent) {
//        if images.count > 0 {
//            if let itemView = event.responseInfo["itemView"] as? UIView{
//                if let view = itemView.viewWithTag(12060) {
//                    let _lunboView = ComponentDoubleFeedLunboView.init(frame: CGRect.zero)
//                    _lunboView.tag = 1206099
//                    view.insertSubview(_lunboView, at: 0)
//                }
//            }
//        }
//    }
//
//    func receiveComponentEventReuseItemView(event:YKSCEvent) {
//        if let itemView = event.params?["itemView"] as? UIView {
//            if images.count > 0 {
//                if let view = itemView.viewWithTag(12060) {
//                    if let _lunboView = view.viewWithTag(1206099) as? ComponentDoubleFeedLunboView{
//                        _lunboView.frame = view.bounds
//                        _lunboView.setImages(images: images)
//                        _lunboView.isHidden = false
//                        lunboView = _lunboView
//                    }else{
//                        lunboView?.isHidden = true
//                    }
//                }
//            }else{
//                lunboView?.isHidden = true
//            }
//        }
//    }
//
//    func receiveComponentEventItemEnterDisplayArea(event:YKSCEvent) {
//        guard let scComponentContext = scComponentContext else {
//            return
//        }
//
//        var interval = scComponentContext.scConfigInteger(forKey: "scrollInterval")
//        if interval == 0 {
//            interval = 2
//        }
//        lunboView?.startTimer(interval: interval)
//    }
//
//    func receiveComponentEventItemExitDisplayArea(event:YKSCEvent) {
//        lunboView?.endTimer()
//    }
//}
