//
//  ComponentDoubleFeedLunboView.swift
//  YKChannelComponent
//
//  Created by 黄少华 on 2020/12/22.
//  Copyright © 2020 Youku. All rights reserved.
//

import Foundation
import UIKit

class ComponentDoubleFeedLunboView: UIView, UICollectionViewDelegate,UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    var collectionView :UICollectionView?
    var images:[String] = [String]()
    var timer :Timer?
    var flowLayout : UICollectionViewFlowLayout?
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        collectionView?.frame = bounds
    }
    
    func setupSubviews() {
        let collectionViewLayout = UICollectionViewFlowLayout.init()
        collectionViewLayout.scrollDirection = UICollectionView.ScrollDirection.horizontal
        collectionViewLayout.minimumLineSpacing = 0
        collectionViewLayout.minimumInteritemSpacing = 0
        flowLayout = collectionViewLayout
        let _collectionView = UICollectionView.init(frame: bounds, collectionViewLayout: collectionViewLayout)
        collectionView = _collectionView
        addSubview(_collectionView)
        _collectionView.isPagingEnabled = true
        _collectionView.isUserInteractionEnabled = false
        _collectionView.delegate = self
        _collectionView.dataSource = self
        _collectionView.showsHorizontalScrollIndicator = false
        _collectionView.register(ComponentDoubleFeedLunboCell.self, forCellWithReuseIdentifier: "cell")
    }

    public func setImages(images: [String]) {
        self.images = images
        if images.count > 1 {
            collectionView?.isScrollEnabled = true
        }else{
            collectionView?.isScrollEnabled = false
        }
        collectionView?.reloadData()
        if images.count > 1 {
            collectionView?.scrollToItem(at: IndexPath.init(item: 1, section: 0), at: UICollectionView.ScrollPosition.centeredVertically, animated: false)
        }
    }

    //开启自动滚动
    func startTimer(interval: Int) {
        timer?.invalidate()
        timer = nil

        let _timer = Timer.scheduledTimer(timeInterval: TimeInterval(interval), target: self, selector: #selector(handleScroll), userInfo: nil, repeats: true)
        RunLoop.current.add(_timer, forMode: RunLoop.Mode.common)
        timer = _timer
    }

    //离开屏幕停止滚动
    func endTimer() {
        timer?.invalidate()
        timer = nil
    }

    @objc func handleScroll() {
        if images.count == 0 {
            return
        }
        let index = currentIndex()
        let targetIndex = index + 1
        collectionView?.scrollToItem(at: IndexPath.init(item: targetIndex, section: 0), at: UICollectionView.ScrollPosition.init(), animated: true)
    }

    //MARK: UICollectionViewDelegate UICollectionViewDataSource
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return images.count + 2
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath)
        if let _cell = cell as? ComponentDoubleFeedLunboCell {
            let index = dataSourceIndex(for: indexPath.item)
            if index >= 0 && index < images.count {
                if let image = images[index] as? String {
                    _cell.setImage(image: image)
                }
            }
        }
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return bounds.size
    }

    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        let index = currentIndex()
        if index == 0 {
            collectionView?.scrollToItem(at: IndexPath.init(item: images.count, section: 0), at: UICollectionView.ScrollPosition.init(), animated: false)
        }else if index == images.count + 1{
            collectionView?.scrollToItem(at: IndexPath.init(item: 1, section: 0), at: UICollectionView.ScrollPosition.init(), animated: false)
        }
    }

    func currentIndex() -> Int {
        var index = 0
        let itemSize = bounds.size
        if __CGSizeEqualToSize(itemSize, CGSize.zero) == false {
            index = Int(collectionView?.contentOffset.x ?? 0 + itemSize.width * 0.5) / Int(itemSize.width)
            return max(0, index)
        }
        return index
    }

    func dataSourceIndex(for index: Int) -> Int {
        var dataIndex = 0
        if index == 0 {
            dataIndex = images.count - 1
        }else if index == images.count + 1 {
            dataIndex = 0
        }else{
            dataIndex = index - 1
        }
        return dataIndex
    }
}
