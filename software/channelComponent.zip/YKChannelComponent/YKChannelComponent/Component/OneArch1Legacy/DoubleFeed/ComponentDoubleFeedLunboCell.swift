//
//  ComponentDoubleFeedLunboCell.swift
//  YKChannelComponent
//
//  Created by 黄少华 on 2020/12/22.
//  Copyright © 2020 Youku. All rights reserved.
//

import Foundation
import UIKit
import SDWebImage

class ComponentDoubleFeedLunboCell: UICollectionViewCell {

    var imageView :UIImageGIFView?
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }

    func setupSubviews() {
        let _imageView = UIImageGIFView.init(frame: bounds)
        _imageView.contentMode = UIView.ContentMode.scaleAspectFill
        addSubview(_imageView)
        imageView = _imageView

        clipsToBounds = true
    }

    public func setImage(image:String) {
        let url = URL.init(string: image)
        imageView?.sd_setImage(with: url)
    }
}
