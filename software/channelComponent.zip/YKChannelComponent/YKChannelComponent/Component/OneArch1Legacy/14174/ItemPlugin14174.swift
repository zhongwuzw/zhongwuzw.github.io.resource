//
//  ItemPlugin14174.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/2/22.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YKSCConst
import DYKIOSCategory

@objcMembers
class ItemPlugin14174: YKSCItemPlugin {
    
    
    //MARK:事件映射定义
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventParseData,
                "selector":     "receiveParseDataWithEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemCount,
                "selector":     "receiveQueryItemCountWithEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemHeight,
                "selector":     "receiveQueryItemHeightWithEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemReuseId,
                "selector":     "receiveQueryItemReuseIdWithEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemView,
                "selector":     "receiveQueryItemViewWithEvent:",
            ],
            [
                "event":        YKSCItemEventReuseItemView,
                "selector":     "receiveReuseItemViewWithEvent:",
            ],
        ]
    }
    
    func receiveParseData(event:YKSCEvent) {
        guard let itemInfo = event.params?.scDictionary(forKey: "itemInfo") as? Dictionary<String, Any> else { return }
        guard let itemData = itemInfo["data"] as? Dictionary<String, Any> else { return }
        
        let model = Item14174Model(v2Json: itemData)
        scSetData(model, forKey: Item14174Const.Data.Model)
    }
    
    func receiveQueryItemCount(event:YKSCEvent) {
        event.responseInfo.setValue(NSNumber(1), forKey: "itemCount")
    }
    
    func receiveQueryItemHeight(event:YKSCEvent) {
        let itemHeight = Double(backgroundImageSize().height)
        event.responseInfo.setValue(NSNumber(value: itemHeight), forKeyPath: "itemHeight")
    }
    
    func receiveQueryItemReuseId(event:YKSCEvent) {
        guard let model = scData(forKey: Item14174Const.Data.Model) as? Item14174Model else {
            return
        }
        
        var reuseId = "ItemPlugin14174"
        if model.isBottomRoundCorner {
            reuseId = reuseId + "_BottomRoundCorner"
        }
        event.responseInfo.setValue(reuseId, forKey: "reuseId")
    }
    
    func receiveQueryItemView(event:YKSCEvent) {
        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let itemHeight: Double = (event.params?["itemHeight"] as? NSNumber)?.doubleValue ?? 0
        let itemView = ItemPlugin14174ContentView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        event.responseInfo.setValue(itemView, forKeyPath: "itemView")
    }
    
    func receiveReuseItemView(event:YKSCEvent) {
        guard let itemView = event.params?["itemView"] as? ItemPlugin14174ContentView else {
            return
        }
        
        guard let scItemContext = scItemContext else {
            return
        }
        
        itemView.fillItemContext(itemContext: scItemContext)
        
        //埋点
        var params = [String: Any]()
        params["view"] = itemView
        params["tag"] = "root"
        scFireEvent(YKSCItemEventBindItemView, params: params)
    }
    
    func backgroundImageSize() -> CGSize {
        guard let model = scData(forKey: Item14174Const.Data.Model) as? Item14174Model else {
            return CGSize.zero
        }

        var itemHeight: CGFloat = 146
        let statusbarOffset: CGFloat = STATUSBAR_HEIGHT - 20
        if statusbarOffset > 0 {
            itemHeight += statusbarOffset
        }
        if model.isBottomRoundCorner {
            itemHeight += kBottomRoundSpacingHeight
        }
        return CGSize(width: YKRLScreenWidth(), height: itemHeight)
    }
}
