//
//  ItemPlugin14174ImmersionBackgroundAdaptor.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/2/22.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YKSCConst
import YKNodePage

@objcMembers
class ItemPlugin14174ImmersionBackgroundAdaptor: YKSCItemPlugin {
    
    weak var displayingItemView: ItemPlugin14174ContentView? = nil
    
    
    //MARK:事件映射定义
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventItemEnterDisplayArea,
                "selector":     "receiveItemEnterDisplayAreaWithEvent:",
            ],
            [
                "event":        YKSCItemEventItemExitDisplayArea,
                "selector":     "receiveItemExitDisplayAreaWithEvent:",
            ],
            [
                "event":        YKSCPageEventContainerDidScroll,
                "selector":     "receivePageContainerDidScrollWithEvent:",
            ],
        ]
    }
    
    func receiveItemEnterDisplayArea(event:YKSCEvent) {
        displayingItemView = event.params?["itemView"] as? ItemPlugin14174ContentView
    }
    
    func receiveItemExitDisplayArea(event:YKSCEvent) {
        displayingItemView = nil
    }
    
    func receivePageContainerDidScroll(event:YKSCEvent) {
        guard let itemView = displayingItemView else {
            return
        }
        
        let width: Double = scDouble(forKey: YKSCItemDataLayoutContentWidth)
        let height: Double = scDouble(forKey: YKSCItemDataLayoutContentHeight)
        let sizeValue = NSValue(cgSize: CGSize(width: width + 1, height: height))
        let imageView = itemView.imageView
        
        var params = [String: Any]()
        params["view"] = imageView
        params["originalSize"] = sizeValue
        scPageContext?.scFireEvent(YKSCPageEventNPRUpdateImmersionBackground, params: params)
    }
}
