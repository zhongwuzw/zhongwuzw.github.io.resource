//
//  ItemPlugin14174ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/2/22.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YoukuResource
import YKSCScene

class ItemPlugin14174ContentView: AccessibilityView {
    
    //MARK: - Property
    lazy var imageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    lazy var contentView: UIView = {
        return UIView()
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = YKNIconFont.sharedInstance().font(withSize: 30)
        return label
    }()
    
    lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.font = YKNFont.posteritem_subhead()
        label.textColor = YKNColor.cw_1().withAlphaComponent(0.8)
        return label
    }()
    
    lazy var imageTitleView:  UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFit
        imageView.clipsToBounds = true
        return imageView
    }()
    
    lazy var bottomRoundSpacing: UIView = {
        let view = UIView()
        
        let maskFrame = CGRect(x: 0, y: 0, width: width, height: 50)
        let maskPath = UIBezierPath(roundedRect: maskFrame, byRoundingCorners: [.topLeft, .topRight], cornerRadii: CGSize(width: 14,height: 14))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = maskFrame
        maskLayer.path = maskPath.cgPath
        view.layer.mask = maskLayer
        
        return view
    }()
    
    //MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        createSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        createSubviews()
    }
    
    //MARK: -
    func createSubviews() {
        addSubview(imageView)
        addSubview(contentView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(subtitleLabel)
        contentView.addSubview(imageTitleView)
        contentView.addSubview(bottomRoundSpacing)
        
        imageView.frame = bounds.insetBy(dx: -1, dy: 0)
        let statusBarOffset: CGFloat = YKStatusBarHeight() - 20
        contentView.frame = CGRect(x: 0, y: statusBarOffset, width: width, height: height - statusBarOffset)
    }

    func fillItemContext(itemContext: YKSCItemContext) {
        guard let model = itemContext.scData(forKey: Item14174Const.Data.Model) as? Item14174Model else {
            return
        }
        
        imageView.ykn_setImage(withURLString: model.backgroundImageURLString,
                               module: "nodepage",
                               imageSize: .zero,
                               parameters: ["fade":true],
                               completed: nil)
        titleLabel.text = model.title
        subtitleLabel.text = model.subtitle
        
        if !model.imageTitleURLString.isEmpty {
            imageTitleView.isHidden = false
        } else {
            imageTitleView.isHidden = true
        }
        
        layoutWithModel(model: model)
        
        if bottomRoundSpacing.isHidden == false {
            if let sceneInfo = itemContext.scPageContext?.scData(forKey: YKSCSceneDataPageSceneInfo) as? Dictionary<String, Any>,
               let aSceneItem = sceneInfo[YKSCSceneDataPage] as? Dictionary<String, Any>,
               let color = aSceneItem["color"] as? UIColor
            {
                bottomRoundSpacing.backgroundColor = color
            } else {
                bottomRoundSpacing.backgroundColor = .ykn_primaryBackground
            }
        }
    }
    
    func layoutWithModel(model: Item14174Model) {
        if model.isBottomRoundCorner {
            bottomRoundSpacing.isHidden = false
            bottomRoundSpacing.frame = CGRect(x: 0,
                                              y: contentView.height - kBottomRoundSpacingHeight,
                                              width: contentView.width,
                                              height: kBottomRoundSpacingHeight)
        } else {
            bottomRoundSpacing.isHidden = true
        }
        
        let textWidth: CGFloat = width - YKNGap.youku_margin_left() - YKNGap.youku_margin_right()
        
        let subtitleWidth: CGFloat = textWidth
        let subtitleHeight: CGFloat = YKNFont.height(with: subtitleLabel.font, lineNumber: 1)
        let subtitleX: CGFloat = YKNGap.youku_margin_left()
        var subtitleY: CGFloat = contentView.height - 18 - subtitleHeight
        if model.isBottomRoundCorner {
            subtitleY -= kBottomRoundSpacingHeight
        }
        subtitleLabel.frame = CGRect(x: subtitleX, y: subtitleY, width: subtitleWidth, height: subtitleHeight)
        
        let titleWidth: CGFloat = textWidth
        let titleHeight: CGFloat = YKNFont.height(with: titleLabel.font, lineNumber: 1)
        let titleX: CGFloat = YKNGap.youku_margin_left()
        let titleY: CGFloat = subtitleLabel.frame.minY - 6 - titleHeight
        titleLabel.frame = CGRect(x: titleX, y: titleY, width: titleWidth, height: titleHeight)
        
        if model.imageTitleURLString.isEmpty {
            titleLabel.isHidden = false
            imageTitleView.isHidden = true
        } else {
            titleLabel.isHidden = true
            imageTitleView.isHidden = false
            
            
            let imageRenderHeight: CGFloat = 30
            let imageY = subtitleY - 8 - imageRenderHeight
            var params = [String: Any]()
            params["fade"] = true
            params["placeholderColor"] = UIColor.clear
            imageTitleView.ykn_setImage(withURLString: model.imageTitleURLString,
                                        module: "nodepage",
                                        imageSize: .zero,
                                        parameters: params) { [weak self] (image, error, info) in
                guard let self = self else {return}
                guard let titleImage = image else {return}
                
                //先恢复正常
                self.imageTitleView.frame = CGRect(x:0, y:imageY, width:self.width, height:imageRenderHeight)
                //在往左平移
                let imageRenderWidth: CGFloat = titleImage.size.width/titleImage.size.height * imageRenderHeight;
                self.imageTitleView.left = YKNGap.margin_l() + (imageRenderWidth - self.width) * 0.5;
            }
        }
    }
}
