//
//  Item14174Model.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/2/22.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase

let kBottomRoundSpacingHeight: CGFloat = 14.0

struct Item14174Const {
    struct Data {
        static let Model = "yksc.data.item.14010.dataModel"
    }
    
    struct Event {
    }
}

class Item14174Model: NSObject {
    var title = ""
    var subtitle = ""
    var imageTitleURLString = ""
    var backgroundImageURLString = ""
    var isBottomRoundCorner = false
    
    init(v2Json: [String: Any]) {
        title = v2Json["title"] as? String ?? ""
        subtitle = v2Json["subtitle"] as? String ?? ""
        imageTitleURLString = v2Json["icon"] as? String ?? ""
        backgroundImageURLString = v2Json["img"] as? String ?? ""
        isBottomRoundCorner = v2Json["isBottomRoundCorner"] as? Bool ?? false
    }
}
