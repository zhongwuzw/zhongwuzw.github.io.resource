//
//  CompPLugin14045Adaptor.swift
//  YKChannelComponent
//
//  Created by wustlj on 2021/3/8.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import YKSCBase
import YoukuResource

@objcMembers
class CompPlugin14045Adaptor: YKSCComponentPlugin {
    
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCComponentEventParseData,
                "selector":     "receiveParseDataWithEvent:"
            ],
        ]
    }
    
    func receiveParseData(event: YKSCEvent) {
        let titleH: CGFloat = YKNFont.height(with: YKNFont.secondry_auxiliary_text(), lineNumber: 1)
        let imageH: CGFloat = 48 * YKNSize.yk_icon_size_scale()
        let padding: CGFloat = YKNGap.youku_picture_title_spacing();

        scSetData(ceil(Double(titleH + imageH + padding)), forKey: YKSCComponentDataLayoutPreferredRowHeight)
        scSetData(YKNGap.youku_margin_left(), forKey: YKSCComponentDataHorizontalInsetLeft)
        scSetData(YKNGap.youku_margin_right(), forKey: YKSCComponentDataHorizontalInsetRight)
        scSetData((21), forKey: YKSCComponentDataLayoutColumnSpacing)
        scSetData((0), forKey: YKSCComponentDataHorizontalInsetTop)
        scSetData((0), forKey: YKSCComponentDataHorizontalInsetBottom)
    }
}
