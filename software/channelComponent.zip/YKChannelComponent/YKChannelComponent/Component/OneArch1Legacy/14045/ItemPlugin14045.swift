//
//  ItemPlugin14045.swift
//  YKChannelComponent
//
//  Created by wustlj on 2021/3/8.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import YKSCBase
import YoukuResource

@objcMembers
class ItemPlugin14045: YKSCItemPlugin {
    
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventQueryItemCount,
                "selector":     "receiveQueryItemCountWithEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemWidth,
                "selector":     "receiveQueryItemWidthWithEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemHeight,
                "selector":     "receiveQueryItemHeightWithEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemView,
                "selector":     "receiveQueryItemViewWithEvent:",
            ],
            [
                "event":        YKSCItemEventReuseItemView,
                "selector":     "receiveReuseItemViewWithEvent:",
            ],
        ]
    }
    
    func receiveQueryItemCount(event: YKSCEvent) {
        event.responseInfo.setValue(1, forKey: "itemCount")
    }
    
    func receiveQueryItemWidth(event: YKSCEvent) {
        let w: CGFloat = 48 * YKNSize.yk_icon_size_scale();
        event.responseInfo.setValue(Double(w), forKey: "itemWidth")
    }
    
    func receiveQueryItemHeight(event: YKSCEvent) {
        let titleH: CGFloat = YKNFont.height(with: YKNFont.secondry_auxiliary_text(), lineNumber: 1)
        let imageH: CGFloat = 48 * YKNSize.yk_icon_size_scale()
        let padding: CGFloat = YKNGap.youku_picture_title_spacing();

        event.responseInfo.setValue(ceil(Double(titleH + imageH + padding)), forKey: "itemHeight")
    }
        
    func receiveQueryItemView(event: YKSCEvent) {
        let itemWidth = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let itemHeight = (event.params?["itemHeight"] as? NSNumber)?.doubleValue ?? 0
        
        let itemView = ItemPlugin14045ContentView.init(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        event.responseInfo.setValue(itemView, forKey: "itemView")
    }
    
    func receiveReuseItemView(event: YKSCEvent) {
        guard let itemView = event.params?["itemView"] as? ItemPlugin14045ContentView else {
            return
        }
        
        guard let scItemContext = scItemContext else {
            return
        }
        
        itemView.fillItemContext(itemContext: scItemContext)
        
        var params = [String: Any]()
        params["view"] = itemView
        params["tag"] = "root"
        params["action"] = "tap"
        scFireEvent(YKSCItemEventBindItemView, params: params)
    }
}
