//
//  ItemPlugin14045ContentView.swift
//  YKChannelComponent
//
//  Created by wustlj on 2021/3/8.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YoukuResource
import YKSCBase
import OneArchSupport4Youku

class ItemPlugin14045ContentView: AccessibilityView {
    
    //MARK: - Property
    lazy var videoImageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .ykn_primaryFill
        imageView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        imageView.layer.masksToBounds = true
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
        
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = YKNFont.posteritem_subhead()
        label.textAlignment = .center
        label.textColor = .ykn_primaryInfo
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        label.isUserInteractionEnabled = true
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        self.addSubview(videoImageView)
        self.addSubview(titleLabel)
        
        let scale = YKNSize.yk_icon_size_scale()
        videoImageView.frame = CGRect(x: 0, y: 0, width: 48 * scale, height: 48 * scale)
        
        let titleH: CGFloat = YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)
        let padding: CGFloat = YKNGap.youku_picture_title_spacing();
        let titleOffset: CGFloat = 5
        let titleWidth: CGFloat = videoImageView.width + 2 * titleOffset
        titleLabel.frame = CGRect(x: -titleOffset, y: videoImageView.bottom + padding, width: titleWidth, height: titleH)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
    }
    
    func fillItemContext(itemContext: YKSCItemContext) {
        let title = itemContext.scString(forKey: YKSCItemDataTitle)
        let imgPath = itemContext.scString(forKey: YKSCItemDataImagePath)
        
        titleLabel.text = title;
        
        videoImageView.ykn_setImage(withURLString: imgPath,
                                    module: "nodepage",
                                    imageSize: .zero,
                                    parameters: [String: Any](),
                                    completed: nil)
    }
    
    func fillItemModel(itemModel: BaseItemModel) {
        let title = itemModel.title
        var imgPath = itemModel.gifImg
        if imgPath == nil {
            imgPath = itemModel.img
        }
        
        titleLabel.text = title
        
        videoImageView.ykn_setImage(withURLString: imgPath,
                                    module: "nodepage",
                                    imageSize: .zero,
                                    parameters: [String: Any](),
                                    completed: nil)
    }
}
