//
//  CompPlugin14179Adaptor.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/7/5.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YKSCConst
import YoukuResource

@objcMembers
class CompPlugin14179Adaptor: YKSCComponentPlugin {
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCComponentEventParseData,
                "selector":     "receiveParseDataEvent:",
            ],
        ]
    }
    
    func receiveParseDataEvent(_ event: YKSCEvent) {
        scSetData(NSNumber(value: Double(YKNGap.youku_margin_left())), forKey: YKSCComponentDataLayoutPaddingLeft)
        scSetData(NSNumber(value: Double(YKNGap.youku_margin_right())), forKey: YKSCComponentDataLayoutPaddingRight)
    }
}
