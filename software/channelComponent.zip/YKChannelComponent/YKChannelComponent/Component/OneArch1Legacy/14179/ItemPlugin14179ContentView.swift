//
//  ItemPlugin14179ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/7/5.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YKChannelBase
import YoukuResource

class ItemPlugin14179ContentView: AccessibilityView {
    
    lazy var contentView: UIView = {
        let view = UIView()
        return view
    }()

    lazy var imageView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.isUserInteractionEnabled = false
        view.clipsToBounds = true
        
        let image = UIImage.init(named: "ykn_error_empty_s")
        if #available(iOS 12.0, *) {
            if let darkImage = UIImage.init(named: "ykn_error_empty_s_dark") {
                image?.imageAsset?.register(darkImage, with: .init(userInterfaceStyle: .dark))
            }
        }
        view.image = image
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_tertiaryInfo
        view.font = YKNFont.posteritem_maintitle()
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        self.backgroundColor = UIColor.ykn_primaryBackground
        addSubview(contentView)
        contentView.addSubview(imageView)
        contentView.addSubview(titleLabel)
    }
    
    func fillData(itemContext: YKSCItemContext) {
        if let contentLayout = itemContext.layoutModel.uploader {
            contentView.frame = contentLayout.renderRect
        } else {
            contentView.frame = .zero
        }
        
        if let titleLayout = itemContext.layoutModel.title {
            titleLabel.frame = titleLayout.renderRect
        } else {
            titleLabel.frame = .zero
        }
        
        if let iconLayout = itemContext.layoutModel.cover {
            imageView.frame = iconLayout.renderRect
        } else {
            imageView.frame = .zero
        }
        
        titleLabel.text = itemContext.model.title
        titleLabel.textColor = sceneUtil(UIColor.ykn_tertiaryInfo, sceneColor: itemContext.sceneSubTitleColor())
        backgroundColor = sceneUtil(UIColor.ykn_primaryBackground, sceneColor: itemContext.sceneBgColor())
    }

}
