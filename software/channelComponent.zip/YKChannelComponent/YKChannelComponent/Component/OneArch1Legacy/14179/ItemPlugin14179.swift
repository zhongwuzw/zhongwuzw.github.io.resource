//
//  ItemPlugin14179.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/7/5.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKChannelBase
import YKSCBase
import YoukuResource

@objcMembers
class ItemPlugin14179: YKSCItemPlugin {
    
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventParseData,
                "selector":     "receiveParseData:",
            ],
            [
                "event":        YKSCItemEventQueryItemCount,
                "selector":     "receiveQueryItemCount:",
            ],
            [
                "event":        YKSCItemEventEstimatedLayout,
                "selector":     "receiveEstimatedLayout:",
            ],
            [
                "event":        YKSCItemEventQueryItemHeight,
                "selector":     "receiveQueryItemHeight:",
            ],
            [
                "event":        YKSCItemEventQueryItemReuseId,
                "selector":     "receiveQueryItemReuseId:",
            ],
            [
                "event":        YKSCItemEventQueryItemView,
                "selector":     "receiveQueryItemView:",
            ],
            [
                "event":        YKSCItemEventReuseItemView,
                "selector":     "receiveReuseItemView:",
            ],
        ]
    }

    func receiveParseData(_ event: YKSCEvent) {
        guard let scItemContext = scItemContext else { return }

        if scItemContext.model.title == nil || scItemContext.model.title?.count == 0 {
            scItemContext.model.title = "你还没有追过任何内容哦"
        }
    }
    
    func receiveQueryItemCount(_ event: YKSCEvent) {
        event.responseInfo.setValue(NSNumber(value: 1), forKey: "itemCount")
    }
    
    func receiveEstimatedLayout(_ event: YKSCEvent) {
        guard let scItemContext = scItemContext else { return }

        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let itemHeight: Double = 278
        
        let iconSize = CGSize.init(width: 74, height: 74)
        let gapBetweenIconAndTitle = YKNGap.dim_8()
        
        let contentLayout = TextLayoutModel()
        contentLayout.renderRect = CGRect.init(x: 0.0, y: (itemHeight - Double(iconSize.height)) / 2, width: itemWidth, height: Double(iconSize.height))
        
        let titleHeight = Double(YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1))
        let titleWidth = calcStringSize(scItemContext.model.title, font: YKNFont.posteritem_maintitle(), size: CGSize.init(width: CGFloat(itemWidth) - iconSize.width - gapBetweenIconAndTitle, height: CGFloat(titleHeight))).width
        let titleY = (iconSize.height - CGFloat(titleHeight)) / 2
        let iconX = (CGFloat(itemWidth) - (iconSize.width + gapBetweenIconAndTitle + CGFloat(titleWidth))) / 2
        let titleX = iconX + iconSize.width + gapBetweenIconAndTitle
        
        let iconLayout = ImageLayoutModel()
        iconLayout.renderRect = CGRect.init(x: iconX, y: 0, width: iconSize.width, height: iconSize.height)
        
        let titleLayout = TextLayoutModel()
        titleLayout.renderRect = CGRect.init(x: titleX, y: titleY, width: titleWidth, height: CGFloat(titleHeight))
        
        //借用uploader存放contentLayout
        scItemContext.layoutModel.uploader = contentLayout
        scItemContext.layoutModel.cover = iconLayout
        scItemContext.layoutModel.title = titleLayout
        
        scItemContext.layoutModel.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)
    }
        
    func receiveQueryItemHeight(_ event: YKSCEvent) {

        let itemHeight = self.scItemContext?.layoutModel.renderRect.height ?? 0
        event.responseInfo.setValue(NSNumber(value: Double(itemHeight)), forKey: "itemHeight")
    }
    
    func receiveQueryItemReuseId(_ event: YKSCEvent) {
        event.responseInfo.setValue("item14179", forKey: "reuseId")
    }
    
    func receiveQueryItemView(_ event: YKSCEvent) {
        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let itemHeight: Double = (event.params?["itemHeight"] as? NSNumber)?.doubleValue ?? 0
        let itemView = ItemPlugin14179ContentView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        event.responseInfo.setValue(itemView, forKey:"itemView")
    }
    
    func receiveReuseItemView(_ event: YKSCEvent) {
        guard let itemView = event.params?["itemView"] as? ItemPlugin14179ContentView else {
            return
        }
        
        guard let scItemContext = scItemContext else {
            return
        }
        
        itemView.fillData(itemContext:scItemContext)
    }
}
