//
//  ItemPluginOnePlusNBaseVideo.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/6/30.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YoukuResource

@objcMembers
class ItemPlugin50104: ItemPluginBaseVideo {
        
    override func getItemHeight(itemWidth: Double, videoImageHeight: Double, textAreaHeight: Double) -> Double {
        guard let scItemContext = scItemContext,
              let scComponentContext = scComponentContext
        else {
            return super.getItemHeight(itemWidth: itemWidth, videoImageHeight: videoImageHeight, textAreaHeight: textAreaHeight)
        }
        
        let startIndex = scComponentContext.scInteger(forKey: YKSCComponentDataLayoutPageStartItemIndex)
        let itemIndex = scItemContext.scInteger(forKey: YKSCItemDataItemContextIndex)
        
        if startIndex == itemIndex && (UIApplication.shared.keyWindow?.bounds.size.width ?? 0) >= 1024 {
            return ceil(itemWidth / 1.488) + textAreaHeight
        } else {
            return super.getItemHeight(itemWidth: itemWidth, videoImageHeight: videoImageHeight, textAreaHeight: textAreaHeight)
        }
    }
    
    override func receiveQueryItemHeightEvent(_ event: YKSCEvent) {
        super.receiveQueryItemHeightEvent(event)
        
        guard let scItemContext = scItemContext else {
            return
        }
        
        //主标题
        let rect = scItemContext.layoutModel.title?.renderRect ?? CGRect.zero
        scItemContext.layoutModel.title?.renderRect = CGRect.init(x: rect.origin.x, y: rect.origin.y, width: rect.size.width, height: YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1))
    }
    
    override func receiveQueryItemViewEvent(_ event: YKSCEvent) {
        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let itemHeight: Double = (event.params?["itemHeight"] as? NSNumber)?.doubleValue ?? 0
        let itemView = ItemPluginOnePlusNBaseVideoContentView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        event.responseInfo.setValue(itemView, forKey:"itemView")
    }

}

@objcMembers
class ItemPlugin50108: ItemPluginBaseVideo {
        
    override func receiveQueryItemViewEvent(_ event: YKSCEvent) {
        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let itemHeight: Double = (event.params?["itemHeight"] as? NSNumber)?.doubleValue ?? 0
        let itemView = ItemPluginOnePlusNBaseVideoContentView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        event.responseInfo.setValue(itemView, forKey:"itemView")
    }

}
