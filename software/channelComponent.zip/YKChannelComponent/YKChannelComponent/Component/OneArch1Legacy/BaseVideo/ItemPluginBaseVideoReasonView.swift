//
//  ItemPluginBaseVideoReasonView.swift
//  YKChannelComponent
//
//  Created by xinwei on 2021/7/16.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import YKChannelBase
import YKSCiPhoneService

class ItemPluginBaseVideoReasonView: UIView {
    
    var useClientArrow: Bool = true
    var reasonModel: ReasonModel?

    lazy var iconImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_brandInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        return view
    }()
    
    lazy var arrowLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_brandInfo
        view.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.posteritem_subhead().pointSize)
        view.numberOfLines = 1
        view.text = "\u{e60f}"
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        clipsToBounds = true
        
        addSubview(iconImageView)
        addSubview(titleLabel)
        addSubview(arrowLabel)
    }
    
    func fillData(_ itemContext: YKSCItemContext) {
        if itemContext.scConfigInteger(forKey: "useClientArrow") == 1 {
            useClientArrow = true
        } else {
            useClientArrow = false
        }
        
        if let reason = itemContext.model.reason {
            self.isHidden = false
            
            reasonModel = reason
            
            //标题
            self.titleLabel.text = reason.title
            self.titleLabel.textColor = reason.titleColor
            
            //icon
            if let iconURLString = reason.icon, iconURLString.isEmpty == false {
                iconImageView.sd_setImage(with: URL.init(string: iconURLString))
                iconImageView.isHidden = false
            } else {
                iconImageView.image = nil
                iconImageView.isHidden = true
            }
            
            //跳转
            Service.action.bind(reason.action, self)
            if let _ = reason.action, useClientArrow {
                self.arrowLabel.isHidden = false
            } else {
                self.arrowLabel.isHidden = true
            }
            sizeToFit()
        } else {
            self.isHidden = true
        }
    }
    
    override func sizeToFit() {
        super.sizeToFit()
        
        let textSize = calcStringSize(titleLabel.text, font: titleLabel.font, size: .zero)
        var width = textSize.width + ((reasonModel?.icon?.isEmpty ?? true) ? 0 : 17)
        if let _ = reasonModel?.action, useClientArrow {
            let arrowWidth: CGFloat = 12
            width += arrowWidth
        }
        self.frame = CGRect.init(x: self.origin.x, y: self.origin.y, width: width, height: 18)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        
        var frame = titleLabel.frame
        if let icon = reasonModel?.icon, icon.isEmpty == false {
            iconImageView.frame = CGRect.init(x: 0, y: (self.frame.size.height - 14) / 2, width: 14, height: 14)
            frame.origin.x = 14 + 3;
        }
        
        let arrowSize = CGSize.init(width: 12, height: self.frame.size.height)
        if let _ = reasonModel?.action, useClientArrow {
            frame.origin.y = 0
            frame.size.width = self.frame.size.width - frame.origin.x - 0 - arrowSize.width
            frame.size.height = self.frame.size.height
            
            titleLabel.frame = frame
            arrowLabel.frame = CGRect.init(x: titleLabel.right, y: 0, width: arrowSize.width, height: arrowSize.height)
        } else {
            frame.origin.y = 0
            frame.size.width = self.frame.size.width - frame.origin.x - 0
            frame.size.height = self.frame.size.height
            
            titleLabel.frame = frame
        }
    }
}
