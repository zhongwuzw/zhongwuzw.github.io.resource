//
//  CompPluginBaseVideo.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/4/27.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YKSCConst
import YoukuResource

@objcMembers
class CompPluginBaseVideoAdaptor: YKSCComponentPlugin {
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCComponentEventParseData,
                "selector":     "receiveParseData:",
            ],
        ]
    }
    
    func receiveParseData(_ event: YKSCEvent) {
        scSetData(NSNumber(value: Double(YKNGap.youku_margin_left())), forKey: YKSCComponentDataLayoutPaddingLeft)
        scSetData(NSNumber(value: Double(YKNGap.youku_margin_right())), forKey: YKSCComponentDataLayoutPaddingRight)
        scSetData(NSNumber(value: Double(YKNGap.youku_column_spacing())), forKey: YKSCComponentDataLayoutColumnSpacing)
        
        guard let scComponentContext = scComponentContext,
              let compInfo = event.params?["componentInfo"] as? [String: Any],
              let dataInfo = compInfo["data"] as? [String: Any]
        else {
            return
        }
        
        //是否支持标题换行
        let enableNewLine: Bool = dataInfo["enableNewLine"] as? Bool ?? false
        scComponentContext.model.extraExtend["enableNewLine"] = enableNewLine
    }
}

private func windowWidth() -> CGFloat {
    if isiPad() {
        return UIApplication.shared.keyWindow?.bounds.size.width ?? 0.0
    } else {
        return UIScreen.main.bounds.size.width
    }
}

private func windowHeight() -> CGFloat {
    if isiPad() {
        return UIApplication.shared.keyWindow?.bounds.size.height ?? 0.0
    } else {
        return UIScreen.main.bounds.size.height
    }
}

@objcMembers
class CompPlugin50104Adaptor: CompPluginBaseVideoAdaptor {
    
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCComponentEventParseData,
                "selector":     "receiveParseData:",
            ],
            [
                "event":        YKSCComponentEventUpdateLayoutCacheBefore,
                "selector":     "receiveUpdateLayoutCacheBeforeEvent:",
            ],
        ]
    }

    override func receiveParseData(_ event: YKSCEvent) {
        super.receiveParseData(event)
        
        //布局列数
        scSetData(NSNumber(2), forKey: YKSCComponentDataLayoutColumnCount)
        scSetData(NSNumber(2), forKey: YKSCComponentDataLayoutSupportedMaxRowCount)
        scSetData(NSNumber(12), forKey: YKSCComponentDataLayoutColumnSpacing)           //列间距
        scSetData(NSNumber(5), forKey: YKSCComponentDataLayoutRowSpacing)               //行间距
        scSetData(NSNumber.init(value: Double(YKNGap.margin_l())), forKey: YKSCComponentDataLayoutPaddingLeft)          //左边距
        scSetData(NSNumber.init(value: Double(YKNGap.margin_r())), forKey: YKSCComponentDataLayoutPaddingRight)         //右边距
                
        //视频图片宽高比 ， 数据中心key 定义见 YKHome.YKHomeItemPluginBaseVideo.m
        scComponentContext?.model.extraExtend["aspectRatio"] = NSNumber(1.781)  /*488.f/274.0f*/
        
        let bigRate = 488.0 / (488.0 + 238.0 * 2.0)
        let smallRate = 238.0 / (488.0 + 238.0 * 2.0)
        scSetData(NSNumber(value: bigRate), forKey: "yksc.data.comp.layout.bigItemWidthRate")          //大图比例
        scSetData(NSNumber(value: smallRate), forKey: "yksc.data.comp.layout.smallItemWidthRate")        //小图比例
                
        updateColumnAndRowCount()
    }
    
    func receiveUpdateLayoutCacheBeforeEvent(_ event: YKSCEvent) {
        updateColumnAndRowCount()
    }
    
    func updateColumnAndRowCount() {
        if windowWidth() >= 1024 {
            scSetData(NSNumber(2), forKey: YKSCComponentDataLayoutColumnCount)
            scSetData(NSNumber(2), forKey: YKSCComponentDataLayoutSupportedMaxRowCount)
        } else if (windowWidth() >= 694 && windowWidth() < 1024) {
            scSetData(NSNumber(3), forKey: YKSCComponentDataLayoutColumnCount)
            scSetData(NSNumber(2), forKey: YKSCComponentDataLayoutSupportedMaxRowCount)
        } else {
            scSetData(NSNumber(2), forKey: YKSCComponentDataLayoutColumnCount)
            scSetData(NSNumber(3), forKey: YKSCComponentDataLayoutSupportedMaxRowCount)
        }
    }
}

@objcMembers
class CompPlugin50108Adaptor: CompPluginBaseVideoAdaptor {
    
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCComponentEventParseData,
                "selector":     "receiveParseData:",
            ],
            [
                "event":        YKSCComponentEventUpdateLayoutCacheBefore,
                "selector":     "receiveUpdateLayoutCacheBeforeEvent:",
            ],
        ]
    }

    override func receiveParseData(_ event: YKSCEvent) {
        super.receiveParseData(event)
        
        //布局列数
        scSetData(NSNumber(4), forKey: YKSCComponentDataLayoutColumnCount)
        scSetData(NSNumber(2), forKey: YKSCComponentDataLayoutSupportedMaxRowCount)
        scSetData(NSNumber(12), forKey: YKSCComponentDataLayoutColumnSpacing)           //列间距
        scSetData(NSNumber(5), forKey: YKSCComponentDataLayoutRowSpacing)               //行间距
        scSetData(NSNumber.init(value: Double(YKNGap.margin_l())), forKey: YKSCComponentDataLayoutPaddingLeft)          //左边距
        scSetData(NSNumber.init(value: Double(YKNGap.margin_r())), forKey: YKSCComponentDataLayoutPaddingRight)         //右边距
                
        //视频图片宽高比 ， 数据中心key 定义见 YKHome.YKHomeItemPluginBaseVideo.m
        scComponentContext?.model.extraExtend["aspectRatio"] = NSNumber(0.753)  /*338.f/449.0f*/
        
        let bigRate = 344.0 / (344.0 + 149.0 * 4.0)
        let smallRate = 149.0 / (344.0 + 149.0 * 4.0)
        scSetData(NSNumber(value: bigRate), forKey: "yksc.data.comp.layout.bigItemWidthRate")          //大图比例
        scSetData(NSNumber(value: smallRate), forKey: "yksc.data.comp.layout.smallItemWidthRate")        //小图比例
    }
    
    func receiveUpdateLayoutCacheBeforeEvent(_ event: YKSCEvent) {
        if windowWidth() >= 694 {
            scSetData(NSNumber(4), forKey: YKSCComponentDataLayoutColumnCount)
            scSetData(NSNumber(2), forKey: YKSCComponentDataLayoutSupportedMaxRowCount)
        } else {
            scSetData(NSNumber(3), forKey: YKSCComponentDataLayoutColumnCount)
            scSetData(NSNumber(3), forKey: YKSCComponentDataLayoutSupportedMaxRowCount)
        }
    }
}
