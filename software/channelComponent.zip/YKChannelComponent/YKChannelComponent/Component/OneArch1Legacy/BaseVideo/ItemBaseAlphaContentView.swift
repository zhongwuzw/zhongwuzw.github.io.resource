//
//  ItemBaseAlphaContentView.swift
//  YKChannelComponent
//
//  Created by better on 2022/8/22.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import YKSCBase
import Lottie
import YKChannelBase
import YKChannelPage

class ItemBaseAlphaContentView: AccessibilityView {

    var pageIsThemeMode:Bool = false //页面是否有氛围
    var isSecondFloorComponent:Bool = false
    var alphaProgress:CGFloat = 1.0
    private var navBackgroundAlpha:CGFloat = 1.0

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleAlphaChanged), name: NSNotification.Name.init(rawValue: "home.secondFloorComponent.alpha.changed"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleLunboAlphaNotification), name: NSNotification.Name.init(rawValue: "KRefreshHomeTopViewByNewLunboNotification"), object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    func getNavBackgroundAlpha() -> CGFloat {
        if self.pageIsThemeMode {
            return 1.0
        }
        return self.navBackgroundAlpha
    }
    
    @objc func handleAlphaChanged(notification: Notification) {
        guard let userInfo = notification.userInfo,
              let alpha = userInfo["alpha"] as? CGFloat
        else {
            return
        }
        if isSecondFloorComponent {
            self.alphaProgress = alpha
            self.alpha = self.alphaProgress * self.getNavBackgroundAlpha()
        } else {
            self.alphaProgress = 1.0
            self.alpha = 1.0
        }
        print("[ItemBaseAlpha] alphaChange item progress \(self.alphaProgress) \(self.getNavBackgroundAlpha()), view:\(self)")
    }
    
    @objc func handleLunboAlphaNotification(notification: Notification) {
        guard let userInfo = notification.userInfo,
              let backgroundAlpha = userInfo["backgroundAlpha"] as? CGFloat
        else {
            return
        }
        var isTopAnimationADMode = false
        if SelectionTopAnimationADManager.enableTopAnimationAD {
            isTopAnimationADMode = UserDefaults.standard.bool(forKey: "home.NewSectionPage.isTopAnimationADMode")
        }
        
        self.navBackgroundAlpha = backgroundAlpha
        if isTopAnimationADMode, let realBackgroundAlpha = userInfo["realBackgroundAlpha"] as? CGFloat {
            self.navBackgroundAlpha = realBackgroundAlpha
        }
        if self.isSecondFloorComponent {
            self.alpha = self.alphaProgress * self.getNavBackgroundAlpha()
        } else {
            self.alpha = 1.0
        }
        print("[ItemBaseAlpha] lunboAlpha navBackgroundAlpha \(self.navBackgroundAlpha)")
    }

    func fillData(itemContext: YKSCItemContext) {

        if let card = itemContext.scCardContext, let tag = card.scString(forKey: YKSCCardDataTemplateTag) {
            self.isSecondFloorComponent = (tag == "15029" || tag == "15038")
        } else {
            self.isSecondFloorComponent = false
        }
        if (self.isSecondFloorComponent) {
            self.alpha = self.alphaProgress * self.getNavBackgroundAlpha()
        } else {
            self.alpha = 1.0
        }
    }
}
