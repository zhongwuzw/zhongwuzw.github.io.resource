//
//  ItemPluginBaseVideo.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/5/6.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YKChannelBase
import YoukuResource
import OneArchCore
import YKOneConfig
import YoukuAnalytics

@objcMembers
class ItemPluginBaseVideo: YKSCItemPlugin {
    
    weak var _displayingItemView: ItemPluginBaseVideoContentView?
    
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventParseData,
                "selector":     "receiveParseDataEvent:",
            ],
            [
                "event":        YKSCItemEventInit,
                "selector":     "receiveItemInitEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemCount,
                "selector":     "receiveQueryItemCountEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemHeight,
                "selector":     "receiveQueryItemHeightEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemReuseId,
                "selector":     "receiveQueryItemReuseIdEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemView,
                "selector":     "receiveQueryItemViewEvent:",
            ],
            [
                "event":        YKSCItemEventReuseItemView,
                "selector":     "receiveReuseItemViewEvent:",
                "priority":     600,
            ],
            [
                "event":        YKSCItemEventItemEnterDisplayArea,
                "selector":     "receiveItemEnterDisplayAreaEvent:",
            ],
            [
                "event":        YKSCItemEventItemExitDisplayArea,
                "selector":     "receiveItemExitDisplayAreaEvent:",
            ],
            [
                "event":        YKSCItemEventItemDidActivate,
                "selector":     "receiveItemDidActivateEvent:",
            ],
            [
                "event":        YKSCItemEventItemWillDeactivate,
                "selector":     "receiveItemWillDeactivateEvent:",
            ],
            [
                "event":        YKSCItemEventItemDidDeactivate,
                "selector":     "receiveItemDidDeactivateEvent:",
            ],
        ]
    }
    
    func receiveParseDataEvent(_ event: YKSCEvent) {
        guard let scItemContext = scItemContext,
              let itemInfo = event.params?["itemInfo"] as? [String:Any],
              let dataInfo = itemInfo["data"] as? [String:Any]
        else {
            return
        }
        
        if let title = dataInfo["title"] as? String, title.count > 0 {
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 3.0
            paragraphStyle.lineBreakMode = .byTruncatingTail
            let attributedTitle = NSAttributedString.init(string: title, attributes: [.paragraphStyle: paragraphStyle])
            scItemContext.model.extraExtend["attributedTitle"] = attributedTitle
        }
        
        if let lTop = dataInfo["lTop"] as?  [String:Any],
           let lTopdata = lTop["data"] as? [String:Any],
           let img = lTopdata["img"] as? String {
            scSetData(img, forKey: "yksc.item.data.lTop.img")
        }
        
        if let interactionLabel = dataInfo["interactionLabel"] as? [String] {
            processInteractionLabel(interactionLabel)
        }
        
        self.sendCustomPlayerStatistic()
    }
    
    func receiveItemInitEvent(_ event: YKSCEvent) {
        guard let scItemContext = scItemContext else {
            return
        }
        
        // 使得标签支持图片样式
        if let reasons = scItemContext.model.reasons {
            for (index, reason) in reasons.enumerated() {
                if let img = reason.img, img.isEmpty == false {
                    scItemContext.model.reasons?[index].imgEnabled = true
                }
            }
        }
        
        if let reason = scItemContext.model.reason {
            if let img = reason.img, img.isEmpty == false {
                scItemContext.model.reason?.imgEnabled = true
            }
        }
    }
    
    func processInteractionLabel(_ labels: [String]) {
        guard let scItemContext = scItemContext else {
            return
        }
        
        guard labels.count > 0 else {
            return
        }
        
        var widths = [CGFloat]()
        var texts = [String]()
        
        var lastText = ""
        let dot = "·"
        
        for aLabel in labels {
            var text = aLabel
            if text.isEmpty {
                continue
            }
            if !lastText.isEmpty {
                text = lastText + dot + text
            }
            let width: CGFloat = ceil(calcStringSize(text, font: posteritem_subhead(), size: CGSize.init(width: Int.max, height: Int.max)).width)
            widths.append(width)
            texts.append(text)
            
            lastText = text
        }
        
        scItemContext.model.extraExtend["interactionLabel"] = labels
        scItemContext.model.extraExtend["interactionLabel.widths"] = widths
        scItemContext.model.extraExtend["interactionLabel.texts"] = texts
    }
    
    func receiveQueryItemCountEvent(_ event: YKSCEvent) {
        event.responseInfo.setValue(NSNumber(value: 1), forKey: "itemCount")
    }
        
    func receiveQueryItemHeightEvent(_ event: YKSCEvent) {
        guard let scComponentContext = scComponentContext,
              let scItemContext = scItemContext
        else {
            return
        }
        
        let itemWidth = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let aspectRatio = scComponentContext.model.extraExtend["aspectRatio"] as? Double ?? 1.78
        let videoImageHeight = ceil(itemWidth / aspectRatio)
        let textAreaH = Double(ceil(textAreaHeight()))
        let itemHeight = getItemHeight(itemWidth: itemWidth, videoImageHeight: videoImageHeight, textAreaHeight: textAreaH)
        event.responseInfo.setValue(NSNumber(value: Double(itemHeight)), forKey: "itemHeight")
        
        scItemContext.layoutModel.renderRect = CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight)
        
        //预布局
        let model = scItemContext.model
        let videoImageSize = CGSize.init(width: itemWidth, height: videoImageHeight)
        
        //封面图
        let coverLayout = ImageLayoutModel.init()
        coverLayout.boundingSize = videoImageSize
        coverLayout.renderRect = CGRect.init(x: 0, y: 0, width: videoImageSize.width, height: videoImageSize.height)
        scItemContext.layoutModel.cover = coverLayout
                
        if let mark = scItemContext.model.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: videoImageSize)
            scItemContext.layoutModel.mark = layout
        }
        
        if let summary = model.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize:videoImageSize)
            scItemContext.layoutModel.summary = layout
        }
        
        if let lbTexts = model.lbTexts {
            let layout = Service.lbTexts.estimatedLayout(lbTexts, toViewSize:videoImageSize)
            scItemContext.layoutModel.lbTexts = layout
        }
        
        //主标题
        let titleLayout = TextLayoutModel.init()
        let titleY = coverLayout.renderRect.maxY + YKNGap.youku_picture_title_spacing()
        titleLayout.renderRect = CGRect.init(x: 0,
                                             y: titleY,
                                             width: videoImageSize.width,
                                             height: ceil(38.0 * YKNSize.yk_icon_size_scale()))
        scItemContext.layoutModel.title = titleLayout
        
        
        let subtitleWidth:CGFloat = scItemContext.model.feedbackModel != nil ? (videoImageSize.width - 15) : videoImageSize.width
        
        //副标题
        let subtitleLayout = TextLayoutModel.init()
        let subtitleY = coverLayout.renderRect.maxY
            + YKNGap.youku_picture_title_spacing()
            + YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
            + YKNGap.youku_maintitle_subtitle_spacing()
        subtitleLayout.renderRect = CGRect.init(x: 0,
                                                y: subtitleY,
                                                width: subtitleWidth,
                                                height: YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1))
        scItemContext.layoutModel.subtitle = subtitleLayout
        
        if let reasons = model.reasons {
            let boundingSize = CGSize.init(width: CGFloat(subtitleWidth), height: CGFloat.greatestFiniteMagnitude)
            var layout = Service.reasons.estimatedLayout(reasons, boundingSize: boundingSize)
            let position = CGPoint.init(x: 0, y: itemHeight - Double(layout.first?.renderRect.size.height ?? 0))
            layout = Service.reasons.estimatedLayout(reasons, position: position, boundingSize: boundingSize)
            scItemContext.layoutModel.reasons = layout
        }
    }
    
    func receiveQueryItemReuseIdEvent(_ event: YKSCEvent) {
        guard let scComponentContext = scComponentContext else {
            return
        }
        
        let componentTag = scComponentContext.scString(forKey: YKSCComponentDataTemplateTag) ?? "unknown"
        let itemIndexTag = scInteger(forKey: YKSCItemDataItemContextIndex) % 3
        let reuseId = String("BaseVideo_" + componentTag + "_\(itemIndexTag)")
        event.responseInfo.setValue(reuseId, forKey: "reuseId")
    }
    
    func receiveQueryItemViewEvent(_ event: YKSCEvent) {
        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let itemHeight: Double = (event.params?["itemHeight"] as? NSNumber)?.doubleValue ?? 0
        let itemView = ItemPluginBaseVideoContentView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        event.responseInfo.setValue(itemView, forKey:"itemView")
    }

    func receiveReuseItemViewEvent(_ event: YKSCEvent) {
        guard let scItemContext = scItemContext else {
            return
        }
        
        guard let itemView = event.params?["itemView"] as? ItemPluginBaseVideoContentView else {
            return
        }
        
        itemView.fillData(scItemContext)
    }
    
    func receiveItemEnterDisplayAreaEvent(_ event: YKSCEvent) {
        guard let itemView = event.params?["itemView"] as? ItemPluginBaseVideoContentView else {
            _displayingItemView = nil
            return
        }
        
        _displayingItemView = itemView
    }
    
    func receiveItemExitDisplayAreaEvent(_ event: YKSCEvent) {
        _displayingItemView = nil
    }
    
    func receiveItemDidActivateEvent(_ event: YKSCEvent) {
        _displayingItemView?.startAnimating()
    }
    
    func receiveItemWillDeactivateEvent(_ event: YKSCEvent) {
        _displayingItemView?.stopAnimating()
    }
    
    func receiveItemDidDeactivateEvent(_ event: YKSCEvent) {
        _displayingItemView?.stopAnimating()
    }
    
    /// 坑位高度计算（供子类重写）
    func getItemHeight(itemWidth: Double,videoImageHeight: Double, textAreaHeight: Double) -> Double {
        return videoImageHeight + textAreaHeight
    }
    
    /// 文本区域高度（含spacing）
    func textAreaHeight() -> CGFloat {
        guard let scComponentContext = scComponentContext,
              let scItemContext = scItemContext
        else {
            return 0
        }
        
        let model = scItemContext.model
        var totalHeight: CGFloat = 0
        
        if isEmpty(model.title) {
            return 0
        }
        
        let hasReasons: Bool = model.reasons?.count ?? 0 > 0
        if hasReasons {
            //有推荐理由一律按2行标题（主副标题）+ 1行推荐理由布局，总体高度需要双对齐列卡片
            totalHeight = 30 + ceil(38.0 * YKNSize.yk_icon_size_scale())
            
        } else {
            let noSubtitle: Bool = model.subtitle?.count == 0
            let noMultiLineTitle: Bool = scComponentContext.model.extraExtend.yk_bool("enableNewLine")
            let noReason: Bool = model.reason?.title?.count == 0
            let noInteractionLabels: Bool  = model.extraExtend.yk_string("interactionLabel").isEmpty
            
            if noSubtitle
                && noMultiLineTitle
                && noReason
                && noInteractionLabels {
                totalHeight = YKNGap.youku_picture_title_spacing()
                    + YKNFont.height(with: posteritem_maintitle(), lineNumber: 1)
                    + YKNGap.youku_maintitle_subtitle_spacing()
                
            } else {
                totalHeight = YKNGap.youku_picture_title_spacing()
                    + YKNFont.height(with: posteritem_maintitle(), lineNumber: 1)
                    + YKNGap.youku_maintitle_subtitle_spacing()
                    + YKNFont.height(with: posteritem_subhead(), lineNumber: 1)
            }
        }
        
        return totalHeight
    }
    
    func sendCustomPlayerStatistic() {
        if let itemTag = self.scItemContext?.scString(forKey: YKSCItemDataTemplateTag), itemTag != "14001" {
            return
        }
        if let canPlay = self.scItemContext?.model.playerModel?.canPlay, !canPlay {
            return
        }
        if self.scItemContext?.model.playerModel?.playerEngineType != .Live {
            return
        }
        let report = self.scItemContext?.model.action?.report
        let pageName = report?.pageName ?? "page_homeselect"
        let arg1 = "PREVIEW_LIVE_PREVIEW_STAT"
        let arg2 = report?.spm
        let arg3 = report?.scm
        
        var args = [String: Any]()
        if let spm = report?.spm {
            args["spm"] = spm
        }
        if let scm = report?.scm {
            args["scm"] = scm
        }
        if let utparam = report?.utparam {
            args["utparam"] = utparam
        }

        if let itemTag = self.scItemContext?.scString(forKey: YKSCItemDataTemplateTag) {
            args["item"] = itemTag
        }
        
        if self.isPageInPreload() {
            args["is_home_cache"] = "1"
        } else {
            args["is_home_cache"] = "0"
        }

        if let liveState = self.scItemContext?.model.extraExtend["liveState"] {
            args["live_state"] = liveState
        }
        
        args["pageName"] = pageName
        
        YoukuAnalytics.sharedInstance()?.collectALiCustomEvent(withEventID: "19999",
                                                               pageName: pageName,
                                                               arg1: arg1,
                                                               arg2: arg2,
                                                               arg3: arg3,
                                                               args: args
        )
    }
    
    func isPageInPreload() -> Bool {
        guard let scPageContext = self.scItemContext?.scPageContext else {
            return false
        }
        let state = scPageContext.scString(forKey: YKSCPageDataDataState)
        if state == "preload" || state == "cache" {
            return true
        }
        return false
    }

}
