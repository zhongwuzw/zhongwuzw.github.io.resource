//
//  ItemPluginBaseVideoContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/5/6.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import YKSCBase
import Lottie
import YKChannelBase
import YKUIComponent

class ItemPluginBaseVideoContentView: AccessibilityView {
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var titleLabel: MarginLabel = {
        let view = MarginLabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.verticalAlignment = .top
        view.numberOfLines = 2
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var reasonView: ItemPluginBaseVideoReasonView = {
        let view = ItemPluginBaseVideoReasonView()
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        addSubview(videoImageView)
        addSubview(titleLabel)
        addSubview(subtitleLabel)
        addSubview(reasonView)
    }

    func fillData(_ itemContext: YKSCItemContext) {
        relayoutSubviews(itemContext.layoutModel)
        let model = itemContext.model
        let layoutModel = itemContext.layoutModel

        // 背景色
        backgroundColor = sceneUtil(.clear, sceneColor: itemContext.sceneBgColor())
        
        // 封面图
        if var imgUrl = model.img, imgUrl.count > 0 {
            if let keepImgAnim = self.scConfigString(forKey: "keepImgAnim") as? String, keepImgAnim == "1" {
                imgUrl = imgUrl + (imgUrl.hasSuffix("?") ? "keepImgAnim=1" : "?keepImgAnim=1")
            } else if let keepImgAnim = self.scConfigInteger(forKey: "keepImgAnim") as? Int, keepImgAnim == 1 {
                imgUrl = imgUrl + (imgUrl.hasSuffix("?") ? "keepImgAnim=1" : "?keepImgAnim=1")
            }
            videoImageView.ykn_setImage(withURLString: imgUrl,
                                        module: "home",
                                        imageSize: CGSize.zero,
                                        parameters: nil,
                                        completed: nil)
        } else {
            videoImageView.image = nil
        }
        
        // 主标题
        if let attributedTitle = model.extraExtend["attributedTitle"] as? NSAttributedString {
            titleLabel.attributedText = attributedTitle
        } else {
            titleLabel.text = model.title
        }
        titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: itemContext.sceneTitleColor())
        let enableNewLine = itemContext.scComponentContext?.model.extraExtend["enableNewLine"] as? Bool ?? false
        titleLabel.numberOfLines = enableNewLine ? 2 : 1
        
        // 副标题
        subtitleLabel.isHidden = enableNewLine
        fillSubtitle(itemContext)
        
        // 推荐理由（单项，老旧能力，G桶在用）
        if let reasonTitle = model.reason?.title,
           reasonTitle.count > 0,
           enableNewLine == false
           {
            subtitleLabel.isHidden = true
            reasonView.isHidden = false
            reasonView.fillData(itemContext)
        } else {
            reasonView.isHidden = true
        }
        
        // 跳转
        let isCheckMode: Bool = itemContext.scPageContext?.scBool(forKey: "yksc.data.page.np.icCheckMode") ?? false
        if isCheckMode {
            var params = [String: Any]()
            params["view"] = self
            params["tag"] = "root"
            params["action"] = "tap"
            itemContext.scFireEvent(YKSCItemEventBindItemView, params: params)
        } else {
            if let reportRelyOnPicture = self.scConfigString(forKey: "reportRelyOnPictureExposure") as? String,
               reportRelyOnPicture == "1" {
                videoImageView.isUserInteractionEnabled = true
                Service.action.bind(itemContext.model.action, videoImageView)
                Service.action.bind(itemContext.model.action, self, .OnlyClick)
            } else {
                videoImageView.isUserInteractionEnabled = false
                Service.action.bind(nil, videoImageView)
                Service.action.bind(itemContext.model.action, self)
            }
        }

        // 角标
        Service.mark.attach(model.mark, toView: videoImageView, layout: layoutModel.mark)

        // 右下角腰封 及 选中标记
        Service.summary.attach(model.summary, toView: videoImageView, layout: layoutModel.summary)
        
        //评分氛围适配
        if let sceneColor = itemContext.sceneScoreColor(),
           model.summary?.textType == .score,
           let label = videoImageView.viewWithTag(19000010) as? UILabel
        {
            label.textColor = sceneColor
        }
        
        // 左下角腰封
        Service.lbTexts.attach(model.lbTexts, toView: videoImageView, layouts: layoutModel.lbTexts)
        
        // 推荐理由（多项）
        Service.reasons.attach(model.reasons, toView: self, layouts: layoutModel.reasons)
        
        // 水印
        Service.waterMark.attach(model.waterMark, toView: videoImageView)
        
        // 长按预览
        var params = [String: Any]()
        params["view"] = self
        params["tag"] = "root"
        params["action"] = "longPress"
        itemContext.scFireEvent(YKSCItemEventBindItemView, params: params)
        
        //player
        Service.player.attach(itemContext.model.playerModel, toView: self.videoImageView, displayFrame: self.videoImageFrame(layoutModel))
        itemContext.model.playerModel?.isHideWaterMark = true

        //feedback
        Service.feedback.attach(itemContext.model.feedbackModel, toView: self, morePos: .BottomRight, isSupportUndo: true, feedbackSuccess: nil)
    }
    
    func relayoutSubviews(_ layoutModel: LayoutModel) {
        videoImageView.frame = self.videoImageFrame(layoutModel)
        titleLabel.frame = layoutModel.title?.renderRect ?? CGRect.zero
        subtitleLabel.frame = layoutModel.subtitle?.renderRect ?? CGRect.zero
        reasonView.frame = subtitleLabel.frame
    }
    
    func videoImageFrame(_ layoutModel: LayoutModel) -> CGRect {
        return layoutModel.cover?.renderRect ?? CGRect.zero
    }
    
    func fillSubtitle(_ itemContext: YKSCItemContext) {
        let model = itemContext.model
        
        if let interactionLabelWidths = model.extraExtend["interactionLabel.widths"] as? [CGFloat],
           let interactionLabelTexts = model.extraExtend["interactionLabel.texts"] as? [String],
           let firstLabelWidth = interactionLabelWidths.first,
           0.1 ... width ~= firstLabelWidth {
            var text = ""
            for i in 0 ..< interactionLabelWidths.count {
                if interactionLabelWidths[i] > width {
                    break
                }
                text = interactionLabelTexts[i]
            }
            
            subtitleLabel.text = text
        } else {
            subtitleLabel.text = model.subtitle
        }
        
        subtitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: itemContext.sceneSubTitleColor())
    }

    //MARK: - Animation Image
    func startAnimating() {
        if !videoImageView.isAnimating {
            videoImageView.startAnimating()
        }
    }
    
    func stopAnimating() {
        if videoImageView.isAnimating {
            videoImageView.stopAnimating()
        }
    }
}
