//
//  ItemPluginOnePlusNBaseVideoContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/6/30.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YoukuResource

class ItemPluginOnePlusNBaseVideoContentView: ItemPluginBaseVideoContentView {

    lazy var backgroundView: UIView = {
        let view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        view.layer.cornerRadius = YKNConfig.ykn_item_default_radius()
        return view
    }()

    
    override func initSubviews() {
        super.initSubviews()
        
        addSubview(backgroundView)
        sendSubviewToBack(backgroundView)
        clipsToBounds = false
        
        backgroundView.leadingAnchor.constraint(equalTo: self.leadingAnchor).isActive = true
        backgroundView.topAnchor.constraint(equalTo: self.topAnchor, constant: YKNConfig.ykn_item_default_radius()).isActive = true
        backgroundView.trailingAnchor.constraint(equalTo: self.trailingAnchor).isActive = true
        backgroundView.bottomAnchor.constraint(equalTo: self.bottomAnchor).isActive = true
    }
    
    override func fillData(_ itemContext: YKSCItemContext) {
        super.fillData(itemContext)
        
        guard let cardContext = itemContext.scCardContext,
              let componentContext = itemContext.scComponentContext
        else {
            return
        }
        
        let cardContentWidth = cardContext.scDouble(forKey: YKSCCardDataLayoutContentWidth)
        let componentPaddingLeft = componentContext.scDouble(forKey: YKSCComponentDataLayoutPaddingLeft)
        let componentPaddingRight = componentContext.scDouble(forKey: YKSCComponentDataLayoutPaddingRight)
        let componentContentWidth = max(round(cardContentWidth - componentPaddingLeft - componentPaddingRight), 0)
        
        let columnCount = componentContext.scDouble(forKey: YKSCComponentDataLayoutColumnCount)
        
        var columnSpacing = componentContext.scDouble(forKey: YKSCComponentDataLayoutColumnSpacing)
        if columnSpacing == 0 {
            columnSpacing = cardContext.scDouble(forKey: YKSCCardDataLayoutColumnSpacing)
        }
        
        let itemWidth = Int(itemContext.scDouble(forKey: YKSCItemDataLayoutContentWidth))
        let temp = Int((componentContentWidth - columnCount * columnSpacing) * 488.0 / (488.0 + 238.0 * 2.0))
        
        if itemWidth == temp {
            
            videoImageView.frame = itemContext.layoutModel.cover?.renderRect ?? CGRect.zero
            titleLabel.frame = CGRect.init(x: 8, y: 16, width: self.width - 16, height: titleLabel.height)
            subtitleLabel.frame = CGRect.init(x: 8, y: 0, width: self.width - 16, height: subtitleLabel.height)
            titleLabel.top = videoImageView.bottom + (self.frame.size.height - videoImageView.frame.size.height - titleLabel.frame.size.height - subtitleLabel.frame.size.height - YKNGap.youku_maintitle_subtitle_spacing()) / 2
            subtitleLabel.top = titleLabel.bottom + YKNGap.youku_maintitle_subtitle_spacing()
            
            if #available(iOS 11.0, *) {
                videoImageView.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
            }
            backgroundView.backgroundColor = .ykn_secondaryBackground
            
        } else {
            if #available(iOS 11.0, *) {
                videoImageView.layer.maskedCorners = [.layerMaxXMaxYCorner, .layerMaxXMinYCorner, .layerMinXMaxYCorner, .layerMinXMinYCorner]
            }
            backgroundView.backgroundColor = .clear
        }
    }
}
