//
//  CompJumpPlugin.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2021/10/27.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import YKSCBase

@objcMembers
class CompJumpPlugin: YKSCItemPlugin {
    //MARK:事件映射定义
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventTapAction,
                "selector":     "receiveTapActionEvent:",
                "priority":     800
            ]
        ]
    }
    
    func receiveTapActionEvent(_ event: YKSCEvent) {
        
        guard let tag = event.params?.scString(forKey: "tag") else {
            return
        }
        
        guard let actionInfo = self.scDictionary(forKey: YKSCItemDataTapActionInfo), let routeInfo = actionInfo[tag] as? Dictionary<String, AnyObject> else {
            return
        }
        
        guard let routeType = routeInfo["routeType"] as? String, routeType == "JUMP_TO_COMPONENT" , let routeParams = routeInfo["routeParams"] as? Dictionary<String, AnyObject>, routeParams.count >= 2 else {
            return
        }
        
        event.userInfo?.scSetData(NSNumber.init(value:true), forKey: "disableRouteAction")
        
        print("fuzhong CompJumpPlugin \(actionInfo)")
        guard let typeStr = routeParams["type"] as? String , let indexStr = routeParams["index"] as? String else {
            return
        }
        
        let typeVal:Int = Int(typeStr) ?? 0
        let indexVal:Int = Int(indexStr) ?? 0
        
        jumpToComp(typeVal, index:indexVal)
    }
    
    /// MARK: private
    func jumpToComp(_ type: Int, index: Int) {
        guard let cardContexts = self.scPageContext?.scCardContexts, cardContexts.count > 0 else {
           return
        }
        
        var resultCompContext: YKSCComponentContext?
        for i in 0..<cardContexts.count {
            if resultCompContext != nil { //底层已经找到，则return掉
                break
            }
            guard let cardContext = cardContexts[i] as? YKSCCardContext else {
                continue
            }
            
            guard let compContexts = cardContext.scComponentContexts, compContexts.count > 0 else {
                continue
            }
            
            for j in 0..<compContexts.count {
                guard let compContext = compContexts[j] as? YKSCComponentContext else {
                    continue
                }
                
                guard let componentTag = compContext.scString(forKey: YKSCComponentDataTemplateTag) else {
                    continue
                }
                
                let compTagVal:Int = Int(componentTag) ?? 0
                if compTagVal == type && index == (j + 1) { //index从1开始
                    resultCompContext = compContext
                    break
                }
            }
        }
        
        if resultCompContext != nil {
            triggerScrollToComp(resultCompContext!)
        }
    }
    
    func triggerScrollToComp(_ compContext:YKSCComponentContext) {
        print("fuzhong CompJumpPlugin trigger to comp")
        
        var config = [String: Any]()
        config["componentContext"] = compContext
        self.scPageContext?.scFireEvent(YKSCPageEventTriggerContainerScroll, params: config)
    }
}
