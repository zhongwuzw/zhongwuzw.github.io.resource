//
//  CompPlugin14180ItemView.swift
//  CompPlugin14180ItemView
//
//  Created by dylanlai on 2021/8/24.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YoukuResource

class CompPlugin14180ItemView: UICollectionViewCell {
    
    private lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textAlignment = .center
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clear
        addSubview(titleLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        titleLabel.frame = CGRect.init(origin: .zero, size: frame.size)
    }
    
    public func fillData(_ text: String) {
        titleLabel.text = text
    }

    public func drawSelectedStyle(textColor : UIColor?) {
        titleLabel.textColor = textColor ?? UIColor.ykn_brandInfo
        titleLabel.font = Component14180.itemSelectedFont()
        print("[14180] didSelectItemAt drawDeselectedStyle:\(textColor)")
    }

    public func drawDeselectedStyle(textColor : UIColor?) {
        titleLabel.textColor = textColor ?? UIColor.ykn_secondaryInfo
        titleLabel.font = Component14180.itemUnselectedFont()
        print("[14180] didDeselectItemAt drawDeselectedStyle:\(textColor)")
    }
    
}
