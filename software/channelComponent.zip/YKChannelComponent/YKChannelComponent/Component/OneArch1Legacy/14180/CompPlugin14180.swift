//
//  CompPlugin14180.swift
//  CompPlugin14180
//
//  Created by dylanlai on 2021/8/24.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YoukuResource
//import YKChannelBase

class CompPlugin14180Container: UIView {
    
    var laneGroupView: LaneGroupView?
    var optionsView: CompPlugin14180OptionsView?
    
    var lightweightLaneGroupView: LaneGroupView?
    var showAllTipsView: CompPlugin14180OptionsView?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        tag = 202111302
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//@objcMembers
//class CompPlugin14180: YKSCComponentPlugin, LaneGroupViewDelegate, LaneGroupViewDataSource, CompPlugin14180OptionsViewDelegate {
//
//    // MARK: 本组件坑位字号边距统一收口
//    static func itemSelectedFont() -> UIFont {
//        return YKNFont.module_headline_linktext_weight(.medium)
//    }
//
//    static func itemUnselectedFont() -> UIFont {
//        return YKNFont.module_headline_linktext_weight(.regular)
//    }
//
//    static func itemPadding() -> UIEdgeInsets {
//        let horizontal = YKNGap.dim_7()
//        let vertical = YKNGap.dim_5()
//        return UIEdgeInsets.init(top: vertical, left: horizontal, bottom: vertical, right: horizontal)
//    }
//
//    // MARK: 私有变量
//    var config = LaneGroupConfig()
//    var itemContainer: CompPlugin14180Container?
//
//    // MARK: - 事件映射定义与实现
//    override class func scEventHandlerInfo() -> [Any]! {
//        return [
//            [
//                "event":        YKSCComponentEventParseData,
//                "selector":     "receiveParseData:",
//            ],
//            [
//                "event":        YKSCComponentEventInit,
//                "selector":     "receiveInit:",
//            ],
//            [
//                "event":        YKSCComponentEventQueryItemCount,
//                "selector":     "receiveContainerQueryItemCount:",
//            ],
//            [
//                "event":        YKSCComponentEventQueryItemHeight,
//                "selector":     "receiveContainerQueryItemHeight:",
//            ],
//            [
//                "event":        YKSCComponentEventQueryItemReuseId,
//                "selector":     "receiveContainerQueryItemReuseId:",
//            ],
//            [
//                "event":        YKSCComponentEventQueryItemView,
//                "selector":     "receiveQueryItemView:",
//            ],
//            [
//                "event":        YKSCComponentEventReuseItemView,
//                "selector":     "receiveReuseView:",
//            ],
//        ]
//    }
//
//    func receiveParseData(_ event: YKSCEvent) {
//        scSetData(1, forKey: YKSCComponentDataLayoutColumnCount)
//    }
//
//    func receiveInit(_ event: YKSCEvent) {
//        var config = LaneGroupConfig()
//        config.cellClassIdentifier = LaneCellClassIdentifier.init(class: CompPlugin14180ItemView.self, identifier: "CompPlugin14180ItemView-Reuse")
//        config.numberOfLanes = UInt(scItemContexts?.count ?? 0)
//
//        let itemPadding = CompPlugin14180.itemPadding()
//        var aLaneHeight = calcStringSize("Ag", font: CompPlugin14180.itemSelectedFont(), size: CGSize.init(width: 1_0000, height: 1_000)).height
//        aLaneHeight += itemPadding.top + itemPadding.bottom
//        aLaneHeight = floor(aLaneHeight)
//        config.aLaneHeight = aLaneHeight
//
//        config.laneSpacing = YKNGap.dim_5()
//        config.itemSpacing = 0
//        config.margin = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: 0, right: YKNGap.youku_margin_right())
//        config.selectedIndictorBorderWidth = 0.5
//        config.selectedIndictorBorderColor = UIColor.ykn_border
//
//        if let selectedColor = scPageContext?.sceneOptionButtonSelectedTextColor() {
//            config.selectedIndictorBackgroundColor = UIColor.clear
//        } else {
//            config.selectedIndictorBackgroundColor = UIColor.ykn_buttonFill
//        }
//
//        self.config = config
//
//        // 创建子坑位context
//        if let scItemContexts = scItemContexts as? [YKSCItemContext] {
//            for itemContext in scItemContexts {
//                if let subitemJSONs = itemContext.model.extraExtend["subitemJSONs"] as? [[String: Any]] {
//                    let subitemContexts = createItemContextWithItemsInfo(subitemJSONs)
//                    itemContext.model.extraExtend["subitemContexts"] = subitemContexts
//                }
//            }
//        }
//    }
//
//    func receiveContainerQueryItemCount(_ event: YKSCEvent) {
//        event.responseInfo.setValue(1, forKey: "itemCount")
//    }
//
//    func receiveContainerQueryItemHeight(_ event: YKSCEvent) {
//        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
//        let itemHeight = config.sizeThatFits(CGSize.init(width: itemWidth, height: 1_000_000)).height
//        event.responseInfo.setValue(NSNumber(value: Double(itemHeight)), forKey: "itemHeight")
//    }
//
//    func receiveContainerQueryItemReuseId(_ event: YKSCEvent) {
//        event.responseInfo.setValue(String("CompPlugin14180-ReuseId"), forKey: "reuseId")
//    }
//
//    func receiveQueryItemView(_ event: YKSCEvent) {
//        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
//        let itemHeight: Double = (event.params?["itemHeight"] as? NSNumber)?.doubleValue ?? 0
//
//        //注意: 布局初始化按首次渲染数据进行，目前不存在复用时修改布局的情况。
//        let laneGroupView = LaneGroupView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight), laneGroupConfig: self.config)
//        laneGroupView.tag = 202111303
//
//        let optionsView = CompPlugin14180OptionsView.init(frame: CGRect.init(x: 0, y: 0, width: itemWidth, height: 40.0))
//        optionsView.tag = 202111304
//
//        let itemContainer = CompPlugin14180Container.init(frame: laneGroupView.frame)
//        itemContainer.addSubview(laneGroupView)
//        itemContainer.laneGroupView = laneGroupView
//        itemContainer.optionsView = optionsView
//        self.itemContainer = itemContainer
//
//        event.responseInfo.setValue(itemContainer, forKey:"itemView")
//    }
//
//    func receiveReuseView(_ event: YKSCEvent) {
//        guard let itemContainer = event.params?["itemView"] as? CompPlugin14180Container else {
//            return
//        }
//        guard let laneGroupView = itemContainer.laneGroupView else {
//            return
//        }
//        guard let optionsView = itemContainer.optionsView else {
//            return
//        }
//        self.itemContainer = itemContainer
//
//        // work around 转屏时重置宽度，默认取vc宽, reuse 需要同步原尺寸
//        laneGroupView.width = itemContainer.bounds.width
//        laneGroupView.apply(self.config)
//        optionsView.width = itemContainer.bounds.width
//
//        laneGroupView.delegate = self
//        laneGroupView.dataSource = self
//        laneGroupView.reloadData()
//
//        optionsView.delegate = self
//        resetOptionView()
//
//        scSetWeakData(itemContainer, forKey: "yksc.data.comp.14180.weak.container")
//        scSetWeakData(laneGroupView, forKey: "yksc.data.comp.14180.weak.laneGroupView")
//        scSetWeakData(optionsView, forKey: "yksc.data.comp.14180.weak.optionsView")
//    }
//
//    func resetOptionView() {
//        guard let optionsView = itemContainer?.optionsView else {
//            return
//        }
//        guard let scItemContexts = scItemContexts as? [YKSCItemContext] else {
//            optionsView.setOptionsText("筛选")
//            return
//        }
//
//        var titles = [String]()
//        for scItemContext in scItemContexts {
//            if let selectedIndex = scItemContext.model.extraExtend["selectedIndex"] as? Int,
//               let subitemContexts = scItemContext.model.extraExtend["subitemContexts"] as? [YKSCItemContext],
//               selectedIndex < subitemContexts.count {
//
//                if selectedIndex == 0 && scItemContext != scItemContexts.last {
//                    continue
//                }
//
//                if let title = subitemContexts[selectedIndex].model.title, !title.isEmpty {
//                    titles.append(title)
//                }
//            }
//        }
//
//        let text = titles.joined(separator: "·")
//        optionsView.setOptionsText(text)
//    }
//
//    // MARK: - LaneGroupViewDataSource
//    func laneGroupView(_ laneGroupView: LaneGroupView, numberOfItemsInLaneIndex laneIndex: Int) -> Int {
//        guard let scItemContexts = scItemContexts as? [YKSCItemContext],
//              laneIndex < scItemContexts.count,
//              let subitemContexts = scItemContexts[laneIndex].model.extraExtend["subitemContexts"] as? [YKSCItemContext]
//        else {
//            return 0
//        }
//
//        return subitemContexts.count
//    }
//
//    // MARK: - LaneGroupViewDelegate
//    func laneGroupView(_ laneGroupView: LaneGroupView, selectedItemAtLaneIndex laneIndex: Int) -> Int {
//        guard let scItemContexts = scItemContexts as? [YKSCItemContext],
//              laneIndex < scItemContexts.count,
//              let selectedIndex = scItemContexts[laneIndex].model.extraExtend["selectedIndex"] as? Int
//        else {
//            return 0
//        }
//
//        return selectedIndex
//    }
//
//    func laneGroupView(_ laneGroupView: LaneGroupView, widthForItemAt indexPath: IndexPath) -> CGFloat {
//        guard let scItemContexts = scItemContexts as? [YKSCItemContext], indexPath.section < scItemContexts.count else {
//            return 0
//        }
//
//        let itemContext = scItemContexts[indexPath.section]
//
//        guard let subitemContexts = itemContext.model.extraExtend["subitemContexts"] as? [YKSCItemContext],
//              indexPath.row < subitemContexts.count
//        else {
//            return 0
//        }
//
//        let subitemContext = subitemContexts[indexPath.row]
//        return subitemContext.layoutModel.renderRect.size.width ?? 0
//    }
//
//    func laneGroupView(_ laneGroupView: LaneGroupView, didSelectItemAt indexPath: IndexPath) {
//        guard let scItemContexts = scItemContexts as? [YKSCItemContext], indexPath.section < scItemContexts.count else {
//            return
//        }
//
//        let itemContext = scItemContexts[indexPath.section]
//
//        guard let subitemContexts = itemContext.model.extraExtend["subitemContexts"] as? [YKSCItemContext],
//              indexPath.row < subitemContexts.count
//        else {
//            return
//        }
//
//        let subitemContext = subitemContexts[indexPath.row]
//        let title = subitemContext.model.title ?? ""
//        let filterStatement = subitemContext.model.extraExtend["filterStatement"] as? String ?? ""
//
//        // 记录选中索引
//        itemContext.model.extraExtend["selectedIndex"] = indexPath.row
//
//        laneGroupView.scrollToItem(at: indexPath, animated: true)
//        if let cell = laneGroupView.cellForItem(at: indexPath) as? CompPlugin14180ItemView {
//            cell.drawSelectedStyle(textColor: sceneUtil(nil, sceneColor: scPageContext?.sceneOptionButtonSelectedTextColor()))
//        }
//        reloadCardData()
//        resetOptionView()
//        redirectToCardIfNeeded(laneGroupView)
//    }
//
//    func laneGroupView(_ laneGroupView: LaneGroupView, didDeselectItemAt indexPath: IndexPath) {
//        if let cell = laneGroupView.cellForItem(at: indexPath) as? CompPlugin14180ItemView {
//            cell.drawDeselectedStyle(textColor: sceneUtil(nil, sceneColor: scPageContext?.sceneOptionButtonUnselectedTextColor()))
//        }
//    }
//
//    // MARK: - LaneGroupViewDataSource
//    func laneGroupView(_ laneGroupView: LaneGroupView, cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
//        guard let cell = cell as? CompPlugin14180ItemView else {
//            return
//        }
//
//        guard let scItemContexts = scItemContexts as? [YKSCItemContext], indexPath.section < scItemContexts.count else {
//            return
//        }
//
//        let itemContext = scItemContexts[indexPath.section]
//
//        guard let subitemContexts = itemContext.model.extraExtend["subitemContexts"] as? [YKSCItemContext],
//              indexPath.row < subitemContexts.count
//        else {
//            return
//        }
//
//        let subitemContext = subitemContexts[indexPath.row]
//        cell.fillData(subitemContext.model.title ?? "")
//
//        let selectedIndex = itemContext.model.extraExtend["selectedIndex"] as? Int ?? 0
//        if selectedIndex == indexPath.row {
//            cell.drawSelectedStyle(textColor: sceneUtil(nil, sceneColor: scPageContext?.sceneOptionButtonSelectedTextColor()))
//        } else {
//            cell.drawDeselectedStyle(textColor: sceneUtil(nil, sceneColor: scPageContext?.sceneOptionButtonUnselectedTextColor()))
//        }
//
//        Service.statistics.bind(subitemContext.model.action?.report, cell, .Defalut)
//    }
//
//    private func createItemContextWithItemsInfo(_ itemsInfo: [[String: Any]]) -> [YKSCItemContext] {
//        var itemsContexts = [YKSCItemContext]()
//        var params = [String: Any]()
//        params["itemsInfo"] = itemsInfo
//        let responseInfo = self.scFireEvent(YKSCComponentEventCreateItemsModule, params: params)
//        let itemContexts = responseInfo?["itemContexts"] as? [YKSCItemContext] ?? [YKSCItemContext]()
//        return itemContexts
//    }
//
//    private func updateCardFirstPageRequestParams() {
//        guard let scCardContext = scCardContext,
//              let scComponentContext = scComponentContext,
//              let scItemContexts = scItemContexts as? [YKSCItemContext]
//        else {
//            return
//        }
//
//        var filterParts = [String]()
//        for itemContext in scItemContexts {
//            let selectedIndex = itemContext.model.extraExtend["selectedIndex"] as? Int ?? 0
//            if let subitemContexts = itemContext.model.extraExtend["subitemContexts"] as? [YKSCItemContext],
//               selectedIndex < subitemContexts.count {
//                let selectedSubitemContext = subitemContexts[selectedIndex]
//                if let filterStatement = selectedSubitemContext.model.extraExtend["filterStatement"] as? String,
//                   filterStatement.isEmpty == false {
//                    filterParts.append(filterStatement)
//                }
//            }
//        }
//        let filter = filterParts.joined(separator: "|")
//
//        var extentParams = scCardContext.scData(forKey: "yksc.data.card.prop.cms.firstPageRequest.extendParams") as? [String: Any] ?? [String: Any]()
//        extentParams["filterParam"] = filter
//        scCardContext.scSetData(extentParams, forKey: "yksc.data.card.prop.cms.firstPageRequest.extendParams")
//    }
//
//    private func reloadCardData() {
//        updateCardFirstPageRequestParams()
//        scCardContext?.scFireEvent(YKSCCardEventSendFirstPageRequest, params: nil)
//    }
//
//    private func redirectToCardIfNeeded(_ laneGroupView: LaneGroupView) {
//        if laneGroupView.superview == itemContainer {
//            return
//        }
//
//        guard let scPageContext = scPageContext else {
//            return
//        }
//
//        guard let scComponentContext = scComponentContext else {
//            return
//        }
//
//        scPageContext.scFireEvent(YKSCPageEventTriggerContainerScroll, params: ["componentContext": scComponentContext, "offsetY": -9.0])
//    }
//
//    //MARK: CompPlugin14180OptionsViewDelegate
//    func optionsViewDidClick(optionsView: CompPlugin14180OptionsView) {
//        if let superviewOfOptionsView = optionsView.superview,
//           let laneGroupView = itemContainer?.laneGroupView {
//            optionsView.removeFromSuperview()
//
//            let paddingVertical = 9.0
//
//            var laneGroupframe = laneGroupView.frame
//            laneGroupframe.origin.y = paddingVertical
//            laneGroupView.frame = laneGroupframe
//            superviewOfOptionsView.addSubview(laneGroupView)
//
//            var frame = superviewOfOptionsView.frame
//            frame.size.height = laneGroupView.bounds.size.height + paddingVertical * 2
//            superviewOfOptionsView.frame = frame
//        }
//    }
//}
