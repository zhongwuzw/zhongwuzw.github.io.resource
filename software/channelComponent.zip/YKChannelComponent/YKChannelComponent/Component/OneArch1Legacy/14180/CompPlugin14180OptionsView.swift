//
//  CompPlugin14180OptionsView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/12/1.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YoukuResource

protocol CompPlugin14180OptionsViewDelegate: AnyObject {
    func optionsViewDidClick(optionsView: CompPlugin14180OptionsView)
}

class CompPlugin14180OptionsView: UIView {
    
    private lazy var textLabel: UILabel = {
        let view = UILabel()
        view.backgroundColor = .clear
        view.font = .systemFont(ofSize: 14)
        view.textColor = UIColor.ykn_primaryInfo
        view.textAlignment = .center
        view.isUserInteractionEnabled = true
        return view
    }()

    private lazy var indicatorView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.isUserInteractionEnabled = false
        view.clipsToBounds = true
        view.tintColor = UIColor.ykn_primaryInfo
        let image = UIImage.init(named: "channel_game_rank")?.withRenderingMode(.alwaysTemplate)
        view.image = image
        return view
    }()
    
    private lazy var separatorView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.init(white: 0, alpha: 0.06)
        return view
    }()
    
    public weak var delegate: CompPlugin14180OptionsViewDelegate?
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        
        let tapGesture = UITapGestureRecognizer.init(target: self, action: #selector(didClick))
        addGestureRecognizer(tapGesture)
        
        addSubview(textLabel)
        addSubview(indicatorView)
        addSubview(separatorView)
    }
    
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func useMoreViewStyle() {
        textLabel.textColor = UIColor.ykn_tertiaryInfo
        indicatorView.tintColor = UIColor.ykn_tertiaryInfo
        separatorView.isHidden = true
    }
    
    public override func layoutSubviews() {
        let cellWidth = self.frame.width
        let cellHeight = self.frame.height
        
        let textSize = textLabel.sizeThatFits(CGSize.init(width: cellWidth, height: cellHeight))
        let width = ceil(textSize.width)
        let height = ceil(textSize.height)
        
        textLabel.frame = CGRect.init(x: (cellWidth - width)/2, y: (cellHeight - height)/2, width: width, height: height)
        indicatorView.frame = CGRect.init(x: textLabel.frame.maxX, y: (cellHeight - 15)/2, width: 15, height: 15)
        separatorView.frame = CGRect.init(x: 0, y: cellHeight - 0.5, width: cellWidth, height: 0.5)
    }
    
    public func setOptionsText(_ text: String) {
        textLabel.text = text
        setNeedsLayout()
        layoutIfNeeded()
    }
    
    @objc func didClick() {
        self.delegate?.optionsViewDidClick(optionsView: self)
    }
}
