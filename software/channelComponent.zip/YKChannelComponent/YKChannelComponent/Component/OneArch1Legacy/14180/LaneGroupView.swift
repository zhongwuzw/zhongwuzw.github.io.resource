//
//  LaneGroupView.swift
//  LaneGroupView
//
//  Created by dylanlai on 2021/8/24.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit

class LaneView: UICollectionView {
    
    var initialSetupPerformed: Bool = false
    var initialSelectedIndexPath: IndexPath?
    lazy var selectedIndicator: UIView = {
        let view = UIView()
        view.tag = 2021818999
        return view
    }()
    
    override init(frame: CGRect, collectionViewLayout layout: UICollectionViewLayout) {
        super.init(frame: frame, collectionViewLayout: layout)
        backgroundColor = .clear
        showsHorizontalScrollIndicator = false
        showsVerticalScrollIndicator = false
        alwaysBounceHorizontal = true
        addSubview(selectedIndicator)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func tag(for index: UInt) -> NSInteger {
        return NSInteger(2021818000 + index)
    }
    
    func index() -> UInt {
        return UInt(tag - 2021818000)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()

        if !initialSetupPerformed && initialSelectedIndexPath != nil {
            selectItem(at: initialSelectedIndexPath, animated: false, scrollPosition: .centeredHorizontally)
            initialSetupPerformed = true
        }
    }
    
    override func selectItem(at indexPath: IndexPath?, animated: Bool, scrollPosition: UICollectionView.ScrollPosition) {
        super.selectItem(at: indexPath, animated: animated, scrollPosition: scrollPosition)
        updateSelectedIndicator(at: indexPath, animated: animated)
    }
    
    func updateSelectedIndicator(at indexPath: IndexPath?, animated: Bool) {
        guard let indexPath = indexPath,
              let attr = self.layoutAttributesForItem(at: indexPath)
        else {
            selectedIndicator.isHidden = true
            return
        }
        
        if !initialSetupPerformed && initialSelectedIndexPath != nil && initialSelectedIndexPath != indexPath {
            initialSelectedIndexPath = indexPath
        }
        
        selectedIndicator.isHidden = false
        sendSubviewToBack(selectedIndicator)
        
        let frameUpdating = { (frame: CGRect) -> Void in
            self.selectedIndicator.frame = frame
            self.selectedIndicator.layer.cornerRadius = frame.height / 2
        }
        
        if animated {
            UIView.animate(withDuration: 0.25) {
                frameUpdating(attr.frame)
            }
        } else {
            frameUpdating(attr.frame)
        }
    }
}

public class LaneGroupView: UIView, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {
    
    public private(set) var config = LaneGroupConfig()
    
    weak public var delegate: LaneGroupViewDelegate?
    
    weak public var dataSource: LaneGroupViewDataSource?
    
    private var laneViews = Array<LaneView>()
    
    open override var tag: Int {
        didSet {
            //work around，设备转屏时，来自底层库（YKChannelPage）将该view 重设tag时，以便更新布局。
            self.apply(self.config)
            self.reloadData()
        }
    }
    
    @available(*, unavailable, renamed: "init(frame:laneGroupConfig:)")
    public init() {
        fatalError("init() has not been implemented")
    }
    
    @available(*, unavailable, renamed: "init(frame:laneGroupConfig:)")
    public override init(frame: CGRect) {
        fatalError("init(frame:) has not been implemented")
    }
    
    @available(*, unavailable, renamed: "init(frame:laneGroupConfig:)")
    public required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public init(frame: CGRect, laneGroupConfig config: LaneGroupConfig) {
        super.init(frame: frame)
        clipsToBounds = true
        apply(config)
    }
    
    public func apply(_ config: LaneGroupConfig) {
        self.config = config
        
        // 重新创新LaneViews
        for aLaneView in laneViews {
            aLaneView.removeFromSuperview()
        }
        
        laneViews = Array<LaneView>()
        let aLaneViewSize = CGSize.init(width: bounds.size.width, height: config.aLaneHeight)
        let xCursor: CGFloat = 0
        var yCursor: CGFloat = config.margin.top
        for index in 0..<config.numberOfLanes {
            let aLaneView = createLandView(frame: CGRect.init(origin: CGPoint.init(x: xCursor, y: yCursor), size: aLaneViewSize), index: index)
            laneViews.append(aLaneView)
            addSubview(aLaneView)
            yCursor = yCursor + config.aLaneHeight + config.laneSpacing
        }
    }
    
    public func reloadData() {
        for (sectionIndex, aLaneView) in laneViews.enumerated() {
            aLaneView.reloadData()
            if let itemIndex = delegate?.laneGroupView(self, selectedItemAtLaneIndex: sectionIndex) {
                let itemCount = aLaneView.numberOfItems(inSection:0)
                if itemIndex < itemCount {
                    let indexPath = IndexPath.init(item: itemIndex, section: 0)
                    aLaneView.selectItem(at: indexPath, animated: false, scrollPosition: .centeredHorizontally)
                }
            }
        }
    }
    
    public override func sizeThatFits(_ size: CGSize) -> CGSize {
        return config.sizeThatFits(size)
    }
    
    public func selectItem(at indexPath: IndexPath?, animated: Bool, scrollPosition: UICollectionView.ScrollPosition) {
        guard let indexPath = indexPath else {
            return
        }
        
        let laneIndex = indexPath.section
        guard laneIndex < laneViews.count else {
            return
        }
        
        let laneView = laneViews[laneIndex]
        let itemCount = laneView.numberOfItems(inSection:0)
        if indexPath.item < itemCount {
            laneView.selectItem(at: IndexPath.init(item: indexPath.item, section: 0), animated: animated, scrollPosition: scrollPosition)
        }
    }
    
    public func scrollToItem(at indexPath: IndexPath, animated: Bool) {
        let laneIndex = indexPath.section
        guard laneIndex < laneViews.count else {
            return
        }
        
        let laneView = laneViews[laneIndex]
        let itemCount = laneView.numberOfItems(inSection:0)
        if indexPath.item < itemCount {
            laneView.scrollToItem(at: IndexPath.init(item: indexPath.item, section: 0), at: .centeredHorizontally, animated: animated)
        }
    }
    
    public func cellForItem(at indexPath: IndexPath) -> UICollectionViewCell? {
        let laneIndex = indexPath.section
        guard laneIndex < laneViews.count else {
            return nil
        }
        
        let laneView = laneViews[laneIndex]
        return laneView.cellForItem(at: IndexPath.init(item: indexPath.item, section: 0))
    }
    
    private func createLandView(frame: CGRect, index: UInt) -> LaneView {
        let layout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        layout.minimumInteritemSpacing = config.itemSpacing
        layout.minimumLineSpacing = 0
        let aLaneView = LaneView.init(frame: frame, collectionViewLayout: layout)
        aLaneView.tag = aLaneView.tag(for: index)
        aLaneView.delegate = self
        aLaneView.dataSource = self
        aLaneView.register(config.cellClassIdentifier.class, forCellWithReuseIdentifier: config.cellClassIdentifier.identifier)
        if config.defaultSelected {
            aLaneView.initialSelectedIndexPath = IndexPath.init(item: 0, section: 0)
        }
        aLaneView.selectedIndicator.isHidden = !config.showsSelectedIndictor
        aLaneView.selectedIndicator.layer.borderColor = config.selectedIndictorBorderColor.cgColor
        aLaneView.selectedIndicator.layer.borderWidth = config.selectedIndictorBorderWidth
        aLaneView.selectedIndicator.backgroundColor = config.selectedIndictorBackgroundColor
        aLaneView.contentInset = UIEdgeInsets.init(top: 0, left: config.margin.left, bottom: 0, right: config.margin.right)
        return aLaneView
    }
    
    public override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        super.traitCollectionDidChange(previousTraitCollection)
        
        for laneView in laneViews {
            laneView.selectedIndicator.layer.borderColor = config.selectedIndictorBorderColor.cgColor
        }
    }
    
    // MARK: UICollectionViewDataSource
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        guard let laneView = collectionView as? LaneView else {
            return 0
        }
        
        let laneIndex = laneView.index()
        let count = dataSource?.laneGroupView(self, numberOfItemsInLaneIndex: Int(laneIndex)) ?? 0
        return count
    }
    
    // MARK: UICollectionViewDelegateFlowLayout
    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        guard let laneView = collectionView as? LaneView else {
            return .zero
        }
        
        let laneIndex = laneView.index()
        let cellIndex = indexPath.item
        let externalIndexPath = IndexPath.init(item: cellIndex, section: Int(laneIndex))
        let width = delegate?.laneGroupView(self, widthForItemAt: externalIndexPath) ?? 0.0
        return CGSize.init(width: width, height: collectionView.bounds.height)
    }
    
    public func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard let laneView = collectionView as? LaneView else {
            return
        }
        
        let laneIndex = laneView.index()
        let cellIndex = indexPath.item
        let externalIndexPath = IndexPath.init(item: cellIndex, section: Int(laneIndex))
        laneView.updateSelectedIndicator(at: indexPath, animated: true)
        delegate?.laneGroupView(self, didSelectItemAt: externalIndexPath)
    }
    
    public func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        guard let laneView = collectionView as? LaneView else {
            return
        }
        
        let laneIndex = laneView.index()
        let cellIndex = indexPath.item
        let externalIndexPath = IndexPath.init(item: cellIndex, section: Int(laneIndex))
        delegate?.laneGroupView(self, didDeselectItemAt: externalIndexPath)
    }
    
    // MARK: UICollectionViewDataSource
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        print("[14180] cellForItemAt:\(indexPath)")
        guard let laneView = collectionView as? LaneView else {
            return UICollectionViewCell.init()
        }
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: config.cellClassIdentifier.identifier, for: indexPath)
        
        let laneIndex = laneView.index()
        let cellIndex = indexPath.item
        let externalIndexPath = IndexPath.init(item: cellIndex, section: Int(laneIndex))
                
        dataSource?.laneGroupView(self, cell: cell, forItemAt: externalIndexPath)
        
        return cell
    }
    
    public func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        guard let laneView = collectionView as? LaneView else {
            return
        }
        
        let laneIndex = laneView.index()
        let cellIndex = indexPath.item
        let externalIndexPath = IndexPath.init(item: cellIndex, section: Int(laneIndex))
        delegate?.laneGroupView(self, willDisplay: cell, indexPath: externalIndexPath)
    }
}

public protocol LaneGroupViewDataSource: NSObjectProtocol {
    
    func laneGroupView(_ laneGroupView: LaneGroupView, cell: UICollectionViewCell, forItemAt indexPath: IndexPath)
    
    func laneGroupView(_ laneGroupView: LaneGroupView, numberOfItemsInLaneIndex laneIndex: Int) -> Int
    
}

public protocol LaneGroupViewDelegate: NSObjectProtocol {
    
    func laneGroupView(_ laneGroupView: LaneGroupView, selectedItemAtLaneIndex laneIndex: Int) -> Int
    
    func laneGroupView(_ laneGroupView: LaneGroupView, widthForItemAt indexPath: IndexPath) -> CGFloat
    
    func laneGroupView(_ laneGroupView: LaneGroupView, didSelectItemAt indexPath: IndexPath)
    
    func laneGroupView(_ laneGroupView: LaneGroupView, didDeselectItemAt indexPath: IndexPath)
    
    func laneGroupView(_ laneGroupView: LaneGroupView, willDisplay cell: UICollectionViewCell, indexPath: IndexPath)
}

public struct LaneCellClassIdentifier {
    public let `class`: AnyClass
    public let identifier: String
}

public struct LaneGroupConfig {
    
    /// Cell Class-Identifier
    public var cellClassIdentifier: LaneCellClassIdentifier = LaneCellClassIdentifier.init(class: UICollectionViewCell.self, identifier: "Identifier")
    
    /// 默认选中开关
    public var defaultSelected: Bool = true
    
    /// 选中项指示器展示
    public var showsSelectedIndictor: Bool = true
    
    /// 选中项指示器边框颜色
    public var selectedIndictorBorderColor: UIColor = .red
    
    /// 选中项指示器边框宽度
    public var selectedIndictorBorderWidth: CGFloat = 1
    
    /// 选中项指示器背景颜色
    public var selectedIndictorBackgroundColor: UIColor = .gray
    
    /// 行数
    public var numberOfLanes: UInt = 2
    
    /// 每行高度
    public var aLaneHeight: CGFloat = 30
    
    /// 边距
    public var margin: UIEdgeInsets = UIEdgeInsets.init(top: 5, left: 5, bottom: 5, right: 5)
    
    /// 行间距
    public var laneSpacing: CGFloat = 9
    
    /// 元素间距
    public var itemSpacing: CGFloat = 6
    
    /// 渲染尺寸
    public func sizeThatFits(_ size: CGSize) -> CGSize {
        var renderHeight: CGFloat = 0.0
        if numberOfLanes > 0 {
            renderHeight += (margin.top + margin.bottom)
            renderHeight += (CGFloat(numberOfLanes) * aLaneHeight)
            if numberOfLanes > 1 {
                renderHeight += (CGFloat(numberOfLanes - 1) * laneSpacing)
            }
        }

        var fitSize = CGSize.init()
        fitSize.width = size.width
        fitSize.height = min(size.height, renderHeight)
        return fitSize
    }
}

