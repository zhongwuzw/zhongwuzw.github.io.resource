////
////  ItemPlugin14180.swift
////  ItemPlugin14180
////
////  Created by dylanlai on 2021/8/24.
////  Copyright © 2021 Youku. All rights reserved.
////
//
//import UIKit
//import YKSCBase
//import YoukuResource
//import YKChannelBase
//
//@objcMembers
//class ItemPlugin14180: YKSCItemPlugin {
//
//    override class func scEventHandlerInfo() -> [Any]! {
//        return [
//            [
//                "event":        YKSCItemEventParseData,
//                "selector":     "receiveParseData:",
//            ]
//        ]
//    }
//
//    func receiveParseData(_ event: YKSCEvent) {
//        guard let itemInfo = event.params?["itemInfo"] as? [String: Any],
//              let scItemContext = scItemContext
//        else {
//            return
//        }
//
//        let model = scItemContext.model
//        let layoutModel = scItemContext.layoutModel
//
//        // 计算title渲染尺寸
//        if let title = model.title {
//            var size = calcStringSize(title, font:CompPlugin14180.itemSelectedFont(), size: CGSize.init(width: 1_000, height: 1_000))
//            let padding = CompPlugin14180.itemPadding()
//
//            size.width += padding.left + padding.right
//            size.width = floor(size.width)
//
//            size.height += padding.top + padding.bottom
//            size.height = floor(size.height)
//            layoutModel.renderRect = CGRect.init(origin: CGPoint.init(x: 0, y: 0), size: size)
//        }
//
//        // 存储子坑位JSON
//        if let subitemsInfo = itemInfo["nodes"] as? [[String: Any]] {
//            model.extraExtend["subitemJSONs"] = subitemsInfo
//        }
//
//        // 筛选条件
//        if let itemData = itemInfo["data"] as? [String: Any],
//           let filterType = itemData["filterType"] as? String,
//           let filterValue = itemData["value"] as? String,
//           filterType.count() > 0 && filterValue.count() > 0 {
//            model.extraExtend["filterStatement"] = "\(filterType):\(filterValue)"
//        }
//
//        // 默认筛选项
//        model.extraExtend["selectedIndex"] = 0
//    }
//
//}
