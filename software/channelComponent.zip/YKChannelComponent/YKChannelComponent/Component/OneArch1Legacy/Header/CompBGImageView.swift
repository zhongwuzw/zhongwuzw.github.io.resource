////
////  CompBGImageView.swift
////  YKChannelComponent
////
////  Created by better on 2021/4/2.
////  Copyright © 2021 Youku. All rights reserved.
////
//
//import UIKit
//import YKSCBase
//import YoukuResource
//
//class CompBGImageView: UIImageGIFView {
//
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        self.contentMode = .scaleAspectFill
//        self.clipsToBounds = true
//    }
//    
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//
//    func setData(_ imgPath: String?, compSize: CGSize) {
//        self.frame = .zero
//        weak var weakself = self
//        self.ykn_setImage(withURLString: imgPath ?? "",
//                          module: "",
//                          imageSize: CGSize.init(width: compSize.width*3, height: compSize.height*3),
//                          parameters: ["placeholderColor":UIColor.clear]) { (image: UIImage?, _: Error?, _: [AnyHashable : Any]?) in
//            if let weakself = weakself, let image = image, image.size.width > 0 {
//                let imgHeight = min(compSize.height, compSize.width * image.size.height/image.size.width)
//                weakself.frame = CGRect.init(x: 0, y: 0, width: compSize.width, height: imgHeight)
//                let maskPath = UIBezierPath.init(roundedRect: weakself.bounds, byRoundingCorners: UIRectCorner(rawValue: UIRectCorner.topLeft.rawValue + UIRectCorner.topRight.rawValue), cornerRadii: CGSize(width: YKNCorner.radius_medium(), height: YKNCorner.radius_medium()))
//                let maskLayer = CAShapeLayer.init()
//                maskLayer.frame = weakself.bounds
//                maskLayer.path = maskPath.cgPath
//                weakself.layer.mask = maskLayer
//            }
//        }
//    }
//}
