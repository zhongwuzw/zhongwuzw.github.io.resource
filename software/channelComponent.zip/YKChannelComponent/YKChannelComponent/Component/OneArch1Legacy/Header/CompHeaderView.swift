////
////  ComponnetHeader.swift
////  YKChannelComponent
////
////  Created by better on 2021/4/1.
////  Copyright © 2021 Youku. All rights reserved.
////
//
//import UIKit
//import YoukuResource
//import YKChannelBase
//
//class CompHeaderView: UIView {
//
//    var layoutModel: LayoutModel?
//
//    //MARK: - Property
//    lazy var titleLabel: UILabel = {
//        let label = UILabel.init(frame: CGRect.init(x: YKNGap.dim_6(), y: YKNGap.dim_7(), width: 180, height: 22))
//        label.textColor = UIColor.ykn_primaryInfo
//        label.font = YKNFont.module_headline_weight(YKNFontWeight.semibold)
//        return label
//    }()
//
//    lazy var subtitleLabel: UILabel = {
//        let label = UILabel.init(frame: CGRect.init(x: titleLabel.left, y: titleLabel.bottom + YKNGap.dim_1(), width: 180, height: 16))
//        label.font = YKNFont.tertiary_auxiliary_text()
//        label.textColor = UIColor.ykn_tertiaryInfo
//        return label
//    }()
//
//    lazy var arrowIcon: UIImageGIFView = {
//        let imageView = UIImageGIFView.init(frame: CGRect.init(x: titleLabel.right + YKNGap.dim_1(), y: titleLabel.centerY - 8, width: 16.0, height: 16.0))
//        imageView.image = UIImage.init(named: "ic_home_comp_title_arrow")?.withRenderingMode(.alwaysTemplate)
//        imageView.tintColor = UIColor.ykn_primaryInfo
//        imageView.clipsToBounds = true
//        imageView.contentMode = .scaleAspectFill
//        return imageView
//    }()
//    
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        self.addSubview(titleLabel)
//        self.addSubview(subtitleLabel)
//        self.addSubview(arrowIcon)
//    }
//
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
//    func setModel(_ model: BaseComponentModel?, _ layoutModel: LayoutModel?, width: CGFloat, compContext: YKSCComponentContext?) {
//        
//        self.isHidden = isStringEmpty(model?.title)
//
//        guard let model = model, let layoutModel = layoutModel else {
//            return
//        }
//                
//        // bind action
//        Service.action.bind(model.action, self)
//        self.arrowIcon.isHidden = (model.action == nil)
//
//        // fill data
//        self.titleLabel.text = model.title
//        self.subtitleLabel.text = model.subTitle
//
//        // layout
//        self.width = width
//        self.height = layoutModel.renderRect.height
//        
//        let maxX = self.width - 30
//        var titleWidth = maxX - self.arrowIcon.width - YKNGap.dim_3() - self.titleLabel.left
//        if let size = layoutModel.title?.boundingSize {
//            if titleWidth > size.width {
//                titleWidth = size.width
//            }
//        }
//        self.titleLabel.width = titleWidth
//        if let titleModel = layoutModel.title {
//            self.titleLabel.height = titleModel.boundingSize?.height ?? 22
//            self.titleLabel.font = titleModel.font
//        }
//
//        self.arrowIcon.frame = CGRect.init(x: titleLabel.right + YKNGap.dim_1(), y: titleLabel.centerY - 8, width: 16.0, height: 16.0)
//        self.subtitleLabel.frame = CGRect.init(x: titleLabel.left, y: titleLabel.bottom + YKNGap.dim_1(), width: self.width, height: layoutModel.subtitle?.boundingSize?.height ?? 16)
//
//        //color
//        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: compContext?.sceneTitleColor())
//        self.subtitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: compContext?.sceneSubTitleColor())
//        self.arrowIcon.tintColor = sceneUtil(.ykn_primaryInfo, sceneColor: compContext?.sceneTitleColor())
//        self.backgroundColor = .clear// sceneUtil(UIColor.clear, sceneColor: compContext?.sceneBgColor())
//    }
//
//    static func calcHeaderLayoutModel(_ context: YKSCComponentContext?) {
//        guard let context = context else {
//            return
//        }
//        
//        let model: BaseComponentModel? = context.model
//        
//        let titleLayout = TextLayoutModel.init()
//        titleLayout.font = context.module_headline_weight(.medium)
//        var boundSize = calcStringSize(model?.title, font: titleLayout.font, size: CGSize.init(width: 1000, height: 22))
//        if boundSize.height < 22 {
//            boundSize.height = 22
//        }
//        titleLayout.boundingSize = boundSize
//        context.layoutModel.title = titleLayout
//
//        let subTitleLayout = TextLayoutModel.init()
//        subTitleLayout.font = context.posteritem_auxiliary_text()
//        if let subtitleFont = subTitleLayout.font {
//            subTitleLayout.boundingSize = CGSize.init(width: 0, height: max(YKNFont.height(with: subtitleFont, lineNumber: 1), 14))
//        }
//        context.layoutModel.subtitle = subTitleLayout
//        
//        context.layoutModel.renderRect = CGRect.init(x: 0, y: 0, width: 0, height: calcHeaderHeight(model, context.layoutModel))
//    }
//
//    private static func calcHeaderHeight(_ model: BaseComponentModel?, _ layoutModel: LayoutModel?) -> CGFloat {
//        guard let model = model, let layoutModel = layoutModel else {
//            return YKNGap.dim_7()
//        }
//        
//        if isStringEmpty(model.title) {
//            return YKNGap.dim_7()
//        }
//        
//        let cellHeight = YKNGap.dim_7() + YKNGap.dim_7() + (layoutModel.title?.boundingSize?.height ?? 0)
//        if isStringEmpty(model.subTitle) {
//            return cellHeight
//        }
//        return cellHeight + YKNGap.dim_1() + (layoutModel.subtitle?.boundingSize?.height ?? 0)
//    }
//
//}
