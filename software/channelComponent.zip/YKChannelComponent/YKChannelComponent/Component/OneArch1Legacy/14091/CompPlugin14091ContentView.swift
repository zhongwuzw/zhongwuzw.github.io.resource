//
//  CompPlugin14091ContentView.swift
//  YKChannelComponent
//
//  Created by better on 2021/6/3.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKChannelBase
import YoukuResource

class CompPlugin14091BGView: UIView {

    //MARK: - Property
    lazy var imageView: UIImageGIFView = {
        let imageView = UIImageGIFView.init()
        imageView.layer.cornerRadius = YKNCorner.radius_medium()
        imageView.clipsToBounds = true
        imageView.contentMode = .scaleAspectFill
        addSubview(imageView)
        return imageView
    }()
    
    lazy var eyeglassHollowBg: UIView = {
        let view = createEyeglassHollow(parentView: imageView)
        imageView.addSubview(view)
        return view
    }()

    func fill(url: String?) {
        let imageWidth = (self.width - YKNGap.youku_margin_right() - YKNGap.youku_margin_left())
        let itemWidth = (imageWidth - YKNGap.youku_column_spacing())/2.0
        self.imageView.frame = CGRect.init(x: YKNGap.youku_margin_left(), y: 0, width: imageWidth, height: itemWidth * 9/16.0)
        self.imageView.ykn_setImage(withURLString:url, module: nil, imageSize: CGSize.init(), parameters: nil, completed:nil)
    }
}
