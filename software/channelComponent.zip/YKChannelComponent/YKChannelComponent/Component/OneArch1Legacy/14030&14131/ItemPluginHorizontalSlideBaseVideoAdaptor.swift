//
//  ItemPlugin14030.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/6/2.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YoukuResource
import YKSCService
import YKResponsiveLayout

@objcMembers
class ItemPluginHorizontalSlideBaseVideoAdaptor: YKSCItemPlugin {
    
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventParseData,
                "selector":     "receiveParseDataEvent:",
            ],
            [
                "event":        YKSCItemResponseLayoutEventSettingRule,
                "selector":     "receiveResponseLayoutSettingRuleEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemWidth,
                "selector":     "receiveQueryItemWidthEvent:",
            ],
            [
                "event":        YKSCItemEventReuseItemView,
                "selector":     "receiveReuseItemViewWithEvent:",
            ],
        ]
    }
    
    func receiveParseDataEvent(_ event: YKSCEvent) {
        guard let itemInfo = event.params?.scDictionary(forKey: "itemInfo") as? Dictionary<String, Any> else { return }
        guard let itemData = itemInfo["data"] as? Dictionary<String, Any> else { return }
        
        var params = [String: Any]()
        params["itemInfo"] = itemData
        params["viewTag"] = "imageView"
        scFireEvent(YKSCItemEventParseRank, params: params)
    }

    func receiveQueryItemWidthEvent(_ event: YKSCEvent) {
        let response = scFireEvent(YKSCItemResponseLayoutEventQueryWidth, params: nil)
        guard let width = response?.yk_double("width") else {
            return
        }
        
        event.responseInfo["itemWidth"] = width
    }
    
    func receiveReuseItemViewWithEvent(_ event: YKSCEvent) {
        guard let itemView = event.params?["itemView"] as? ItemPluginBaseVideoContentView else {
            return
        }
        
        var params = [String: Any]()
        params["view"] = itemView.videoImageView
        params["tag"] = "imageView"
        scFireEvent(YKSCItemEventBindItemView, params: params)
    }
}

@objcMembers
class ItemPlugin14030: ItemPluginHorizontalSlideBaseVideoAdaptor {
    
    func receiveResponseLayoutSettingRuleEvent(_ event: YKSCEvent) {
        event.responseInfo["rule"] = response_layout_rule_5_1
    }
    
}

@objcMembers
class ItemPlugin14031: ItemPluginHorizontalSlideBaseVideoAdaptor {
        
    func receiveResponseLayoutSettingRuleEvent(_ event: YKSCEvent) {
        event.responseInfo["rule"] = response_layout_rule_2
    }
    
}

