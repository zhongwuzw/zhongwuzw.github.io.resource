//
//  ItemPlugin14031MoreContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/6/1.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKChannelBase
import YoukuResource

class ItemPluginBaseMoreContentView: UIView {
    
    lazy var contentView: UIView = {
        let view = UIView.init()
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init()
        view.font = YKNFont.posteritem_subhead()
        return view
    }()
    
    lazy var arrowImageView: UIImageView = {
        let view = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 12, height: 12))
        view.image = UIImage.init(named: "ykn_more_btn")?.withRenderingMode(.alwaysTemplate)
        return view
    }()

    //MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        createSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        createSubviews()
    }
    
    //MARK: -
    func createSubviews() {
        addSubview(contentView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(arrowImageView)
    }
    
    func fillItemContext(_ itemContext:YKSCItemContext) {
        titleLabel.text = itemContext.model.title
        
        let itemWidth = self.width
        let radio = itemContext.scComponentContext?.model.extraExtend["aspectRatio"] as? CGFloat ?? 1
        contentView.frame = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemWidth/radio)
        
        titleLabel.frame = itemContext.layoutModel.title?.renderRect ?? CGRect.zero
        titleLabel.centerX = contentView.centerX - (arrowImageView.width / 2)
        titleLabel.centerY = contentView.centerY
        
        arrowImageView.left = titleLabel.right
        arrowImageView.centerY = titleLabel.centerY
        
        // 绑定跳转
        Service.action.bind(itemContext.model.action, self)
        
        // 氛围接入
        contentView.backgroundColor = sceneUtil(.ykn_secondaryBackground, sceneColor: itemContext.sceneCardFooterBgColor())
        let titleColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: itemContext.sceneCardFooterTitleColor())
        titleLabel.textColor = titleColor
        arrowImageView.tintColor = titleColor
    }
}
