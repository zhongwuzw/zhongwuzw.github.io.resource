//
//  CompPlugin14030Adaptor.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/6/2.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YoukuResource
import YKSCService
import YKResponsiveLayout

@objcMembers
class CompPluginHorizontalSlideBaseVideoAdaptor: YKSCComponentPlugin {
    
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCComponentEventParseData,
                "selector":     "receiveParseDataEvent:",
            ],
            [
                "event":        YKSCCompResponseLayoutEventSettingRule,
                "selector":     "receiveComponentResponseLayoutSetRuleEvent:",
            ],
        ]
    }

    func receiveParseDataEvent(_ event: YKSCEvent) {
        scSetData(NSNumber(value: Double(youku_margin_left())), forKey: YKSCComponentDataHorizontalInsetLeft)
        scSetData(NSNumber(value: Double(youku_margin_right())), forKey: YKSCComponentDataHorizontalInsetRight)
        scSetData(NSNumber(value: Double(youku_column_spacing())), forKey: YKSCComponentDataLayoutColumnSpacing)
    }
    
}

@objcMembers
class CompPlugin14030Adaptor: CompPluginHorizontalSlideBaseVideoAdaptor {
    
    override func receiveParseDataEvent(_ event: YKSCEvent) {
        super.receiveParseDataEvent(event)
        
        //视频图片宽高比
        scComponentContext?.model.extraExtend["aspectRatio"] = NSNumber(1.78)
    }
    
    func receiveComponentResponseLayoutSetRuleEvent(_ event: YKSCEvent) {
        event.responseInfo["rule"] = response_layout_rule_5_1
    }
    
}

@objcMembers
class CompPlugin14031Adaptor: CompPluginHorizontalSlideBaseVideoAdaptor {
    
    override func receiveParseDataEvent(_ event: YKSCEvent) {
        super.receiveParseDataEvent(event)
        
        //视频图片宽高比
        scComponentContext?.model.extraExtend["aspectRatio"] = NSNumber(0.75)
    }
    
    func receiveComponentResponseLayoutSetRuleEvent(_ event: YKSCEvent) {
        event.responseInfo["rule"] = response_layout_rule_2
    }
    
}
