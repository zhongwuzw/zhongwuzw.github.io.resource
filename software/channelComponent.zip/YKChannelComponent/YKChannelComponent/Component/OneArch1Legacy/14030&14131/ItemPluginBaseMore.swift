//
//  ItemPlugin14031More.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/6/1.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YKChannelBase
import YKMtopRecover.RCVRJSONClient
import OneArchCore
import YoukuResource
import YKSCService
import YKResponsiveLayout

@objcMembers
class ItemPluginBaseMore: YKSCItemPlugin {

    //MARK:事件映射定义
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventParseData,
                "selector":     "receiveParseDataEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemCount,
                "selector":     "receiveQueryItemCountEvent:",
            ],
            [
                "event":        YKSCItemResponseLayoutEventSettingRule,
                "selector":     "receiveResponseLayoutSettingRuleEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemWidth,
                "selector":     "receiveQueryItemWidthEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemReuseId,
                "selector":     "receiveQueryItemReuseIdEvent:",
            ],
            [
                "event":        YKSCItemEventQueryItemView,
                "selector":     "receiveQueryItemViewEvent:",
            ],
            [
                "event":        YKSCItemEventReuseItemView,
                "selector":     "receiveReuseItemViewEvent:",
            ],
        ]
    }
    
    func receiveParseDataEvent(_ event: YKSCEvent) {
        guard let scItemContext = scItemContext else {
            return
        }
        
        if isEmpty(scItemContext.model.title) {
            scItemContext.model.title = "更多"
        }
    }
    
    func receiveQueryItemCountEvent(_ event:YKSCEvent) {
        event.responseInfo.setValue(1, forKey: "itemCount")
    }
    
    func receiveQueryItemWidthEvent(_ event:YKSCEvent) {
        let response = scFireEvent(YKSCItemResponseLayoutEventQueryWidth, params: nil)
        let itemWidth = response?["width"] as? Double ?? 0
        
        event.responseInfo.setValue(itemWidth, forKey: "itemWidth")
        
        
        // 标题预计算
        if let scItemContext = scItemContext,
           let title = scItemContext.model.title
        {
            let size = calcStringSize(title, font: YKNFont.posteritem_subhead(), size: .init(width: 1000, height: 1000))
            let titleLayout = TextLayoutModel()
            titleLayout.renderRect = CGRect.init(origin: .zero, size: size)
            scItemContext.layoutModel.title = titleLayout
        }
    }
    
    func receiveQueryItemViewEvent(_ event:YKSCEvent) {
        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let itemHeight: Double = (event.params?["itemHeight"] as? NSNumber)?.doubleValue ?? 0
        let itemView = ItemPluginBaseMoreContentView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        event.responseInfo.setValue(itemView, forKeyPath: "itemView")
    }
    
    func receiveReuseItemViewEvent(_ event:YKSCEvent) {
        guard let itemView = event.params?["itemView"] as? ItemPluginBaseMoreContentView else {
            return
        }
        
        guard let scItemContext = scItemContext else {
            return
        }
        
        itemView.fillItemContext(scItemContext)
    }
}

@objcMembers
class ItemPlugin14030More: ItemPluginBaseMore {
    
    func receiveResponseLayoutSettingRuleEvent(_ event:YKSCEvent) {
        event.responseInfo["rule"] = response_layout_rule_5
    }
    
    func receiveQueryItemReuseIdEvent(_ event:YKSCEvent) {
        event.responseInfo.setValue(String(describing: ItemPlugin14031More.self), forKey: "reuseId")
    }
    
}

@objcMembers
class ItemPlugin14031More: ItemPluginBaseMore {
    
    func receiveResponseLayoutSettingRuleEvent(_ event:YKSCEvent) {
        event.responseInfo["rule"] = response_layout_rule_2
    }
    
    func receiveQueryItemReuseIdEvent(_ event:YKSCEvent) {
        event.responseInfo.setValue(String(describing: ItemPlugin14031More.self), forKey: "reuseId")
    }
    
}
