//
//  CompPlugin15004.swift
//  YKChannelComponent
//
//  Created by wustlj on 2022/1/24.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YKSCBase
import YKHome
import AliReachability

@objcMembers
class CompPlugin15004: YKSCComponentPlugin, YKShopWindowPlayDelegate, YKShopWindowViewDelegate {
    var adModel: YKShopWindowAdvModel?
    var adController: YKShopWindowADController?
    
    var cellHeight: CGFloat = 0.0
    var exposed: Bool = false
    var replayExposed: Bool = false
    weak var advCell: YKShopWindowAdvCell?

    deinit {
        print("[CC]===>[WindowAd] CompPlugin15004 deinit")
    }
    
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCComponentEventParseData,
                "selector":     "receiveParseData:",
            ],
            [
                "event":        YKSCComponentEventInit,
                "selector":     "receiveInit:",
            ],
            [
                "event":        YKSCComponentEventQueryItemCount,
                "selector":     "receiveQueryItemCount:",
            ],
            [
                "event":        YKSCComponentEventQueryItemHeight,
                "selector":     "receiveQueryItemHeight:",
            ],
            [
                "event":        YKSCComponentEventQueryItemReuseId,
                "selector":     "receiveQueryItemReuseId:",
            ],
            [
                "event":        YKSCComponentEventQueryItemView,
                "selector":     "receiveQueryItemView:",
            ],
            [
                "event":        YKSCComponentEventReuseItemView,
                "selector":     "receiveReuseItemView:",
            ],
            [
                "event":        YKSCComponentEventVisibleViewDidScroll,
                "selector":     "receiveVisibleViewDidScroll:",
            ],
            [
                "event":        YKSCComponentEventVisibleViewDidEndScroll,
                "selector":     "receiveVisibleViewDidEndScroll:",
            ],
            [
                "event":        YKSCPageEventDidActivate,
                "selector":     "receiveDidActivate:",
            ],
            [
                "event":        YKSCPageEventDidDeactivate,
                "selector":     "receiveDidDeactivate:",
            ],
            [
                "event":        YKSCComponentEventItemEnterDisplayArea,
                "selector":     "receiveEnterDisplayArea:",
            ],
            [
                "event":        YKSCComponentEventItemExitDisplayArea,
                "selector":     "receiveExitDisplayArea:",
            ],
        ]
    }
        
    func receiveParseData(_ event: YKSCEvent) {
        guard let cardInfo = event.params?["cardInfo"] as? [String: Any], let data = cardInfo["data"] as? [String: Any] else {
            return
        }
                
        if let adInfo = data["shopWindowAd"] as? [String: Any] {
            adModel = YKShopWindowAdvModel(cmsInfo: adInfo)
        } else {
            adModel = nil
            adController = nil
        }
    }

    func receiveInit(_ event: YKSCEvent) {
        DispatchQueue.main.async { [self] in
            setupPlayer()
        }
    }
            
    func receiveQueryItemCount(_ event: YKSCEvent) {
        let rowCount = adModel != nil ? 1 : 0
        event.responseInfo.setValue(NSNumber(value: rowCount), forKey: "itemCount")
    }
    
    func receiveQueryItemHeight(_ event: YKSCEvent) {
        if cellHeight == 0 {
            let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
            cellHeight = YKShopWindowAdvCell.heightWithADModel(adModel, width: CGFloat(itemWidth))
        }
        event.responseInfo.setValue(NSNumber(value: cellHeight), forKey: "itemHeight")
    }
    
    func receiveQueryItemReuseId(_ event: YKSCEvent) {
        event.responseInfo.setValue("YKShopWindowAdvCell", forKey: "reuseId")
    }
    
    func receiveQueryItemView(_ event: YKSCEvent) {
        let itemWidth: Double = (event.params?["itemWidth"] as? NSNumber)?.doubleValue ?? 0
        let itemHeight: Double = (event.params?["itemHeight"] as? NSNumber)?.doubleValue ?? 0
        let itemView = YKShopWindowAdvCell(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        
        event.responseInfo.setValue(itemView, forKey: "itemView")
    }
    
    func receiveReuseItemView(_ event: YKSCEvent) {
        guard let itemView = event.params?["itemView"] as? YKShopWindowAdvCell else {
            return
        }
        
        advCell = itemView
        
        itemView.viewDelegate = self
        itemView.setup(adModel: adModel)
    }
    
    func receiveVisibleViewDidScroll(_ event: YKSCEvent) {
        removeFeedbackView()
        tryExpose()
    }
    
    func receiveVisibleViewDidEndScroll(_ event: YKSCEvent) {
        guard let adController = adController else {
            return
        }
        
        if tryPlay(true) == false {
            adController.deactivate()
        }
    }
    
    func receiveDidActivate(_ event: YKSCEvent) {
        guard let _ = adController else {
            return
        }
        
        let _ = tryPlay(true)
    }
    
    func receiveDidDeactivate(_ event: YKSCEvent) {
        guard let adController = adController else {
            return
        }
        
        adController.deactivate()
    }
    
    func receiveEnterDisplayArea(_ event: YKSCEvent) {
        guard let _ = adController else {
            return
        }
        
        let _ = tryPlay(true)
        
        tryExpose()
    }
    
    func receiveExitDisplayArea(_ event: YKSCEvent) {
        guard let adController = adController else {
            return
        }
        
        adController.deactivate()
    }
    
    //MARK: play
    
    func setupPlayer() {
        if adController != nil {
            return
        }
        
        if let scPageContext = scPageContext,
            let scComponentContext = scComponentContext,
            let adModel = adModel,
            let vc = scPageContext.scData(forKey: YKSCPageDataController) as? UIViewController {
            
            let leftPadding = scComponentContext.scDouble(forKey: YKSCComponentDataLayoutPaddingLeft)
            let rightPadding = scComponentContext.scDouble(forKey: YKSCComponentDataLayoutPaddingRight)
            let containerWidth = scPageContext.scDouble(forKey: YKSCPageDataContainerWidth)
            let width = containerWidth - leftPadding - rightPadding
            
            adController = YKShopWindowADController(adModel: adModel, width: width, controller: vc)
            adController?.playDelegate = self
        }
    }
    
    func tryPlay(_ detectFeedbackView: Bool) -> Bool {
        if detectFeedbackView && isShowingFeedbackView {
            return false
        }
        
        if isPageInActive && isWifi && isPlayerVisible {
            adController?.activate()
            return true
        }
        
        return false
    }

    //MARK: feedback
    
    func showFeedbackView() {
        guard let adModel = adModel, let scComponentContext = scComponentContext, let advCell = advCell else {
            return
        }
                
        adModel.sendFeedbackExposeStatistics()
        
        let roundStyleInfo = scComponentContext.scDictionary(forKey: YKSCDataRoundStyleInfo)
        let enabled = roundStyleInfo?["enabled"] as? Bool
        var cornerRadius:Double = 0
        if enabled == true {
            cornerRadius = roundStyleInfo?.yk_double("cornerRadius", defaultValue: 0) ?? 0.0
        }
        
        let identifier = "com.youku.negativefeedback.shopWindow_" + String(adModel.adStyle == .defaultStyle ? 0 : 1)

        weak var weakself = self
        HomeNegativeFeedbackADView.showRoundStyleADFeedbackView(in: advCell,
                                                                identifier: identifier,
                                                                cornerRadius: cornerRadius) { negativeFeedBack in
            if negativeFeedBack {
                weakself?.removeComponent()
            } else {
                let _ =  weakself?.tryPlay(false)
            }
        }
    }
    
    func removeComponent() {
        guard let scComponentContext = scComponentContext, let scCardContext = scCardContext, let adModel = adModel else {
            return
        }
        
        var params = [String: Any]()
        params["type"] = "delete"
        params["componentContexts"] = scComponentContext
        scCardContext.scFireEvent(YKSCCardEventUpdateCardModule, params: params)
        scCardContext.scFireEvent(YKSCCardEventRefreshCardModule, params: params)
        
        adModel.sendCloseCheckStatistics()
    }
        
    func removeFeedbackView() {
        let feedbackView = advCell?.viewWithTag(116899)
        feedbackView?.removeFromSuperview()
    }
    
    var isShowingFeedbackView: Bool {
        let feedbackView = advCell?.viewWithTag(116899)
        return feedbackView != nil
    }
    
    //MARK: expose
    
    func tryExpose() {
        if !exposed && isPageInActive && isAdVisible {
            exposed = true
            
            adModel?.sendShowCheckStatistics()
        }
    }
    
    var isWifi:Bool {
        return NWReachabilityManager.shareInstance()?.currentNetworkStatus() == NetworkStatus.ReachableViaWiFi
    }
    
    var isPageInActive:Bool {
        let state = scPageContext?.scBool(forKey: YKSCPageDataActiveState)
        
        return state ?? false
    }
    
    var isAdVisible:Bool {
        if let view = (adModel?.adStyle == .defaultStyle ? advCell?.logoView : advCell?.videoImageView) {
            return isExpose(view: view, exposeRatio: 0.001)
        }
        
        return false
    }
    
    var isPlayerVisible:Bool {
        if let view = advCell?.videoImageView {
            return isExpose(view: view, exposeRatio: 0.33)
        }
        
        return false
    }
    
    func isExpose(view: UIView, exposeRatio: CGFloat) -> Bool {
        guard let frame = view.superview?.convert(view.frame, to: nil) else {
            return false
        }
        
        if view.frame.height == 0 {
            return false
        }
                
        let minY = frame.minY
        let maxY = frame.maxY
        let min = YKStatusBarHeight() + 110.0
        let max = YKRLScreenHeight() - 49
        
        if maxY <= min || minY >= max {
            print("<windowShopAd> 不在可视区域")
            return false
        }
        
        let adRect = CGRect(x: 0, y: minY, width: frame.width, height: frame.height)
        let visibleRect = CGRect(x: 0, y: min, width: YKRLScreenWidth(), height: (max - min))
        let intersectionRect = adRect.intersection(visibleRect)
        
        if intersectionRect.size.height <= 0 {
            print("<windowShopAd> 无内容露出")
            return false
        }
        
        let viewExposeRatio = intersectionRect.size.height / frame.size.height
        if viewExposeRatio >= exposeRatio {
            return true
        }

        print("<windowShopAd> 曝光比例不足:\(String(viewExposeRatio.description))")
        return false
    }
    
    //MARK: controllerDelegate
    func didClickAd() {
        adModel?.sendClickCheckStatistics()
    }
    
    func didStartPlay() {
        if let adController = adController, let cell = advCell {
            cell.setupPlayerView(view: adController.playerView())
        }
    }
    
    func didFinishPlay() {
        if replayExposed == false {
            replayExposed = true
            adModel?.sendReplayExposeStatistics()
        }
    }
    
    //MARK: YKShopWindowViewDelegate
    
    func didClickCloseBtn() {
        adController?.deactivate()
        
        showFeedbackView()
        
        adModel?.sendCloseMoreStatistics()
    }
    
    func didClickAdView() {
        adModel?.sendClickCheckStatistics()
    }
}
