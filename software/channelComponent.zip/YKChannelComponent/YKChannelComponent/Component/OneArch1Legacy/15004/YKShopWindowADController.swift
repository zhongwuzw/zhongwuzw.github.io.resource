//
//  YKShopWindowADController.swift
//  YKChannelComponent
//
//  Created by wustlj on 2022/1/24.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YKHome
import YoukuResource

protocol YKShopWindowPlayDelegate: NSObjectProtocol {
    func didStartPlay()
    
    func didFinishPlay()
    
    func didClickAd()
}

@objcMembers
class YKShopWindowADController: NSObject, HomePlayerDelegate {
    weak var playDelegate:YKShopWindowPlayDelegate?
    var adModel: YKShopWindowAdvModel
    var isSquareVideo: Bool
    var size: CGSize
    var isStopWhenPreparing: Bool = false
    var isStartPlayed: Bool = false
    
    var muteVolumeButton: YKADVolumeButton?
    var replayButton: UIButton?
    var endImageView: UIImageView?
    var tapButton : UIButton?
    
    var player: HomePlayer
    
    lazy var titleShadow: CAGradientLayer = {
        let titleShadow = CAGradientLayer()
        
        titleShadow.colors = [UIColor(white: 0, alpha: 0).cgColor, UIColor(white: 0, alpha: 0.5).cgColor]
        titleShadow.locations = [NSNumber.init(value: 0), NSNumber.init(value: 1.0)]        
        titleShadow.startPoint = CGPoint(x: 0, y: 0)
        titleShadow.endPoint = CGPoint(x: 0, y: 1.0)
        
        return titleShadow
    }()
    
    var beforePlayStaticImageURL: String? {
        return adModel.videoImagePath
    }
    
    deinit {
        print("[WindowAd] YKShopWindowADController dealloc");

        if Thread.isMainThread {
            player.playerView.removeFromSuperview()
            player.stop()
            player.deinitPlayer()
            player.delegate = nil
        } else {
            let dPlayer = player
            DispatchQueue.main.async {
                dPlayer.playerView.removeFromSuperview()
                dPlayer.stop()
                dPlayer.deinitPlayer()
                dPlayer.delegate = nil
            }
        }
    }
        
    init(adModel model: YKShopWindowAdvModel, width: Double, controller: UIViewController) {
        adModel = model
        
        let ratio = adModel.ratio
        size = CGSize(width: width, height: ceil(width * ratio))
        isSquareVideo = adModel.adStyle == .value1Style;

        player = HomePlayer.init(controller: controller)

        super.init()
        
        player.delegate = self
        player.setupFrame(CGRect(x: 0, y: 0, width: size.width, height: size.height))
        player.run()
        player.qualityType = .typeHigh
        player.videoScreenMode = .aspectFill
        player.disableWatermark = true
        player.disableVV = true
        player.mute = true
        
        player.registerPlugin(withPluginID: "error", params: ChannelSliderPlayerHelper.errorPluginParams())
    }

    func playerView() -> UIView {
        return player.playerView
    }
    
    func activate() {
        if player.isPlayingCompleted == false {
            if isStopWhenPreparing {
                isStopWhenPreparing = false
                player.pause()
            }
            
            if !isStartPlayed {
                isStartPlayed = true
                playVideo()
                
                adModel.sendAutoStartCheckStatistics()
            } else {
                player.play()
            }
        }
    }
    
    func deactivate() {
        if player.isPreparing || player.isPlaying {
            if player.isPreparing {
                isStopWhenPreparing = true
            }
            player.pause()
        }
    }
    
    func stop() {
        player.stop()
    }
    
    func startPlay() {
        if isStartPlayed {
            return
        }
        
        isStartPlayed = true
        
        playVideo()
    }
    
    func playVideo() {
        play(vid: adModel.vid)
    }
    
    func play(vid: String?) {
        guard let vid = vid else {
            return
        }
        
        let video = HomeVideo()
        video.forceReplay = true
        var userDic: [String: Any] = ["isAd": "1"]
        if var userInfo = video.userInfo {
            userInfo["isAd"] = "1"
            video.userInfo = userInfo
        } else {
            video.userInfo = userDic
        }
        player.isAppleSpecialVrVideo = false
        if vid.hasPrefix("http") {
            video.videoUrl = vid
            player.playVideo(withUrl: video)
            return
        }
        video.vid = vid
        player.play(video)
    }
    
    //MARK: playerDelegate
    func player(_ player: HomePlayer, didPrepared event: OPEvent) {
        setupPlayerViews()
    }
    
    func player(_ player: HomePlayer, sceneDidChange event: OPEvent) {
        muteVolumeButton?.isHidden = !player.isPlaying
        
        let scene: OPPlayScene = player.scene
        if scene == .video {
            if isStopWhenPreparing {
                player.pause()
            }
        } else if scene == .complete {
            setupEndImage()
            
            adModel.sendEndCheckStatistics()
            
            playDelegate?.didFinishPlay()
        }
        
        replayButton?.isHidden = (scene != .complete)
    }
    
    func player(_ player: HomePlayer, stateDidChange event: OPEvent) {
        if player.isPlaying {
            adModel.sendPlayStartStatistics()
            adModel.sendVideoRealStartStatistics()
            
            playDelegate?.didStartPlay()
            
            removeEndImage()
        }
    }
    
    func player(_ player: HomePlayer, errorDidChange event: OPEvent) {
        if player.isError {
            print("<windowShopAd> ad play error")
        }
        
        replayButton?.isHidden = false
        muteVolumeButton?.isHidden = true
        
        if player.playerError != .none {
            let errorCode = player.playerError.code
            var args = [String: Any]()
            args["type"] = "windowShopAdPlay"
            args["playtype"] = "fail"
            args["what"] = errorCode
            args["vid"] = adModel.vid
            
            adModel.sendPlayErrorStatistics(args)
        }
    }
    
    func player(_ player: HomePlayer, timeDidChange event: OPEvent) {
        adModel.sendVideoPlayTimeChangedStatistics(time: Int(player.currentTime))
    }
    
    func adEtpInterruptShow() {
        adModel.sendEtpInterruptShowStatistics()
    }

    //MARK: view
    func setupPlayerViews() {
        if endImageView == nil {
            endImageView = UIImageView()
            endImageView?.frame = player.containerView.frame
            endImageView?.isUserInteractionEnabled = false
            endImageView?.backgroundColor = .clear
            endImageView?.contentMode = .scaleAspectFill
        }
        
        if let endImageView = endImageView {
            player.containerView.addSubview(endImageView)
        }
        
        if isSquareVideo {
            player.containerView.layer.addSublayer(titleShadow)
        } else {
            titleShadow.removeFromSuperlayer()
        }
        
        if tapButton == nil {
            tapButton = UIButton()
            tapButton?.backgroundColor = .clear
            tapButton?.isExclusiveTouch = true
            tapButton?.addTarget(self, action: #selector(clickedSkipAd), for: .touchUpInside)
        }
        
        if let tapButton = tapButton {
            player.containerView.addSubview(tapButton)
        }
        
        if muteVolumeButton == nil {
            muteVolumeButton = YKADVolumeButton(type: .custom)
            muteVolumeButton?.isExclusiveTouch = true
            muteVolumeButton?.backgroundColor = YKNColor.co_1()
            muteVolumeButton?.layer.cornerRadius = 13
            muteVolumeButton?.setImage(UIImage.init(named: "WindowsAD_volume_off"), for: .normal)
            muteVolumeButton?.addTarget(self, action: #selector(muteVolum), for: .touchUpInside)
            muteVolumeButton?.isHidden = true
        }
        
        if let muteVolumeButton = muteVolumeButton {
            player.containerView.addSubview(muteVolumeButton)
        }
        
        if replayButton == nil {
            replayButton = UIButton()
            replayButton?.isExclusiveTouch = true
            replayButton?.backgroundColor = YKNColor.co_1()
            replayButton?.layer.cornerRadius = 13
            replayButton?.addTarget(self, action: #selector(replayVideo), for: .touchUpInside)
            replayButton?.titleLabel?.font = YKNFont.font_size_middle4()
            replayButton?.setTitle("重播", for: .normal)
            replayButton?.setTitleColor(YKNColor.cw_1(), for: .normal)
            replayButton?.isHidden = true
        }
        
        if let replayButton = replayButton {
            player.containerView.addSubview(replayButton)
        }
        
        layoutPlayerViews()
    }
    
    func layoutPlayerViews() {
        var frame = player.containerView.frame
        let height = frame.size.height
        let width = frame.size.width
        
        tapButton?.frame = frame
        endImageView?.frame = tapButton?.bounds ?? CGRect.zero
        
        titleShadow.frame = CGRect(x: 0, y: height - 80, width: width, height: 80)
        
        let space: CGFloat = 12.0
        
        if isSquareVideo {
            frame.origin.x = width - 50 - 26
            frame.origin.y = height - 26 - space
            frame.size = CGSize(width: 26, height: 26)
            muteVolumeButton?.frame = frame
            
            frame.origin.x = width - 50 - 48
            frame.origin.y = height - 26 - space
            frame.size = CGSize(width: 48, height: 26)
            replayButton?.frame = frame
            replayButton?.isHidden = true
        } else {
            frame.origin.x = width - 26 - space
            frame.origin.y = height - 26 - space
            frame.size = CGSize(width: 26, height: 26)
            muteVolumeButton?.frame = frame
            
            frame.origin.x = width - 48 - space
            frame.origin.y = height - 26 - space
            frame.size = CGSize(width: 48, height: 26)
            replayButton?.frame = frame
            replayButton?.isHidden = true
        }
    }
    
    func setupEndImage() {
        if let imgPath = adModel.videoImagePath, let endImageView = endImageView {
            endImageView.cms_setImage(withURLString: imgPath,
                                      placeholderImage: nil,
                                      module: "YKBrandAD",
                                      imageSize: CGSize.zero,
                                      parameters: nil,
                                      completed: nil)
        }
    }
    
    func removeEndImage() {
        endImageView?.image = nil
    }
    
    // 跳转广告
    @objc func clickedSkipAd() {
        playDelegate?.didClickAd()
    }
    
    @objc func muteVolum() {
        let mute = player.mute
        let imgName = mute ? "WindowsAD_volume_on" : "WindowsAD_volume_off"
        muteVolumeButton?.setImage(UIImage.init(named: imgName), for: .normal)
        player.mute = !mute
    }
    
    @objc func replayVideo() {
        replayButton?.isHidden = true
        
        adModel.sendReplayCheckStatistics()
        
        player.play() //replay与play接口相比，准备播放过程中不会保留最后一帧
    }
    
}
