//
//  YKADReplayButton.swift
//  YKChannelComponent
//
//  Created by wustlj on 2022/1/21.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit

@objcMembers
class YKADVolumeButton: UIButton {

    override func titleRect(forContentRect contentRect: CGRect) -> CGRect {
        return super.titleRect(forContentRect: contentRect)
    }

    override func imageRect(forContentRect contentRect: CGRect) -> CGRect {
        var rect = super.imageRect(forContentRect: contentRect)
        rect.size.width = 18
        rect.size.height = 18
        rect.origin.x = (contentRect.size.width - rect.size.width) / 2
        rect.origin.y = (contentRect.size.height - rect.size.height) / 2

        return rect
    }

}
