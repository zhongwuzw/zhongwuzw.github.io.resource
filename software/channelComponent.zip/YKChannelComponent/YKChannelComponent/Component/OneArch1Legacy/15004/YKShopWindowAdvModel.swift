//
//  YKShopWindowAdvModel.swift
//  YKChannelComponent
//
//  Created by wustlj on 2022/1/21.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import XAdSDK
import YoukuAnalytics

enum YKShopWindowAdvStyle: Int {
    case defaultStyle = 0
    //16:9
    case value1Style = 1
}

@objcMembers
class YKShopWindowAdvModel: NSObject {
    
    /// 广告logo地址
    var logoUrl: String?
    
    /// 广告图片地址
    var videoImagePath: String?
    
    /// 广告标题
    var title: String?
    
    /// 广告子标题
    var subtitle: String?

    /// 广告视频Vid
    var vid: String?
    
    ///广告来源
    var dspName: String?
    
    /// 广告跳转地址
    var actionUrl: String?
    
    /// 自动播放监测url
    var autoStartCheckUrl: String?
    
    /// 结束播放监测url
    var endCheckUrl: String?
    
    /// 关闭监测url
    var closeCheckUrl: String?
    
    /// 重播监测url
    var replayCheckUrl: String?
    
    /// 曝光监测url
    var showCheckUrl: String?
        
    /// 点击监测url
    var clickCheckUrl: String?
    
    var adStyle: YKShopWindowAdvStyle = .defaultStyle

    var ratio: Double = 0.5625
    
    var dspDisplayName: String?
    
    var dspLogo: String?
    
    var subDspName: String?
    
    var xadContext: WindowAdController
    
    var xadModel: WindowAdItem?
    
    init(cmsInfo: [String: Any]) {
        xadContext = WindowAdController()
   
        xadModel = xadContext.parseAd(cmsInfo)

        logoUrl = xadModel?.logoUrl
        
        videoImagePath = xadModel?.coverImageUrl
        
        title = xadModel?.title
        
        subtitle = xadModel?.subtitle
        
        vid = xadModel?.vid
        
        dspName = xadModel?.dspName
        
        adStyle = xadModel?.userInterfaceStyle == 213 ? .defaultStyle : .value1Style
        
        ratio = adStyle == .defaultStyle ? 0.5625 : 1.0
        
        dspDisplayName = xadModel?.dspDisplayName
        
        dspLogo = xadModel?.dspLogo
        
        subDspName = xadModel?.subDspName
    }
    init(context:WindowAdController,model:WindowAdItem) {
        xadContext = context
   
        xadModel = model

        logoUrl = xadModel?.logoUrl
        
        videoImagePath = xadModel?.coverImageUrl
        
        title = xadModel?.title
        
        subtitle = xadModel?.subtitle
        if let vid = xadModel?.vid,vid.count > 0 {
            self.vid = vid;
        }else{
            vid = xadModel?.url
        }
        
        dspName = xadModel?.dspName
        
        adStyle =  .defaultStyle
        
        ratio = adStyle == .defaultStyle ? 0.5625 : 1.0
        
        dspDisplayName = xadModel?.dspDisplayName
        
        dspLogo = xadModel?.dspLogo
        
        subDspName = xadModel?.subDspName
    }

    func sendAutoStartCheckStatistics() {
        xadContext.onVideoStart()
    }
    
    func sendEndCheckStatistics() {
        xadContext.onVideoComplete()
    }
    
    func sendCloseCheckStatistics() {
        xadContext.onAdClose()
    }

    func sendReplayCheckStatistics() {
        xadContext.onVideoRestart()
    }
    
    func sendShowCheckStatistics() {
        xadContext.onAdShow()
    }

    func sendClickCheckStatistics() {
        xadContext.onAdClick()
    }

    func sendReplayExposeStatistics() {

    }
    
    /// 重播
    func sendCloseMoreStatistics() {
        xadContext.onClickFeedback()
    }
    
    func sendFeedbackExposeStatistics() {
    }
    
    /// 曝光
    func sendPlayStartStatistics() {
        xadContext.onVideoStart()
    }
    
    /// 点击
    func sendPlayErrorStatistics(_ errorInfo: [String: Any]?) {
        xadContext.onVideoError(errorInfo)
    }
    
    /// 视频真正开始播放
    func sendVideoRealStartStatistics() {
        xadContext.onVideoRealStart()
    }
    
    /// 视频播放进度
    func sendVideoPlayTimeChangedStatistics(time:Int) {
        xadContext.onVideoPlayTimeChanged(time)
    }
    
    func sendEtpInterruptShowStatistics() {
        xadContext.onAdEtpInterruptShow()
    }
}
