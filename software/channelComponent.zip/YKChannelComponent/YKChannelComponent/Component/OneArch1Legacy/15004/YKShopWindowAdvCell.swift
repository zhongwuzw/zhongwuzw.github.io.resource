//
//  YKShopWindowAdvCell.swift
//  YKChannelComponent
//
//  Created by wustlj on 2022/1/21.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import orange
import NovelAdSDK

private let SUBTITLE_FONT = (YKNFont.font_size_middle4())
private let TITLE_TOP_SPACE = 10
private let SUBTITLE_TOP_SPACE = (YKNGap.dim_4())
private let CELL_PADDING = (YKNGap.dim_7())
let AD_HEADER_HEIGHT = 44

protocol YKShopWindowViewDelegate: NSObjectProtocol {
    func didClickCloseBtn()
    
    func didClickAdView()
}

@objcMembers
class YKShopWindowAdvCell: AccessibilityView {
    class ShopLogoView: UIImageView {
        lazy var txtLabel: UILabel = {
            let lbl = UILabel()
            self.addSubview(lbl)
            lbl.textAlignment = .left;
            lbl.backgroundColor = .clear
            lbl.font = YKNFont.mediumfont_size_big1()
            lbl.textColor = .ykn_primaryInfo
            lbl.bounds = CGRect(x: 0, y: 0, width: 170, height: 22)
            return lbl
        }()
        override func didMoveToSuperview() {
            super.didMoveToSuperview()
            superview?.addSubview(txtLabel)
        }
    }
    weak var playerView: UIView?
    weak var viewDelegate: YKShopWindowViewDelegate?
    
    lazy var controlView: UIView = {
        let view = UIView.init(frame: CGRect.zero)
        view.backgroundColor = .clear

        return view
    }()
    
    lazy var oadMarkView: OADMarkView = {
        let view = OADMarkView.init(frame: CGRect.zero)
        view.setFont(UIFont.systemFont(ofSize: 11.0), textColor: UIColor.white, backgroundColor: UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.6), cornerRadius: 0, borderColor: nil, borderWidth: 0)
        view.setPaddingHorizontal(4.5, paddingVertical: 2.5, maxWidth: 300)
        return view
    }()

    lazy var adMarkLabel: UILabel = {
        let view = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 32, height: 17))
        view.isExclusiveTouch = true
        view.backgroundColor = UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.6)
        view.font = UIFont.systemFont(ofSize: 11.0)
        view.textColor = UIColor.white
        view.textAlignment = .center
        view.text = "广告";
        view.isUserInteractionEnabled = true

        var maskPath: UIBezierPath = UIBezierPath(roundedRect: view.bounds, byRoundingCorners: [.topRight, .bottomLeft], cornerRadii: CGSize(width: 7, height: 7))
        var maskLayer: CAShapeLayer = CAShapeLayer.init()
        maskLayer.frame = view.bounds
        maskLayer.path = maskPath.cgPath
        view.layer.mask = maskLayer
        view.layer.masksToBounds = true
        
        return view
    }()
    
    lazy var videoImageView: UIImageView = {
        let view = UIImageView.init(frame: CGRect.zero)
        view.contentMode = .center
        view.layer.masksToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.isUserInteractionEnabled = true
        view.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#E4E4E4")
        return view
    }()

    lazy var closeBtn: UIButton = {
        let view = UIButton(type: .custom)
        view.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
        view.setImage(UIImage.init(named: "home_feedback_gray_button_image"), for: .normal)
        return view
    }()

    lazy var roundCloseBtn: YKADVolumeButton = {
        let view = YKADVolumeButton(type: .custom)
        view.addTarget(self, action: #selector(closeAction), for: .touchUpInside)
        view.setImage(UIImage.init(named: "WindowsAD_more"), for: .normal)
        view.backgroundColor = UIColor.init(white: 0, alpha: 0.6)
        view.layer.cornerRadius = 13
        view.isHidden = true
        
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init(frame: CGRect.zero)
        view.backgroundColor = .clear
        view.textAlignment = .left
        view.font = YKNFont.mediumfont_size_middle2()
        view.textColor = .ykn_primaryInfo
        view.isUserInteractionEnabled = true

        return view
    }()
        
    lazy var subTitleLabel: UILabel = {
        let view = UILabel.init(frame: CGRect.zero)
        view.backgroundColor = .clear
        view.textAlignment = .left
        view.font = SUBTITLE_FONT
        view.textColor = .ykn_tertiaryInfo
        view.numberOfLines = 0
        view.isUserInteractionEnabled = true

        return view
    }()

    lazy var logoView: ShopLogoView = {
        let view = ShopLogoView.init(frame: CGRect.init(x: 0, y: 13, width: 100, height: 20))
        view.contentMode = .center
//        view.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#E4E4E4")
        view.backgroundColor = .clear
        view.layer.masksToBounds = true
        view.isUserInteractionEnabled = true

        return view
    }()
    
    var adModel: YKShopWindowAdvModel?
        
    func setupPlayerView(view: UIView) {
        playerView = view
        
        if let playerView = playerView {
            videoImageView.addSubview(playerView)
        }
        
        reloadUISubViews()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubview(logoView)
        addSubview(videoImageView)
        addSubview(closeBtn)
        addSubview(roundCloseBtn)
        addSubview(titleLabel)
        addSubview(subTitleLabel)
        addSubview(oadMarkView)
        addSubview(adMarkLabel)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(tapAction))
        addGestureRecognizer(tapGesture)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setup(adModel: YKShopWindowAdvModel?) {
        self.adModel = adModel
        titleLabel.text = adModel?.title
        subTitleLabel.text = adModel?.subtitle
        
        if self.isShowOADMark() {
            oadMarkView.fillData(withDspName: adModel?.dspDisplayName ?? "", subName: adModel?.subDspName ?? "", logoUrl: adModel?.dspLogo ?? "")
            oadMarkView.isHidden = false
            adMarkLabel.isHidden = true
        } else {
            if self.shopWindowShowDsp(), let dspName = adModel?.dspName, !dspName.isEmpty {
                adMarkLabel.text = dspName
            } else {
                adMarkLabel.text = "广告"
            }
            adMarkLabel.isHidden = false
            oadMarkView.isHidden = true
        }
        
        reloadUISubViews()
        logoView.txtLabel.isHidden = true
        if (adModel?.logoUrl ?? "").count == 0,let logoText = adModel?.xadModel?.logoTxt,!logoText.isEmpty {
            logoView.txtLabel.isHidden = false
            logoView.txtLabel.text = logoText
            
        }
        weak var weakself = self
        logoView.contentMode = .center
        logoView.cms_setImage(withURLString: adModel?.logoUrl ?? "",
                              placeholderImage: nil,
                              module: nil,
                              imageSize: CGSize.zero,
                              parameters: nil) { (image: UIImage?, error: Error?, info: [AnyHashable: Any]?) in
            if let image = image {
                weakself?.logoView.contentMode = .scaleAspectFill
                
                let size = image.size
                weakself?.logoView.frame = CGRect(x: 0, y: 13, width: CGFloat(ceil(size.width * 20.0 / size.height)), height: 20)
//                weakself?.logoView.backgroundColor = .clear
            }
        }
                
        videoImageView.contentMode = .center
        videoImageView.cms_setImage(withURLString: adModel?.videoImagePath ?? "",
                                    placeholderImage: nil,
                                    module: nil,
                                    imageSize: CGSize.zero,
                                    parameters: nil) { (image: UIImage?, error: Error?, info: [AnyHashable: Any]?) in
            if image != nil {
                weakself?.videoImageView.contentMode = .scaleAspectFill
            }
        }
        
        if let playerView = playerView {
            playerView.removeFromSuperview()
        }
    }
    
    func reloadUISubViews() {
        if let adModel = adModel, adModel.adStyle == .defaultStyle {
            layoutDefaultStyle()
        } else {
            layoutOtherStyle()
        }
    }
    
    @objc func tapAction() {
        viewDelegate?.didClickAdView()
    }
    
    @objc func closeAction() {
        viewDelegate?.didClickCloseBtn()
    }
    
    func layoutDefaultStyle() {
        let width: CGFloat = CGFloat(self.frame.width)

        logoView.isHidden = false

        closeBtn.isHidden = false
        if UIAccessibility.isVoiceOverRunning {
            closeBtn.isHidden = true
        }
        roundCloseBtn.isHidden = true

        titleLabel.textColor = .ykn_primaryInfo

        subTitleLabel.textColor = .ykn_tertiaryInfo

        closeBtn.frame = CGRect(x: width - 24, y: CGFloat((AD_HEADER_HEIGHT - 24) / 2), width: 24, height: 24)
        logoView.txtLabel.left = logoView.left
        logoView.txtLabel.bottom = logoView.bottom
        logoView.txtLabel.width = width - 24 - 5 - logoView.left

        let ratio:CGFloat = adModel?.ratio ?? 0.5625
        videoImageView.frame = CGRect(x: 0, y: CGFloat(AD_HEADER_HEIGHT), width: CGFloat(width), height: CGFloat(ceil(width * ratio)))

        playerView?.frame = CGRect(x: 0, y: 0, width: playerView?.frame.size.width ?? 0.0, height: playerView?.frame.size.height ?? 0.0)
        
        if !oadMarkView.isHidden {
            let adMarkSize = oadMarkView.getSize()
            oadMarkView.frame = CGRect(x: width - adMarkSize.width, y: videoImageView.frame.minY, width: adMarkSize.width, height: 17)
            oadMarkView.addRoundingCorners([.topRight, .bottomLeft], radius: 7)
        } else {
            let adMarkSize = YKShopWindowAdvCell.textSizeWithText(adMarkLabel.text, font: adMarkLabel.font, maxSize: CGSizeMake(81, 14))
            let adMarkLabelWidth = max(23,adMarkSize.width) + 9
            adMarkLabel.frame = CGRect(x: width - adMarkLabelWidth, y: videoImageView.frame.minY, width: adMarkLabelWidth, height: 17)
            
            let maskLayer = CAShapeLayer.init()
            maskLayer.frame = adMarkLabel.bounds
            maskLayer.path = UIBezierPath(roundedRect: adMarkLabel.bounds, byRoundingCorners: [.topRight, .bottomLeft], cornerRadii: CGSize(width: 7, height: 7)).cgPath
            adMarkLabel.layer.mask = maskLayer
        }

        titleLabel.frame = CGRect(x: 0, y: videoImageView.frame.maxY + CGFloat(TITLE_TOP_SPACE), width: CGFloat(width), height: 20)

        subTitleLabel.numberOfLines = 0

        let textSize = YKShopWindowAdvCell.textSizeWithText(subTitleLabel.text, font: subTitleLabel.font, maxSize: CGSize(width: CGFloat(width), height: CGFloat(MAXFLOAT)))
        subTitleLabel.frame = CGRect(x: 0, y: titleLabel.frame.maxY + SUBTITLE_TOP_SPACE, width: textSize.width, height: textSize.height)
    }
    
    func layoutOtherStyle() {
        let width = CGFloat(self.frame.width)

        logoView.isHidden = true

        closeBtn.isHidden = true

        roundCloseBtn.isHidden = false

        titleLabel.textColor = UIColor.white

        subTitleLabel.textColor = UIColor(white: 1, alpha: 0.8)

        let ratio:CGFloat = adModel?.ratio ?? 1.0

        videoImageView.frame = CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(ceil(width * ratio)))

        playerView?.frame = CGRect(x: 0, y: 0, width: playerView?.frame.size.width ?? 0.0, height: playerView?.frame.size.height ?? 0.0)
        
        if !oadMarkView.isHidden {
            let adMarkSize = oadMarkView.getSize()
            oadMarkView.frame = CGRect(x: width - adMarkSize.width, y: videoImageView.frame.minY, width: adMarkSize.width, height: 17)
            oadMarkView.addRoundingCorners([.topRight, .bottomLeft], radius: 7)
        } else {
            let adMarkSize = YKShopWindowAdvCell.textSizeWithText(adMarkLabel.text, font: adMarkLabel.font, maxSize: CGSizeMake(81, 14))
            let adMarkLabelWidth = max(23,adMarkSize.width) + 9
            adMarkLabel.frame = CGRect(x: width - adMarkLabelWidth, y: videoImageView.frame.minY, width: adMarkLabelWidth, height: 17)

            let maskLayer = CAShapeLayer.init()
            maskLayer.frame = adMarkLabel.bounds
            maskLayer.path = UIBezierPath(roundedRect: adMarkLabel.bounds, byRoundingCorners: [.topRight, .bottomLeft], cornerRadii: CGSize(width: 7, height: 7)).cgPath
            adMarkLabel.layer.mask = maskLayer
        }

        roundCloseBtn.frame = CGRect(x: width - CELL_PADDING - 26, y: videoImageView.frame.maxY - CELL_PADDING - 26, width: 26, height: 26)

        subTitleLabel.numberOfLines = 1
        subTitleLabel.frame = CGRect(x: CELL_PADDING, y: videoImageView.frame.maxY - 17 - YKNGap.dim_9(), width: width - CELL_PADDING - 99, height: 17)

        titleLabel.frame = CGRect(x: CELL_PADDING, y: subTitleLabel.frame.minY - YKNGap.dim_4() - 20, width: subTitleLabel.width, height: 20)
    }
    
    static func textSizeWithText(_ text: String?, font: UIFont?, maxSize: CGSize) -> CGSize {
        if let text = text, let font = font {
            let rect = text.boundingRect(with: maxSize, options: .usesLineFragmentOrigin, attributes: [.font: font], context: nil)
            return CGSize(width: ceil(rect.size.width), height: ceil(rect.size.height))
        }
        
        return CGSize.zero
    }
    
    static func heightWithADModel(_ adModel: YKShopWindowAdvModel?) -> CGFloat {
        return self.heightWithADModel(adModel, width: SCREEN_WIDTH)
    }
    
    static func heightWithADModel(_ adModel: YKShopWindowAdvModel?, width: CGFloat) -> CGFloat {
        guard let adModel = adModel else {
            return 0.0
        }

        if adModel.adStyle == .value1Style {
            return CGFloat(width * adModel.ratio)
        }

        let textSize = textSizeWithText(adModel.subtitle, font: SUBTITLE_FONT, maxSize: CGSize(width: width, height: CGFloat(MAXFLOAT)))

        return CGFloat(ceil(width * adModel.ratio)) + CGFloat(TITLE_TOP_SPACE + 20 + Int(SUBTITLE_TOP_SPACE) + AD_HEADER_HEIGHT) + textSize.height
    }
    
    func shopWindowShowDsp() -> Bool {
        //广告标dspname是否透出orange
        if let orangeDict = Orange.getGroupConfig(byGroupName: "NovelAdSDK-iOS") {
            if let openValue = orangeDict["shop_window_show_dsp"] as? String {
                if openValue == "1" {
                    return true
                } else if openValue == "0" {
                    return false
                }
            }
        }
        return true
    }
    
    func isShowOADMark() -> Bool {
        if let dspDisplayName = adModel?.dspDisplayName, !dspDisplayName.isEmpty {
            return true
        }
        if let dspLogo = adModel?.dspLogo, !dspLogo.isEmpty {
            return true
        }
        if let subDspName = adModel?.subDspName, !subDspName.isEmpty {
            return true
        }
        return false
    }
    
    private var hitTestIsMisClick = false
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let hitView = super.hitTest(point, with: event)
        if hitView == closeBtn {
            guard let adModel = adModel else {
                return hitView
            }
            if hitTestIsMisClick {
                hitTestIsMisClick = false
                return self
            }
            
            if adModel.xadContext.isMisClick() {
                hitTestIsMisClick = true
                return self
            }
        }
        return hitView
    }
}

