//
//  Card15030.swift
//  YKChannelComponent
//
//  Created by better on 2022/10/21.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuAppAlarm

class Card15030: BaseCardDelegate {

    override func layoutConfig() -> CardLayoutConfig {
        var config = super.layoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        return config
    }

    override func getComponentJsonExtracter() -> ComponentJsonExtracter? {
        return Card15030ComponentJsonExtracter.init()
    }
    
    override func getModelClass<T>() -> T.Type? where T : NodeModel {
        return ChannelBaseCardModel.self as? T.Type
    }
}

class Card15030ComponentJsonExtracter: DefaultComponentJsonExtracter {

    // MARK: - 原始数据加工
    override public func getComponentsJson(cardJson: [String : Any]?, card: ICard?) -> Result<[[String : Any]], Error> {
        guard let components = cardJson?["nodes"] as? [[String: Any]] else {
            return .success([[String : Any]]()) //允许没有组件列表
        }
        var result = [[String:Any]]()
        for i in 0..<components.count {
            var component = components[i]
            let type = component["type"] as? Int ?? 0
            if type == 12116 || type == 12117 || type == 12118 {
                if i + 1 < components.count, var nodes = component["nodes"] as? [[String:Any]] {
                    if nodes.count == 1 { //组件1+8
                        let nextComp = components[i+1]
                        let nextType = nextComp["type"] as? Int ?? 0
                        if nextType == 12113, let nextNodes = nextComp["nodes"] as? [[String:Any]], nextNodes.count == 8 {
                            nodes.append(contentsOf: nextNodes)
                            component["nodes"] = nodes
                            result.append(component)
                        }
                    } else if nodes.count == 9 { //已下发1+8
                        result.append(component)
                    }
                }
            } else if type != 12113 {
                result.append(component)
            }
        }
        
        //feed空数据上报预警
        if result.count == 0 {
            if let cardModel = card?.model as? BaseCardModel {
                let errorMsg = "current_page=\(cardModel.curPageIndex)"
                print("[15030] \(errorMsg)")
                YoukuAppAlarm.alarm(withBizType: "responsive_feed_empty", bizChannelKey: "15030", traceId: "", errorCode: "", errorMsg: errorMsg, needAlarm: true)
            }
        }

        return .success(result)
    }
}
