//
//  NegativeFeedbackView.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/9/3.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuShare
import YoukuResource
import YoukuAnalytics
import OneArchSupport
import OneArchSupport4Youku

class NegativeFeedbackButton: UIView {

    var title: String?
    var isSelected: Bool = false
    
    init(frame: CGRect, title: String?) {
        super.init(frame: frame)
        
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        self.backgroundColor = .ykn_seconarySeparator
        self.titleView.textColor = .ykn_primaryInfo
        
        self.title = title
        self.titleView.text = title
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    lazy var titleView: UILabel = {
        var label = UILabel.init(frame: self.bounds)
        label.textAlignment = .center
        label.font = YKNFont.button_text_m()
        addSubview(label)
        return label
    }()
    
    func setIsSelected(_ isSelected: Bool) {
        if isSelected {
            //选中
            self.titleView.textColor = UIColor.ykn_brandInfo
            self.backgroundColor = UIColor.ykn_co_15
        }else{
            //非选中
            self.titleView.textColor = .ykn_primaryInfo
            self.backgroundColor = .ykn_seconarySeparator
        }
        self.isSelected = isSelected
    }
}

public typealias FeedbackConfirmBlock = ([String]) -> Void
public typealias FavorActionBlock = () -> Void

public protocol NegativeFeedbackViewDelegate:NSObjectProtocol {
    func dismissFeedbackVC()
}

class NegativeFeedbackView: UIView {
    
    var submitString: String?
    var reasons:[FeedbackItemModel]?
    var confirmBlock: FeedbackConfirmBlock?

    var feedBackButtonArray = [NegativeFeedbackButton]()
    var submitBtn: UIButton = UIButton.init(type: .custom)

    //选中理由
    var selectedReasons = [String]()
    weak var delegate: NegativeFeedbackViewDelegate?
    
    lazy var bottomView: UILabel = {
        let view = UILabel()
        view.font = PingFangSCRegularFont(18)
        view.textColor = .ykn_primaryInfo
        view.textAlignment = .center
        view.text = "取消"
        view.textColor = .ykn_primaryInfo
        view.isUserInteractionEnabled = true
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func fillModel(reasons: [FeedbackItemModel],
                topRightItem: FeedbackItemModel?,
                feedbackModel: FeedbackModel?,
                confirm: FeedbackConfirmBlock?) {

        _ = NegativeFeedbackView.calcFrame(reasons: reasons)

        self.reasons = reasons
        self.confirmBlock = confirm

        self.alpha = 1
        self.layer.cornerRadius = 7
        self.clipsToBounds = true
        self.backgroundColor = .clear
        
        self.removeAllSubviews()
        self.feedBackButtonArray.removeAll()
        
        let iconView = UILabel.init(frame: CGRect.init(x: YKNGap.youku_margin_left(), y: 27, width: 24, height: 24))
        iconView.textColor = .ykn_primaryInfo
        iconView.numberOfLines = 1
        iconView.textAlignment = .center
        iconView.font = YKNIconFont.sharedInstance().font(withSize: 24)
        iconView.backgroundColor = UIColor.clear
        iconView.text = "\u{e6ef}"
        addSubview(iconView)
        
        let title = UILabel.init(frame: CGRect.init(x: iconView.right + 6, y: 28, width: 200, height: 21))
        title.font = YKNFont.popup_maintitle_weight(.medium)
        title.textColor = .ykn_primaryLikeInfo
        title.text = "请选择不喜欢的原因？"
        addSubview(title)

        //绘制区域按钮
        var top = 78.0
        for i in 0..<reasons.count {
            let itemModel: FeedbackItemModel = reasons[i]
            let titleStr = itemModel.title

            //item button
            let btnWidth = (self.width - YKNGap.youku_margin_left() * 2 - 9)/2
            let feedButton = NegativeFeedbackButton.init(frame: CGRect.init(x: i % 2 == 0 ? YKNGap.youku_margin_left() : (YKNGap.youku_margin_left() + btnWidth + 9), y: CGFloat(top), width: btnWidth, height: 36), title: titleStr)
            addSubview(feedButton)
            self.feedBackButtonArray.append(feedButton)
            
            if let itemReason = itemModel.reason, self.selectedReasons.count > 0 {
                for reasonStr in selectedReasons {
                    if reasonStr == itemReason {
                        feedButton.setIsSelected(true)
                    }
                }
            } else {
                feedButton.setIsSelected(false)
            }
            
            //item click event
            weak var weakButton = feedButton
            weak var weakSelf = self
            feedButton.whenTapped {
                guard let self = weakSelf else {
                    return
                }
                
                if let weakButton = weakButton, let reason = itemModel.reason {
                    let isSelected = !weakButton.isSelected
                    if isSelected {
                        self.selectedReasons.append(reason)
                    } else {
                        self.selectedReasons.removeAll{ $0 == reason }
                    }
                    self.submitBtn.setTitle("确认", for: .normal)
                    weakButton.setIsSelected(isSelected)
                }
                if self.selectedReasons.count > 0 {
                    self.submitBtn.backgroundColor = .ykn_primaryButtonFill
                } else {
                    self.submitBtn.backgroundColor = .ykn_primaryButtonFill.withAlphaComponent(0.2)
                }
                self.updateSubmitButtonState()
            }

            if i % 2 == 1 {
                top = Double(feedButton.bottom + 9)
            }
        }
        
        if let topRightItem = topRightItem {
            //右上角按钮
            self.submitBtn.frame = CGRect.init(x: self.width - YKNGap.youku_margin_left() - 72, y: 27, width: 72, height: 30)
            self.submitBtn.layer.cornerRadius = self.submitBtn.height/2.0
            self.submitBtn.clipsToBounds = true
            self.submitBtn.isUserInteractionEnabled = false
            self.submitBtn.backgroundColor = .ykn_primaryButtonFill.withAlphaComponent(0.2)
            self.submitString = topRightItem.title
            self.submitBtn.setTitle("确认", for: .normal)
            self.submitBtn.titleLabel?.font = YKNFont.mediumfont_size_middle2()
            self.submitBtn.setTitleColor(.ykn_primaryButtonInfo, for: .normal)
            addSubview(self.submitBtn)
            
            //confirm click event
            weak var weakself = self
            self.submitBtn.whenTapped {
                weakself?.updateSubmitButtonState()
                
                if let isUserInteractionEnabled = weakself?.submitBtn.isUserInteractionEnabled, isUserInteractionEnabled {
                    if let weakself = weakself, let block = weakself.confirmBlock {
                        var selReasons = weakself.selectedReasons
                        if selReasons.count == 0, let r = topRightItem.reason {
                            selReasons.append(r)
                        }
                        block(selReasons)
                    }
                    if let spmAB = feedbackModel?.report?.spmAB, let spmC = feedbackModel?.report?.spmC {
                        let spm = spmAB + "." + spmC + ".feedback"
                        let scm = feedbackModel?.report?.scm ?? ""
                        YoukuAnalytics.sharedInstance()?.collectALiCustomEvent(withEventID: "2101",
                                                                               pageName: feedbackModel?.report?.pageName ?? "",
                                                                               arg1: nil,
                                                                               arg2: nil,
                                                                               args:["spm": spm, "scm":scm])
                    }
                }
            }
        }
        
        addSubview(self.bottomView)
        if self.safeAreaInsets.bottom > 0 {
            self.bottomView.frame = CGRect(x: 0, y: self.height - 50.0 - self.safeAreaInsets.bottom, width: self.width, height: 50.0)
        } else {
            self.bottomView.frame = CGRect(x: 0, y: self.height - 50.0, width: self.width, height: 50.0)
        }
        weak var weakself = self
        self.bottomView.whenTapped {
            weakself?.delegate?.dismissFeedbackVC()
        }
    }
    
    func updateSubmitButtonState() {
        if self.selectedReasons.count > 0 {
            self.submitBtn.backgroundColor = .ykn_primaryButtonFill
            self.submitBtn.isUserInteractionEnabled = true
        } else {
            self.submitBtn.backgroundColor = .ykn_primaryButtonFill.withAlphaComponent(0.2)
            self.submitBtn.isUserInteractionEnabled = false
        }
    }
    
    static func calcFrame(reasons: [FeedbackItemModel]) -> (CGRect) {
        let reasonCount = reasons.count
        let lineNumber = ceil(Double(reasonCount)/2.0)
        let height = 78 + lineNumber * 36 + max((lineNumber - 1), 0) * 9 + (lineNumber > 0 ? 16 : 0) + 50.0
        var containerWidth = YKRLLayoutManager.sharedInstance()?.screenSize.width ?? YKRLScreenWidth()
        if containerWidth > 450 {
            containerWidth = 450
        }
        let width = containerWidth - 10 * 2
        return (CGRect.init(x: 0.0, y: 0.0, width: Double(width), height: Double(height)))
    }
    
}
