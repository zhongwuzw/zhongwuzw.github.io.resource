//
//  Component14000.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/28.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku

class Component14000: NSObject, ComponentDelegate {
   
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {
        if let componentModel = self.component?.model as? BaseComponentModel {
            componentModel.extraExtend["aspectRatio"] = 1.78
        }
    }
   
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_column_spacing()
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
