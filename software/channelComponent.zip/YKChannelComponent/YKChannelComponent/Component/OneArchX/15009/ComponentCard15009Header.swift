//
//  ComponentCard15009Header.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/31.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArch
import YoukuResource
import OneArchSupport4Youku
import YKResponsiveLayout
let YKComponentCard15009HeaderContentViewTag = 3842765
class ComponentCard15009Header: ComponentEventHandler, ComponentDelegate, IPageScrollEventHandler {
    
    var componentWrapper: ComponentWrapper?
    
    var contentView: ComponentCard15009HeaderView?
    weak var reuseView: UIView?

    func componentDidInit() {
    }

    func layoutType() -> ComponentLayoutType {
        return .custom
    }
     
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.dim_6(), right: 0)
        if let isUserSystemPage = self.component?.getPage()?.pageContext?.concurrentDataMap["isUserSystemPage"] as? Int,
           isUserSystemPage == 1 {
            config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        }
        return config
    }

    func columnCount() -> CGFloat {
        return 1
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [self]
    }

    func reuseId() -> String? {
        let addressString = self.description
        return "card15009header" + addressString
    }

    /// item高度
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        var totalHeight = ComponentCard15009HeaderView.calItemHeight(false)
            if let item = self.component?.getItems()?.first, let model = item.itemModel, let subtTitle = model.subtitle, subtTitle.isEmpty == false {} else {
                totalHeight -= (YKNFont.height(with: YKNFont.quaternary_auxiliary_text(), lineNumber: 1) + 6)
            }
        return totalHeight
        
    }

    /// 初始化item view
    func createView(_ itemSize: CGSize) -> UIView {
        removeLastViewIfNeeded()
        
        let frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
        let parentView = UIView.init(frame:frame)
        let view = ComponentCard15009HeaderView.init(frame: frame)
        view.tag = YKComponentCard15009HeaderContentViewTag
        parentView.addSubview(view)
        contentView = view
        addObserver()
        return parentView
    }

    /// 复用
    func reuseView(itemView: UIView) {
        self.reuseView = itemView
        changeContentViewParent()
        UIView.performWithoutAnimation {
            contentView?.fillData(component: self.component)
        }
    }
    
    // MARK: scroll delegate
    
    /// 容器滚动
    func containerDidScroll(_ scrollView: UIScrollView) {
        changeContentViewParent()
    }
    
    func changeContentViewParent() {
        guard let scrollView = component?.pageContext?.getContainerView() as? UICollectionView else {
            return
        }
        guard let component = self.component else {
            return
        }
        
        let layoutInfo = component.getLayoutInfo()
        let scrollOffset = scrollView.contentInset.top + scrollView.contentOffset.y
        changeParentView(scrollOffset > layoutInfo.y - (self.component?.getCard()?.cardModel?.dataCenterMap["headerMarginTop"] as? CGFloat ?? 0.0))
        print("fuzhong 15009 content offset y \(layoutInfo.y) \(scrollOffset)")
    }
    
    /// 拖拽容器开始
    func containerWillBeginDragging(_ scrollView: UIScrollView) {
        
    }
    
    /// 拖拽容器将结束
    func containerWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        
    }
    
    /// 拖拽容器已结束
    func containerDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        
    }
    
    /// 容器滚动减速开始
    func containerWillBeginDecelerating(_ scrollView: UIScrollView) {
        
    }
    
    /// 容器滚动减速结束
    func containerDidEndDecelerating(_ scrollView: UIScrollView) {
        
    }

    /// 容器滚动动画结束
    func containerDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        
    }
    
    func changeParentView(_ isFilterType: Bool) {
        guard let contentView = contentView else {
            return
        }
        
        if isFilterType {
            guard let component = component, let vcView = component.pageContext?.getViewController()?.view else {
                return
            }
            guard let scrollView = component.pageContext?.getContainerView() as? UICollectionView else {
                return
            }
            vcView.addSubview(contentView)
            contentView.top = scrollView.contentInset.top + (component.getCard()?.cardModel?.dataCenterMap["headerMarginTop"] as? CGFloat ?? 0.0)
            contentView.updateFilterType(true)
            vcView.bringSubviewToFront(contentView)
        } else {
            contentView.top = 0
            contentView.updateFilterType(false)
            self.reuseView?.addSubview(contentView)
        }
    }
    
    @objc func resetParentView() {
        if let isUserCenterPage = self.component?.getPage()?.data(forKey: "YoukuUserCenterPage") as? String, isUserCenterPage == "1" {
            changeContentViewParent()
            return
        }
        changeParentView(false)
    }
    
    func addObserver() {
        NotificationCenter.default.removeObserver(self)
        NotificationCenter.default.addObserver(self, selector: #selector(resetParentView), name: NSNotification.Name("card.15009.resetParentView"), object: nil)
    }
    
    func removeLastViewIfNeeded() {
        guard let component = component, let vcView = component.pageContext?.getViewController()?.view else {
            return
        }
        
        if let view = vcView.viewWithTag(YKComponentCard15009HeaderContentViewTag) {
            view.removeFromSuperview()
            print("15009 removeLastViewIfNeeded")
        }
    }
}
