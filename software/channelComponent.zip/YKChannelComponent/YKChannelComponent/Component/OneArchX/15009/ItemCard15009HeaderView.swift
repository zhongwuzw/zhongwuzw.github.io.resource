//
//  ItemCard15009Header.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/31.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

class ItemCard15009HeaderView: AccessibilityView {

    weak var item:IItem?
    
    //MARK: Property
    lazy var titleLabel:UILabel = {
        let label = UILabel(frame:CGRect.init(x: 0, y: 12, width: self.width, height: 22 * YKNSize.yk_icon_size_scale()))
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        label.textColor = UIColor.ykn_secondaryInfo
        return label
    }()
    
    lazy var subtitleLabel:UILabel = {
        let label = UILabel(frame:CGRect.init(x: 0, y: self.titleLabel.bottom, width: self.width, height: 15 * YKNSize.yk_icon_size_scale()))
        label.textAlignment = .center
        label.font = YKNFont.quaternary_auxiliary_text()
        label.textColor = UIColor.ykn_tertiaryInfo
        return label
    }()
    
    lazy var imageView: UIImageGIFView = {
        let view = UIImageGIFView.init(frame: CGRect.init(x: 0, y: YKNGap.dim_7(), width: 52 * YKNSize.yk_icon_size_scale(), height: 24 * YKNSize.yk_icon_size_scale()))
        view.contentMode = .scaleAspectFit
        return view
    }()
    
    lazy var subTitleLabelBGView: UIView = {
        let view = UIView.init(frame: CGRect.zero)
        view.backgroundColor = UIColor.ykn_elevatedIconFill
        view.layer.cornerRadius = subtitleLabel.height / 2
        return view
    }()
    
    var isFilterType: Bool = false
    weak var contentView: ComponentCard15009HeaderView?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.titleLabel)
        self.addSubview(self.subTitleLabelBGView)
        self.addSubview(self.subtitleLabel)
        self.addSubview(self.imageView)
        NotificationCenter.default.addObserver(self, selector: #selector(selectItemChanged), name: NSNotification.Name("card.15009.sel.index.changed"), object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(item: IItem?, component: IComponent?) {
        self.item = item
        guard let item = item, let itemModel = item.model as? BaseItemModel else {
            return
        }
        guard let compModel = component?.model as? BaseComponentModel else {
            return
        }
        self.backgroundColor = .clear
      
        self.titleLabel.text = itemModel.title
        self.subtitleLabel.text = itemModel.subtitle
        
        let subtitleLabelfitSize = self.subtitleLabel.sizeThatFits(self.subtitleLabel.size)
        self.subTitleLabelBGView.frame = CGRect.init(x: (self.width - subtitleLabelfitSize.width - 15) / 2, y: self.subtitleLabel.top, width: subtitleLabelfitSize.width + 15, height: self.subtitleLabel.height)
        
        let count = itemModel.subtitle?.count ?? 0 
        self.subtitleLabel.alpha = !(count > 0) ? 0 : 1
        self.subTitleLabelBGView.alpha = self.subtitleLabel.alpha

        refreshSelectItem(itemModel)
        updateFilterType(self.isFilterType)
        relayoutSubviews()
        // action
        Service.statistics.bind(itemModel.action?.report, self, .Defalut)
        weak var weakself = self
        self.whenTapped {
            if weakself?.isItemSelected() == true {
                return
            }
            if weakself?.isFilterType == true ?? false {
                weakself?.item?.getComponent()?.scrollTo(at: .top, animated: false)
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "card.15009.resetParentView"), object: nil, userInfo: nil)
            }
            compModel.extraExtend["item.select.index"] = item.index
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "card.15009.sel.index.changed"), object: nil, userInfo: nil)
            component?.getCard()?.changeMultiTabCardIndex(item.index)
        }
    }
    
    func refreshSelectItem(_ itemModel: BaseItemModel) {
        let isSelected = isItemSelected()
        if isSelected {
            self.titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
            self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: itemModel.scene?.sceneTitleColor())
            self.subtitleLabel.textColor = UIColor.ykn_whiteNavigationBar
            self.titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .medium)
        } else {
            self.titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .regular)
            self.titleLabel.textColor = sceneUtil(.ykn_secondaryInfo, sceneColor: itemModel.scene?.sceneSubTitleColor())
            self.subtitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: itemModel.scene?.sceneSubTitleColor())
            self.titleLabel.font = UIFont.systemFont(ofSize: 18, weight: .regular)
        }
        
        self.subTitleLabelBGView.backgroundColor = sceneUtil(.ykn_elevatedIconFill, sceneColor: itemModel.scene?.sceneThemeColor())
        subTitleLabelBGView.isHidden = !isSelected
    }
    
    func updateFilterType(_ isFilterType: Bool) {
        self.isFilterType = isFilterType
        
        self.subtitleLabel.isHidden = isFilterType
        self.subTitleLabelBGView.isHidden = isFilterType
        if !isFilterType {
            let isSelect = isItemSelected()
            self.subTitleLabelBGView.isHidden = !isSelect
        }
    }

    func isItemSelected() -> Bool {
        guard let item = self.item else {
            return ((self.item?.index) ?? 0) == 0
        }
        if let componentModel = item.getComponent()?.model as? BaseComponentModel {
            if let selIndex = componentModel.extraExtend["item.select.index"] as? Int {
                return (selIndex == item.index)
            }
        }
        return ((self.item?.index) ?? 0) == 0
    }
    
    @objc func selectItemChanged() {
        guard let item = item, let itemModel = item.model as? BaseItemModel else {
            return
        }
        
        refreshSelectItem(itemModel)
        updateFilterType(self.isFilterType)
    }
    
    func relayoutSubviews() {
        if self.subtitleLabel.bottom > self.height { //适配大字体 
            let minY = self.subtitleLabel.bottom - self.height
            self.titleLabel.top = self.titleLabel.top - minY
            self.subtitleLabel.top = self.titleLabel.bottom
            self.subTitleLabelBGView.top = self.subtitleLabel.top
        }
    }
}

class ItemCard15009Header: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {
        
    }
    
    func itemWidth() -> CGFloat {
        return 0
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView.init()
    }
    
    func reuseView(itemView: UIView) {

    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
}
