//
//  ComponentCard15009HeaderView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/31.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArch
import OneArchSupport4Youku
import YKModeConfigFramework

class ComponentCard15009HeaderView: UIView {
    
    lazy var scrollView: UIScrollView = {
        let view = UIScrollView(frame:self.bounds)
        view.contentInset = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: 0, right: YKNGap.youku_margin_right())
        view.showsHorizontalScrollIndicator = false
        view.showsVerticalScrollIndicator = false
        view.isScrollEnabled = false
        return view
    }()
    
    var curItemViews: [ItemCard15009HeaderView]?
    var isFilterType: Bool = false
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.clipsToBounds = true
        self.addSubview(self.scrollView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func fillData(component: IComponent?) {
        
        guard let items = component?.getItems() else {
            return
        }
        
        createUsedItemViews(items)
        
        for i in 0..<items.count {
            let item = items[i]
            if let view = curItemViews?[i] {
                view.isFilterType = isFilterType
                view.fillData(item: item, component: component)
            }
        }
        
        if let view = curItemViews?.last {
            self.scrollView.contentSize = CGSize.init(width: view.right + YKNGap.dim_9(), height: 1)
        }
        
        // scene
        self.backgroundColor = sceneUtil(.ykn_primaryBackground, sceneColor: component?.compModel?.scene?.sceneBgColor())
        
        if let isUserSystemPage = component?.getPage()?.pageContext?.concurrentDataMap["isUserSystemPage"] as? Int,
           isUserSystemPage == 1 {
            self.backgroundColor = .ykn_primaryBackground
        }
    }
    
    func updateFilterType(_ isFilterType: Bool) {
        if self.isFilterType == isFilterType {
            return
        }
        
        self.isFilterType = isFilterType
        
        self.height = ComponentCard15009HeaderView.calItemHeight(isFilterType)
        if let curItemViews = curItemViews {
            for view in curItemViews {
                view.updateFilterType(isFilterType)
            }
        }
    }
    
    /// MARK: - private
    
    func createUsedItemViews(_ items: [IItem]) {
        var shouldCreate: Bool = false
        if curItemViews == nil {
            shouldCreate = true
        } else if let curItemViews = curItemViews ,curItemViews.count != items.count {
            shouldCreate = true
            for view in curItemViews {
                view.removeFromSuperview()
            }
        }
        
        if shouldCreate {
            self.scrollView.isScrollEnabled = false
            createItemViews(items)
        }
    }
    
    func createItemViews(_ items:[IItem]) {
        var result = [ItemCard15009HeaderView]()
        
        var totalWidth:CGFloat = 0
        var calWidths:[CGFloat] = [CGFloat]()
        
        for i in 0..<items.count {
            let item = items[i]
            
            let calWidth = calItemWidth(item)
            let calHeight = ComponentCard15009HeaderView.calItemHeight(false)
            
            calWidths.append(calWidth)
            totalWidth += calWidth
            
            let itemView = ItemCard15009HeaderView.init(frame: CGRect.init(x: 0, y: 0, width: calWidth, height: calHeight))
            self.scrollView.addSubview(itemView)
            result.append(itemView)
        }
        self.curItemViews = result
        
        let calMagin = calUsedItemMagin(totalWidth, items.count)
        var x:CGFloat = 0
        for i in 0..<result.count {
            let view = result[i]
            view.left = x
            let calWidth = calWidths[i]
            view.width = calWidth
            x = x + calWidth + calMagin
        }
    }
    
    func calItemWidth(_ item: IItem) -> CGFloat {
        guard let model = item.itemModel else {
            return 0
        }
        
        let titleW = ceil(calcStringSize(model.title, font: UIFont.systemFont(ofSize: 18, weight: .medium), size: CGSize.init(width: 1000, height: CGFloat.greatestFiniteMagnitude)).width)
        let subTitleW = ceil(calcStringSize(model.subtitle, font: YKNFont.quaternary_auxiliary_text(), size: CGSize.init(width: 1000, height: CGFloat.greatestFiniteMagnitude)).width)
        let realW = max(titleW, subTitleW + 15)
        return  realW
    }
    
    static func calItemHeight(_ isFilterType: Bool) -> CGFloat {
        if isFilterType {
            return 12 + YKNFont.height(with: UIFont.systemFont(ofSize: 18, weight: .medium), lineNumber: 1) + 12
        } else {
            return 20 * YKFontModeManager.sharedInstance().getFontScale() + YKNFont.height(with: UIFont.systemFont(ofSize: 18, weight: .medium), lineNumber: 1) + YKNFont.height(with: YKNFont.quaternary_auxiliary_text(), lineNumber: 1)
        }
    }
    
    func calItemMagin(_ totalW: CGFloat, _ itemCount: Int) -> CGFloat {
        return (self.width - YKNGap.youku_margin_left() - YKNGap.youku_margin_right() - totalW) / CGFloat((itemCount - 1))
    }
    
    func calUsedItemMagin(_ totalW: CGFloat, _ itemCount: Int) -> CGFloat {
        var calMagin = calItemMagin(totalW, itemCount)
        if calMagin < 10 {
            calMagin = 15
            self.scrollView.isScrollEnabled = true
        } else if calMagin > 70 {
            calMagin = 15
        }
        return calMagin
    }
}
