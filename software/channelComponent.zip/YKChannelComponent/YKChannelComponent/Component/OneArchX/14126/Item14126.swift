//
//  Item14126.swift
//  YKChannelComponent
//
//  Created by better on 2022/6/14.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource
import YKHome

class Item14126: NSObject, ItemDelegate {
    
    let kYKSCItemPluginNUNativeViewH: CGFloat = 105;
    let kYKSCItemPluginNUNativeViewW: CGFloat = 244;

    var itemWrapper: ItemWrapper?
    func itemDidInit() {
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func itemWidth() -> CGFloat {
        return kYKSCItemPluginNUNativeViewW * YKNSize.yk_icon_size_scale()
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return kYKSCItemPluginNUNativeViewH * YKNSize.yk_icon_size_scale()
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemWidth = itemSize.width
        let itemHeight = itemSize.height
        let ratio:CGFloat = YKNSize.yk_icon_size_scale() > 0 ? (1.0 / YKNSize.yk_icon_size_scale()) : 1.0
        let itemView = createItemView(frame: CGRect.init(x: 0, y: 0, width: itemWidth * ratio, height: itemHeight * ratio))
        itemView.tag = -10101
        let containerView = UIView.init(frame: CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight))
        containerView.backgroundColor = UIColor.clear
        containerView.addSubview(itemView)
        return itemView
    }

    func createItemView(frame:CGRect) -> YKSCItemPluginNUNativeView {
        return YKSCItemPluginNUNativeView.init(frame: frame)
    }

    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? YKSCItemPluginNUNativeView else {
            return
        }
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        
        resetFrameBeforeReuse(itemView)
        
        itemView.transform = CGAffineTransform.identity
        itemView.setup(withExtraExtendInfo: itemModel.extraExtend)
        
        itemView.abTestKey = item?.getComponent()?.compModel?.abTestKey

        Service.statistics.bind(itemModel.action?.report, itemView.leftExpoView, .OnlyExposure)
        
        itemView.transform = CGAffineTransform.init(scaleX: YKNSize.yk_icon_size_scale(), y: YKNSize.yk_icon_size_scale())
        if let parentView = itemView.superview {
            itemView.center = CGPoint.init(x: parentView.width/2.0, y: parentView.height/2.0)
        }
        
        if itemModel.action != nil, itemModel.action?.actionType == "route" {
            Service.action.bind(itemModel.action, itemView) {
                itemView.getReward {
                    
                }
            } didAction: {
                
            }
        } else {
            weak var weakItemView = itemView
            itemView.whenTapped {
                weakItemView?.getReward {
                    
                }
            }
        }
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func resetFrameBeforeReuse(_ itemView: UIView) {
        itemView.bounds = CGRect.init(x: 0, y: 0, width: kYKSCItemPluginNUNativeViewW, height: kYKSCItemPluginNUNativeViewH) //从标准frame开始缩放，这里架构已经将frame设置成缩放后值，先重置回去
    }
}

class Item14293: Item14126 {

    override func itemWidth() -> CGFloat {
        return 244 * YKNSize.yk_icon_size_scale()
    }

    override func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 65 * YKNSize.yk_icon_size_scale()
    }
    override func createItemView(frame:CGRect) -> YKSCItemPluginNUNativeView {
        return YKSCItemPluginNUNativeView14293.init(frame: frame)
    }
    
    override func resetFrameBeforeReuse(_ itemView: UIView) {
        itemView.bounds = CGRect.init(x: 0, y: 0, width: 244, height: 65)
    }
}

class Item14294: Item14126 {
    
    override func itemWidth() -> CGFloat {
        let itemWidth:CGFloat = (YKRLScreenWidth() - YKNGap.youku_margin_left() * 2 - YKNGap.youku_column_spacing())/2.0
        return itemWidth
    }

    override func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 73 * YKNSize.yk_icon_size_scale()
    }
    override func createItemView(frame:CGRect) -> YKSCItemPluginNUNativeView {
        return YKSCItemPluginNUNativeView14294.init(frame: frame)
    }
    
    override func resetFrameBeforeReuse(_ itemView: UIView) {
        itemView.bounds = CGRect.init(x: 0, y: 0, width: itemView.width / YKNSize.yk_icon_size_scale(), height: 73)
    }
}
