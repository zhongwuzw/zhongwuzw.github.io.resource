//
//  Component14126.swift
//  YKChannelComponent
//
//  Created by better on 2022/6/14.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout
import OneArchSupport4Youku
import orange

class Component14126:NSObject, ComponentDelegate {
    
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {
        NotificationCenter.default.addObserver(self, selector: #selector(memberInfoChange), name: NSNotification.Name("kMemberInfoChangedOnlyForUSER"), object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func memberInfoChange() {
        if disablePullRefresh() {
            return
        }
        self.component?.getPage()?.triggerFirstPageRequest()
    }

    func layoutType() -> ComponentLayoutType {
        return .horizontalScroll
    }

    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        config.preferredCardSpacingTop = 0
        config.pageFirstCompTopMargin = 9
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.preferredRowHeight = preferredRowHeight()
        config.horizontalPaddingLeft = YKNGap.youku_margin_left()
        config.horizontalPaddingRight = YKNGap.youku_margin_right()
        return config
    }

    func preferredRowHeight() -> CGFloat {
        return 105 * YKNSize.yk_icon_size_scale()
    }

    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        if let collectionView = itemView.subviews.first as? UICollectionView {
            collectionView.contentOffset = CGPoint.init(x: -YKNGap.youku_margin_left(), y: 0)
        }
    }
    
    func columnCount() -> CGFloat {
        return 0.0
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
    
    func disablePullRefresh() -> Bool {
        //默认关闭
        let orangeInfo = Orange.getGroupConfig(byGroupName: "YKHome_Selection_Common")
        let disablePullRefresh = orangeInfo?["disablePullRefresh"] as? String
        //disablePullRefresh有值 并且 为0时才能打开刷新能力
        if (disablePullRefresh != nil), disablePullRefresh == "0" {
            return false
        }
        return true
    }
}

class Component14293: Component14126 {
    override func preferredRowHeight() -> CGFloat {
        return 65 * YKNSize.yk_icon_size_scale()
    }
}

class Component14294: Component14126 {
    override func preferredRowHeight() -> CGFloat {
        return 73 * YKNSize.yk_icon_size_scale()
    }
}
