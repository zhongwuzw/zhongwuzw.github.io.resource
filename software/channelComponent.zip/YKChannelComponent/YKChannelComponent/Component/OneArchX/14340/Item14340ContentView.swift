//
//  Item14340ContentView.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/6/7.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import Lottie
import YKHome
import OneArchSupport
import OneArchSupport4Youku
import OneArch
import OneTransition
import YKResponsiveLayout

class Item14340ContentView: AccessibilityView, Item14340PlayerContainerDelegate {
    
    weak var component: IComponent?
    var nruItemModel: NruItemModel?
    var itemModel: Item14340Model?

    let slientIconTag: Int = 202406071

    var shouldShowNruItemView: Bool = false
    
    lazy var playerContainer: Item14340PlayerContainer = {
        let view = Item14340PlayerContainer.init()
        view.delegate = self
        view.frame = self.bounds
        view.slientIcon = self.slientIcon
        return view
    }()
    
    lazy var logoContainer: Item14340TitleLogoView = {
        let view = Item14340TitleLogoView.init();
        view.frame = self.bounds
        return view
    }()
    
    lazy var slientIcon: UIButton = {
        let view = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 50, height: 50))
        view.backgroundColor = .clear
        view.tag = slientIconTag
        view.isUserInteractionEnabled = true
        view.imageView?.contentMode = .scaleAspectFit
        view.setImage(UIImage.init(named: "muteVoice"), for: UIControl.State.normal)
        view.addTarget(self, action: #selector(slientIconTap), for: UIControl.Event.touchUpInside)
        view.backgroundColor = .clear
        view.alpha = 0.8
        return view
    }()
    
    lazy var nruItemView: NruItemView = {
        let nruX = YKNGap.dim_8();
        let nruWidth = self.width - nruX * 2;
        let view = NruItemView.init(frame: CGRect(x: nruX, y: self.height - 66, width: nruWidth, height: 66))
        view.isHidden = true
        return view
    }()
    
    lazy var nruTitleView: UILabel = {
        let nruX = YKNGap.dim_8();
        let nruWidth = self.width - nruX * 2;
        let view = UILabel.init(frame: CGRect(x: nruX, y: 0, width: nruWidth, height: 22))
        view.font = YKNFont.discuss_content_text_weight(.medium)
        view.textColor = UIColor.ykn_primaryInfo
        return view
    }()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        initSubviews()
    }
    
    func initSubviews() {
        self.addSubview(self.playerContainer)
        self.addSubview(self.logoContainer)
        self.addSubview(self.nruTitleView)
        self.addSubview(self.nruItemView)
        self.addSubview(slientIcon)

        NotificationCenter.default.addObserver(self, selector: #selector(showChannelTabMenu), name: NSNotification.Name.init(rawValue: "YKHomeToolMenu.showChannelTabMenu"), object: nil)
        
        self.layoutCustomViews()
    }

    func fillData(_ itemModel: Item14340Model?, component: IComponent?) {
        let isSameComp = isSameobject(object1: component, object2: self.component)

        self.itemModel = itemModel
        self.component = component
        guard let itemModel = itemModel else { return }
        
        if !isSameComp {
            self.shouldShowNruItemView = false
            self.nruItemModel = (component?.compModel as? ComponentModel14340)?.nruItemModel
            if self.nruItemModel == nil {
                self.shouldShowNruItemView = false
            } else {
                self.shouldShowNruItemView = true
            }
            // nruTitleView
            let nextCardTitle = getNextCardTitle()
            self.nruTitleView.text = nextCardTitle;
            // nruItemView
            if let nruItemModel = self.nruItemModel {
                nruItemView.fillData(model: nruItemModel, component: component)
                if self.shouldShowNruItemView {
                    nruItemView.isHidden = false
                } else {
                    nruItemView.isHidden = true
                }
            } else {
                nruItemView.isHidden = true
            }
        }
        
        Service.action.bind(itemModel.action, self)
        self.layoutCustomViews()
        playerContainer.fillData(itemModel)
        logoContainer.fillData(itemModel)
        self.resetSlientIconFrame()
    }
    
    func resetSlientIconFrame() {
        self.slientIcon.bottom = self.logoContainer.top
        self.slientIcon.right = self.width
    }
    
    func getNextCardKeywordsJson() -> [String: Any]? {
        if let cards = component?.getPage()?.getCards(),
           let cardIndex = component?.getCard()?.index {
            if cardIndex + 1 < cards.count {
                let nextCard = cards[cardIndex + 1]
                return nextCard.cardModel?.keywords?.first?.cmsInfo
            }
        }
        return nil
    }
    
    func getNextCardTitle() -> String? {
        if let cards = component?.getPage()?.getCards(),
           let cardIndex = component?.getCard()?.index {
            if cardIndex + 1 < cards.count {
                let nextCard = cards[cardIndex + 1]
                return nextCard.cardModel?.title
            }
        }
        return nil
    }
    
    func layoutCustomViews() {
        let playerHeight = Item14340CommonUtils.playerContainerHeight(self.width)
        self.playerContainer.frame = CGRect(x: 0, y: self.height - playerHeight, width: self.width, height: playerHeight)
        
        let logoContainerHeight = Item14340TitleLogoView.viewHeight()
        let logoContainerTop = self.height - Item14340CommonUtils.logoContainerBottomMargin_GoodsCardHidden() - logoContainerHeight //底部40
        
        if self.shouldShowNruItemView {
            self.logoContainer.bottom = self.height - Item14340CommonUtils.logoContainerBottomMargin_GoodsCardShow()
        } else {
            self.logoContainer.frame = CGRect(x: 0, y: logoContainerTop, width: self.width, height: logoContainerHeight)
        }
        self.resetSlientIconFrame()
        
        let nruX = YKNGap.dim_8();
        let nruWidth = self.width - nruX * 2;
        self.nruTitleView.frame = CGRect(x: nruX, y: 0, width: nruWidth, height: 22)
        self.nruTitleView.bottom = self.height
        self.nruItemView.frame = CGRect(x: nruX, y: 0, width: nruWidth, height: 66)
        self.nruItemView.bottom = self.height
    }
    
    @objc func slientIconTap() {
        self.playerContainer.slientIconTap()
    }
    
    @objc func showChannelTabMenu() {
        self.layoutCustomViews()
    }
    
    ///MARK:Item14340PlayerContainerDelegate
    func playingProgress(_ progress: Int, totalTime time: Int) {

    }
}
