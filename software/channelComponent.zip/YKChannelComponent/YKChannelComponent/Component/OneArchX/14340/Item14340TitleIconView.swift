//
//  Item14340TitleLogoView.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/6/7.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKHome
import YKUIComponent
import OneArchSupport
import OneArchSupport4Youku

class Item14340TitleLogoView: UIView {
    
    var itemModel: Item14340Model?

    lazy var logoImageView:UIImageGIFView = {
        let view = UIImageGIFView()
        view.backgroundColor = .clear
        view.contentMode = .scaleAspectFit
        return view
    }()

    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.white
        view.font = UIFont.init(name: "PingFangSC-Semibold", size: 24)
        view.numberOfLines = 1
        view.isHidden = true
        return view
    }()
    
    lazy var markLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.white
        view.font = YKNFont.posteritem_auxiliary_text()
        view.numberOfLines = 1
        view.textAlignment = .center
        return view
    }()
    
    lazy var markLabelGradientLayerView: UIView = {
        let view = UIView.init(frame: CGRect(x: 0, y: 0, width: 50, height: 18))
        self.addSubview(view)
        view.backgroundColor = UIColor.clear
        view.frame = self.bounds
        view.height = self.height - 100
        view.isUserInteractionEnabled = true
        view.isHidden = true
        view.clipsToBounds = true
        view.layer.cornerRadius = 4.0
        return view
    }()
    
    lazy var markLabelGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint =  CGPoint.init(x: 0.0, y: 1.0)
        layer.endPoint = CGPoint.init(x: 1.0, y: 1.0)

        self.markLabelGradientLayerView.layer.insertSublayer(layer, at: 0)
        
        layer.colors = [UIColor.createColorWithHexRGB(colorStr: "#00c9fd").cgColor, UIColor.createColorWithHexRGB(colorStr: "#00a3f5").cgColor]
        return layer
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.white
        view.font = YKNFont.posteritem_maintitle_weight(.medium)
        view.numberOfLines = 1
        return view
    }()
    
    lazy var playBtn: UIButton = {
        let view = UIButton(frame: CGRect(x: 0, y: 0, width: 60, height: 30))
        view.backgroundColor = UIColor.white.withAlphaComponent(0.2)
        view.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        view.setTitle("播放", for: UIControl.State.normal)
        var titleColor = UIColor.createColorWithHexRGB(colorStr: "#eaeaea")
        view.setTitleColor(titleColor, for: UIControl.State.normal)
        view.clipsToBounds = true
        view.layer.cornerRadius = 15
        view.layer.borderColor = UIColor.white.withAlphaComponent(0.2).cgColor
        view.layer.borderWidth = 1.0
        view.isHidden = true
        return view
    }()
    
    lazy var summaryLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.white
        view.font = YKNFont.posteritem_auxiliary_text()
        view.numberOfLines = 1
        view.textAlignment = .center
        view.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#ff4f34")
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 7.0
        view.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner, .layerMaxXMaxYCorner]
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: .zero)
        addSubview(self.logoImageView)
        addSubview(self.titleLabel)
        addSubview(self.markLabelGradientLayerView)
        markLabelGradientLayerView.addSubview(self.markLabel)
        addSubview(self.subtitleLabel)
        addSubview(playBtn)
        addSubview(summaryLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    func fillData(_ itemModel: Item14340Model?) {
        self.itemModel = itemModel
        self.layoutCustomSubViews()

        guard let itemModel = itemModel else {return}
        
        titleLabel.text = itemModel.title
        subtitleLabel.text = itemModel.subtitle
                
        if let img = itemModel.titleIcon?.url, !img.isEmpty {
            titleLabel.isHidden = true
            logoImageView.isHidden = false
            logoImageView.alpha = 1.0
            logoImageView.sd_setImage(with: URL(string: img)) { image, error, cacheType, url in
                
            }
        } else {
            titleLabel.isHidden = false
            logoImageView.isHidden = true
        }
        
        playBtn.isHidden = false
        playBtn.setTitle(itemModel.playButtonText ?? "播放", for: .normal)
        
        Service.action.bind(itemModel.action, playBtn)
        
        markLabel.isHidden = true
        markLabelGradientLayerView.isHidden = true
        if let mark = itemModel.mark?.text, !mark.isEmpty {
            markLabel.text = mark
            markLabel.isHidden = false
            markLabelGradientLayerView.isHidden = false
        }
        
        summaryLabel.isHidden = true
        if let summary = itemModel.summary?.text, !summary.isEmpty {
            summaryLabel.text = summary
            summaryLabel.isHidden = false
        }
        
        subtitleLabel.textColor = .white
        if let themeColor = itemModel.scene?.sceneThemeColor() {
            subtitleLabel.textColor = themeColor
        }
        
        self.layoutCustomSubViews()
    }
    
    
    
    func layoutCustomSubViews() {
        
        var markSize = CGSize(width: 50, height: 18)
        if let markLayout = itemModel?.layout.mark {
            markSize = markLayout.renderRect.size
        }
        markLabelGradientLayerView.frame = CGRect(x: 15.0, y: height - markSize.height, width: markSize.width, height: markSize.height)
        markLabelGradientLayer.frame = markLabelGradientLayerView.bounds

        markLabel.frame = markLabelGradientLayerView.bounds
            
        let subtitleHeight = Item14340CommonUtils.logoSubtitleHeight()
        let subtitleTop = Item14340CommonUtils.logoSubtitleTop()
        let subtitleLeft:CGFloat = markLabelGradientLayerView.isHidden ? 15.0 : markLabelGradientLayerView.right + 6.0
        subtitleLabel.frame = CGRect(x: subtitleLeft, y: height - subtitleHeight, width: width - 30, height: subtitleHeight)
        subtitleLabel.centerY = markLabelGradientLayerView.centerY
        
        logoImageView.layer.anchorPoint = CGPoint.init(x: 0, y: 1)
        logoImageView.transform = .identity
        logoImageView.frame = getImgFrame(itemModel)
        
        let logoViewSize = Item14340CommonUtils.logoSize()
        titleLabel.frame = CGRect(x: 15, y: 0, width: logoViewSize.width, height: logoViewSize.height)
        
        if let extraExtend = itemModel?.layout.extendExtra, let playBtnLayout = extraExtend["playButtonText"] as? TextLayoutModel {
            playBtn.frame = playBtnLayout.renderRect
        } else {
            playBtn.frame = CGRect(x: 0, y: 0, width: 60, height: 30)
        }
        playBtn.right = self.width - 15
        playBtn.centerY = titleLabel.centerY
        
        var summarySize = CGSize(width: 48, height: 14)
        if let summaryLayout = itemModel?.layout.summary {
            summarySize = summaryLayout.renderRect.size
            summarySize.width += 12
            summarySize.height = 14
        }
        summaryLabel.size = summarySize
        summaryLabel.bottom = playBtn.top + 5.0
        summaryLabel.right = playBtn.right
    }
    
    func getImgRatio(_ itemModel:Item14340Model) -> CGFloat {
        var ratioH = Item14340CommonUtils.logoSize().height
        let ratioW = Item14340CommonUtils.logoSize().width
        ratioH = max(1, ratioH)
        var ratio:CGFloat = ratioW / ratioH
        let imgW:CGFloat = CGFloat(itemModel.titleIcon?.width ?? 0)
        let imgH:CGFloat = CGFloat(itemModel.titleIcon?.height ?? 0)
        if imgW > 0 , imgH > 0 {
            ratio = imgW / imgH
        }
        return ratio
    }
    
    func getImgSize(_ itemModel:Item14340Model) -> CGSize {
        let ratio = getImgRatio(itemModel)
        let imgHeight = Item14340CommonUtils.logoSize().height
        let imgWidth = imgHeight * ratio
        let logoViewSize = CGSize.init(width: imgWidth, height: imgHeight)
        return logoViewSize
    }
    
    func getImgFrame(_ itemModel:Item14340Model?) -> CGRect {
        var logoViewSize = Item14340CommonUtils.logoSize()
        guard let itemModel = itemModel else {
            return CGRect(x: 15, y: 0, width: logoViewSize.width, height: logoViewSize.height)
        }
        logoViewSize = getImgSize(itemModel)
        return CGRect(x: 15, y: 0, width: logoViewSize.width, height: logoViewSize.height)
    }

    
    static func viewHeight() -> CGFloat {
        return Item14340CommonUtils.logoSubtitleHeight() + Item14340CommonUtils.logoSubtitleTop() + Item14340CommonUtils.logoSize().height
    }
}
