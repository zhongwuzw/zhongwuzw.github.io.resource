//
//  Item14340Moel.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/6/7.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class ComponentModel14340: BaseComponentModel {
    // nru
    var nruItemModel: NruItemModel?

    override func setup(_ cmsInfo: [String: Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        guard let dataInfo = cmsInfo?["data"] as? [String: Any] else {
            return
        }
        
        // 创建nru数据模型
        self.nruItemModel = NruItemModel.creatModel(dataInfo)
    }
}


class Item14340Model: BaseItemModel {
    var playButtonText: String?
    
    override func setup(_ cmsInfo: [String: Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        guard let dataInfo = cmsInfo?["data"] as? [String: Any] else {
            return
        }
        
        if let playButtonText = dataInfo["playButtonText"] as? String {
            self.playButtonText = playButtonText
        }        
    }
}
