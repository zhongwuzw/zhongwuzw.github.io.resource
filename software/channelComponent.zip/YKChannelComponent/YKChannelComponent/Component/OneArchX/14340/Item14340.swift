//
//  Item14340.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/6/7.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item14340:NSObject, ItemDelegate {
    var itemWrapper: OneArch.ItemWrapper?
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14340Model.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    
    func columnCount() -> CGFloat {
        return 1.0
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler()]
    }
    
    func itemDidInit() {
    }
    
    func receiveEstimatedLayout(_ itemWidth: Double) {

    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView()
    }

    func reuseView(itemView: UIView) {
    }
}
