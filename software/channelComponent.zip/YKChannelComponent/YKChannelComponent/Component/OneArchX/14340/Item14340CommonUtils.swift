//
//  Item14340CommonUtils.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/6/7.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKHome
import OneArchSupport4Youku

public class Item14340CommonUtils {
    
    static func playerContainerOverTop() -> CGFloat {
        return homeContainerPaddingTop()
    }
    
    static func playerContainerHeight(_ itemWidth: CGFloat) -> CGFloat {
        let height = (450.0 / 375.0) * itemWidth
        return height
    }
    
    static func itemViewHeight(_ itemWidth: CGFloat) -> CGFloat {
        var height = playerContainerHeight(itemWidth)
        height -= playerContainerOverTop()
        return height
    }

    static func logoSize() -> CGSize {
        return CGSize.init(width: 198, height: 50)
    }

    static func logoSubtitleTop() -> CGFloat {
        return 6.0
    }

    static func logoSubtitleHeight() -> CGFloat {
        return 20
    }
    
    static func logoContainerBottomMargin_GoodsCardHidden() -> CGFloat {
        return 40
    }
    static func logoContainerBottomMargin_GoodsCardShow() -> CGFloat {
        return 75
    }
}
