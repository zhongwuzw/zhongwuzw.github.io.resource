//
//  Component14340.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/6/7.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku
import OneArchSupport
import YKHome
import YKChannelPage

class Component14340:NSObject, ComponentDelegate,ComponentLifeCycleDelegate,ComponentAddPageScrollEventHandlerDelegate {
    
    weak var itemView: Item14340ContentView?
    // 时间间隔统计
    var isItemAppear = false
    var isPageAppear = false
    var end = CFAbsoluteTimeGetCurrent() * 1000
    var start = CFAbsoluteTimeGetCurrent() * 1000
    
    var progress: CGFloat = 0.0
    var itemSize: CGSize = .zero
    var itemModel: Item14340Model? {
        get {
            return self.component?.getItems()?.first?.itemModel as? Item14340Model
        }
    }
    
    lazy var lifeCycleHandler:ComponentLifeCycleEventHandler = {
        let handler = ComponentLifeCycleEventHandler()
        handler.delegate = self
        return handler
    }()

    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    var componentWrapper: ComponentWrapper?
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 9.0
        config.preferredRowHeight = 0.0 //100
        return config
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        var array = [ComponentEventHandler]()
        let addPageScollHandler = ComponentAddPageScrollEventHandler.init()
        addPageScollHandler.delegate = self
        array.append(addPageScollHandler)
        array.append(self.lifeCycleHandler)
        let playerHandler = PlayerScrollEndCompEventHandler()
        array.append(playerHandler)
        return array
    }
    
    func componentDidInit() {
        
    }
    
    func columnCount() -> CGFloat {
        return 1
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        var height = Item14340CommonUtils.playerContainerHeight(itemWidth)
        height -= YKHomeNuImmersiveHelper.sharedInstance().getTargetPagePaddingTop(isNuImmersiveShowChannelBtnMode(self.component?.getPage()))
        
        self.estimatedLayout(itemWidth, itemHeight: height)

        return height
    }
    
    
    func createView(_ itemSize: CGSize) -> UIView {
        let view = Item14340ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return view
    }
    

    func reuseView(itemView: UIView) {
        itemSize = itemView.size
        guard let itemView = itemView as? Item14340ContentView else { return  }
        
        if let component = component {
            let layoutInfo = component.getLayoutInfo()
            if let pageModel = self.component?.getPage()?.model as? SelectionPageModel {
                pageModel.lunboY = layoutInfo.y
                pageModel.lunboMaxY = layoutInfo.height + layoutInfo.y
            }
        }
        
        self.itemView = itemView
        itemView.clipsToBounds = false
        itemView.superview?.clipsToBounds = false
//        itemView.superview?.superview?.clipsToBounds = false
        itemView.fillData(self.itemModel, component: self.component)
        
        itemModel?.extend["scrollAutoPlay"] = "play"
        if let playerModel = itemModel?.playerModel {
            let height = Item14340CommonUtils.playerContainerHeight(itemView.width)
            Service.player.attach(playerModel, toView: itemView.playerContainer.videoImageView, displayFrame: CGRect.init(origin: CGPoint.zero, size: CGSize(width: itemView.width, height: height)))
        }
        
        self.notifyNavigatinBar()
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return ComponentModel14340.self as? T.Type
    }
    
    func estimatedLayout(_ itemWidth: CGFloat, itemHeight: CGFloat) {
        let itemLayout = self.itemModel?.layout
        itemLayout?.extendExtra = [String: Any]()
        if let mark = self.itemModel?.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: CGSize(width: itemWidth, height: itemHeight))
            itemLayout?.mark = layout
        }
        if let summary = self.itemModel?.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize: CGSize(width: itemWidth, height: itemHeight))
            itemLayout?.summary = layout
        }
        if let playButtonText = self.itemModel?.playButtonText {
            let layout = TextLayoutModel()
            let titleSize = calcStringSize(playButtonText, font: UIFont.systemFont(ofSize: 13), size: .zero)
            layout.renderRect = CGRect(x: 0, y: 0, width: titleSize.width + 30.0, height: 30)
            itemLayout?.extendExtra?["playButtonText"] = layout
        }
    }
    
    func notifyNavigatinBar() {
        //通知顶导
        var userInfo = [String: Any]()
        userInfo["backgroundAlpha"] = self.progress
        userInfo["navAlpha"] = self.progress
        
        postNotification("KRefreshHomeTopViewByNuImmersiveNotification", nil, userInfo)
        
        
        //          var state = "immersiveClear"
        //          if isImmersiveNormalArea {
        //              state = "immersiveNormal"
        //          }
        //          NotificationCenter.default.post(name: NSNotification.Name.init("KRefreshHomeTopViewByImmersiveChannelNotification"), object: nil, userInfo: ["state": state,"enterImmersiveChannel":true])
        //          self.sendProgressToTopNavigation(0.0)
        
        let containerView = self.component?.pageContext?.getContainerView()
        let topBgColorView = containerView?.viewWithTag(202303176)
        topBgColorView?.alpha = 0
    }
    
    func sendProgressToTopNavigation(_ progress:CGFloat) {
        var params = [String: Any]()
        params["progress"] = progress
        NotificationCenter.default.post(name: NSNotification.Name.init("Theater3.topNavigation.background.alpha.changed"), object: "", userInfo: params)
    }
    
    
    func enterDisplayArea(itemView: UIView?) {
        isItemAppear = true
    }
    
    func exitDisplayArea(itemView: UIView?) {
        isItemAppear = false
    }
    
    func didActivate() {
        isPageAppear = true;
        // 触发组件刷新
        start = CFAbsoluteTimeGetCurrent() * 1000
        let interval = start - end //两次操作时间差需要大于800ms
        if isItemAppear, interval > 800  {
            itemView?.nruItemView.refreshData()
        }
    }
    
    func didDeactivate() {
        isPageAppear = false;
        end = CFAbsoluteTimeGetCurrent() * 1000
    }
    
    var isScrollByDragging: Bool = false
    
    func containerWillBeginDragging(_ scrollView: UIScrollView) {
        isScrollByDragging = true
    }
    
    /// 拖拽容器将结束
    func containerWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {}
    
    /// 拖拽容器已结束
    func containerDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if decelerate == false {

        }
    }
    
    /// 容器滚动减速开始
    func containerWillBeginDecelerating(_ scrollView: UIScrollView) { }
    
    /// 容器滚动减速结束
    func containerDidEndDecelerating(_ scrollView: UIScrollView) {

        isScrollByDragging = false
    }

    /// 容器滚动动画结束
    func containerDidEndScrollingAnimation(_ scrollView: UIScrollView) {

        isScrollByDragging = false
    }
    
    func containerDidScroll(_ scrollView: UIScrollView) {
        self.itemView?.playerContainer.containerDidScroll(scrollView)

//        if !isScrollByDragging {
//            return
//        }
        let offsetY = scrollView.contentOffset.y
        let startOffsetY = 120.0 - scrollView.contentInset.top
        let progressHeight = topGradientProgessHeight()
        let stopOffsetY = startOffsetY + progressHeight
        var progress:CGFloat = 0.0
        if offsetY < startOffsetY {
            progress = 0.0
        } else if offsetY > stopOffsetY {
            progress = 1.0
        } else if offsetY >= startOffsetY , offsetY <= stopOffsetY {
            progress = (offsetY - startOffsetY) / progressHeight
        }
        
        self.progress = progress
        self.notifyNavigatinBar()
    }

    func topGradientProgessHeight() -> CGFloat {
        return 40.0
    }
    
}
