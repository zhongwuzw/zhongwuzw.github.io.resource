//
//  Item14340PlayerContainer.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/6/7.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import YKHome
import OneArchSupport
import OneArchSupport4Youku
import YoukuAnalytics

protocol Item14340PlayerContainerDelegate:AnyObject {
    func playingProgress(_ progress: Int, totalTime time: Int)
}

class Item14340PlayerContainer: UIView, PlayerStatusCallback  {
    
    weak var delegate: Item14340PlayerContainerDelegate?
    weak var slientIcon: UIButton?
    
    var itemModel: Item14340Model?
    var topBgHeight = homeContainerPaddingTop()
    var isNodePage: Bool = false
    var selectedIndex:Int = -1
    var playerModel: PlayerModel?
    
    var isDisplaying:Bool = false
    var isActive:Bool = false
    var isSlientMode: Bool = true
//    let slientIconTag:Int = 202406071
    var isPaused = false
    var isStarted = false
    var isPlaying = false
    

//    lazy var slientIcon: UIButton = {
//        let view = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 50, height: 50))
//        view.backgroundColor = .clear
//        view.tag = slientIconTag
//        view.isUserInteractionEnabled = true
//        view.imageView?.contentMode = .scaleAspectFit
//        view.setImage(UIImage.init(named: "muteVoice"), for: UIControl.State.normal)
//        view.addTarget(self, action: #selector(slientIconTap), for: UIControl.Event.touchUpInside)
//        view.backgroundColor = .clear
//        return view
//    }()
    
    lazy var topRefreshBgView: UIView = {
        let view = UIView.init();
        view.frame = self.bounds
        view.height = 800
        view.bottom = 0
        view.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#16161a")
        return view
    }()
    
    lazy var topBgView: UIView = {
        let view = UIView.init();
        view.frame = self.bounds
        view.height = homeContainerPaddingTop()
        view.bottom = self.height
        return view
    }()
    
    lazy var topBgGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)

        self.topBgView.layer.insertSublayer(layer, at: 0)
        
        layer.colors = [UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0.4).cgColor, UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0.4).cgColor]
        layer.frame = self.topBgView.bounds
        return layer
    }()
    
    lazy var topGradientLayerView: UIView = {
        let view = UIView.init();
        view.backgroundColor = UIColor.clear
        view.frame = self.bounds
        view.height = homeContainerPaddingTop()
        view.bottom = self.height
        return view
    }()
    lazy var topGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)

        self.topGradientLayerView.layer.insertSublayer(layer, at: 0)
        
        layer.colors = [UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0.4).cgColor, UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0.0).cgColor]
        layer.frame = self.topGradientLayerView.bounds
        return layer
    }()
    
    lazy var bottomGradientLayerView: UIView = {
        let view = UIView.init(frame: CGRect(x: 0, y: 0, width: 300, height: 80))
        self.addSubview(view)
        view.backgroundColor = UIColor.clear
        view.frame = self.bounds
        view.height = self.height - 80
        view.isUserInteractionEnabled = true
        view.isHidden = true
        return view
    }()

    lazy var bottomGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)

        self.bottomGradientLayerView.layer.insertSublayer(layer, at: 0)
        
        layer.colors = [UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0.0).cgColor, UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(1.0).cgColor]
        layer.frame = self.bottomGradientLayerView.bounds
        return layer
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.isUserInteractionEnabled = true
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.topRefreshBgView)
        self.addSubview(self.videoImageView)
        self.addSubview(self.topBgView)
        self.addSubview(self.topGradientLayerView)
        self.addSubview(self.bottomGradientLayerView)
//        self.addSubview(slientIcon)

        self.layoutCustomViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func fillData(_ itemModel: Item14340Model?) {
        self.itemModel = itemModel
        
        topBgHeight = homeContainerPaddingTop()
        
        var bottomLayerColor = UIColor.ykn_primaryBackground
        if let bgColor = itemModel?.scene?.sceneBgColor() {
            bottomLayerColor = bgColor
        }
        bottomGradientLayer.colors = [bottomLayerColor.withAlphaComponent(0.0).cgColor, bottomLayerColor.withAlphaComponent(1.0).cgColor]
        bottomGradientLayerView.isHidden = false
        
        self.playerModel = itemModel?.playerModel
        self.playerModel?.slientModeInPage = true
        self.playerModel?.playerDelegate = self
        self.playerModel?.disableSeekStart = true
        self.slientIcon?.isHidden = true
        
        let img = self.getVideoImageUrl(itemModel)
        videoImageView.frame = CGRect.init(x: 0, y: 0, width: self.width, height: self.height)
        videoImageView.sd_setImage(with: URL.init(string: img ?? ""))

        self.layoutCustomViews()
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.layoutCustomViews()
    }
    
    func layoutCustomViews() {
        
        let topRefreshHeight = 800.0
        self.topRefreshBgView.frame = CGRect(x: 0, y: -topRefreshHeight, width: self.width, height: topRefreshHeight)

        self.topBgView.frame = CGRect(x: 0, y: 0, width: self.width, height: homeContainerPaddingTop())
        self.topBgGradientLayer.frame = self.topBgView.bounds

        self.topGradientLayerView.frame = CGRect(x: 0, y: topBgView.bottom, width: self.width, height: 40.0)
        self.topGradientLayer.frame = self.topGradientLayerView.bounds
        
        self.bottomGradientLayerView.frame = CGRect(x: 0, y: self.height - 80, width: self.width, height: 80)
        self.bottomGradientLayer.frame = self.bottomGradientLayerView.bounds
                
        videoImageView.frame = CGRect.init(x: 0, y: 0, width: self.width, height: self.height)
    }
    
    @objc func slientIconTap() {
        if let player = PlayerControlManagerV2.shareInstance().currentPlayerView {
            if self.isSlientMode {
                player.isSlientMode = false
            } else {
                player.isSlientMode = true
            }
            self.isSlientMode = player.isSlientMode
            self.slientIconUpdate()
        }
    }
    
    func slientIconUpdate()  {
        var image = UIImage.init(named: "unmuteVoice")
        if self.isSlientMode {
            image = UIImage.init(named: "muteVoice")
        }
        self.slientIcon?.setImage(image, for: UIControl.State.normal)
    }
    
    func containerDidScroll(_ scrollView: UIScrollView) {
        let topInset = scrollView.pullToRefreshView.originalTopInset
        let offsetY = scrollView.contentOffset.y
        if offsetY < -topInset {
            self.topBgGradientLayer.colors = [UIColor.createColorWithHexRGB(colorStr: "#16161a").cgColor, UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0).cgColor]
            self.topGradientLayer.colors = [UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0).cgColor, UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0).cgColor]
        } else {
            self.topBgGradientLayer.colors = [UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0.4).cgColor, UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0.4).cgColor]
            self.topGradientLayer.colors = [UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0.4).cgColor, UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0).cgColor]
        }
    }
    
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
        var bottomLayerColor = UIColor.ykn_primaryBackground
        if let bgColor = itemModel?.scene?.sceneBgColor() {
            bottomLayerColor = bgColor
        }
        bottomGradientLayer.colors = [bottomLayerColor.withAlphaComponent(0.0).cgColor, bottomLayerColor.withAlphaComponent(1.0).cgColor]
    }
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
}

extension Item14340PlayerContainer {
    func didStartPlayVideoInPlayer(_ player: PlayerView) {
        print("[14340] player didStartPlayVideoInPlayer")
//        self.bringSubviewToFront(self.slientIcon)
        
        //1.isUserInteractionEnabled
        if let embedPlayerView = player.embedPlayerView {
            embedPlayerView.isUserInteractionEnabled = true
        }
        isPaused = false
        isStarted = true
        isPlaying = true
        
        //同步静音设置
        slientIcon?.isHidden = false
        player.isSlientMode = self.isSlientMode
        self.slientIconUpdate()
    }
    func didFinishPositiveVideoInPlayer(_ player: PlayerView) {
        slientIcon?.isHidden = true
        isStarted = false
        isPlaying = false
    }
    func didPassiveStopPlayer(_ player: PlayerView) {
        isStarted = false
        isPlaying = false
    }
    func didClickStopPlayer(_ player: PlayerView) {
        isStarted = false
        isPlaying = false
    }
    func playTimeDidChange(_ player: PlayerView) {
        self.delegate?.playingProgress(Int(player.playingTime), totalTime: Int(player.totalTime))
    }
}
    
///MARK:IMAGE
extension Item14340PlayerContainer {
    func getVideoImageUrl(_ itemModel: Item14340Model?) -> String? {
        guard let itemModel = itemModel else {return nil}

        var img = itemModel.img
        if let coverImg = itemModel.previewModel?.coverImg {
            img = coverImg
        }
        return img
    }
    
}
