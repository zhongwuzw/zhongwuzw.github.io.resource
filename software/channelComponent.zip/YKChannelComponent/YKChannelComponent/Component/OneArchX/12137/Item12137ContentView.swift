//
//  Item12137ContentView.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/11/15.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import Lottie
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item12137ContentView: UIView {
        
    //MARK: Property
    lazy var bgView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.clipsToBounds = true
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
//        view.clipsToBounds = true
//        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.numberOfLines = 0
        return view
    }()
    
    lazy var subTitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.textAlignment = .left
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        self.addSubview(bgView)
        bgView.addSubview(videoImageView)
        bgView.addSubview(titleLabel)
        bgView.addSubview(subTitleLabel)
        
        self.backgroundColor = UIColor.ykn_primaryBackground
        self.clipsToBounds = true
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
    }
    
    func fillData(_ model: BaseItemModel) {

        titleLabel.text = model.title

        subTitleLabel.text = model.subtitle
        
        videoImageView.frame = self.imageViewFrame()
        videoImageView.ykn_setImage(withURLString: XCDNSTRING(model.img),
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
    

        

        relayoutSubviews()

        //color
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: model.scene?.sceneTitleColor() )
        self.subTitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: model.scene?.sceneSubTitleColor())
        self.subTitleLabel.isHidden = model.hideSubtitle
        self.backgroundColor = sceneUtil(UIColor.ykn_elevatedPrimaryBackground, sceneColor: model.scene?.sceneCardFooterBgColor())
    }
    
    
    func relayoutSubviews() {
        bgView.frame = self.bounds
        
        let w = self.imageViewFrame().size.width
        videoImageView.frame = self.imageViewFrame()

        let y = CGFloat(videoImageView.frame.maxY) + YKNGap.youku_picture_title_spacing()
        titleLabel.frame = CGRect.init(x: 9, y: y, width: w - 18.0, height: Item12137.titleHeight)

        subTitleLabel.frame = CGRect.init(x: 9, y: titleLabel.frame.maxY, width: w - 18.0, height: Item12137.subtitleHeight)
    }
    
    func imageViewFrame() -> CGRect {
        let w = self.frame.size.width
        let h = ceil(w * 4.0/3.0)
        return CGRect.init(x: 0, y: 0, width: w, height: h)
    }
}

class Item12160ContentView: Item12137ContentView {
    
    override func fillData(_ model: BaseItemModel) {
        super.fillData(model)
        self.backgroundColor = sceneUtil(UIColor.clear, sceneColor: model.scene?.sceneCardFooterBgColor())
    }
    
    override func relayoutSubviews() {
        bgView.frame = self.bounds
        
        let w = self.imageViewFrame().size.width
        videoImageView.frame = self.imageViewFrame()
        videoImageView.clipsToBounds = true
        videoImageView.layer.cornerRadius = YKNCorner.radius_secondary_medium()

        let y = CGFloat(videoImageView.frame.maxY) + YKNGap.youku_picture_title_spacing()
        titleLabel.frame = CGRect.init(x: 2.0, y: y, width: w - 4.0, height: Item12137.titleHeight)
        titleLabel.font = YKNFont.posteritem_maintitle_weight(.medium)

        subTitleLabel.frame = CGRect.init(x: 2.0, y: titleLabel.frame.maxY, width: w - 4.0, height: Item12137.subtitleHeight)
        subTitleLabel.textColor = UIColor.ykn_secondaryInfo
    }
    
}
