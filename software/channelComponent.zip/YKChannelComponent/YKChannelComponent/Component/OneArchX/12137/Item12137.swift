//
//  Item12137.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/11/15.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout

class Item12137:NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    
    func columnCount() -> CGFloat {
        return 2.0
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.receiveEstimatedLayout(Double(itemWidth))
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler(),
                ItemPlayerProgressEventHandler(),
                LongPressPreviewItemEventHandler()
        ]
    }
    
    func itemDidInit() {
        if let reasons = item?.itemModel?.reasons {
            for (index, reason) in reasons.enumerated() {
                if index == 1, let img = reason.img, img.isEmpty == false {
                    item?.itemModel?.reasons?[index].imgEnabled = true
                }
            }
            
            //靠下对齐布局，需要统一高度，恢复所有推荐理由的垂直边距
            item?.itemModel?.reasons = reasons.map({
                var newReason = $0
                newReason.isNeedVerticalPaddingAtYK11 = true
                return newReason
            })
        }
    }
    
    static var titleHeight:CGFloat = 20
    static var subtitleHeight:CGFloat = 17

    func receiveEstimatedLayout(_ itemWidth: Double) {
        //标题顶部9.0 + 推荐理由顶部padding9.0 + 推荐理由尾部12.0
        // 所以最终是9.0 + 9.0 + 10.0 = 28的padding
        //适配大字体:内容是20+17+14
        let bottomPadding = 12.0

        var reasonHeight = ceil(17.0 * CGFloat(YKNSize.yk_icon_size_scale()))
        if let reasons = item?.itemModel?.reasons {
//            let h: Double = ceil(17.0 * Double((YKNSize.yk_icon_size_scale() - 1.0) / 2.0 + 1.0))
            let h: Double = ceil(17.0 * Double(YKNSize.yk_icon_size_scale()))
            let x = 9.0
            let boundingwidth = itemWidth - x - 30
            let layout = Service.reasons.estimatedLayout(reasons,
                                                         position: CGPoint.zero,
                                                         boundingSize: CGSize.init(width: boundingwidth, height: h))
            item?.layout?.reasons = layout

            if let firstLayout = layout.first, firstLayout.renderRect.height > 0 {
                reasonHeight = firstLayout.renderRect.height
            }
        }
        
        var bottomHeight = 27 + 20 + 17 + reasonHeight
        if self.item?.itemModel?.hideSubtitle == true {
            bottomHeight = 27 + 20 + reasonHeight
        }

        let ratio_4_3 = 4.0 / 3.0
        let itemHeight = ceil(itemWidth * ratio_4_3) + bottomHeight
        item?.layout?.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)
        
        
        let width = itemWidth
        let height = width * ratio_4_3
        let videoImageViewSize = CGSize.init(width: width, height: height)
        if let mark = item?.itemModel?.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: videoImageViewSize)
            item?.layout?.mark = layout
        }
        
        if let lbTexts = item?.itemModel?.lbTexts {
            let layout = Service.lbTexts.estimatedLayout(lbTexts, toViewSize: videoImageViewSize)
            item?.layout?.lbTexts = layout
        }
        
        if let summary = item?.itemModel?.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize: videoImageViewSize)
            item?.layout?.summary = layout
        }
        
        if let reasons = item?.itemModel?.reasons {
//            let h: Double = ceil(17.0 * Double((YKNSize.yk_icon_size_scale() - 1.0) / 2.0 + 1.0))
            let h: Double = ceil(17.0 * Double(YKNSize.yk_icon_size_scale()))
            let x = 9.0
            let boundingwidth = width - x - 30
            let layout = Service.reasons.estimatedLayout(reasons,
                                                         position: CGPoint.init(x: x, y: itemHeight - h - bottomPadding),
                                                         boundingSize: CGSize.init(width: boundingwidth, height: h))
            item?.layout?.reasons = layout
        }
    }
    
    
    func createView(_ itemSize: CGSize) -> UIView {
            let itemView = Item12137ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            return itemView
    }

    func reuseView(itemView: UIView) {
       
        guard let itemView = itemView as? Item12137ContentView else {
            return
        }
        guard let itemModel = self.item?.itemModel else {
            return
        }
        
        itemView.fillData(itemModel)

        let layout = self.item?.itemModel?.layout

        //埋点
        Service.action.bind(self.item?.itemModel?.action, itemView)

        //负反馈
        weak var weakself = self
        weak var weakComponent = self.item?.getComponent()
        
        itemModel.feedbackModel?.feedbackFinished = {
            if let weakself = weakself,
               let component = weakComponent
               {
                deleteComponentWithAnimation(component)
            }
        }
        
        Service.player.attach(itemModel.playerModel, toView: itemView.videoImageView, displayFrame: itemView.imageViewFrame())
                
        Service.summary.attach(itemModel.summary, toView: itemView.videoImageView, layout: layout?.summary)
        Service.lbTexts.attach(itemModel.lbTexts, toView: itemView.videoImageView, layouts: layout?.lbTexts)
        Service.reasons.attach(itemModel.reasons, toView: itemView, layouts: layout?.reasons)
        Service.mark.attach(itemModel.mark, toView: itemView.videoImageView, layout: layout?.mark)
    }
}

class Item12160:Item12137 {
    
    override func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item12160ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    override func receiveEstimatedLayout(_ itemWidth: Double) {
        super.receiveEstimatedLayout(itemWidth)

        var reasonHeight = ceil(17.0 * CGFloat(YKNSize.yk_icon_size_scale()))
        if let reasons = item?.itemModel?.reasons {
//            let h: Double = ceil(17.0 * Double((YKNSize.yk_icon_size_scale() - 1.0) / 2.0 + 1.0))
            let h: Double = ceil(17.0 * Double(YKNSize.yk_icon_size_scale()))
            let x = 2.0
            let boundingwidth = itemWidth - x - 30
            let layout = Service.reasons.estimatedLayout(reasons,
                                                         position: CGPoint.zero,
                                                         boundingSize: CGSize.init(width: boundingwidth, height: h))
            item?.layout?.reasons = layout

            if let firstLayout = layout.first, firstLayout.renderRect.height > 0 {
                reasonHeight = firstLayout.renderRect.height
            }
        }
        
        var bottomHeight = 20.0 + YKNGap.youku_picture_title_spacing() + 17.0 + 6.0 + reasonHeight
        if self.item?.itemModel?.hideSubtitle == true || self.item?.itemModel?.subtitle == nil || self.item?.itemModel?.subtitle?.count == 0 {
            bottomHeight = 20.0 + YKNGap.youku_picture_title_spacing() + reasonHeight
        }
        
        let ratio_4_3 = 4.0 / 3.0
        let itemHeight = ceil(itemWidth * ratio_4_3) + bottomHeight
        item?.layout?.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)
        
        if let reasons = item?.itemModel?.reasons {
//            let h: Double = ceil(17.0 * Double((YKNSize.yk_icon_size_scale() - 1.0) / 2.0 + 1.0))
            let h: Double = ceil(17.0 * Double(YKNSize.yk_icon_size_scale()))
            let x = 2.0
            let boundingwidth = itemWidth - x - 30
            let layout = Service.reasons.estimatedLayout(reasons,
                                                         position: CGPoint.init(x: x, y: itemHeight - h),
                                                         boundingSize: CGSize.init(width: boundingwidth, height: h))
            item?.layout?.reasons = layout
        }
    }
    
}
