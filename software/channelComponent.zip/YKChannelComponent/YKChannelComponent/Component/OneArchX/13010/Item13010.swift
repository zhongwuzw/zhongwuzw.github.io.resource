//
//  Item13010.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/4/21.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item13010: NSObject, ItemDelegate {

    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func itemWidth() -> CGFloat {
        let width :CGFloat = ceil(92 * YKNSize.yk_icon_size_scale())
        return width
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        var height: CGFloat = ceil(123 * YKNSize.yk_icon_size_scale())
        if let firstBrotherItem = item?.getComponent()?.getItems()?.first,
           let firstBrotherItemModel = firstBrotherItem.model as? HomeItemModel,
           let coverLayout = firstBrotherItemModel.layout.cover
        {
            height = coverLayout.renderRect.size.height
        }
        estimatedLayout(CGSize.init(width: itemWidth, height: height))
        
        return height
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item13010ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item13010ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        
        itemView.fillWithModel(itemModel)
        Service.action.bind(itemModel.action, itemView)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func estimatedLayout(_ itemSize: CGSize) {
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        
        let layoutModel = itemModel.layout
        if layoutModel.boundingSize == itemSize {
            return //重复计算跳过
        }
        
        layoutModel.boundingSize = itemSize
        layoutModel.renderRect = CGRect.init(origin: .zero, size: itemSize)
        layoutModel.extendExtra = [String: Any]()
        
        // cover
        let cover = ImageLayoutModel.init()
        cover.renderRect = CGRect.init(origin: .zero, size: itemSize)
        layoutModel.cover = cover
    }
}

