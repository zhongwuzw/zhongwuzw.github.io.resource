//
//  Item13010ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/4/21.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import OneArchSupport4Youku

class Item13010ContentView: AccessibilityView {
    
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .ykn_primaryFill
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel.init()
        label.font = YKNFont.posteritem_subhead()
        label.textAlignment = .center
        label.textColor = UIColor.ykn_tertiaryInfo
        return label
    }()
    
    lazy var moreArrowImageView: UIImageView = {
        let icon = UIImageView.init(frame:CGRect.init(x: 0, y: 0, width: 12, height: 12))
        icon.image = UIImage.init(named: "ykn_more_btn")?.withRenderingMode(.alwaysTemplate)
        icon.tintColor = .ykn_tertiaryInfo
        return icon
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(self.contentView)
        
        contentView.addSubview(self.titleLabel)
        contentView.addSubview(self.moreArrowImageView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillWithModel(_ itemModel: BaseItemModel) {
        let title = itemModel.title ?? "更多"
        self.titleLabel.text = title
        self.contentView.frame = itemModel.layout.cover?.renderRect ?? .zero
        
        self.titleLabel.width = calcStringSize(title, font: self.titleLabel.font, size: .zero).width
        self.titleLabel.height = YKNFont.height(with: titleLabel.font, lineNumber: 1)
        self.titleLabel.centerX = contentView.centerX - moreArrowImageView.width / 2
        self.titleLabel.centerY = contentView.centerY
        
        self.moreArrowImageView.left = self.titleLabel.right
        self.moreArrowImageView.centerY = self.titleLabel.centerY
        
        //氛围
        let scene = itemModel.scene
        self.contentView.backgroundColor = sceneUtil(.ykn_secondaryBackground, sceneColor: scene?.sceneCardFooterBgColor())
        self.titleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: scene?.sceneCardFooterTitleColor())
        self.moreArrowImageView.tintColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: scene?.sceneCardFooterTitleColor())
    }
}

