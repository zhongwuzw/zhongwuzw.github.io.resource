//
//  Item12095ContentView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/10/19.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import OneTransition
import OneTransitionCore

class Item12095ContentView: AccessibilityView {
    
    weak var model:BaseItemModel?
    weak var feedMoreBtn: UIView?
    var sceneTitleColor: UIColor?
    var sceneThemeColor: UIColor?
    var sceneButtonSelectBgColor: UIColor?
    var transitionAutoPlayAdaptor = TransitionAutoPlayAdaptorV2()

    lazy var contentView: UIView = {
        let view = UIView()
        view.layer.masksToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.layer.borderColor = UIColor.ykn_hideAbleSeparator.cgColor
        view.layer.borderWidth = 0.5
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        return view
    }()
    
    lazy var favorBtn: YKTrackShowView = {
        let view = YKTrackShowView.init(frame: CGRect.init(x: 0, y: 0, width: 60, height: 30))
        view.whenTapped {
            self.favorAction()
        }
        view.isHidden = true
        return view
    }()
    
    lazy var playIconView: PlayerIconPreviewView = {
        let view = PlayerIconPreviewView()
        return view
    }()
        
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle_weight(YKNFontWeight.medium)
        view.numberOfLines = 0
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_secondaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        return view
    }()
    
    lazy var uploaderLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        return view
    }()
            
    lazy var followContentView: UserFollowViewV2 = {
        let view = UserFollowViewV2()
        return view
    }()


    //MARK:

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        self.backgroundColor = UIColor.ykn_primaryBackground
        
        self.addSubview(contentView)
        
        contentView.addSubview(videoImageView)
        let w = Double(self.frame.size.width);
        let h = Double(ceil(w * 9.0/16.0));
        videoImageView.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
//        videoImageView.addSubview(playIconView)
        
        contentView.addSubview(followContentView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(subtitleLabel)
        contentView.addSubview(uploaderLabel)
        contentView.addSubview(favorBtn)

        
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddCollectSuccessNotication), name: NSNotification.Name.init("kBSAddCollectSuccess"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelCollectSuccessNotication), name: NSNotification.Name.init("kBSCancelCollectSuccess"), object: nil)
    }
    
    
    func relayoutSubviews(_ model: BaseItemModel) {
        if UIAccessibility.isVoiceOverRunning {
            followContentView.userFollowView.isHidden = true
            feedMoreBtn?.isHidden = true
            playIconView.isHidden = true
        }


        let margin = Double(YKNGap.dim_6())
        let spacing = Double(YKNGap.dim_5())
        ///VideoImage
        var w = Double(self.frame.width);
        var h = ceil(w * 9.0/16.0);
        var x = 0.0
        var y = 0.0
        contentView.frame = CGRect.init(x: 0, y: 0, width: self.width, height: self.height)
        videoImageView.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
        playIconView.frame = CGRect.init(x: 0, y: 0, width: videoImageView.width, height: videoImageView.height)

        ///Bottom
        //favor
        self.sceneTitleColor = model.scene?.sceneTitleColor()
        self.sceneThemeColor = model.scene?.sceneThemeColor()
        self.sceneButtonSelectBgColor = model.scene?.sceneButtonSelectBgColor()
        self.favorBtnLayout(self.model?.trackShow?.isFavor ?? false)
        
        //follow icon
        x = Double(videoImageView.left) + margin;
        y = Double(videoImageView.bottom) + margin;
        w = 36
        h = w + 10
        followContentView.frame = CGRect.init(x: x, y: y, width: w, height: h)
        
        x = Double(followContentView.right) + spacing;
        y = Double(videoImageView.bottom) + spacing;
        w = Double(self.width - x - 9 - 60 - 9)
         if favorBtn.isHidden {
            w = Double(self.width - x - 9)
        }
        h = Double(model.layout.title?.boundingSize?.height ?? 20)
        titleLabel.frame = CGRect.init(x: x, y: y, width:w, height: h)
          
        //subtitle
        x = Double(titleLabel.left)
        y = Double(titleLabel.bottom + 1)
        w = Double(self.width - x - 9 - 60 - 9)
        if favorBtn.isHidden {
            w = Double(self.width - x - 9)
        }
        h = Double(20)
        subtitleLabel.frame = CGRect.init(x: x, y: y, width: w, height: h)

        //uploader
        x = Double(titleLabel.left)
        y = Double(self.height - 20 - 9)
        w = Double(self.width - x - 9 - 60 - 9)
        if favorBtn.isHidden {
            w = Double(self.width - x - 9)
        }
        h = Double(20)
        uploaderLabel.frame = CGRect.init(x: x, y: y, width: w, height: h)

//        feedMoreBtn?.top = self.videoImageView.bottom + 10
//        feedMoreBtn?.right = self.width - 2
    }
    
    func refreshScene() {
        titleLabel.textColor = sceneUtil(UIColor.ykn_primaryInfo, sceneColor: model?.scene?.sceneTitleColor())
        subtitleLabel.textColor = sceneUtil(UIColor.ykn_secondaryInfo, sceneColor: model?.scene?.sceneSubTitleColor())
        uploaderLabel.textColor = sceneUtil(UIColor.ykn_tertiaryInfo, sceneColor: model?.scene?.sceneSubTitleColor())
        self.backgroundColor = .clear
        contentView.backgroundColor = sceneUtil(UIColor.ykn_secondaryGroupedBackground, sceneColor: model?.scene?.sceneCardFooterBgColor())
    }
    
    func fillData(_ itemModel: BaseItemModel, _ layout: OneArchSupport4Youku.LayoutModel) {
        model = itemModel
        let item = model?.domainObject as? IItem
        transitionAutoPlayAdaptor.item = item

        Service.action.bind(itemModel.action, self) {
            // 设置无缝参数
            let transitionId = self.addTransitionItem(itemModel: itemModel)
            let transitionKey = "onetransition_native_params"
            var transitionParams: [String: Any] = [
                "ot_transition_ids": [transitionId]
            ]
            itemModel.action?.routeParams.yk_set(transitionKey, transitionParams)
            if transitionId != nil {
                if PlayerControlManagerV2.enablePlayerPause {
                    if let curPlayerModel = PlayerControlManagerV2.shareInstance().currentPlayerView?.model, let itemPlayerModel = itemModel.playerModel {
                        if curPlayerModel == itemPlayerModel {
                            itemModel.playerModel?.stopNeedCapture = true
                            PlayerControlManagerV2.shareInstance().addStopCaptureView(itemModel.playerModel)
                        }
                    }
                }
            }
        } didAction: {
            // 清除无缝参数
            itemModel.action?.routeParams.removeValue(forKey: "onetransition_native_params")
        }


        // 标题
        titleLabel.text = itemModel.title
                
        // 子标题
        subtitleLabel.text = itemModel.subtitle
        
        // 上传者
        uploaderLabel.text = itemModel.uploader?.name
        
        Service.action.bind(itemModel.uploader?.action, uploaderLabel)

        // 封面
        let w = Double(self.frame.width);
        let h = ceil(w * 9.0/16.0);
        videoImageView.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
        videoImageView.ykn_setImage(withURLString: itemModel.img ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        // 关注
        followContentView.fill(itemModel)
        
        
        if itemModel.trackShow != nil {
            bindStatisticsService()
            favorBtn.isHidden = false
        } else {
            favorBtn.isHidden = true
        }
                
        self.relayoutSubviews(itemModel)


        //负反馈
   
        if let feedbackBtn = self.viewWithTag(999998) {
            self.superview?.accessibilityElements = [self, feedbackBtn]
        }
        self.feedMoreBtn = self.viewWithTag(999998)

        if UIAccessibility.isVoiceOverRunning {
            followContentView.userFollowView.isHidden = true
            feedMoreBtn?.isHidden = true
            ///改为加追
            favorBtn.isHidden = true
            playIconView.isHidden = true
        }

        refreshScene()
        
        self.relayoutSubviews(itemModel)
    }
        
    func addTransitionItem(itemModel: BaseItemModel) -> String? {
        guard let playId = itemModel.playerModel?.playerId,
              let itemView = itemModel.playerModel?.itemView
        else { return nil }
        
        let item = OTTransitionItem()
        item.playId = playId
        item.viewContainer = itemView
        let imgView = UIImageView(frame: self.videoImageView.frame)
        imgView.ykn_setImage(withURLString: itemModel.img ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        item.originRect = self.videoImageView.convert(self.videoImageView.frame, to: nil)
        item.videoCover = imgView
        item.needTransitionBack = true
        item.transitionType = .player
        item.transitionBackDelegate = self.transitionAutoPlayAdaptor
        item.forceChangeGravity = true
        item.originPlayerGravity = .resizeAspectFull
        item.targetPlayerGravity = .resizeAspect
        let transitionId = OTTransitionMonitor.sharedInstance.addTransitionItem(item: item)
        return transitionId
    }
    
    ///MARK: favor
    func favorBtnLayout(_ isFavor: Bool) {
        if model?.trackShow == nil{
            return
        }
  
        if let sceneTitleColor = self.sceneTitleColor, let sceneThemeColor = self.sceneThemeColor  {
            favorBtn.selectTextColor = sceneTitleColor
            favorBtn.selectBgColor = .clear
            favorBtn.selectBorderWidth = 1.0
            favorBtn.selectBorderColor = sceneTitleColor
            
            favorBtn.unselectTextColor = sceneThemeColor
            favorBtn.unselectBgColor = .clear
            favorBtn.unselectBorderWidth = 1.0
            favorBtn.unselectBorderColor = sceneThemeColor
        } else {
            favorBtn.selectTextColor = .ykn_tertiaryInfo
            favorBtn.selectBgColor = .ykn_seconarySeparator
            favorBtn.selectBorderWidth = 0.0
            favorBtn.selectBorderColor = .clear
            
            favorBtn.unselectTextColor = .ykn_brandInfo
            favorBtn.unselectBgColor = .ykn_border
            favorBtn.unselectBorderWidth = 1.0
            favorBtn.unselectBorderColor = .clear
        }
                        
        if let feedMore = self.feedMoreBtn {
            favorBtn.right = feedMore.left - 2
        } else {
            favorBtn.right = self.width - YKNGap.dim_6()
        }
        favorBtn.right = self.width - 9
        favorBtn.top = videoImageView.bottom + 15
        favorBtn.update(isFavor)
    }
    
    func bindStatisticsService() {
        guard let trackShow = model?.trackShow else {
            return
        }
        
        if let isFavor = trackShow.isFavor, isFavor == true {
            let actionModel =  self.model?.extraExtend["uncollectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        } else {
            let actionModel = self.model?.extraExtend["collectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        }
    }
    
    func favorAction() {
        guard let favor = model?.trackShow,
              let isFavor = favor.isFavor
        else {
            return
        }
        
        var params = [String : Any]()
        params["isFavor"] = isFavor
        params["id"] = favor.favorId ?? ""
        
    
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channel.function.adaptor.zhuiju"), object: nil, userInfo: params)
    }
    
    @objc func handleAddCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: true)
    }
    
    @objc func handleCancelCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: false)
    }
    
    func handleNotication(notification: Notification, favored: Bool) {
        guard let userInfo = notification.userInfo,
              let targetId = userInfo["targetId"] as? String
        else {
            return
        }
        
        print("[LJ] 3 userInfo:", userInfo)
        
        guard let favor = model?.trackShow,
              let currentId = favor.favorId,
              let isFavor = favor.isFavor
        else {
            return

        }
        
        guard currentId == targetId else {
            return
        }
        favor.isFavor = favored
        favorBtnLayout(favor.isFavor ?? false)
        bindStatisticsService()
    }
    

}
