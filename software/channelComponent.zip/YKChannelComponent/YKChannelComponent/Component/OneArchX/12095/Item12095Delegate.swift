//
//  Item12095Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/10/19.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item12095Delegate: NSObject, ItemDelegate, PlayerToolsEventHandlerDelegate {
    func didPlayerStart(_ playerModel: PlayerModel?) {
        
    }
    
    func didPlayerStop(_ playerModel: PlayerModel?) {
        
    }
    
    lazy var playerToolsEventHandler:PlayerToolsEventHandler = {
        let handler = PlayerToolsEventHandler()
        handler.delegate = self
        return handler
    }()
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView()
    }
    
    func reuseView(itemView: UIView) {
        
    }
    
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler(),
                self.playerToolsEventHandler,
                ItemPlayerProgressEventHandler(),
                ]
    }
    
    func itemDidInit() {
        if let itemModel = item?.itemModel {
            //favor
            let followActionModel = ActionFactoryV2(itemModel, spmDExt: "_watching")
            
            let unfollowActionModel = ActionFactoryV2(itemModel, spmDExt: "_cancelwatching")
            
            if followActionModel != nil {
                itemModel.extraExtend["collectActionModel"] = followActionModel
            }
            
            if unfollowActionModel != nil {
                itemModel.extraExtend["uncollectActionModel"] = unfollowActionModel
            }
            //follow
            if itemModel.follow != nil {
                let followActionModel = ActionFactoryV2(itemModel, spmDExt: "_sub")
                let unfollowActionModel = ActionFactoryV2(itemModel, spmDExt: "_unsub")
                
                if followActionModel != nil {
                    itemModel.extraExtend["followActionModel"] = followActionModel
                }
                
                if unfollowActionModel != nil {
                    itemModel.extraExtend["unfollowActionModel"] = unfollowActionModel
                }
            }
        }
    }
    
    required override init() {
        
    }

}
