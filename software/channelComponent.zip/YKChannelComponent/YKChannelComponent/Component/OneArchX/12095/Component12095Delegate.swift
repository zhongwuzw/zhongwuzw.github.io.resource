//
//  Component12095Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/10/19.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKChannel
import OneArchBridge
import YKSCBase
import YKResponsiveLayout

class Component12095Delegate: NSObject, ComponentDelegate {

    var itemModel:BaseItemModel? {
        return self.component?.getItems()?.first?.itemModel
    }
    func componentDidInit() {
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseComponentModel.self as? T.Type
    }

    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = 18
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: 18, right: YKNGap.youku_margin_right())
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 9.0
        config.preferredRowHeight = 0.0
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        let playerEvent = PlayerScrollEndCompEventHandler()
        let playerProgress = ComponentPlayerProgressEventHandler()
        return [playerEvent, playerProgress]
    }
    
    var componentWrapper: ComponentWrapper?
    
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.estimatedLayout(itemWidth)
        return itemModel?.layout.renderRect.height ?? 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return Item12095ContentView.init(frame: CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
    }

    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item12095ContentView else {
            return
        }
        guard let itemModel = itemModel else {
            return
        }
        
        let itemLayout = itemModel.layout
        // 角标
        Service.mark.attach(itemModel.mark, toView: itemView.videoImageView, layout: itemLayout.mark)
        // 左下角文案
        Service.lbTexts.attach(itemModel.lbTexts, toView: itemView.videoImageView, layouts: itemLayout.lbTexts)
        // 右下角腰封
        Service.summary.attach(itemModel.summary, toView: itemView.videoImageView, layout: itemLayout.summary)

        // 阴影+圆角
        if let sceneBgImagePath = itemModel.scene?.sceneBgImagePath(), !sceneBgImagePath.isEmpty {
            itemView.yk_addBorderAndShadow(sceneBorderColor:nil)
        } else {
            itemView.yk_addBorderAndShadow(sceneBorderColor:itemModel.scene?.sceneCardFooterBgColor())
        }
        
        // player
        if let playerModel = itemModel.playerModel {

            if playerModel.canPlay {
                itemView.playIconView.isHidden = false
            } else {
                itemView.playIconView.isHidden = true
            }
            var w = CGFloat(itemView.frame.width)
            var h = ceil(w * 9.0/16.0)
            Service.player.attach(playerModel,
                                  toView: itemView.videoImageView,
                                  displayFrame: CGRect.init(origin: CGPoint.zero, size: CGSize.init(width: w, height: h)))
        }

        weak var weakself = self
        Service.feedback.attach(itemModel.feedbackModel, toView: itemView, morePos: .BottomRightBorder, isSupportUndo: false) {
            if let weakself = weakself,
               let component = weakself.component
               {
                deleteComponentWithAnimation(component)
            }
        }
        if let feedbackBtn = itemView.viewWithTag(999998) {
            itemView.superview?.accessibilityElements = [itemView, feedbackBtn]
        }
        
        
        itemView.fillData(itemModel, itemModel.layout)
    }
    
    func estimatedLayout(_ itemWidth: CGFloat) {

        let itemLayout = itemModel?.layout
        
        let itemHeight = self.calcItemHeight(itemWidth)
        
        itemLayout?.renderRect = CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight)
    }
    
    // MARK: 坑位布局计算
    func calcItemHeight(_ itemWidth: CGFloat) -> Double {
        guard let itemModel = itemModel else {
            return 0
        }
        let itemLayout = itemModel.layout
        if  itemLayout.renderRect.isEmpty {
            
            // 坑位
            let videoImgWidth = itemWidth
            let videoImgHeight = ceil(itemWidth * 9.0/16.0)
            let bottomHeight = 79.0
            let itemHeight = videoImgHeight + bottomHeight
            itemLayout.renderRect = .init(x: 0, y: 0, width: itemWidth, height: itemHeight)
         
            if let mark = itemModel.mark {
                let layout = Service.mark.estimatedLayout(mark, toViewSize: CGSize(width: videoImgWidth, height: videoImgHeight))
                itemLayout.mark = layout
            }
            
            if let lbTexts = itemModel.lbTexts {
                let layout = Service.lbTexts.estimatedLayout(lbTexts, toViewSize:CGSize(width: videoImgWidth, height: videoImgHeight))
                itemLayout.lbTexts = layout
            }
            
            if let summary = itemModel.summary {
                let layout = Service.summary.estimatedLayout(summary, toViewSize:CGSize(width: videoImgWidth, height: videoImgHeight))
                itemLayout.summary = layout
            }
        }
        
        return Double(itemLayout.renderRect.height)
    }
}
