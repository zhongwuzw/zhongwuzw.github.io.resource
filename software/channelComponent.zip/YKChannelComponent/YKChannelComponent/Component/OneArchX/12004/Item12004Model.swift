//
//  Item12004Model.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/7/18.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku
import YKResponsiveLayout

class Item12004Model: HomeItemModel {
    var logo: String?
    var extraExtendBgImg: String?
    var bottomItemTitle: String?
    var displayInChannel: Bool = false
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        guard let cmsInfo = cmsInfo, let data = cmsInfo["data"] as? [String : Any], data.count > 0 else {
            return
        }
        
        if let logo = data["logo"] as? String {
            self.logo = logo
        }
        if let posterInfo = data["poster"] as? [String: Any], let lBottomInfo = posterInfo["lBottom"] as? [String: Any] {
            self.bottomItemTitle = lBottomInfo["title"] as? String
        }
        
        if let item = self.domainObject as? IItem, let card = item.getCard(), let cardModel = card.model as? BaseCardModel {
            self.displayInChannel = cardModel.extraExtend["displayInChannel"] as? Bool ?? false
        }
        
        self.extraExtendBgImg = self.extraExtend["bgImg"] as? String
        
        if self.previewModel?.title == nil {
            self.previewModel?.title = self.preview?["title"] as? String
        }
    }
}
