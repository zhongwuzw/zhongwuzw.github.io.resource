//
//  Item12004ContentView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/7/18.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKModeConfigFramework
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKUIComponent
import YKCMSComponent

let  Margin = YKNGap.youku_margin_left()
let  kPlayerMaxRelationWidth: CGFloat = 768
let  kPlayerMaxWidth: CGFloat = 645
let  Padding: CGFloat = 12
let  VideoRatio: CGFloat = 197.0 / 351

class Item12004ContentView: UIView, ChannelSliderPlayerDelegate {
    
    lazy var titleLabel: UILabel = {
        let titleLabel = UILabel.init(frame: .zero)
        titleLabel.textColor = .white
        titleLabel.font = .boldSystemFont(ofSize: 26)
        titleLabel.textAlignment = .center
        return titleLabel
    } ()
    
    lazy var subtitleLabel: UILabel = {
        let subtitleLabel = UILabel.init(frame: .zero)
        subtitleLabel.textColor = .white
        subtitleLabel.font = .systemFont(ofSize: 13)
        subtitleLabel.textAlignment = .center
        return subtitleLabel
    } ()
    
    lazy var bkgrdImageView: UIImageGIFView = {
        let v = UIImageGIFView.init(frame: .zero)
        v.contentMode = .scaleAspectFill
        v.clipsToBounds = true
        return v
    } ()
    
    lazy var logoImageView: UIImageGIFView = {
        let v = UIImageGIFView.init(frame: .zero)
        v.contentMode = .scaleAspectFill
        v.clipsToBounds = true
        return v
    } ()
    
    lazy var playTitleLabel: MarginLabel = {
        let v = MarginLabel.init(frame: .zero)
        v.textColor = .white
        v.font = .systemFont(ofSize: 16)
        v.textAlignment = .left
        v.numberOfLines = 2
        v.verticalAlignment = .top
        return v
    } ()
    
    lazy var playerContainer: UIView = {
        let v = UIView.init(frame: .zero)
        v.layer.cornerRadius = 7
        v.clipsToBounds = true
        return v
    } ()
    
    lazy var gradientLayer: CAGradientLayer = {
        let v = CAGradientLayer.init()
        v.locations = [0.0, 1.0]
        v.startPoint = .zero
        v.endPoint = CGPoint(x: 0, y: 1)
        v.colors = [UIColor(white: 0, alpha: 0.6).cgColor, UIColor(white: 0, alpha: 0.0).cgColor]
        return v
    } ()
    
    lazy var playDurationLabel: UILabel = {
        let v = UILabel.init(frame: .zero)
        v.textColor = .white
        v.textAlignment = .right
        v.font = .systemFont(ofSize: 11)
        return v
    } ()
    
    lazy var bottomGradientLayer: CAGradientLayer = {
        let v = CAGradientLayer.init()
        v.locations = [0.0, 1.0]
        v.startPoint = .zero
        v.endPoint = CGPoint(x: 0, y: 1)
        v.colors = [UIColor(white: 0, alpha: 0.0).cgColor, UIColor(white: 0, alpha: 0.6).cgColor]
        return v
    } ()
    
    lazy var playImageView: UIImageGIFView = {
        let v = UIImageGIFView.init(frame: .zero)
        v.contentMode = .scaleAspectFill
        v.isUserInteractionEnabled = true
        return v
    } ()
    
    lazy var playIconView: UIImageGIFView = {
        let v = UIImageGIFView.init(image: UIImage(named: "st_player_plugin_icon_play"))
        v.isUserInteractionEnabled = true
        
        weak var weakSelf = self
        v.whenTapped {
            weakSelf?.startPlay(true)
        }
        return v
    } ()
    
    weak var item: IItem?
    weak var Handler: Component12004?
    
    var lastImageURLString: String?
    var _isPlaying: Bool = false
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubview(bkgrdImageView)
        addSubview(logoImageView)
        addSubview(titleLabel)
        addSubview(subtitleLabel)
        addSubview(playerContainer)
        
        playerContainer.addSubview(playImageView)
        playImageView.layer.addSublayer(gradientLayer)
        playImageView.addSubview(playTitleLabel)
        playImageView.addSubview(playIconView)
        playImageView.layer.addSublayer(bottomGradientLayer)
        playImageView.addSubview(playDurationLabel)
        
        layoutInit()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        
        if let player = player {
            if Thread.isMainThread {
                player.stopVideo()
                player.embedPlayerView().removeFromSuperview()
            } else {
                DispatchQueue.main.async {
                    player.stopVideo()
                    player.embedPlayerView().removeFromSuperview()
                }
            }
        }
    }
    
    func fillData(_ item: IItem?) {
        guard let item = item , let model = item.itemModel as? Item12004Model else {
            return
        }
        self.item = item
        
        var bgImageURLString = model.img
        
        // bgImg取值逻辑如下：
        /* phone端
        1. 频道页取extraExtend.bgImg
        2. 二级页取img
         */
        
        /* pad端
        1. 统一取bgImg
         */
        
        if ykrl_isResponsiveLayout() {
            bgImageURLString = model.bgImg
        } else if !ykrl_isResponsiveLayout() && model.displayInChannel {
            bgImageURLString = model.extraExtendBgImg
            let statusBarOffset: CGFloat = -44 + YKStatusBarHeight()
            let y: CGFloat = statusBarOffset - 50
            // 适配上顶导状态，高度减50，与安卓保持一致。
            bkgrdImageView.frame = CGRect(x: 0, y: y, width: self.width, height: self.height - statusBarOffset)
        }

        if let bgURLString = bgImageURLString, !bgURLString.isEmpty {
            if bgURLString != lastImageURLString {
                bkgrdImageView.sd_setImage(with: URL(string: bgURLString))
                lastImageURLString = bgURLString
            }
            
            // 无障碍剧场适配无障碍
            if UIAccessibility.isVoiceOverRunning {
                bkgrdImageView.isAccessibilityElement = true
                playerContainer.accessibilityTraits = .header
                let contentDesc = model.config.getStringValue("contentDesc")
                bkgrdImageView.accessibilityLabel = contentDesc ?? "无障碍剧场"
                bkgrdImageView.accessibilityFrame = CGRect(x: (bkgrdImageView.width - 280) / 2, y: playerContainer.top - 120, width: 280, height: 110)
                
                playerContainer.isAccessibilityElement = true
                playerContainer.accessibilityTraits = .startsMediaSession
                playerContainer.accessibilityLabel = "视频播放器，\(String(describing: model.previewModel?.title)))"
                playerContainer.accessibilityHint = "轻点两下控制播放与暂停"
                
                playerContainer.whenTapped { [weak self] in
                    guard let self = self, let player = self.player else {
                        return
                    }
                    
                    if player.isPlaying {
                        player.pauseVideo()
                        self.playerContainer.accessibilityLabel = "暂停"
                    } else {
                        player.replayVideo()
                        self.playerContainer.accessibilityLabel = "播放"
                    }
                }
            }
        } else {
            bkgrdImageView.image = nil
            lastImageURLString = nil
        }

        logoImageView.isHidden = true
        if ykrl_isResponsiveLayout(), let logoImageURLString4iPad = model.logo, !logoImageURLString4iPad.isEmpty {
            logoImageView.sd_setImage(with: URL(string: logoImageURLString4iPad)) { [weak self] (_, _, _, _) in
                self?.logoImageView.isHidden = false
            }
        }

        titleLabel.text = model.title
        subtitleLabel.text = model.subtitle

        playImageView.backgroundColor = UIColor(hexRGB: "e4e4e4")
        if let posterURLString = model.poster?.img, !posterURLString.isEmpty {
            playImageView.sd_setImage(with: URL(string: posterURLString))
        } else {
            playImageView.image = nil
        }

        playTitleLabel.text = model.previewModel?.title
        playDurationLabel.text = model.bottomItemTitle

        self.player = self.newPlayer
        self.Handler?.player = self.player
        
        //绑定事件
        Service.action.bind(model.action, bkgrdImageView)
    }
    
    func layoutInit() {
        let statusBarOffset: CGFloat = -44 + YKStatusBarHeight()
        self.bkgrdImageView.frame = CGRect(x: 0, y: 0, width: self.width, height: self.height - statusBarOffset)
        
        if ykrl_isResponsiveLayout() {
            self.playerContainer.width = min(675, ceil(self.width * kPlayerMaxWidth / kPlayerMaxRelationWidth))
        } else {
            self.playerContainer.width = ceil(self.width - Padding * 2)
        }
        self.playerContainer.height = ceil(self.playerContainer.width * VideoRatio)
        self.playerContainer.left = (self.width - self.playerContainer.width) * 0.5
        self.playerContainer.top = self.height - self.playerContainer.height
        self.playImageView.frame = self.playerContainer.bounds
        self.gradientLayer.frame = CGRect(x: 0, y: 0, width: self.playImageView.width, height: 80)
        self.playTitleLabel.frame = CGRect(x: Padding, y: Padding, width: self.playImageView.width - Padding * 2, height: 40)
        self.playIconView.center = CGPoint(x: self.playImageView.width / 2.0, y: self.playImageView.height / 2.0)
        self.bottomGradientLayer.frame = CGRect(x: 0, y: self.playImageView.height - 20, width: self.playImageView.width, height: 20)
        self.playDurationLabel.frame = CGRect(x: self.playImageView.width - 6 - 100, y: self.playImageView.height - 16, width: 100, height: 12)
        
        self.subtitleLabel.frame = CGRect(x: Padding, y: self.playerContainer.top - 65, width: self.width - Padding * 2, height: 14)
        self.titleLabel.frame = CGRect(x: Padding, y: self.subtitleLabel.top - 42, width: self.width - Padding * 2, height: 27)
        
        let logoWidth = ceil(0.3 * self.width)
        let logoHeight = ceil(logoWidth * 87.0 / 227.0)
        let logoX = (self.width - logoWidth) / 2.0
        let logoY = self.playerContainer.top - 30 - logoHeight
        self.logoImageView.frame = CGRect(x: logoX, y: logoY, width: logoWidth, height: logoHeight)
    }

    func startPlay(_ forceStart: Bool = false) {
        guard configIsAutoPlay() || forceStart else { // 服务端控制起播
            NSLog("[12004] startPlayer \(self) return not autoplay")
            return
        }
        
        guard isPageInActive() && playerViewIsVisible() else {
            NSLog("[12004] startPlayer \(self) return isPageInActive:\(isPageInActive()) v:\(playerViewIsVisible())")
            return
        }
        
        if let player = self.player, player.isPlaying ,isSamePreviewId(player) {
            NSLog("[12004] startPlayer \(self) return isPlaying")
            return
        }
        
        guard let vid = getPreviewVid(), vid.isEmpty == false, let vc = getVc() else {
            NSLog("[12004] vid:\(getPreviewVid()) vc:\(getVc())")
            return
        }
        
        let disableVV = true
        var para: [String: Any] = ["play_style": "2", "playtrigger": "1", "disableVV": disableVV]
        let historyPlayTime: CGFloat = Item12004PlayerHistoryManager.shared.getTime(vid)
        let from = historyPlayTime > 0 ? historyPlayTime : -1
        para["from"] = from
        
        _isPlaying = true
        NSLog("[12004] \(YKCCUtil.objAddress(self)) startPlay")
        player?.playVideo(withVid: vid, params: para, controller: vc)
    }
    
    func stopPlay() {
        NSLog("[12004] \(YKCCUtil.objAddress(self)) stopPlay")
        _isPlaying = false
        player?.stopVideo()
        player?.embedPlayerView().removeFromSuperview()
        
//        let ns = Thread.callStackSymbols
//        for n in ns {
//            NSLog("[12004] \(YKCCUtil.objAddress(self)) stopPlay  cs:\(n)")
//        }
//        NSLog("[12004] \(YKCCUtil.objAddress(self)) stopPlay ------------------")
    }
    
    func isPageInActive() -> Bool {
        return self.item?.getPage()?.pageContext?.isPageActive() ?? false
    }
    
    func configIsSilent() -> Bool {
        return YKCCUtil.getBoolValue(self.item?.itemModel?.extend["isMutePlay"]) ?? true
    }
    
    func configIsAutoPlay() -> Bool {
        return YKCCUtil.getBoolValue(self.item?.itemModel?.extend["isAutoPlay"]) ?? true
    }
    
    // MARK: - private
    
    func getPreviewVid() -> String? {
        return item?.itemModel?.previewModel?.vid
    }
    
    func getVc() -> UIViewController? {
        return self.item?.getPage()?.pageContext?.getViewController()
    }
    
    private func isSamePreviewId(_ player: ChannelSliderPlayer) -> Bool {
        guard let previewVid = getPreviewVid() else {
            return false
        }
        
        if let playingVid = player.playingVid , previewVid == playingVid {
            return true
        } else if let playingViddecode = player.playingViddecode, previewVid == playingViddecode {
            return true
        }
        
        return false
    }
    
    // MARK: - player
    
    public weak var player: ChannelSliderPlayer?
    
    lazy var newPlayer: ChannelSliderPlayer? = {
        var playerWidth = ceil(self.width - Padding * 2)
        if ykrl_isResponsiveLayout() {
            playerWidth = min(675, ceil(self.width * kPlayerMaxWidth / kPlayerMaxRelationWidth))
        }
        let playerHeight = ceil(playerWidth * VideoRatio)
        
        var extra = [String: Any]()
        extra["useCorePlugin"] = true
        extra["pluginPath"] = "plugins_npplayer_base"
        
        let player = ChannelSliderPlayer.init(controller: getVc() ,width: playerWidth, ratio: VideoRatio, extra: extra)
        player?.delegate = self
        player?.isSlientMode = self.configIsSilent()
        player?.videoScreenMode = 0
        player?.isHideWaterMark = true
        player?.enable4GPlay()
        player?.handleLandScapeFullScreen = true
        player?.setupFrame(CGRect(x: 0, y: 0, width: playerWidth, height: playerHeight))
        
        // 注册插件
        if let path = Bundle.main.path(forResource: "comp12004_player_plugins", ofType: "plist"),
           let plugsDic = NSDictionary(contentsOfFile: path),
           let keys = plugsDic.allKeys as? [String] {
            
           for key in keys {
               if let pluginParams = plugsDic[key] as? [String: Any], pluginParams.count > 0 {
                   player?.registerPlugin(withPluginID: key, params: pluginParams)
               }
           }
        }
        
        return player
    }()
            
    // MARK: - ChannelSliderPlayerDelegate
    
    /// 开始播放
    public func didStartPlayVideo(in player: ChannelSliderPlayer) {
        NSLog("[12004] didStartPlayVideo quality:\(player.qualityType)")
        
        if self.superview != nil {
            if player.isFullScreen {
                return; //全屏状态下不能修改superView
            }
            
            if let embedPlayerView = player.embedPlayerView(), embedPlayerView.superview != self.superview {
                NSLog("[12004] didStartPlayVideo playerView inserted")
                self.playerContainer.addSubview(embedPlayerView)
            }
        } else {
            self.stopPlay()
        }
    }

    /// 播放错误
    public func player(_ player: ChannelSliderPlayer, playError errorCode: Int32) {
        NSLog("[12004] \(self) playError :\(errorCode)")
        _isPlaying = false
    }
    
    /// 播放完成
    public func didFinishPositiveVideo(in player: ChannelSliderPlayer) {
        NSLog("[12004] \(self) didFinishPositiveVideo")
        stopPlay()
        updateHistory(0)
    }
    
    public func didTouch(_ player: ChannelSliderPlayer!) {
        guard let player = player else {
            return
        }
        
        NSLog("[12004] \(self) didTouch")
        if UIAccessibility.isVoiceOverRunning { // 无障碍
            if player.isPlaying {
                player.pauseVideo()
            } else {
                player.replayVideo()
            }
        }
    }
    
    public func didPlyerStopPassive(_ embedPlayer: ChannelSliderPlayer!) {
        NSLog("[12004] \(self) 被动暂停")
    }
    
    public func playingProgress(_ progress: Int, totalTime time: Int) {
        NSLog("[12004] \(self) playingProgress p:\(progress) t:\(time)")
        updateHistory(progress)
    }
    
    func updateHistory(_ progress: Int) {
        guard let vid = getPreviewVid() else {
            return
        }
        
        Item12004PlayerHistoryManager.shared.updateTime(vid, Double(progress))
    }
    
    // MARK：- 播控
    
    func containerDidScroll() {
        guard _isPlaying else {
            return
        }
        
        let visible = playerViewIsVisible()
        if !visible {
            NSLog("[12004] scroll stopPlay")
            stopPlay()
            return
        }
    }
    
    func containerEndScroll() {
        guard !_isPlaying else {
            return
        }
        
        let visible = playerViewIsVisible()
        if visible {
            NSLog("[12004] scrollEnd startPlay")
            startPlay()
        }
    }
    
    func playerViewIsVisible() -> Bool {
        var playerAbsoluteFrame = self.convert(self.frame, to: nil)
        if playerAbsoluteFrame.minX < 0 { //x值不会为负，加一个校验
            playerAbsoluteFrame.origin = CGPoint(x: 0, y: playerAbsoluteFrame.minY)
        }
        let screenSize = YKRLLayoutManager.sharedInstance().screenSize
        let visibleY: CGFloat = 44 + YKStatusBarHeight()
        let visibleHeight: CGFloat = screenSize.height - visibleY
        
        let visibleFrame = CGRect.init(origin: .init(x: 0, y: visibleY), size: CGSize.init(width: screenSize.height, height: visibleHeight))
        print("[12004] visibleFrame:\(visibleFrame) playerFrame:\(self.frame) pSFrame:\(playerAbsoluteFrame) vY:\(visibleY) vH:\(visibleHeight)")
        return visibleFrame.intersects(playerAbsoluteFrame)
    }

}

class Item12004PlayerHistoryManager {
    static let shared = Item12004PlayerHistoryManager.init()
    var seekTimeMap: [String : Double] = [String : Double]() //记录播放时间
    
    func getTime(_ vid: String) -> Double {
        return self.seekTimeMap[vid] ?? 0
    }
    
    func updateTime(_ vid: String, _ time: Double) {
        self.seekTimeMap[vid] = time
    }
}
