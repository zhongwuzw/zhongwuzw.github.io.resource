//
//  Component12004.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/7/18.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKUIComponent
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import AliReachability
import DYKNavigator
import DYKURLRouter
import DYKNetwork_YK
import YoukuCore
import YKCMSComponent

class Component12004: NSObject, ComponentDelegate, ComponentLifeCycleDelegate, ComponentAddPageScrollEventHandlerDelegate {
    var componentWrapper: ComponentWrapper?
    weak var item: IItem? {
        return self.component?.getItems()?.first
    }
    weak var contentView: Item12004ContentView?
    weak var player: ChannelSliderPlayer? = nil //保存当前播放器
    
    func componentDidInit() {
        registNotification(#selector(receiveLoginStatusChangedNotification), "HYUserSessionUpdatedNotification")
        registNotification(#selector(triggerRefresh), "kAuthorUnBindSuccessNotification")
        registNotification(#selector(triggerRefresh), "kAuthorBindSuccessNotification")
        
        checkZhifubao()
    }

    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.zero
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.rowSpacing = 0
        config.responsiveMaxColumnCount = 1
        return config
    }

    func columnCount() -> CGFloat {
        return 1.0
    }
    
    deinit {
        if let player = self.player { //不能取contentView的player，view是复用的
            print("[12004] \(YKCCUtil.objAddress(self)) deinit player:\(YKCCUtil.objAddress(player)) will release")
            YKCCUtil.runOnMainThread {
                player.stopVideo()
                player.embedPlayerView().removeFromSuperview()
                print("[12004] player:\(YKCCUtil.objAddress(player)) release")
            }
        }
    }

    /// 加载事件处理器
    func loadEventHandlers() -> [ComponentEventHandler]? {
        var handlers = [ComponentEventHandler]()
        let lifeHandler = ComponentLifeCycleEventHandler()
        lifeHandler.delegate = self
        let scrollHandler = ComponentAddPageScrollEventHandler()
        scrollHandler.delegate = self
        handlers.append(lifeHandler)
        handlers.append(scrollHandler)
        return handlers
    }

    /// item高度（custom布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return contentViewSize(itemWidth).height
    }

    func createView(_ itemSize: CGSize) -> UIView {
        let view = Item12004ContentView.init(frame: CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return view
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item12004ContentView else {
            return
        }
        contentView = itemView
        itemView.Handler = self
        itemView.fillData(item)
        itemView.startPlay()
    }
    
    // MARK: - private
    
    func contentViewSize(_ width: CGFloat) -> CGSize {
        if ykrl_isResponsiveLayout() {
            let playerWidth = min(675, ceil(width * kPlayerMaxWidth / kPlayerMaxRelationWidth))
            let playerHeight = ceil(playerWidth * VideoRatio)
            let naviagtionBarHeight: CGFloat = 44.0
            let statusBarHeight = YKStatusBarHeight()
            let topBlankHeight: CGFloat = 147.0
            
            let totalHeight = naviagtionBarHeight + statusBarHeight + topBlankHeight + playerHeight
            
            return CGSize(width: width, height: totalHeight)
        } else {
            var itemHeight = (width - Margin * 2) * VideoRatio + (184.0 + (-44.0 + YKStatusBarHeight())) * (414.0/375.0)
            
            if isChannelEnvironment() && isLiuhai() {
                itemHeight -= 50 //适配上顶导状态，高度减50，与安卓保持一致。
            }
            
            return CGSize(width: width, height: itemHeight)
        }
    }
    
    // MARK: - private
    
    func isChannelEnvironment() -> Bool {
        return (item?.model as? Item12004Model)?.displayInChannel ?? false
    }
    
    func isLiuhai() -> Bool {
        return YKStatusBarHeight() > 20
    }
    
    func isWifi() -> Bool {
        return NWReachabilityManager.shareInstance()?.currentNetworkStatus() == NetworkStatus.ReachableViaWiFi
    }
    
    // MARK: - ComponentLifeCycleDelegate
    func enterDisplayArea(itemView: UIView?) {
        print("[12004] enterDisplayArea")
    }
    
    func exitDisplayArea(itemView: UIView?) {
        print("[12004] exitDisplayArea")
    }
    
    func willDeactivate() {
        
    }
    
    func willActivate() {
        
    }
    
    func didActivate() {
        print("[12004] didActivate")
        contentView?.startPlay()
    }
    
    func didDeactivate() {
        print("[12004] didDeactivate")
        contentView?.stopPlay()
    }
    
    func appDidBecomeActive() {
        contentView?.startPlay()
    }
    
    func appWillResignActive() {
        contentView?.stopPlay()
    }
    
    func visibleViewsDidEndScroll() {
        
    }
    
    // MARK: - ComponentAddPageScrollEventHandlerDelegate
    
    func containerDidScroll(_ scrollView: UIScrollView) {
        // 滚动过程中，enterDisplayArea和exitDisplayArea不会回调，此方法里统一处理
        self.contentView?.containerDidScroll()
    }
    
    /// 拖拽容器已结束
    func containerDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate {
            handleScrollEnded(scrollView)
        }
    }
    
    /// 容器滚动减速结束
    func containerDidEndDecelerating(_ scrollView: UIScrollView) {
        handleScrollEnded(scrollView)
    }
    
    func handleScrollEnded(_ scrollView: UIScrollView) {
        self.contentView?.containerEndScroll()
    }
    
    
    // MARK: - observers
    
    private func registNotification(_ sel:Selector, _ name:String, _ object: Any? = nil) {
        NotificationCenter.default.addObserver(self, selector: sel, name: NSNotification.Name.init(rawValue: name), object: object)
    }
    
    @objc func triggerRefresh() {
        self.item?.getPage()?.triggerFirstPageRequest()
    }
    
    @objc func receiveLoginStatusChangedNotification(notification: Notification) {
        if willCheckZFB {
            willCheckZFB = false
            checkZhifubao()
        }
    }
    
    // MARK: - 支持宝
    
    var willCheckZFB: Bool = false
    
    func checkZhifubao() {
        if let binded = self.item?.getPage()?.pageContext?.concurrentDataMap["yksc.page.nodepage.zhifubaobind"] as? Bool, binded == true {
            return
        }
        
        guard let pageParams = getNPRRouterParams(),
              let zfbDspFrom = pageParams["zfbDspFrom"] as? Int,
              let tokenId = pageParams["tokenId"] as? String else {
            return
        }
        
        if zfbDspFrom == 1 {
            if User.current() != nil {
                self.item?.getPage()?.pageContext?.concurrentDataMap["yksc.page.nodepage.zhifubaobind"] = true
                self.getZhifubaorenzheng(tokenId)
            } else {
                self.showLoginPage()
            }
        }
    }

    private func getNPRRouterParams() -> [String: Any]? {
        return self.item?.getPage()?.pageContext?.concurrentDataMap["nprRouterParams"] as? [String: Any]
    }
    
    
    func showLoginPage() {
        willCheckZFB = true
        let nav = DYKNavigatorParamers()
        nav.openType = .push
        DYKNavigatorManager.sharedInstance().openURL("youku://UserLogin", navigatorParams: nav)
    }
    
    func getZhifubaorenzheng(_ tokenId: String) {
        var parameters = [String: Any]()
        parameters["api_version"] = "1.0"
        parameters["tokenId"] = tokenId
        
        let requestModel = DYKHttpRequestModel()
        requestModel.enableMtop = true
        requestModel.requestURL = "mtop.youku.tp.alipay.user.get"
        requestModel.paramDict = parameters
        
        YKJSONClient.sharedMtop().request(withHttpModel: requestModel) { (task, responseObject)  in
            guard let responseObject = responseObject as? [String: Any],
                  let dataDict = responseObject["data"] as? [String: Any] else {
                return
            }
            
            /**
            * 当前did和登陆ytid的绑定状态
            * binded【登陆ytid已在优酷侧完成过认证或者当前did已与登陆ytid绑定 可直接放行】
            * unbindedUnoccupied【当前did未与登陆ytid绑定，当前did绑定的ytid数量<3,且登陆ytid未绑定任何did】
            * unbindedOccupied【当前did未与登陆ytid绑定，当前did绑定的ytid数量<3,且登陆ytid已绑定其他did】
            * unbindedFull【当前did未与登陆ytid绑定，当前did绑定的ytid数量==3】
            */
            guard let bindingStatus = dataDict["bindingStatus"] as? String else {
                return
            }
            
            if bindingStatus == "binded" {
                
            } else if bindingStatus == "unbindedUnoccupied" {
                self.openZFBBind(type: 1, token: tokenId)
            } else if bindingStatus == "unbindedOccupied" {
                self.openZFBBind(type: 2, token: tokenId)
            } else if bindingStatus == "unbindedFull" {
                self.openZFBBind(type: 3, token: tokenId)
            } else {
                
            }
        } failure: { (task, error) in
            
        }
    }

    func openZFBBind(type: Int, token: String) {
        DispatchQueue.main.async {
            let nav = DYKNavigatorParamers()
            nav.openType = .push
            DYKNavigatorManager.sharedInstance().openURL("youku://accessible/authenticationant?state=(type)&token=(token)", navigatorParams: nav)
        }
    }
}
