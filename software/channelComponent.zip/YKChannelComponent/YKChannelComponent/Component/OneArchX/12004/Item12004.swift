//
//  Item12004.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/7/18.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch

class Item12004: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView.init()
    }
    
    func reuseView(itemView: UIView) {}
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item12004Model.self as? T.Type
    }

}
