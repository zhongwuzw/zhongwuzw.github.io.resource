//
//  Item14063.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/23.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YKAdSDK
import OneArchSupport
import OneArchSupport4Youku

class Item14063ContentView: AccessibilityView {
    
    var model:BaseItemModel?
    var adModel: YKAdResponseModel?
    
    lazy var adView: YKAdImageView = {
        let view = YKAdImageView.init(cardType: .homeBase, width: self.width)
        return view
    }()
    
    lazy var endView: Item14063PlayEndView = {
        let view = Item14063PlayEndView.init(frame: self.playerContainerView.frame)
        view.isHidden = true
        setRoundedForView(view, 7)
        return view
    }()
    
    lazy var playerContainerView: UIView = {
        let view = UIView.init(frame: YKAdImageView.adImageCoverFrame(with: .homeBase, containerWidth: self.width))
        view.isHidden = true
        setRoundedForView(view, 7)
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubview(adView)
        addSubview(playerContainerView)
        addSubview(endView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func setModel(_ model: BaseItemModel, _ adModel: YKAdResponseModel) {
        self.model = model
        self.adModel = adModel

        adView.adModel = adModel
        adView.hideNegativeFeedbackView()
    }
    
    public func showEndView() {
        adView.updatePlayIconHiddenState(true)
        adView.hideNegativeFeedbackView()
        playerContainerView.isHidden = true
        endView.isHidden = false
    }
    
    public func hideEndView() {
        endView.isHidden = true
        adView.updatePlayIconHiddenState(false)
    }
    
    public class func itemHeight(_ width:CGFloat) -> CGFloat {
        return YKAdImageView.adCardViewSize(with: .homeBase, containerWidth: width).height
    }

    // MARK: - player
    
    func stickPlayerView(_ playerView: UIView?) {
        if playerView != nil {
            self.playerContainerView.isHidden = false
            playerView?.frame = self.playerContainerView.bounds
            
            if playerView?.superview == self.playerContainerView {
                return
            }
            
            self.playerContainerView.addSubview(playerView ?? UIView.init())
        } else {
            self.playerContainerView.isHidden = true
            playerView?.removeFromSuperview()
        }
        
        self.adView.hideNegativeFeedbackView()
        self.hideEndView()
    }
    
    func setRoundedForView(_ view: UIView, _ cornerRadius: CGFloat) {
        let corner = UIRectCorner.allCorners
        let maskPath = UIBezierPath.init(roundedRect: view.bounds, byRoundingCorners: corner, cornerRadii: CGSize.init(width: cornerRadius, height: cornerRadius))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = view.bounds
        maskLayer.path = maskPath.cgPath
        view.layer.mask = maskLayer
    }
}
