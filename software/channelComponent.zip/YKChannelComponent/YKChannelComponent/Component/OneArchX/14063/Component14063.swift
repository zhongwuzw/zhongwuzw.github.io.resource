//
//  Component14063.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/23.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKAdSDK
import NovelAdSDK
import OneArchSupport4Youku
import AliReachability

class Component14063: ComponentEventHandler, ComponentDelegate, IPageLifeCycleEventHandler, IComponentLifeCycleEventHandler,
                      YKAdImageViewDelegate, Item14063PlayEndViewDelegate, YKUcAdLightPlayerDelegate {
    var ucAdModel: YKAdResponseModel?
    var isExposed = false
    var isVisible: Bool = false
    var drawerView:Item14063ContentView?
    
    var itemModel: BaseItemModel? {
        get {
            return self.component?.getItems()?.first?.itemModel
        }
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = 9.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0 //100
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        let playerEvent = PlayerScrollEndCompEventHandler()
        return [playerEvent,self]
    }
    
    public func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseComponentModel.self as? T.Type
    }
    
    func componentDidInit() {
        guard let itemModel = self.component?.getItems()?.first?.itemModel else {
            return
        }
        
        let feedbackModel = createUCAdFeedbackModelNew(itemModel)
        self.ucAdModel = feedbackModel.ucAdModel as? YKAdResponseModel
    }
    
    var componentWrapper: ComponentWrapper?
    
    /// item高度（custom布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        guard let _ = self.itemModel, let _ = self.ucAdModel else  {
            return CGFloat(0)
        }
        
        return Item14063ContentView.itemHeight(itemWidth)
    }

    /// 初始化item view（custom布局使用）
    func createView(_ itemSize: CGSize) -> UIView {
        let itemWidth = itemSize.width
        let itemHeight = itemSize.height

        let itemView = Item14063ContentView.init(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        return itemView
    }
    
    func reuseId() -> String? {
        var reuseId = "YKChannelComponent.Item14063ContentView"
        if let tag = self.component?.compModel?.type {
            reuseId += tag
        }
        return reuseId
    }

    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14063ContentView else {
            return
        }
        guard let itemModel = self.itemModel, let ucAdModel = self.ucAdModel else {
            return
        }

        self.drawerView = itemView
        
        itemView.setModel(itemModel, ucAdModel)
        itemView.adView.delegate = self
        itemView.endView.delegate = self
    }

    // MARK: - YKAdImageViewDelegate
    
    @objc public func dislikeFeedback() {
        deleteComponentWithAnimation(self.component)
    }
    
    @objc public func hideNegativeFeedbackView() {
        
    }
    
    @objc public func negativeFeedback() {
        //adx预播打点-退出播放
        let isPlaying = player?.isPlaying ?? false
        if isPlaying {
            self.playHelper()?.commit(withEid:YKAdEid.playQuit.rawValue)
        }
        
        stopPlayer()
    }
    
    // MARK: - Item14063PlayEndViewDelegate
    
    func drawerEndViewDidReplayBtnClick() {
        playWithDelay(false)
        drawerView?.hideEndView()
        
        //adx预播打点-手动播放
        self.playHelper()?.commit(withEid: YKAdEid.playStart.rawValue)
    }
    
    // MARK: - player
    lazy var player: YKUcAdLightPlayer? = {
        let player = YKUcAdLightPlayer.init(controller: currentVc())
        player?.isHideWaterMark = true
        player?.setupFrame(CGRect.init(x: 0, y: 0, width: self.drawerView?.playerContainerView.width ?? 0, height: self.drawerView?.playerContainerView.height ?? 0))
        player?.videoScreenMode = 1
        player?.loadPlugins(withPlist: "plugins_ucad_drawer")
        player?.delegate = self
        return player
    }()
    
    func playWithDelay(_ delay: Bool) {
        stopPlayer()
        
        if UtilityHelper.isWifi() == false {
            return
        }
        
        var para = [String: Any]()
        para["play_style"] = "1"
        para["playtrigger"] = "2"
        para["disableVV"] = true
        
        //adBizInfo
        if self.ucAdModel != nil, let adBizInfo = YKAdUtil.ykAdPlayMonitorParams(self.ucAdModel!) as? [String:Any] {
            para["adBizInfo"] = adBizInfo
        }
        
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        
        if delay {
            self.perform(#selector(delayPlayWithParas(_:)), with: para, afterDelay: 0.5)
        } else {
            self.delayPlayWithParas(para)
        }
    }
    
    @objc func delayPlayWithParas(_ params: [String: Any]) {
        guard let videoUrl = videoUrl() else {
            return
        }
        
        let dspName = dspName() ?? "广告"
        if shouldPlay() && videoUrl.count > 0 {
            self.player?.postEventType("E.Play.Ad.DspName", data: ["dspName": dspName])
            self.player?.postEventType("E.Play.ST.SlientSyncStatus", data: ["isSilent": true, "isPrePlay": true])
            self.player?.playVideo(withVid: videoUrl, sid: nil, statisInfo: nil , owner: self.currentVc(), params: params)
        }
    }
    
    func startPlayer() {
        guard let videoUrl = videoUrl() , let player = player else {
            return
        }
        
        if player.isPlaying {
            if player.playingVid == videoUrl {
                return
            }
        }
        playWithDelay(true)
        
        //adx预播打点-自动播放
        self.playHelper()?.url = self.ucAdModel?.firstNative().videoPlayUrl
        self.playHelper()?.commit(withEid: YKAdEid.playAutoStart.rawValue)
    }
    
    func stopPlayer() {
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        
        player?.stopVideo()
        drawerView?.stickPlayerView(nil)
    }
    
    var isPageInActive: Bool {
        if let page = self.component?.getPage() , let state = page.activeState, state == true {
            return true
        }
        return false
    }
    
    func currentVc() -> UIViewController? {
        return self.component?.getPage()?.pageContext?.getViewController()
    }
    
    // MARK: - YKUcAdLightPlayerDelegate
    
    func didStartPlayVideo(in player: YKUcAdLightPlayer!) {
        guard let videoUrl = videoUrl() else {
            return
        }
        if player.playingVid != videoUrl {
            self.stopPlayer()
            self.playWithDelay(false)
            return
        }
        
        if self.shouldPlay() {
            self.drawerView?.stickPlayerView(player.embedPlayerView())
        } else {
            self.stopPlayer()
        }
    }
    
    func didFinishPositiveVideo(in player: YKUcAdLightPlayer!) {
        self.drawerView?.showEndView()
        
        //adx预播打点-完成播放
        self.playHelper()?.commit(withEid:YKAdEid.playComplete.rawValue)
    }
    
    func player(_ player: YKUcAdLightPlayer!, playError errorCode: Int32) {
        self.drawerView?.stickPlayerView(nil)
    }
    
    func didEndTouch(_ player: YKUcAdLightPlayer!) {
        self.clickAction.clickAction(withAdModel: self.ucAdModel, statisInfo: nil)
    }
    
    lazy var clickAction: YKAdActionHandler = {
        let action = YKAdActionHandler.init()
        return action
    }()
    
    func videoUrl() -> String? {
        return self.ucAdModel?.firstNativeContentVideo().url
    }
    
    func dspName() -> String? {
        return self.ucAdModel?.firstNativeContent().dspName
    }
    
    func shouldPlay() -> Bool {
        return isPageInActive && isVisible
    }
    
    func enableDrawerVideoPlay() -> Bool {
        return self.ucAdModel?.isVideo() ?? false
    }
    
    //MARK: - IPageLifeCycleEventHandler
    
    public func viewDidLoad() {
        
    }
    
    public func willActivate() {
        
    }
    
    public func didActivate() {
        
    }
    
    public func willDeactivate() {
    }
    
    public func didDeactivate() {
        isVisible = false
        //adx预播打点-退出播放
        let isPlaying = player?.isPlaying ?? false
        if isPlaying {
            self.playHelper()?.commit(withEid:YKAdEid.playQuit.rawValue)
        }
        stopPlayer()
    }
    
    public func pageDealloc() {
        
    }
    
    public func appDidBecomeActive() {
        
    }
    
    public func appWillResignActive() {
        //adx预播打点-退出播放
        let isPlaying = player?.isPlaying ?? false
        if isPlaying {
            self.playHelper()?.commit(withEid:YKAdEid.playQuit.rawValue)
        }
    }
    
    //MARK: - IComponentLifeCycleEventHandler
    var utExposed: Bool = false
    var ucExposed: Bool = false
    
    public func enterDisplayArea(itemView: UIView?) {
        isVisible = true
        
        if !ucExposed {
            ucExposed = true
            self.drawerView?.adView.reportUCExpose()
        }
        
        if !utExposed {
            utExposed = true
            self.drawerView?.adView.reportYKExpose()
        }
        
        if enableDrawerVideoPlay() {
            if drawerView?.endView.isHidden == true && drawerView?.adView.feedbackViewIsShown() == false {
                startPlayer()
            }
        }
    }
    
    public func exitDisplayArea(itemView: UIView?) {
        isVisible = false
        //adx预播打点-退出播放
        let isPlaying = player?.isPlaying ?? false
        if isPlaying {
            self.playHelper()?.commit(withEid:YKAdEid.playQuit.rawValue)
        }
        stopPlayer()
    }
    
    public func visibleViewDidScroll(itemView: UIView?) {
        
    }
    
    public func visibleViewDidEndScroll(itemView: UIView?) {
//        print("fuzhong 14063 visibleViewDidEndScroll")
        if isVisible == false {
            enterDisplayArea(itemView: self.drawerView)
        }
    }
    
    public func visibleViewsDidEndScroll() {

    }
    
    func calViewFrameByScrollView(_ view: UIView, _ scrollView: UIScrollView) -> CGRect {
        let contentInsetTop = scrollView.contentInset.top
        var viewByFrame: CGRect = view.superview?.convert(view.frame, to: scrollView) ?? CGRect.zero
        viewByFrame.origin.y -= contentInsetTop //需考虑contentInset值
        return viewByFrame
    }

    func calVisibleViewRatio(_ view: UIView, _ scrollView: UIScrollView) -> CGFloat {
        let viewByFrame = calViewFrameByScrollView(view, scrollView)
        let interFrame = scrollView.bounds.intersection(viewByFrame)
        print("fuzhong 14063 viewFrame:\(viewByFrame) interFrame:\(interFrame)")
        return 1.0
    }
    
    // MARK: - 预播埋点(广告@铭钰沟通)
    func playHelper() -> YKAdPlayEventHelper? {
        return YKAdPlayEventHelper.shareInstance()
    }
}
