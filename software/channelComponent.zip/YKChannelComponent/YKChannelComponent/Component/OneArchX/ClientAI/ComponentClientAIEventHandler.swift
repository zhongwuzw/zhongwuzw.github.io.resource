//
//  ComponentClientAIEventHandler.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/9/19.
//  Copyright © 2024 Youku. All rights reserved.
//

import OneArch
import OneArchSupport4Youku
import UIKit
import YKChannelPage

public class ComponentClientAIEventHandler: ComponentEventHandler, IPageLifeCycleEventHandler, IComponentLifeCycleEventHandler {
    
    public var isDisplaying = false
    var enterTimeStamp:TimeInterval = 0
    var leaveTimeStamp:TimeInterval = 0

    var itemModel:BaseItemModel? {
        return self.component?.getItems()?.first?.itemModel
    }
    
    public required init() {
        super.init()
    }
    
    override public func listeningEventObservers() -> [EventObserver]? {
        return nil
    }
    
    public override func onEvent(_ event: OEvent) {
        
    }
    
    ///MARK: IPageLifeCycleEventHandler
    public func viewDidLoad() {
        
    }
    
    public func willActivate() {

    }
    
    public func didActivate() {
        realEnter()
    }
    
    public func willDeactivate() {

    }
    
    public func didDeactivate() {
        realLeave()
    }
    
    public func pageDealloc() {
        
    }
    
    public func appDidBecomeActive() {
        realEnter()
    }
    
    public func appWillResignActive() {
        realLeave()
    }
    
    ///MARK: IComponentLifeCycleEventHandler
    public func enterDisplayArea(itemView: UIView?) {
        isDisplaying = true
        realEnter()
    }
    
    public func exitDisplayArea(itemView: UIView?) {
        isDisplaying = false
        realLeave()
    }
    
    func realEnter() {
        NSLog("[CustomBehavior] realEnter: \(self.itemModel?.title)_\(self.itemModel?.type)")
        enterTimeStamp = NSDate().timeIntervalSince1970 * 1000
    }
    
    func realLeave() {
        if !CustomBehaviorPageService.shareInstance().isEnabelCustomClientAIReport() {
            return
        }
        if !HomeBizUtil.isSelectionPage(self.component?.getPage()) {
            return
        }
        
        let isPageActive = self.component?.pageContext?.isPageActive() ?? false
        let dataState = self.component?.getPage()?.dataState ?? .invalid
        if !isPageActive {
            return
        }
        if dataState != .network {
            return
        }
        
        NSLog("[CustomBehavior] realLeave: \(self.itemModel?.title)_\(self.itemModel?.type)")

        leaveTimeStamp = NSDate().timeIntervalSince1970 * 1000
        let behaviorReport = generateCustomBehaviorReportModel()
        behaviorReport.enterTimeStamp = enterTimeStamp
        behaviorReport.leaveTimeStamp = leaveTimeStamp
        
        CustomBehaviorPageService.shareInstance().joinTaskQueue(behaviorReport)
    }
    
    func generateCustomBehaviorReportModel() -> CustomBehaviorReportModel {
        let behaviorReport = CustomBehaviorReportModel.init()
        let report = self.itemModel?.action?.report
        behaviorReport.spm = report?.spm
        behaviorReport.scm = report?.scm
        behaviorReport.pageName = report?.pageName
        
        return behaviorReport
    }
    
    public func visibleViewDidScroll(itemView: UIView?) {
        
    }
    
    public func visibleViewDidEndScroll(itemView: UIView?) {
        
    }
    
    public func visibleViewsDidEndScroll() {

    }
}
