//
//  ItemClientAIEventHandler.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/9/23.
//  Copyright © 2024 Youku. All rights reserved.
//

import UIKit
import Foundation
import OneArch
import OneArchSupport4Youku
import YKChannelPage

public class ItemClientAIEventHandler: ItemEventHandler, IPageLifeCycleEventHandler, IItemLifeCycleEventHandler {
    
    public var isDisplaying = false
    var enterTimeStamp:TimeInterval = 0
    var leaveTimeStamp:TimeInterval = 0

    public required init() {
        super.init()
    }
    
    override public func listeningEventObservers() -> [EventObserver]? {
        return nil
    }
    
    public override func onEvent(_ event: OEvent) {
        
    }
    
    ///MARK: IPageLifeCycleEventHandler
    public func viewDidLoad() {
        
    }
    
    public func willActivate() {
    }
    
    public func didActivate() {
        realEnter()
    }
    
    public func willDeactivate() {
    }
    
    public func didDeactivate() {
        realLeave()
    }
    
    public func pageDealloc() {
    }
    
    public func appDidBecomeActive() {
        realEnter()
    }
    
    public func appWillResignActive() {
        realLeave()
    }
    
    ///MARK: IItemLifeCycleEventHandler
    public func enterDisplayArea(itemView: UIView?) {
        isDisplaying = true
        realEnter()
    }
    
    public func exitDisplayArea(itemView: UIView?) {
        isDisplaying = false
        realLeave()
    }
    
    func realEnter() {
        NSLog("[CustomBehavior] realEnter: \(self.item?.itemModel?.title)_\(self.item?.itemModel?.type)")
        enterTimeStamp = NSDate().timeIntervalSince1970 * 1000
    }
    
    func realLeave() {
        if !CustomBehaviorPageService.shareInstance().isEnabelCustomClientAIReport() {
            return
        }
        if !HomeBizUtil.isSelectionPage(self.item?.getPage()) {
            return
        }
        
        let isPageActive = self.item?.pageContext?.isPageActive() ?? false
        let dataState = self.item?.getPage()?.dataState ?? .invalid
        if !isPageActive {
            return
        }
        if dataState != .network {
            return
        }
        
        NSLog("[CustomBehavior] realLeave: \(self.item?.itemModel?.title)_\(self.item?.itemModel?.type)")

        leaveTimeStamp = NSDate().timeIntervalSince1970 * 1000
        let behaviorReport = generateCustomBehaviorReportModel()
        behaviorReport.enterTimeStamp = enterTimeStamp
        behaviorReport.leaveTimeStamp = leaveTimeStamp
        
        CustomBehaviorPageService.shareInstance().joinTaskQueue(behaviorReport)
    }
    
    func generateCustomBehaviorReportModel() -> CustomBehaviorReportModel {
        let behaviorReport = CustomBehaviorReportModel.init()
        let report = self.item?.itemModel?.action?.report
        behaviorReport.spm = report?.spm
        behaviorReport.scm = report?.scm
        behaviorReport.pageName = report?.pageName
        
        return behaviorReport
    }
    
    /// 可见item-容器滚动
    public func visibleViewDidScroll(itemView: UIView?) {
        
    }
    
    /// 可见item-容器停止滚动（以cell为单位回调多次）
    public func visibleViewDidEndScroll(itemView: UIView?) {
        
    }
    
    public func autoFocusItemView(_ itemView: UIView?) {
        
    }
    
    public func cancelFocusItemView(_ itemView: UIView?) {
    
    }
}

