//
//  Item14180.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/7.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku

class Item14180: NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {
        guard let model = self.item?.itemModel as? Item14180Model else {
            return
        }
        
        // 计算title渲染尺寸
        if let title = model.title {
            var size = calcStringSize(title, font:Component14180.itemSelectedFont(), size: CGSize.init(width: 1_000, height: 1_000))
            let padding = Component14180.itemPadding()
            
            size.width += padding.left + padding.right
            size.width = floor(size.width)
            
            size.height += padding.top + padding.bottom
            size.height = floor(size.height)
            model.layout.renderRect = CGRect.init(origin: CGPoint.init(x: 0, y: 0), size: size)
        }
        
        // 筛选条件
        if let filterType = model.filterType, filterType.isEmpty == false,
            let filterValue = model.filterValue, filterValue.isEmpty == false {
            model.extraExtend["filterStatement"] = "\(filterType):\(filterValue)"
        }
        
        // 默认筛选项
        model.extraExtend["selectedIndex"] = 0
        
        // 是否隐藏行
        model.extraExtend["hideFilter"] = model.hideFilter
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView.init()
    }
    
    func reuseView(itemView: UIView) {
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14180Model.self as? T.Type
    }
}
