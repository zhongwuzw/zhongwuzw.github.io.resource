//
//  14180ItemModel.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/7.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArchSupport4Youku

class Item14180Model: BaseItemModel {
    var filterType: String?
    var filterValue: String?
    var hideFilter: Bool = false
    
    var isType: Bool {
        return filterType == "type"
    }
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        
        filterType = dataInfo["filterType"] as? String
        filterValue = dataInfo["value"] as? String
        hideFilter = dataInfo["hideFilter"] as? Bool ?? false
        
        // 将第一个子坑位的类型赋值给主坑位
        if self.filterType == nil,
           let nodes = cmsInfo?["nodes"] as? [[String:Any]],
           let firstSubnode = nodes.first,
           let dataInfo = firstSubnode["data"] as? [String:Any],
           let filterType = dataInfo["filterType"] as? String {
            self.filterType = filterType
        }
    }
}
