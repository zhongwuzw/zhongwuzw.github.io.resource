//
//  Comp14180.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/7.
//  Copyright © 2022 Youku. All rights reserved.
//

import OneArch
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import CoreGraphics
import YKResponsiveLayout
import UIKit

class Component14180: NSObject, ComponentDelegate, LaneGroupViewDelegate, LaneGroupViewDataSource, CompPlugin14180OptionsViewDelegate {
    
    var componentWrapper: ComponentWrapper?
    
    /// 是否强制展示全部标记位
    var isForceShowAll: Bool = false
    
    /// 缓存高度，用于reuseId 拼接
    var preferredHeight: CGFloat = 0
    
    /// 缓存轻量版高度，用于初始化轻量版view
    var preferredPriorityItemsHeight: CGFloat = 0
    
    /// 缓存完整版高度，用于初始化完整版view
    var preferredAllItemsHeight: CGFloat = 0
    
    /// 多行筛选视图配置(完整版)
    var config = LaneGroupConfig()
    
    /// 多行筛选视图配置(轻量版)
    var lightWeightConfig = LaneGroupConfig()
    
    /// 组件视图缓存
    weak var itemContainer: CompPlugin14180Container?
    
    /// 重要筛选项
    var priorityItems: [IItem] {
        guard let items = self.component?.getItems() else {
            return [IItem]()
        }
        
        let itemsWithoutHide = items.filter { aItem in
            guard let model = aItem.itemModel,
                  let isHideFilter = model.extraExtend["hideFilter"] as? Bool else {
                return true
            }
            
            return !isHideFilter
        }
        
        return itemsWithoutHide
    }
    
    /// 全部筛选项
    var allItems: [IItem] {
        guard let items = self.component?.getItems() else {
            return [IItem]()
        }
        
        return items
    }
    
    var floatingEnabled: Bool {
        guard let items = self.component?.getItems() else {
            return true
        }
        
        if let firstItemModel = items.first?.itemModel as? Item14180Model {
            if firstItemModel.isType {
                return false
            }
        }
        
        return true
    }
    
    func displayItems(_ laneGroupView: LaneGroupView) -> [IItem] {
        if laneGroupView.tag == 202111305 {
            return priorityItems
        }
        
        return allItems
    }
    
    deinit {
        let laneGroupView = self.itemContainer?.laneGroupView
        let optionsView = self.itemContainer?.optionsView
        DispatchQueue.main.async {
            if laneGroupView?.superview != nil {
                laneGroupView?.removeFromSuperview()
            }
            
            if optionsView?.superview != nil {
                optionsView?.removeFromSuperview()
            }
        }
    }
    
    func allowedLightWeight() -> Bool {
        return false
    }
    
    func componentDidInit() {
        let config = buildLaneGroupConfig()
        self.config = config
        
        let lightWeightConfig = buildLaneGroupConfig(isLightWeight: true)
        self.lightWeightConfig = lightWeightConfig
    }
    
    func buildLaneGroupConfig(isLightWeight: Bool = false) -> LaneGroupConfig {
        var config = LaneGroupConfig()
        config.cellClassIdentifier = LaneCellClassIdentifier.init(class: CompPlugin14180ItemView.self, identifier: "CompPlugin14180ItemView-Reuse")
        config.numberOfLanes = UInt(isLightWeight ? self.priorityItems.count : self.allItems.count)
        
        let itemPadding = Component14180.itemPadding()
        var aLaneHeight = calcStringSize("Ag", font: Component14180.itemSelectedFont(), size: CGSize.init(width: 1_0000, height: 1_000)).height
        aLaneHeight += itemPadding.top + itemPadding.bottom
        aLaneHeight = floor(aLaneHeight)
        config.aLaneHeight = aLaneHeight
        
        config.laneSpacing = YKNGap.dim_5()
        config.itemSpacing = 0
        config.margin = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: 0, right: YKNGap.youku_margin_right())
        config.selectedIndictorBorderWidth = 0
        config.selectedIndictorBorderColor = UIColor.ykn_border
        config.selectedIndictorBackgroundColor = UIColor.ykn_border
        
//        if let _ = self.component?.getPage()?.pageModel?.scene?.sceneOptionButtonSelectedTextColor() {
//            config.selectedIndictorBackgroundColor = UIColor.clear
//        } else {
//            config.selectedIndictorBackgroundColor = UIColor.ykn_buttonFill
//        }
        
        return config
    }

    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.headerBottomMargin = 0.0
        config.rowSpacing = 0.0
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0
        config.horizontalPaddingLeft = 0
        config.horizontalPaddingRight = 0
        config.backgroundLeftMarginOffset = -YKNGap.youku_margin_left()
        config.backgroundRightMarginOffset = -YKNGap.youku_margin_right()
        config.headerLeftMarginOffset = 0
        config.headerRightMarginOffset = 0
        config.backgroundTopMargin = 0
        return config
    }

    /// 是否展示组件尾
    func isShowFooter() -> Bool {
        return false
    }
    
    func reuseId() -> String? {
        let addr = Unmanaged.passUnretained(self).toOpaque()
        return "Component14180-ReuseId-Height-\(preferredHeight)-\(addr)"
    }

    /// item高度
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let height: CGFloat = self.config.sizeThatFits(CGSize.init(width: itemWidth, height: 1_000_000)).height + 18
        self.preferredHeight = height
        self.preferredAllItemsHeight = height
        
        if shouldShowLightweightGroupView() {
            var height: CGFloat = self.lightWeightConfig.sizeThatFits(CGSize.init(width: itemWidth, height: 1_000_000)).height + 18
            self.preferredPriorityItemsHeight = height
            
            if shouldShowShowAllTipsView() {
                let showAllTipsTextHeight: CGFloat = ceil(YKNFont.height(with: .systemFont(ofSize: 14), lineNumber: 1))
                height += showAllTipsTextHeight + 9 // tipViewHeight + padding
            }
            self.preferredHeight = height
            return height
        }
        
        return height
    }

    func createView(_ itemSize: CGSize) -> UIView {
        let itemWidth: Double = itemSize.width
        let itemHeight: Double = itemSize.height
        

        let bgColor  = self.component?.pageContext?.getContainerView()?.backgroundColor
        let laneGroupView = LaneGroupView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: preferredAllItemsHeight - 9), laneGroupConfig: self.config)
        laneGroupView.tag = 202111303
        laneGroupView.backgroundColor = bgColor
        
        let optionsView = CompPlugin14180OptionsView.init(frame: CGRect.init(x: 0, y: 0, width: itemWidth, height: 40.0))
        optionsView.backgroundColor = bgColor
        optionsView.tag = 202111304
        
        let itemContainer = CompPlugin14180Container.init(frame: laneGroupView.frame)
        itemContainer.addSubview(laneGroupView)
        itemContainer.laneGroupView = laneGroupView
        itemContainer.optionsView = optionsView
        
        if shouldShowLightweightGroupView() {
            let lightWeightLaneGroupView = LaneGroupView(frame: CGRect(x: 0, y: 0, width: itemWidth, height: preferredPriorityItemsHeight - 9), laneGroupConfig: self.lightWeightConfig)
            lightWeightLaneGroupView.tag = 202111305
            lightWeightLaneGroupView.backgroundColor = bgColor
            
            let showAllTipsTextHeight: CGFloat = ceil(YKNFont.height(with: .systemFont(ofSize: 14), lineNumber: 1))
            let showAllTipsView = CompPlugin14180OptionsView.init(frame: CGRect.init(x: 0, y: 0, width: itemWidth, height: showAllTipsTextHeight))
            showAllTipsView.useMoreViewStyle()
            showAllTipsView.backgroundColor = bgColor
            showAllTipsView.isHidden = true
            showAllTipsView.tag = 202111306
            bindShowAllTipsStatis(showAllTipsView)
            
            itemContainer.addSubview(lightWeightLaneGroupView)
            itemContainer.addSubview(showAllTipsView)
            
            itemContainer.lightweightLaneGroupView = lightWeightLaneGroupView
            itemContainer.showAllTipsView = showAllTipsView
        }
        
        self.itemContainer = itemContainer
        
        return itemContainer
    }
    
    func reuseView(itemView: UIView) {
        guard let itemContainer = itemView as? CompPlugin14180Container else {
            return
        }

        guard let laneGroupView = itemContainer.laneGroupView else {
            return
        }

        guard let optionsView = itemContainer.optionsView else {
            return
        }
        self.itemContainer = itemContainer
        
        laneGroupView.delegate = self
        laneGroupView.dataSource = self
        laneGroupView.width = itemContainer.bounds.width
        laneGroupView.apply(self.config)
        
        if shouldShowLightweightGroupView() {
            if let lightweightLaneGroupView = itemContainer.lightweightLaneGroupView {
                lightweightLaneGroupView.delegate = self
                lightweightLaneGroupView.dataSource = self
                lightweightLaneGroupView.width = itemContainer.bounds.width
                lightweightLaneGroupView.apply(self.lightWeightConfig)
            }
        }
        
        optionsView.width = itemContainer.bounds.width
        
        applySaveIndexPath()
        
        refreshLaneGroupViews()
        
        optionsView.delegate = self
        resetOptionView()
        
        if shouldShowShowAllTipsView() {
            if let showAllTipsView = itemContainer.showAllTipsView {
                showAllTipsView.isHidden = false
                
                let width = itemContainer.bounds.width
                let height = showAllTipsView.bounds.height
                let y = itemContainer.bounds.height - height - 9
                showAllTipsView.frame = CGRect.init(origin: .init(x: 0, y: y), size: .init(width: width, height: height))
                
                showAllTipsView.delegate = self
                showAllTipsView.setOptionsText("更多筛选")
            }
        } else {
            itemContainer.showAllTipsView?.isHidden = true
        }
    }
    
    func shouldShowShowAllTipsView() -> Bool {
        return shouldShowLightweightGroupView()
    }
    
    func shouldShowLightweightGroupView() -> Bool {
        if allowedLightWeight() == false {
            return false
        }
        
        if isForceShowAll {
            return false
        }
        
        if allItems.count == priorityItems.count {
            return false //优先项数量与总项数量一致时，不显示精简版
        }
        
        return true
    }
    
    func columnCount() -> CGFloat {
        return 1.0
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        var handlers = [ComponentEventHandler]()
        
        if floatingEnabled {
            let scrollEventHandler = Component14180ScrollEventHandler()
            handlers.append(scrollEventHandler)
        }
        
        let refreshHandler = Component14180RefreshHandler()
        handlers.append(refreshHandler)
        
        return handlers
    }
    
    // private
    
    // MARK: 本组件坑位字号边距统一收口
    static func itemSelectedFont() -> UIFont {
        return YKNFont.button_text_weight(.medium)
    }
    
    static func itemUnselectedFont() -> UIFont {
        return YKNFont.button_text_weight(.regular)
    }
    
    static func itemPadding() -> UIEdgeInsets {
        let horizontal = YKNGap.dim_7()
        let vertical = YKNGap.dim_5()
        return UIEdgeInsets.init(top: vertical, left: horizontal, bottom: vertical, right: horizontal)
    }
    
    func bindShowAllTipsStatis(_ view: UIView) {
        guard let items = component?.getItems(),
              let firstItem = items.first,
              let subItems = firstItem.getSubItems(),
              let firstSubitem = subItems.first,
              let firstSubitemReport = firstSubitem.itemModel?.action?.report
        else {
            return
        }
        
        let report = ReportModel()
        let spmAB = firstSubitemReport.spmAB ?? ""
        let spmC = "filter"
        let spmD = "more"
        report.pageName = firstSubitemReport.pageName
        report.spmAB = spmAB
        report.spmC = spmC
        report.spmD = spmD
        report.spm = "\(spmAB).\(spmC).\(spmD)"
        report.trackInfo = firstSubitemReport.trackInfo
        report.controller = firstSubitemReport.controller
        report.controlName = spmC
        
        var args = [String: Any]()
        args["pageName"] = report.pageName
        args["spm"] = report.spm
        args["track_info"] = report.trackInfo
        report.args = args
        
        Service.statistics.bind(report, view, .Defalut)
    }
    
    // MARK: - LaneGroupViewDataDelegate
    func laneGroupView(_ laneGroupView: LaneGroupView, numberOfItemsInLaneIndex laneIndex: Int) -> Int {
        let items = displayItems(laneGroupView)
        guard laneIndex < items.count, let item = items[laneIndex] as? IItem else {
            return 0
        }
        
        return item.getSubItems()?.count ?? 0
    }
    
    // MARK: - LaneGroupViewDelegate
    func laneGroupView(_ laneGroupView: LaneGroupView, selectedItemAtLaneIndex laneIndex: Int) -> Int {
        let items = displayItems(laneGroupView)
        guard laneIndex < items.count, let item = items[laneIndex] as? IItem ,
              let selectedIndex = item.itemModel?.extraExtend["selectedIndex"] as? Int else {
            return 0
        }
        
        return selectedIndex
    }
    
    func laneGroupView(_ laneGroupView: LaneGroupView, widthForItemAt indexPath: IndexPath) -> CGFloat {
        let items = displayItems(laneGroupView)
        guard indexPath.section < items.count, let item = items[indexPath.section] as? IItem else {
            return 0
        }
        
        guard let subItems = item.getSubItems(), indexPath.row < subItems.count , let subItem = subItems[indexPath.row] as? IItem else {
            return 0
        }
        
        return subItem.itemModel?.layout.renderRect.size.width ?? 0
    }

    func laneGroupView(_ laneGroupView: LaneGroupView, didSelectItemAt indexPath: IndexPath) {
        let items = displayItems(laneGroupView)
        guard indexPath.section < items.count, let item = items[indexPath.section] as? IItem else {
            return
        }
        
        guard let subItems = item.getSubItems(), indexPath.row < subItems.count , let subItem = subItems[indexPath.row] as? IItem else {
            return
        }

        // 记录选中索引
        item.itemModel?.extraExtend["selectedIndex"] = indexPath.row
        saveIndexPath(indexPath, forSelected: item)
        
        laneGroupView.scrollToItem(at: indexPath, animated: true)
        if let cell = laneGroupView.cellForItem(at: indexPath) as? CompPlugin14180ItemView {
            cell.drawSelectedStyle(textColor: sceneUtil(nil, sceneColor: self.component?.getPage()?.pageModel?.scene?.sceneOptionButtonSelectedTextColor()))
        }
        reloadCardData()
        resetOptionView()
        redirectToCardIfNeeded(laneGroupView)
        print("[14180] didSelectItemAt:\(indexPath)")
    }
    
    func laneGroupView(_ laneGroupView: LaneGroupView, didDeselectItemAt indexPath: IndexPath) {
        print("[14180] didDeselectItemAt:\(indexPath)")
        if let cell = laneGroupView.cellForItem(at: indexPath) as? CompPlugin14180ItemView {
            cell.drawDeselectedStyle(textColor: sceneUtil(nil, sceneColor: self.component?.getPage()?.pageModel?.scene?.sceneOptionButtonUnselectedTextColor()))
        }
    }
    
    func laneGroupView(_ laneGroupView: LaneGroupView, willDisplay cell: UICollectionViewCell, indexPath: IndexPath) {
        print("[14180] willDisplay:\(indexPath)")
     
        let items = displayItems(laneGroupView)
        guard indexPath.section < items.count, let item = items[indexPath.section] as? IItem else {
            return
        }
        
        if let cell = cell as? CompPlugin14180ItemView {
            let selectedIndex = item.itemModel?.extraExtend["selectedIndex"] as? Int ?? 0
            if selectedIndex == indexPath.row {
                print("[14180] willDisplay is selectedIndex:\(indexPath)")
                cell.drawSelectedStyle(textColor: sceneUtil(nil, sceneColor: self.component?.getPage()?.pageModel?.scene?.sceneOptionButtonSelectedTextColor()))
            } else {
                print("[14180] willDisplay is not selectedIndex:\(indexPath)")
                cell.drawDeselectedStyle(textColor: sceneUtil(nil, sceneColor: self.component?.getPage()?.pageModel?.scene?.sceneOptionButtonUnselectedTextColor()))
            }
        }
    }
    
    // MARK: - LaneGroupViewDataSource
    func laneGroupView(_ laneGroupView: LaneGroupView, cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        guard let cell = cell as? CompPlugin14180ItemView else {
            return
        }
        
        let items = displayItems(laneGroupView)
        guard indexPath.section < items.count, let item = items[indexPath.section] as? IItem else {
            return
        }
        
        guard let subItems = item.getSubItems(), indexPath.row < subItems.count , let subItem = subItems[indexPath.row] as? IItem else {
            return
        }
        
        cell.fillData(subItem.itemModel?.title ?? "")
        
        let selectedIndex = item.itemModel?.extraExtend["selectedIndex"] as? Int ?? 0
        if selectedIndex == indexPath.row {
            print("[14180] is selectedIndex:\(indexPath)")
            cell.drawSelectedStyle(textColor: sceneUtil(nil, sceneColor: self.component?.getPage()?.pageModel?.scene?.sceneOptionButtonSelectedTextColor()))
        } else {
            print("[14180] is not selectedIndex:\(indexPath)")
            cell.drawDeselectedStyle(textColor: sceneUtil(nil, sceneColor: self.component?.getPage()?.pageModel?.scene?.sceneOptionButtonUnselectedTextColor()))
        }
        
        Service.statistics.bind(subItem.itemModel?.action?.report, cell, .Defalut)
    }

    private func updateCardFirstPageRequestParams() {
        let items = allItems

        var filterParts = [String]()
        for item in items {
            let selectedIndex = item.itemModel?.extraExtend["selectedIndex"] as? Int ?? 0
            if let subItems = item.getSubItems(), selectedIndex < subItems.count, let subItem = subItems[selectedIndex] as? IItem {
                if let filterStatement = subItem.itemModel?.extraExtend["filterStatement"] as? String,
                   filterStatement.isEmpty == false {
                    filterParts.append(filterStatement)
                }
            }
        }
        let filter = filterParts.joined(separator: "|")
        self.component?.getCard()?.cardModel?.requestModel?.extraExtend["filterParam"] = filter
    }

    func reloadCardData() {
        updateCardFirstPageRequestParams()
        self.component?.getCard()?.triggerFirstPageRequest()
    }

    private func redirectToCardIfNeeded(_ laneGroupView: LaneGroupView) {
        if laneGroupView.superview == itemContainer {
            return
        }
        
        self.component?.scrollTo(at: .top, animated: false)
    }
    
    //MARK: CompPlugin14180OptionsViewDelegate
    func optionsViewDidClick(optionsView: CompPlugin14180OptionsView) {
        if shouldShowLightweightGroupView() {
            isForceShowAll = true
            
            itemContainer?.laneGroupView?.reloadData()
            itemContainer?.laneGroupView?.isHidden = false
            itemContainer?.lightweightLaneGroupView?.isHidden = true
            
            if let cardIndex = component?.getCard()?.index {
                component?.getPage()?.getCardManager()?.refreshCard(index: cardIndex)
            }
        }
        
        if optionsView.tag == 202111304 {
            makeLaneGroupViewToFloatingView()
        }
    }
    
    func makeLaneGroupViewToFloatingView() {
        guard let optionsView = itemContainer?.optionsView else {
            return
        }
        
        guard let superviewOfOptionsView = optionsView.superview else {
            return
        }
        
        guard let laneGroupView = itemContainer?.laneGroupView else {
            return
        }
        
        optionsView.removeFromSuperview()
        
        let paddingVertical = 9.0
        
        var laneGroupframe = laneGroupView.frame
        laneGroupframe.origin.y = paddingVertical
        laneGroupView.frame = laneGroupframe
        superviewOfOptionsView.addSubview(laneGroupView)
        
        var frame = superviewOfOptionsView.frame
        frame.size.height = laneGroupView.bounds.size.height + paddingVertical * 2
        superviewOfOptionsView.frame = frame
    }
    
    func resetOptionView() {
        guard let optionsView = itemContainer?.optionsView else {
            return
        }
        
        let items = allItems

        var titles = [String]()
        for (itemIndex, item) in items.enumerated() {
            let selectedIndex = item.itemModel?.extraExtend["selectedIndex"] as? Int ?? 0
            if let subItems = item.getSubItems(), selectedIndex < subItems.count, let subItem = subItems[selectedIndex] as? IItem {
                if selectedIndex == 0 && itemIndex != (items.count - 1) {
                    continue
                }
                if let title = subItem.itemModel?.title, !title.isEmpty {
                    titles.append(title)
                }
            }
        }
        let text = titles.joined(separator: "·")
        optionsView.setOptionsText(text)
    }
    
    func closeOptionsView() {
        if itemContainer?.optionsView?.superview != nil {
            itemContainer?.optionsView?.removeFromSuperview()
        }
    }
    
    func refreshLaneGroupViews() {
        guard let itemContainer = itemContainer else {
            return
        }
        
        if shouldShowLightweightGroupView() {
            itemContainer.laneGroupView?.isHidden = true
            itemContainer.lightweightLaneGroupView?.isHidden = false
        } else {
            itemContainer.laneGroupView?.isHidden = false
            itemContainer.lightweightLaneGroupView?.isHidden = true
        }
        
        if let laneGroupView = itemContainer.laneGroupView, laneGroupView.isHidden == false {
            laneGroupView.reloadData()
        }
        
        if shouldShowLightweightGroupView() {
            if let lightweightLaneGroupView = itemContainer.lightweightLaneGroupView, lightweightLaneGroupView.isHidden == false {
                lightweightLaneGroupView.reloadData()
            }
        }
        
        if let laneGroupView = itemContainer.laneGroupView, laneGroupView.superview != itemContainer {
            itemContainer.addSubview(laneGroupView)
            laneGroupView.top = 0
        }
        
        if shouldShowLightweightGroupView() {
            if let lightweightLaneGroupView = itemContainer.lightweightLaneGroupView, lightweightLaneGroupView.superview != itemContainer {
                itemContainer.addSubview(lightweightLaneGroupView)
                lightweightLaneGroupView.top = 0
            }
        }
    }
    
    func saveIndexPath(_ indexPath: IndexPath, forSelected item: IItem) {
        guard let model = item.itemModel as? Item14180Model,
              let filterType = model.filterType, !filterType.isEmpty
        else {
            return
        }
        
        // 点击type类型选项，筛选项面板数据源将重置，需要重置所有已选中的选项
        if (filterType == "type") {
            if let keys = self.component?.getCard()?.cardModel?.extraExtend.keys {
                for aKey in keys {
                    if aKey.hasPrefix("filter-section-") {
                        self.component?.getCard()?.cardModel?.extraExtend[aKey] = nil
                    }
                }
            }
            
            let items = allItems
            for item in items {
                if let model = item.itemModel as? Item14180Model, let filterType = model.filterType, !filterType.isEmpty {
                    if (filterType == "type") {
                        continue
                    }
                    
                    let saveKey = "filter-section-\(filterType)"
                    item.itemModel?.extraExtend["selectedIndex"] = nil
                }
            }
        }
        
        let saveKey = "filter-section-\(filterType)"
        self.component?.getCard()?.cardModel?.extraExtend[saveKey] = indexPath.item
    }
    
    func applySaveIndexPath() {
        guard let items = self.component?.getItems() else {
            return
        }
        
        for index in 0..<items.count {
            let item = items[index]
            
            if let model = item.itemModel as? Item14180Model, let filterType = model.filterType, !filterType.isEmpty {
                let saveKey = "filter-section-\(filterType)"
                if let selectIndex = self.component?.getCard()?.cardModel?.extraExtend[saveKey] as? Int {
                    item.itemModel?.extraExtend["selectedIndex"] = selectIndex
                }
            }
        }
    }
    
    func laneGroupViewIsFloating() -> Bool {
        return self.itemContainer?.laneGroupView?.superview != self.itemContainer
    }
}

class Component14180RefreshHandler : ComponentEventHandler , IComponentLifeCycleEventHandler {

    //MARK: - IComponentLifeCycleEventHandler
    
    func enterDisplayArea(itemView: UIView?) {
        DispatchQueue.main.async {
            DispatchQueue.main.async {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "comp.14180.didRefresh"), object: nil, userInfo: nil)
            }
        }
    }
    
    func exitDisplayArea(itemView: UIView?) {
        
    }
    
    func visibleViewDidScroll(itemView: UIView?) {
        
    }
    
    func visibleViewDidEndScroll(itemView: UIView?) {
        
    }
    
    func visibleViewsDidEndScroll() {
   
    }
    
}

class Component14180ScrollEventHandler : ComponentEventHandler, IComponentLifeCycleEventHandler , IPageScrollEventHandler {
    
    var flag: Int = 0
    
    var filterCardOffsetBegin: CGFloat = 0
    var filterCardOffsetEnd: CGFloat = 0
    
    var filterMenuComponentOffsetBegin: CGFloat = 0
    var filterMenuComponentOffsetEnd: CGFloat = 0
    var filterMenuComponentHeight: CGFloat = 0
    
    public required init() {
        super.init()
        
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(handleYKRLLayoutStatusDidChange(_:)),
                                               name: Notification.Name(rawValue: "YKRLLayoutStatusDidChangeNotification"),
                                               object: nil)
    }
    
    //MARK: - IComponentLifeCycleEventHandler
    
    func enterDisplayArea(itemView: UIView?) {
        guard let vc = component?.getPage()?.pageContext?.getViewController() else {
            return
        }
        guard let vcview = vc.view else {
            return
        }
        guard let floatingView = vcview.viewWithTag(202111301) else {
            return
        }
        
        floatingView.removeFromSuperview()
    }
    
    func exitDisplayArea(itemView: UIView?) {
        
    }
    
    func visibleViewDidScroll(itemView: UIView?) {
        
    }
    
    func visibleViewDidEndScroll(itemView: UIView?) {
        
    }
    
    func visibleViewsDidEndScroll() {
   
    }
    
    // MARK: -
    /// 容器滚动中
    func containerDidScroll(_ scrollView: UIScrollView) {
        if filterCardOffsetBegin == 0, filterCardOffsetEnd == 0 {
            return
        }
        guard let vc = component?.getPage()?.pageContext?.getViewController() else {
            return
        }
        guard let vcview = vc.view else {
            return
        }
        guard let collectionView = scrollView as? UICollectionView else {
            return
        }
        guard let componentDelegate = self.component?.getComponentDelegate() as? Component14180 else {
            return
        }
        
//        var debugLabel = vcview.viewWithTag(202111300) as? UILabel
        var floatingView = vcview.viewWithTag(202111301)
        if floatingView == nil {
//            let label = UILabel.init()
//            label.tag = 202111300
//            label.frame = CGRect.init(x: 0, y: 500, width: collectionView.width, height: 100)
//            label.backgroundColor = .cyan
//            label.alpha = 0.8
//            label.numberOfLines = 0
//            vcview.addSubview(label)
//            debugLabel = label
            
            let view = UIView.init()
            view.isUserInteractionEnabled = true
            view.tag = 202111301
            view.backgroundColor = collectionView.backgroundColor
            
            let y = collectionView.contentInset.top
            view.frame = CGRect.init(x: 0, y: y, width: collectionView.width, height: 0)
            vcview.addSubview(view)
            floatingView = view
        }
        guard let floatingView = floatingView else {
            return
        }
//        guard let debugLabel = debugLabel else {
//            return
//        }
        
        vcview.bringSubviewToFront(floatingView)
//        vcview.bringSubviewToFront(debugLabel)
        
        updateFilterLocationMark()
        let collectionViewInsetTop = collectionView.contentInset.top
//        let filterCardRange = (-collectionViewInsetTop + filterCardOffsetBegin)..<(-collectionViewInsetTop + filterCardOffsetEnd)
//        let filterMenuRange = (-collectionViewInsetTop + filterMenuComponentOffsetBegin)..<(-collectionViewInsetTop + filterMenuComponentOffsetEnd)
//        debugLabel.text = "offset: \(collectionView.contentOffset.y) \n\(collectionViewInsetTop) ; \(filterCardOffsetBegin) ; \(filterCardOffsetEnd) \ncardRange:\(filterCardRange)  menuRange:\(filterMenuRange)"
//
        let collectionViewOffsetY = collectionView.contentOffset.y
//        if filterMenuRange ~= collectionViewOffsetY {
//            debugLabel.backgroundColor = .yellow
//        } else if filterCardRange ~= collectionViewOffsetY {
//            debugLabel.backgroundColor = .purple
//        } else {
//            debugLabel.backgroundColor = .cyan
//        }
        
        var filterOtherRange = 0.0..<0.0
        let filterOtherBegin = (-collectionViewInsetTop + filterMenuComponentOffsetEnd)
        let filterOtherEnd = (-collectionViewInsetTop + filterCardOffsetEnd)
        if filterOtherBegin < filterOtherEnd {
            filterOtherRange = filterOtherBegin..<filterOtherEnd
        }
                
        if filterOtherRange ~= collectionViewOffsetY {
            if flag > 0 {
                if let optionsView = componentDelegate.itemContainer?.optionsView {
                    let optionsViewInFloatingView = floatingView.viewWithTag(202111304)
                    if optionsViewInFloatingView == nil {
                        floatingView.addSubview(optionsView)
                    }
                    
                    var frame = floatingView.frame
                    frame.size = optionsView.bounds.size
                    floatingView.frame = frame
                }
                
                flag = 0
            }
        } else {
            if let optionsViewInFloatingView = floatingView.viewWithTag(202111304) {
                optionsViewInFloatingView.removeFromSuperview()
            }
            
            if let itemContainer = componentDelegate.itemContainer,
               let laneGroupView = componentDelegate.itemContainer?.laneGroupView {

                let laneGroupViewInContainer = itemContainer.viewWithTag(202111303)
                if laneGroupViewInContainer == nil {
                    var frame = laneGroupView.frame
                    frame.origin = .zero
                    laneGroupView.frame = frame
                    itemContainer.addSubview(laneGroupView)
                }
            }
            
            if componentDelegate.shouldShowLightweightGroupView(),
               let itemContainer = componentDelegate.itemContainer,
               let laneGroupView = componentDelegate.itemContainer?.lightweightLaneGroupView {

                let laneGroupViewInContainer = itemContainer.viewWithTag(202111305)
                if laneGroupViewInContainer == nil {
                    var frame = laneGroupView.frame
                    frame.origin = .zero
                    laneGroupView.frame = frame
                    itemContainer.addSubview(laneGroupView)
                }
            }
            
            var frame = floatingView.frame
            frame.size = .zero
            floatingView.frame = frame
        }
    }
    
    /// 拖拽容器开始
    func containerWillBeginDragging(_ scrollView: UIScrollView) {
        guard let vc = component?.getPage()?.pageContext?.getViewController() else {
            return
        }
        guard let vcview = vc.view else {
            return
        }
        guard let collectionView = scrollView as? UICollectionView else {
            return
        }
        guard let componentDelegate = self.component?.getComponentDelegate() as? Component14180 else {
            return
        }
        
//        var debugLabel = vcview.viewWithTag(202111300) as? UILabel
        var floatingView = vcview.viewWithTag(202111301)
        if floatingView == nil {
//            let label = UILabel.init()
//            label.tag = 202111300
//            label.frame = CGRect.init(x: 0, y: 500, width: collectionView.width, height: 150)
//            label.backgroundColor = .cyan
//            label.alpha = 0.8
//            label.numberOfLines = 0
//            vcview.addSubview(label)
//            debugLabel = label
            
            let view = UIView.init()
            view.isUserInteractionEnabled = true
            view.tag = 202111301
            view.backgroundColor = collectionView.backgroundColor
            
            let y = collectionView.contentInset.top
            view.frame = CGRect.init(x: 0, y: y, width: collectionView.width, height: 0)
            vcview.addSubview(view)
            floatingView = view
        }
        guard let floatingView = floatingView else {
            return
        }
//        guard let debugLabel = debugLabel else {
//            return
//        }
        
        vcview.bringSubviewToFront(floatingView)
        updateFilterLocationMark()
        
        let collectionViewInsetTop = collectionView.contentInset.top
        let collectionViewOffsetY = collectionView.contentOffset.y
        
        var filterOtherRange = 0.0..<0.0
        let filterOtherBegin = (-collectionViewInsetTop + filterMenuComponentOffsetEnd)
        let filterOtherEnd = (-collectionViewInsetTop + filterCardOffsetEnd)
        if filterOtherBegin < filterOtherEnd {
            filterOtherRange = filterOtherBegin..<filterOtherEnd
        }
        
        if let itemContainer = componentDelegate.itemContainer,
           let laneGroupView = componentDelegate.itemContainer?.laneGroupView {
            
            let laneGroupViewInContainer = itemContainer.viewWithTag(202111303)
            if laneGroupViewInContainer == nil {
                var frame = laneGroupView.frame
                frame.origin = .zero
                laneGroupView.frame = frame
                itemContainer.addSubview(laneGroupView)
            }
        }
        
        if componentDelegate.shouldShowLightweightGroupView(),
           let itemContainer = componentDelegate.itemContainer,
           let laneGroupView = componentDelegate.itemContainer?.laneGroupView {
               
           let laneGroupViewInContainer = itemContainer.viewWithTag(202111305)
           if laneGroupViewInContainer == nil {
               var frame = laneGroupView.frame
               frame.origin = .zero
               laneGroupView.frame = frame
               itemContainer.addSubview(laneGroupView)
           }
        }
        
        if filterOtherRange ~= collectionViewOffsetY {
            if let optionsView = componentDelegate.itemContainer?.optionsView {
                let optionsViewInFloatingView = floatingView.viewWithTag(202111304)
                if optionsViewInFloatingView == nil {
                    floatingView.addSubview(optionsView)
                }
                
                var frame = floatingView.frame
                frame.size = optionsView.bounds.size
                floatingView.frame = frame
            }
            
            flag = 0
        } else {
            flag = 1
        }
    }
    
    /// 拖拽容器将结束
    func containerWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
    }
    
    /// 拖拽容器已结束
    func containerDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
    }
    
    /// 容器滚动减速开始
    func containerWillBeginDecelerating(_ scrollView: UIScrollView) {
        
    }
    
    /// 容器滚动减速结束
    func containerDidEndDecelerating(_ scrollView: UIScrollView) {
    }

    /// 容器滚动动画结束
    func containerDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        
    }
    
    @objc func handleYKRLLayoutStatusDidChange(_ notifaction: Notification) {
        guard let vc = component?.getPage()?.pageContext?.getViewController() else {
            return
        }
        guard let vcview = vc.view else {
            return
        }
        guard let componentDelegate = self.component?.getComponentDelegate() as? Component14180 else {
            return
        }

        // work around 转屏时重置宽度，默认取vc宽
        if let itemContainer = componentDelegate.itemContainer {
            itemContainer.width = vcview.bounds.width
        }
        
        if let laneGroupView = componentDelegate.itemContainer?.laneGroupView {
            laneGroupView.width = vcview.bounds.width
            laneGroupView.tag = 202111303 //work around 内部重置布局
        }
        
        if let optionsView = componentDelegate.itemContainer?.optionsView {
            optionsView.width = vcview.bounds.width
        }

        
        if let floatingView = vcview.viewWithTag(202111301) {
            floatingView.removeFromSuperview()
        }
        
        updateFilterLocationMark()
    }
    
    func updateFilterLocationMark() {
        guard let component = component,
              let card = component.getCard()
        else {
            return
        }
        
        let componentInfo = component.getLayoutInfo()
        let cardLayoutInfo = card.getLayoutInfo()
        
        let cardOffsetY = cardLayoutInfo.y
        let cardHeight = cardLayoutInfo.height
        let menuOffsetY = componentInfo.y
        let menuHeight = componentInfo.height
        
        filterCardOffsetBegin = cardOffsetY
        filterCardOffsetEnd = cardOffsetY + cardHeight - 40.0
        filterMenuComponentOffsetBegin = menuOffsetY
        filterMenuComponentOffsetEnd = menuOffsetY + menuHeight
        filterMenuComponentHeight = menuHeight
    }
}
