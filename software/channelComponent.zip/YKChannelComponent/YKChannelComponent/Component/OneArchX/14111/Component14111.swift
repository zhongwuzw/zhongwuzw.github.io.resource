//
//  Component14111.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/25.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKHome
import YKSCService
import YKResponsiveLayout
import OneArchSupport4Youku

open class Component14111: CompSliderLayoutDelegate {
    override var compModel:BaseComponentModel? {
        get {
            return self.component?.compModel
        }
    }
    
    public override func itemIdentifier(index: Int) -> String {
        var identifier = ""
        if index < self.allDatas.count {
            let data = self.allDatas[index]
            if let _ = data as? IItem {
                identifier = "14111.item.content.swift"
            }
        }
        if identifier == "" {
            identifier = super.itemIdentifier(index: index)
        }
        return identifier
    }
    
    public override func layoutConfig() -> ComponentLayoutConfig {
        var config = super.layoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_column_spacing(), right: 0)
        return config
    }
    
    override open func itemHeight(itemWidth: CGFloat) -> CGFloat {
        var itemHeight:CGFloat = 130
        if ykrl_isResponsiveLayout() {
            itemHeight = itemHeight * 1.5
        }
        return itemHeight
    }
    
    public override func createItemView(index: Int, itemSize: CGSize) -> UIView {
        let frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
        var itemView: UIView?
        if index < self.allDatas.count {
            let data = self.allDatas[index]
            if let _ = data as? IItem {
                itemView = Item14111ContentView.init(frame: frame)
            }
        }
        if let itemView = itemView {
            if ykrl_isResponsiveLayout() {
                itemView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
                itemView.clipsToBounds = true
            }
            return itemView
        } else {
            return super.createItemView(index: index, itemSize: itemSize)
        }
    }

    public override func reuseItemView(index: Int, itemView: UIView) {
        if let view = itemView as? Item14111ContentView,
            index < self.allDatas.count {
            if let item = self.allDatas[index] as? IItem {
                    view.fillData(item)
                }
            }
    }
    
    override open func reuseView(itemView: UIView) {
        super.reuseView(itemView: itemView)
        self.sliderControlEventHandler.sliderView = self.sliderView
    }
    
    // MARK: - event
    public override func loadEventHandlers() -> [ComponentEventHandler]? {
        var array = [ComponentEventHandler]()
        array.append(self.sliderControlEventHandler)
        return array
    }
    
    lazy var sliderControlEventHandler: CompSliderPlayerControlEventHandler = {
        let event = CompSliderPlayerControlEventHandler()
        return event
    }()
}
