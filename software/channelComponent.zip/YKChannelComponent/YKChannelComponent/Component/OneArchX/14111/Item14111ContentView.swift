//
//  Item14111ContentView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/25.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import YKUIComponent
import YKModeConfigFramework
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item14111GradientView: UIView {

    override class var layerClass: AnyClass {
        return CAGradientLayer.self
    }

    func fillData(_ model: Item14111Model) {
        guard let color = model.extraExtend["imageAvgColor"] as? UIColor else {
            self.isHidden = true
            return
        }
        
        if !model.useColor || color == UIColor.clear {
            self.isHidden = true
        } else {
            self.isHidden = false
            
            let topCGColor = UIColor.createColorWithHexRGB(colorStr: "#000000").withAlphaComponent(0).cgColor
            let bottomColor = UIColor.createColorWithHexRGB(colorStr: "#000000").withAlphaComponent(0.4).cgColor

            if let layer = self.layer as? CAGradientLayer {
                layer.colors = [topCGColor, bottomColor]
            }
        }
    }
}

class Item14111ContentView: UIView {
    lazy var backgroundImageView: UIImageGIFView = {
        let backgroundImageView = UIImageGIFView()
        backgroundImageView.contentMode = UIView.ContentMode.scaleAspectFill
        return backgroundImageView
    }()
    
    lazy var gradientView: Item14111GradientView = {
        let gradientView = Item14111GradientView()
        if let layer = gradientView.layer as? CAGradientLayer {
            layer.locations = [0.0, 1.0]
            layer.startPoint = CGPoint(x: 0.5, y: 0)
            layer.endPoint = CGPoint(x: 0.5, y: 1)
        }
        return gradientView
    }()
    
    lazy var titleLabel: UILabel = {
        let _titleLabel = UILabel()
        _titleLabel.textColor = YKNColor.cw_1()
        _titleLabel.font = YKNFont.mediumfont_size_middle2()
        _titleLabel.textAlignment = NSTextAlignment.left
        _titleLabel.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.3)
        _titleLabel.shadowOffset = CGSize(width: 0, height: 1)
        return _titleLabel
    }()
    
    lazy var subtitleLabel: UILabel = {
        let _subtitleLabel = UILabel()
        _subtitleLabel.textColor = UIColor.white.withAlphaComponent(0.8)
        _subtitleLabel.font = YKNFont.posteritem_subhead()
        _subtitleLabel.textAlignment = NSTextAlignment.left
        return _subtitleLabel
    }()
    
    lazy var hotLabel: UILabel = {
        let hotLabel = UILabel()
        hotLabel.textColor = UIColor.white
        hotLabel.font = UIFont.boldSystemFont(ofSize: 11.0)
        hotLabel.textAlignment = NSTextAlignment.center
        hotLabel.backgroundColor = UIColor.ykn_brandInfo
        hotLabel.layer.cornerRadius = 4
        hotLabel.layer.masksToBounds = true
        return hotLabel
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)

        self.backgroundColor = UIColor.clear
        self.layer.masksToBounds = true

        self.addSubview(self.backgroundImageView)
        self.addSubview(self.gradientView)
        self.addSubview(self.titleLabel)
        self.addSubview(self.subtitleLabel)
        self.addSubview(self.hotLabel)

        self.backgroundImageView.frame = self.bounds

        var gradientViewFrame = self.bounds

        gradientViewFrame.size.height = 56
        gradientViewFrame.origin.y = self.bounds.height - gradientViewFrame.height
        self.gradientView.frame = gradientViewFrame

        let padding = YKNGap.dim_7()
        let textMaxWidth = self.width - 2 * padding - 50

        self.subtitleLabel.frame = CGRect(x: padding, y: self.height - YKNGap.dim_6() - 17, width: textMaxWidth, height: 17)
        self.titleLabel.frame = CGRect(x: padding, y: self.subtitleLabel.top - YKNGap.dim_4() - 20, width: textMaxWidth, height: 20)
        
        self.hotLabel.frame = CGRect(x: padding, y: self.titleLabel.top - 3 - 16, width: 0, height: 17)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(_ item: IItem?) {
        guard let item = item , let model = item.itemModel as? Item14111Model else {
            return
        }

        self.titleLabel.text = model.title
        self.subtitleLabel.text = model.subtitle
        
        if let hotTitle = model.extraExtend["hotTitle"] as? String, hotTitle.isEmpty == false {
            self.hotLabel.isHidden = false
            self.hotLabel.text = hotTitle
            if let hotTitleSize = model.extraExtend["hotTitleSize"] as? CGSize {
                self.hotLabel.width = hotTitleSize.width + 12
            }
        } else {
            self.hotLabel.isHidden = true
        }
        
        self.gradientView.fillData(model)

        let count = item.getComponent()?.getItems()?.count ?? 1
        var indicatorWidth: Int = 0

        if count > 1 {
            indicatorWidth = 19 + (5 + 2) * (count - 1)
            indicatorWidth += 9 //间隔
        }

        self.subtitleLabel.width = self.width - CGFloat(indicatorWidth) - 9 - 12

        self.backgroundImageView.ykn_setImage(withURLString: model.img,
                               module: "nodepage",
                               imageSize: .zero,
                               parameters: nil) { [self] image, error, info in
            if image != nil && model.useColor {
                image?.yk_averageBaseColor(completion: { (color:UIColor?) in
                    model.extraExtend["imageAvgColor"] = color
                    self.gradientView.fillData(model)
                })
            }
        }
        
        Service.action.bind(model.action, self)

        //smart ui token
        self.titleLabel.font = YKNFont.posteritem_maintitle_weight(.medium)
        self.subtitleLabel.font = YKNFont.posteritem_subhead()

        // relayout
        let padding = YKNGap.dim_7()
        let textMaxWidth = self.width - 2 * padding - 50
        
        let subtitleHeight = YKNFont.height(with: self.subtitleLabel.font, lineNumber: 1)
        self.subtitleLabel.frame = CGRect(x: padding, y: self.height - YKNGap.dim_6() - subtitleHeight, width: textMaxWidth, height: subtitleHeight)

        let titleHeight = YKNFont.height(with:self.titleLabel.font, lineNumber: 1)
        self.titleLabel.frame = CGRect(x: padding, y: self.subtitleLabel.top - titleHeight, width: textMaxWidth, height: titleHeight)
        
        self.hotLabel.bottom = self.titleLabel.top - 3
        self.hotLabel.layer.cornerRadius = self.radius_small()
    }
}
