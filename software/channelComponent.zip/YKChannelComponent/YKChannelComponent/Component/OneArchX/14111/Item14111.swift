//
//  Item14111.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/25.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

public class Item14111: NSObject, ItemDelegate {
    
    public var itemWrapper: ItemWrapper?
    
    public func itemDidInit() {
        preCalLayout()
    }
    
    public func itemWidth() -> CGFloat {
        return 0
    }

    public func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 130
    }
    
    public func createView(_ itemSize: CGSize) -> UIView {
        return UIView.init()
    }
    
    public func reuseView(itemView: UIView) {
        
    }
    
    public func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    public func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14111Model.self as? T.Type
    }
    
    // MARK: - private
    
    func preCalLayout() {
        guard let model = item?.itemModel else {
            return
        }

        //cache
        if let hotTitle = model.extraExtend["hotTitle"] as? String, hotTitle.isEmpty == false {
            let size = calcStringSize(hotTitle, font: UIFont.boldSystemFont(ofSize: 11), size: CGSize.zero)
            model.extraExtend["hotTitleSize"] = size
        }
    }
}
