//
//  Item14111Model.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/25.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku

open class Item14111Model: BaseItemModel {
    public var useColor: Bool = false
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)

        if let cmsInfo = cmsInfo, let data = cmsInfo["data"] as? [String : Any] {
            if let value = data["useColor"] as? String {
                self.useColor = (value == "1")
            } else if let value = data["useColor"] as? Int {
                self.useColor = (value == 0)
            } else if let value = data["useColor"] as? Bool {
                self.useColor = value
            } else {
                self.useColor = true
            }
        }
    }
}
