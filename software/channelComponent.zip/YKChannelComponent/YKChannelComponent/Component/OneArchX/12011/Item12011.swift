//
//  Item12011.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/10.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YoukuAnalytics

class Item12011 : NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item12011Model.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }

    func columnCount() -> CGFloat {
        return 2.0
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        estimatedLayoutIfNeeded(itemWidth)
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [
            PlayerScrollEndItemEventHandler(),
            PlayerToolsEventHandler(),
            ItemPlayerProgressEventHandler(),
        ]
    }
    
    func itemDidInit() {
        guard let itemModel = item?.itemModel else {
            return
        }
        
        //预览播放使用 OPVideoScreenModeAspectFit = 0
        itemModel.playerModel?.videoScreenMode = 0
        itemModel.playerModel?.slientModeInPage = true
        itemModel.playerModel?.showBottomProgress = true
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item12011ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }

    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item12011ContentView else {
            return
        }
        guard let itemModel = self.item?.itemModel as? Item12011Model else {
            return
        }
        guard let itemLayout = self.item?.itemModel?.layout else {
            return
        }

        // 使得底部阴影生效
        itemView.superview?.clipsToBounds = false
        
        //player
        let playerModel = itemModel.playerModel
        let size = CGSize(width: itemView.width, height: ceil(itemView.width * 9.0/16.0))
        Service.player.attach(playerModel, toView: itemView.videoImageView, displayFrame: CGRect.init(origin: CGPoint.zero, size: size))
        
        itemView.fillData(itemModel, itemLayout, self.item)
    }

    // MARK: - 坑位布局计算
    func estimatedLayoutIfNeeded(_ itemWidth: CGFloat) {
        guard let itemModel = item?.itemModel as? Item12011Model else {
            return
        }
        
        let itemLayout = itemModel.layout
        guard shouldRelayout(for: itemWidth) else {
            return
        }
        
        itemLayout.extendExtra = [String: Any]()
        
        // 播放器及封面图
        let coverLayout = ImageLayoutModel()
        let coverX: CGFloat = 0
        let coverY: CGFloat = 0
        let coverWidth: CGFloat = CGFloat(itemWidth)
        let coverHeight: CGFloat = ceil(coverWidth * 9.0/16.0)
        coverLayout.renderRect = CGRect.init(x: coverX, y: coverY, width: coverWidth, height: coverHeight)
        itemLayout.cover = coverLayout
        
        // 播放器标题
        let titleBoundingWidth: CGFloat = CGFloat(coverWidth) - 12 * 2
        if let title = itemModel.title, !title.isEmpty {
            let titleFont = YKNFont.module_headline_weight(.medium)
            let titleSingleLineHeight: CGFloat = YKNFont.height(with: titleFont, lineNumber: 1)
            let titleSizeSingleLine = textFitSize(title, font: titleFont, limit: CGSize.init(width: titleBoundingWidth * 2, height: titleSingleLineHeight))
            var titleSize = titleSizeSingleLine

            if titleSizeSingleLine.width > titleBoundingWidth {
                var titleSizeDoubleLine = CGSize.init(width: titleBoundingWidth, height: titleSingleLineHeight * 2)
                titleSizeDoubleLine.height += 1
                titleSize = titleSizeDoubleLine
            }

            let titleLayout = TextLayoutModel()
            titleLayout.font = titleFont
            let titleX: CGFloat = 12
            let titleY: CGFloat = coverLayout.renderRect.minY + 12
            titleLayout.renderRect = CGRect.init(x: titleX, y: titleY, width: titleBoundingWidth, height: titleSize.height)
            itemLayout.title = titleLayout
        } else {
            itemLayout.title = nil
        }
        
        // 播放器腰封
        if let summary = itemModel.extraExtend["poster.summary"] as? SummaryModel {
            let layout = Service.summary.estimatedLayout(summary, toViewSize: coverLayout.renderRect.size)
            itemLayout.summary = layout
        }
        
        // 海报图
        let posterLayout = ImageLayoutModel()
        let posterX: CGFloat = coverLayout.renderRect.minX
        let posterY: CGFloat = coverLayout.renderRect.maxY + YKNGap.dim_5()
        let posterWidth: CGFloat = 36 * YKNSize.yk_icon_size_scale()
        let posterHeight: CGFloat = 48 * YKNSize.yk_icon_size_scale()
        posterLayout.renderRect = CGRect.init(x: posterX, y: posterY, width: posterWidth, height: posterHeight)
        itemLayout.extendExtra?["showRecmImage"] = posterLayout
        
        // 主标题&副标题前置计算
        let titleFont = YKNFont.posteritem_maintitle()
        let titleHeight = YKNFont.height(with: titleFont, lineNumber: 1)
        let subtitleFont = YKNFont.posteritem_subhead_weight(.semibold)
        let subtitleHeight: CGFloat = YKNFont.height(with: subtitleFont, lineNumber: 1)
        let betweenTitleAndSubtitleGap: CGFloat = 6
        let textAreaHeight = titleHeight + betweenTitleAndSubtitleGap + subtitleHeight
        
        // 主标题
        let titleLayout = TextLayoutModel()
        titleLayout.font = titleFont
        let titleX: CGFloat = posterLayout.renderRect.maxX + YKNGap.dim_6()
        let titleY: CGFloat = posterLayout.renderRect.minY + (posterLayout.renderRect.height - textAreaHeight) / 2
        let showRecmTextBoundingWidth: CGFloat = CGFloat(itemWidth - posterWidth - (YKNGap.dim_6() * 2) - 80)
        let titleWidth: CGFloat = textFitSize(itemModel.showRecommendModel?.title, font: titleFont, limit: CGSize.init(width: showRecmTextBoundingWidth, height: titleHeight)).width
        titleLayout.renderRect = CGRect.init(x: titleX, y: titleY, width: titleWidth, height: titleHeight)
        itemLayout.extendExtra?["showRecmTitle"] = titleLayout
        
        var textCursorX = titleLayout.renderRect.maxX
        // 评分
        if let score = itemModel.showRecommendModel?.score, !score.isEmpty {
            let scoreFont = YKNFont.akrobatExtraBoldFont(ofSize: YKNFont.posteritem_maintitle().pointSize)
            let scoreHeight: CGFloat = YKNFont.height(with: scoreFont, lineNumber: 1)
            let scoreLayout = TextLayoutModel()
            scoreLayout.font = scoreFont
            let scoreX: CGFloat = textCursorX + YKNGap.dim_4()
            let scoreY: CGFloat = titleLayout.renderRect.minY + (titleHeight - scoreHeight) / 2
            
            let scoreWidth: CGFloat = textFitSize(score, font: scoreFont, limit: CGSize.init(width: showRecmTextBoundingWidth, height: scoreHeight)).width
            scoreLayout.renderRect = CGRect.init(x: scoreX, y: scoreY, width: scoreWidth, height: scoreHeight)
            itemLayout.extendExtra?["showRecmScore"] = scoreLayout
            
            textCursorX = scoreLayout.renderRect.maxX
        } else {
            itemLayout.extendExtra?["showRecmScore"] = nil
        }
        
        // 小箭头
        let arrowLayout = ImageLayoutModel()
        let arrowWidth: CGFloat = 12 * YKNSize.yk_icon_size_scale()
        let arrowHeight: CGFloat = 12 * YKNSize.yk_icon_size_scale()
        let arrowX: CGFloat = textCursorX + YKNGap.dim_4()
        let arrowY: CGFloat = titleLayout.renderRect.minY + (titleHeight - arrowHeight) / 2
        arrowLayout.renderRect = CGRect.init(x: arrowX, y: arrowY, width: arrowWidth, height: arrowHeight)
        itemLayout.extendExtra?["showRecmArrow"] = arrowLayout

        // 副标题
        let subtitleLayout = TextLayoutModel()
        subtitleLayout.font = subtitleFont
        let subtitleX: CGFloat = titleX
        let subtitleY: CGFloat = titleLayout.renderRect.maxY + betweenTitleAndSubtitleGap
        subtitleLayout.renderRect = CGRect.init(x: subtitleX, y: subtitleY, width: showRecmTextBoundingWidth, height: subtitleHeight)
        itemLayout.extendExtra?["showRecmDesc"] = subtitleLayout
        
        // 去购票
        if let buy = itemModel.showRecommendModel?.guidacne?.desc, !buy.isEmpty {
            let buyLayout = ImageLayoutModel()
            let buyWidth: CGFloat = 60
            let buyHeight: CGFloat = 30
            let buyX: CGFloat = itemWidth - buyWidth
            let buyY: CGFloat = posterLayout.renderRect.minY + (posterLayout.renderRect.size.height - buyHeight) / 2
            buyLayout.renderRect = CGRect.init(x: buyX, y: buyY, width: buyWidth, height: buyHeight)
            itemLayout.extendExtra?["buy"] = buyLayout
        }
        
        // Last Step 保存(下次直接使用)
        let totalHeight = posterLayout.renderRect.maxY
        itemLayout.renderRect = .init(x: 0, y: 0, width: itemWidth, height: totalHeight)
    }
    
    func shouldRelayout(for newItemWidth: Double) -> Bool {
        guard let itemModel = item?.itemModel else {
            return false
        }
        
        let itemLayout = itemModel.layout
        if itemLayout.renderRect.isEmpty {
            return true
        }
        
        if itemLayout.renderRect.width != newItemWidth {
            return true
        }
        
        return false
    }
    
    // MARK: -
    func sendCustomPlayerStatistic() {
        
    }
    
    private func textFitSize(_ text: String?, font: UIFont, limit: CGSize) -> CGSize {
        guard let text = text else {
            return .zero
        }

        var fitSize = NSString(string: text).boundingRect(with: limit,
                                                          options: [.usesLineFragmentOrigin, .truncatesLastVisibleLine],
                                                          attributes: [.font: font],
                                                          context: nil).size
        fitSize = CGSize(width: ceil(fitSize.width), height: ceil(fitSize.height))
        return fitSize
    }

}

