//
//  Item12011ContentView.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/10.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item12011ContentView : AccessibilityView {
    
    weak var model: Item12011Model?
    
    lazy var contentView: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        
        if !ykrl_isResponsiveLayout() {
            view.isUserInteractionEnabled = true
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(didClickVideoImageView(_:)))
            view.addGestureRecognizer(tapGesture)
        }
        
        return view
    }()
    
    lazy var playIconView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.image = UIImage.init(named: "st_player_plugin_icon_play")
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .white
        view.numberOfLines = 2
        return view
    }()
    
    lazy var showRecmImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_small()
        return view
    }()
        
    lazy var showRecmTitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.numberOfLines = 1
        return view
    }()
    
    lazy var showRecmDescLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.numberOfLines = 1
        return view
    }()
    
    lazy var showRecmScoreLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_brandInfo
        view.numberOfLines = 1
        return view
    }()
    
    lazy var showRecmArrowView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.image = UIImage.init(named: "feed_play_gray")?.withRenderingMode(.alwaysTemplate)
        return view
    }()
    
    lazy var buyButton: UIButton = {
        let view = UIButton()
        view.frame = CGRect.init(x: 0, y: 0, width: 60, height: 30)
        view.backgroundColor = .ykn_buttonFill
        view.clipsToBounds = true
        view.titleLabel?.font = YKNFont.secondry_auxiliary_text()
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.ykn_border.cgColor
        view.isUserInteractionEnabled = true
        
        var titleColor = UIColor.ykn_brandInfo
        view.setTitleColor(titleColor, for: UIControl.State.normal)
        view.layer.cornerRadius = 15
        return view
    }()
    
    //MARK: -
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        addSubview(contentView)
        
        contentView.addSubview(videoImageView)
        videoImageView.addSubview(playIconView)
        videoImageView.addSubview(titleLabel)
        
        contentView.addSubview(showRecmImageView)
        contentView.addSubview(showRecmTitleLabel)
        contentView.addSubview(showRecmDescLabel)
        contentView.addSubview(showRecmScoreLabel)
        contentView.addSubview(showRecmArrowView)
        
        contentView.addSubview(buyButton)
    }
    
    func relayoutSubviews(_ model: Item12011Model) {
        let contentViewY: CGFloat = 0
        contentView.frame = CGRect.init(x: 0, y: contentViewY, width: self.width, height: self.height - contentViewY)
        
        // 封面图及播放按钮
        videoImageView.frame = model.layout.cover?.renderRect ?? .zero
        playIconView.bounds = CGRect.init(x: 0, y: 0, width: 45, height: 45)
        playIconView.center = CGPoint.init(x: videoImageView.bounds.width / 2, y: videoImageView.bounds.height / 2)
        titleLabel.font = model.layout.title?.font
        titleLabel.frame = model.layout.title?.renderRect ?? .zero

        // 海报图
        if let layout = model.layout.extendExtra?["showRecmImage"] as? ImageLayoutModel {
            showRecmImageView.frame = layout.renderRect
        } else {
            showRecmImageView.frame = .zero
        }
 
        // 主标题
        if let layout = model.layout.extendExtra?["showRecmTitle"] as? TextLayoutModel {
            showRecmTitleLabel.font = layout.font
            showRecmTitleLabel.frame = layout.renderRect
        } else {
            showRecmTitleLabel.frame = .zero
        }
        
        // 评分
        if let layout = model.layout.extendExtra?["showRecmScore"] as? TextLayoutModel {
            showRecmScoreLabel.font = layout.font
            showRecmScoreLabel.frame = layout.renderRect
        } else {
            showRecmScoreLabel.frame = .zero
        }
        
        // 小箭头
        if let layout = model.layout.extendExtra?["showRecmArrow"] as? ImageLayoutModel {
            showRecmArrowView.frame = layout.renderRect
        } else {
            showRecmArrowView.frame = .zero
        }
        
        // 副标题
        if let layout = model.layout.extendExtra?["showRecmDesc"] as? TextLayoutModel {
            showRecmDescLabel.font = layout.font
            showRecmDescLabel.frame = layout.renderRect
        } else {
            showRecmDescLabel.frame = .zero
        }
        
        // 购票
        if let layout = model.layout.extendExtra?["buy"] as? ImageLayoutModel {
            buyButton.frame = layout.renderRect
        } else {
            buyButton.frame = .zero
        }
    }

    func refreshScene() {
        showRecmTitleLabel.textColor = sceneUtil(UIColor.ykn_primaryInfo, sceneColor: model?.scene?.sceneTitleColor())
        showRecmDescLabel.textColor = sceneUtil(UIColor.ykn_secondaryInfo, sceneColor: model?.scene?.sceneSubTitleColor())
        showRecmScoreLabel.textColor = sceneUtil(UIColor.ykn_brandInfo, sceneColor: model?.scene?.sceneSubTitleColor())
        showRecmArrowView.tintColor = sceneUtil(UIColor.ykn_brandInfo, sceneColor: model?.scene?.sceneSubTitleColor())
        contentView.backgroundColor = sceneUtil(UIColor.ykn_primaryBackground, sceneColor: model?.scene?.sceneNavBackgroundColor())
    }
    
    func fillData(_ itemModel: Item12011Model, _ layout: OneArchSupport4Youku.LayoutModel, _ item: IItem?) {
        model = itemModel
        relayoutSubviews(itemModel)
        
        // 播放器封面
        let coverImage = itemModel.poster?.img ?? ""
        videoImageView.ykn_setImage(withURLString: XCDNSTRING(coverImage),
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        // 播放器标题
        if let title = itemModel.title {
            var titleAttributedString = itemModel.extraExtend["titleAttributedString"] as? NSAttributedString
            if titleAttributedString == nil {
                let paragraphStyle = NSMutableParagraphStyle()
                paragraphStyle.lineSpacing = 1.0
                paragraphStyle.lineBreakMode = .byTruncatingTail

                let attributedText = NSMutableAttributedString.init(string: title)
                attributedText.addAttributes([.paragraphStyle : paragraphStyle],
                                              range: NSRange.init(location: 0, length: attributedText.length))

                titleAttributedString = attributedText
                itemModel.extraExtend["titleAttributedString"] = titleAttributedString
            }
            titleLabel.attributedText = titleAttributedString
            
            Service.viewInnerGradient.attach(.top, toView: videoImageView, scope: 60)
        } else {
            titleLabel.text = ""
            Service.viewInnerGradient.detach(.top, fromView: videoImageView)
        }
        
        // 播放按钮
        fillPlayIconView()
        
        // 播放器腰封
        if let summary = itemModel.extraExtend["poster.summary"] as? SummaryModel {
            Service.summary.attach(summary, toView: videoImageView, layout: layout.summary)
        } else {
            Service.summary.detach(fromView: videoImageView)
        }
        
        // 绑定播放器
        Service.player.attach(itemModel.playerModel, toView: videoImageView, displayFrame: videoImageView.bounds)
        
        // 海报图
        let posterImage = itemModel.showRecommendModel?.img ?? ""
        showRecmImageView.ykn_setImage(withURLString: XCDNSTRING(posterImage),
                                    module: "home",
                                    imageSize: showRecmImageView.bounds.size,
                                    parameters: nil,
                                    completed: nil)
        
        // 标题
        showRecmTitleLabel.text = itemModel.showRecommendModel?.title
        
        // 评分
        showRecmScoreLabel.text = itemModel.showRecommendModel?.score
                
        // 副标题
        showRecmDescLabel.text = itemModel.showRecommendModel?.desc
        
        // 购票按钮
        if let guidance = itemModel.showRecommendModel?.guidacne,
           let buyText = guidance.desc, !buyText.isEmpty {
            buyButton.setTitle(buyText, for: UIControl.State.normal)
            Service.action.bind(guidance.action, buyButton)
        }
        
        // 绑定点击
        Service.action.bind(itemModel.action, self)
        
        refreshScene()
    }
        
    func fillPlayIconView() {
        guard let itemModel = model else {
            playIconView.isHidden = true
            return
        }
        
        if let playerModel = itemModel.playerModel {
            playIconView.isHidden = !playerModel.canPlay
        } else {
            playIconView.isHidden = true
        }
    }
    
    @objc public func didClickVideoImageView(_ sender: AnyObject) {
        guard let playerModel = model?.playerModel else {
            return
        }

        // 点击起播
        PlayerControlManagerV2.shareInstance().startPlayer(playerModel)
    }
    
    public override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
        buyButton.layer.borderColor = UIColor.ykn_border.cgColor
    }
}

