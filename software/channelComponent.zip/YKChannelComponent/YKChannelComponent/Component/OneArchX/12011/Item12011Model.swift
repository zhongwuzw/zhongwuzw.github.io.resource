//
//  Item12011Model.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/10.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku
import YoukuResource

class Item12011Model: BaseItemModel {
        
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        
        // 腰封信息补齐
        if let poster = dataInfo["poster"] as? [String: Any] {
            if let rBottom = poster["rBottom"] as? [String: Any] {
                if let title = rBottom["title"] as? String, !title.isEmpty {
                    let summary = SummaryModel.init()
                    summary.text = title
                    summary.textType = .pureText
                    summary.textFont = YKNFont.corner_text_weight(.medium)
                    self.extraExtend["poster.summary"] = summary
                }
            }
        }
        
        if (dataInfo["preview"] as? [String: Any]) != nil {
            let likeAtion = ActionFactoryV2(self, spmDExt: "_play")
            if let report = likeAtion?.report {
                self.extraExtend["play_report"] = report
            }
        }
        
        if (dataInfo["like"] as? [String: Any]) != nil {
            let likeAtion = ActionFactoryV2(self, spmDExt: "_like")
            if let report = likeAtion?.report {
                self.extraExtend["like_report"] = report
            }
            
            let unlikeAction = ActionFactoryV2(self, spmDExt: "_unlike")
            if let report = unlikeAction?.report {
                self.extraExtend["unlike_report"] = report
            }
        }
        
        if var shareInfo = dataInfo["shareInfo"] as? [String: Any] {
            if let countString = shareInfo["shareCount"] as? String {
                if countString == "" || countString == "0" {
                    shareInfo["shareCount"] = "分享"
                }
            } else if let countInt = shareInfo["shareCount"] as? Int {
                if countInt == 0 {
                    shareInfo["shareCount"] = "分享"
                }
            } else {
                shareInfo["shareCount"] = "分享"
            }
            
            self.extraExtend["shareInfo"] = shareInfo
            
            let action = ActionFactoryV2(self, spmDExt: "_share")
            if let report = action?.report {
                self.extraExtend["shareInfo_report"] = report
            }
        }
    }
    
}
