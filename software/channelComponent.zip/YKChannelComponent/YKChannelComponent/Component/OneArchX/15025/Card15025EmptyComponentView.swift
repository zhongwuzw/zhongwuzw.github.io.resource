//
//  Card15025EmptyComponentView.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/7.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArchSupport
import OneArchBridge
import OneArchSupport4Youku
import YoukuResource
import OneArch

class Card15025EmptyComponentView: AccessibilityView {

    lazy var imageView: UIImageView = {
        let view = UIImageView.init(frame:CGRect.init(x: 0, y: 0, width: 74, height: 74))
        view.contentMode = .scaleAspectFill
        view.isUserInteractionEnabled = false
        view.clipsToBounds = true
        
        let image = UIImage.init(named: "ykn_error_empty_s")
        if #available(iOS 12.0, *) {
            if let darkImage = UIImage.init(named: "ykn_error_empty_s_dark") {
                image?.imageAsset?.register(darkImage, with: .init(userInterfaceStyle: .dark))
            }
        }
        view.image = image
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_tertiaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.text = "抱歉，没有找到相关内容"
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        self.backgroundColor = UIColor.ykn_primaryBackground
        addSubview(imageView)
        addSubview(titleLabel)
    }
    
    func fillData(title: String, titleWidth: CGFloat, component: IComponent) {
        guard let compModel = component.compModel else {
            return
        }
        
        let totalWidth = self.imageView.width + 15 + titleWidth
        let x = (self.width - totalWidth) / 2.0
        self.imageView.left = x
        self.titleLabel.width = titleWidth
        self.titleLabel.height = 74
        self.titleLabel.left = self.imageView.right + 15
        
        titleLabel.textColor = sceneUtil(UIColor.ykn_tertiaryInfo, sceneColor:
                                            compModel.scene?.sceneSubTitleColor())
        backgroundColor = sceneUtil(UIColor.ykn_primaryBackground, sceneColor: compModel.scene?.sceneBgColor())
    }

}
