//
//  Card15025EmptyComponent.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/7.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Card15025EmptyComponent:NSObject, ComponentDelegate {

    var componentWrapper: ComponentWrapper?

    func componentDidInit() {}

    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        return ComponentLayoutConfig()
    }

    func columnCount() -> CGFloat {
        return 1.0
    }

    /// 加载事件处理器
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

    var titleSize: CGSize = .zero
    var title = "抱歉，没有找到相关内容"
    /// item高度（custom布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        titleSize = calcStringSize(title, font: YKNFont.posteritem_maintitle(), size: .zero)
        return 74
    }

    /// 初始化item view（custom布局使用）
    func createView(_ itemSize: CGSize) -> UIView {
        return Card15025EmptyComponentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
    }

    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        guard let view = itemView as? Card15025EmptyComponentView else {
            return
        }
        view.fillData(title: self.title, titleWidth: self.titleSize.width, component: self.component as! IComponent)
        print("[jbp] Card15025EmptyComponentView reuse")
        
        /*
         //test request
         guard let cardModel = self.component?.getCard()?.cardModel else {
             return
         }
        view.whenTapped {
            cardModel.requestModel?.extraExtend["filterParam"] = "tags:喜剧,搞笑"
            self.component?.getCard()?.triggerFirstPageRequest()
        }*/
    }

    func itemViewClicked() {
        print("[OneArch] itemViewClicked")
    }
}
