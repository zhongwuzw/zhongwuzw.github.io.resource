//
//  Card15025.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/7.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku

class Card15025ComponentJsonExtracter: DefaultComponentJsonExtracter {

    override public init() {
        super.init()
    }

    // MARK: - 原始数据加工

    override public func getComponentsJson(cardJson: [String : Any]?, card: ICard?) -> Result<[[String : Any]], Error> {
        guard var subComponents = cardJson?["nodes"] as? [[String: Any]] else {
            return .success([[String : Any]]()) //允许没有组件列表
        }
        
        var onlyFilterComponent = true
        for compDic in subComponents {
            if let type = compDic["type"] as? Int {
                print("[jbp] 15025 extractor comp \(type)")
                if type != 14180 {
                    onlyFilterComponent = false
                    break
                }
            }
        }
        
        if onlyFilterComponent {
            subComponents.append(createEmptyComponentJson())
        }
        
        return .success(subComponents)
    }
    
    func createEmptyComponentJson() -> [String:Any] {
        var componentJson = [String:Any]()
        componentJson["type"] = "card.15025.empty.component"
        componentJson["data"] = [String:Any]()
        return componentJson
    }
}

class Card15025: BaseCardDelegate {

    /// component数据解析格式代理
    override func getComponentJsonExtracter() -> ComponentJsonExtracter? {
        return Card15025ComponentJsonExtracter.init()
    }
}

