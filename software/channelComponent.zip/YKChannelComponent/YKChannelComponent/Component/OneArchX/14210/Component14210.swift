//
//  Component14210.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/7/19.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout

class Component14210 : ComponentEventHandler, ComponentDelegate {
    
    var itemModel: Item14210Model? {
        get {
            return self.component?.getItems()?.first?.itemModel as? Item14210Model
        }
    }
    
    var layoutForceNewLine: Bool {
        get {
            guard ykrl_isResponsiveLayout() else {
                return false
            }
            
            // 新分组，瀑布流布局另起一行
            if let itemModel = self.itemModel, let item = itemModel.domainObject as? IItem {
                Component14210.updatePublishTimeSubIndexInGroup(item)
                if itemModel.isGame {
                    return false // 不予展示的坑位，不另起一行，以免影响后续坑位布局
                }
                
                if itemModel.publishTimeSubIndexInGroup == 0 {
                    return true
                }
            }
            
            return false
        }
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = 0.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        config.responsiveAdjustableMinColumnCount = 1
        config.responsiveMinColumnCount = 1
        config.responsiveMaxColumnCount = isResponsiveLayoutAndIsNotSplited() ? 2 : 1
        config.responsiveForceNewLine = self.layoutForceNewLine
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [
            self
        ]
    }
    
    public func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeComponentModel.self as? T.Type
    }
    
    func componentDidInit() {
        let count = rlcolumnCount();
        self.component?.setData(NSNumber(value: count), forKey: "yksc.data.comp.layout.columnCount.portrait")
        self.component?.setData(NSNumber(value: count), forKey: "yksc.data.comp.layout.columnCount.landscape")
    }
    
    var componentWrapper: ComponentWrapper?
    
    /// item高度（custom布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        estimatedLayout(itemWidth)
        
        if let itemHeight = self.itemModel?.layout.renderRect.height {
            return itemHeight
        }
        
        return 0
    }

    /// 初始化item view（custom布局使用）
    func createView(_ itemSize: CGSize) -> UIView {
        let itemWidth = itemSize.width
        let itemHeight = itemSize.height
        let itemView = Item14210ContentView.init(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))

        return itemView
    }
    
    func reuseId() -> String? {
        var reuseId = "YKChannelComponent.Item14210ContentView"
        if let tag = self.component?.compModel?.type {
            reuseId += tag
        }
        return reuseId
    }

    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14210ContentView else {
            return
        }
        guard let itemModel = self.component?.getItems()?.first?.model as? Item14210Model else {
            return
        }
 
        itemView.fillModel(itemModel)
    }

    func rlcolumnCount() -> Int {
        return 2
    }
    
    func estimatedLayout(_ itemWidth: CGFloat) {
        guard let model = self.itemModel else {
            return
        }
        
        let itemLayout = model.layout
        
        guard let item = itemModel?.domainObject as? IItem else {
            return
        }
        
        // 实时计算分组Index
        Component14210.updatePublishTimeSubIndexInGroup(item)
        
        if model.isGame { // 游戏坑位在iOS平台不展示
            itemLayout.renderRect = .zero
            return
        }
        
        itemLayout.extendExtra = [String: Any]()
        
        //圆圈
        let circleLayout = ImageLayoutModel.init()
        let circleHeight: CGFloat = 9
        circleLayout.renderRect = CGRect.init(origin: .zero, size: CGSize.init(width: circleHeight, height: circleHeight))
        
        //时间线
        let timeLayout = TextLayoutModel.init()
        timeLayout.font = YKNFont.akrobatExtraBoldFont(ofSize: YKNFont.module_headline().pointSize)
        let timeX: CGFloat = circleLayout.renderRect.maxX + YKNGap.dim_5()
        let timeY: CGFloat = Component14210.shouldShow21dpTopPadding(item) ? 21 : 0
        let timeWidth: CGFloat = itemWidth - timeX
        
        let timeHeight: CGFloat = YKNFont.height(with: YKNFont.module_headline_weight(.medium), lineNumber: 1)
        
        timeLayout.renderRect = CGRect.init(x: timeX,
                                            y: timeY,
                                            width: timeWidth,
                                            height: timeHeight)
        itemLayout.extendExtra?["time"] = timeLayout
        
        circleLayout.renderRect = CGRect.init(x: 0, y: timeY + (timeHeight - circleHeight) / 2 , width: circleHeight, height: circleHeight)
        itemLayout.extendExtra?["circle"] = circleLayout
        
        let topbarHeight = timeLayout.renderRect.maxY + YKNGap.dim_6() // 时间线文案 + 间距
        let videoImageHeight = CGFloat(61 * YKNSize.yk_icon_size_scale()) // 封面图高度
        
        //整体预布局
        var itemHeight = videoImageHeight
        if Component14210.shouldShowPublishTimeDesc(item) {
            itemHeight = topbarHeight + videoImageHeight
        }
        
        if Component14210.shouldShowBlankTopbar(item) {
            itemHeight = topbarHeight + videoImageHeight
        }
        itemLayout.renderRect = CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight)
        
        //封面图 及其 附件（角标等）
        var videoImageX: CGFloat = timeX
        if Component14210.isResponsiveLayoutAndIsNotSplited(item) {
            let coulumCount = 2
            if model.publishTimeSubIndexInGroup % coulumCount != 0 {
                videoImageX = 0
            }
        }
        let videoImageWidth = ceil(videoImageHeight * 16.0 / 9.0)
        let videoImageSize = CGSize.init(width: videoImageWidth, height: videoImageHeight)
        
        let coverLayout = ImageLayoutModel.init()
        coverLayout.boundingSize = videoImageSize
        coverLayout.renderRect = CGRect.init(x: videoImageX, y: 0, width: videoImageSize.width, height: videoImageSize.height)
        itemLayout.cover = coverLayout
        
        if let mark = model.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: videoImageSize)
            itemLayout.mark = layout
        }
        
        if let summary = model.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize:videoImageSize)
            itemLayout.summary = layout
        }
        
        let textMinX: CGFloat = coverLayout.renderRect.maxX + YKNGap.dim_6()
        var lastTextMaxY: CGFloat = 0
        
        //主标题
        if let title = model.title, !title.isEmpty {
            let titleLayout = TextLayoutModel.init()
            let titleX = textMinX
            let titleY = lastTextMaxY
            let titleWidth = itemWidth - titleX
            let titleHeight = YKNFont.height(with: YKNFont.module_headline_weight(.medium), lineNumber: 1)
            
            titleLayout.renderRect = CGRect.init(x: titleX,
                                                 y: titleY,
                                                 width: titleWidth,
                                                 height: titleHeight)
            itemLayout.title = titleLayout
            
            lastTextMaxY = titleLayout.renderRect.maxY
        } else {
            itemLayout.title = nil
        }
        
        //副标题
        if let subtitle = model.subtitle, !subtitle.isEmpty {
            let subtitleLayout = TextLayoutModel.init()
            let subtitleX = textMinX
            let subtitleY = lastTextMaxY + (lastTextMaxY > 0 ? YKNGap.dim_2() : 0)
            let subtitleWidth = itemWidth - subtitleX
            let subtitleHeight = YKNFont.height(with: YKNFont.secondry_auxiliary_text(), lineNumber: 1)
            
            subtitleLayout.renderRect = CGRect.init(x: subtitleX,
                                                    y: subtitleY,
                                                    width: subtitleWidth,
                                                    height: subtitleHeight)
            itemLayout.subtitle = subtitleLayout
            
            lastTextMaxY = subtitleLayout.renderRect.maxY
        } else {
            itemLayout.subtitle = nil
        }
        
        //推荐理由
        if let reasons = model.reasons {
            let reasonsStartX = textMinX
            let reasonsStartY = lastTextMaxY + (lastTextMaxY > 0 ? YKNGap.dim_2() : 0)
            let reasonsLayout = Service.reasons.estimatedLayout(reasons, position: CGPoint.init(x: reasonsStartX, y: reasonsStartY) , boundingSize: CGSize.init(width: itemWidth - reasonsStartX, height: 30))
            itemLayout.reasons = reasonsLayout
        }
    }
    
    
    /// 实时计算分组序号，相同发布时间为一组，序号为组内顺序，从第0个开始计
    /// - Parameter item: 给定的坑位domainObject
    static func updatePublishTimeSubIndexInGroup(_ item: IItem) {
        guard let model = item.itemModel as? Item14210Model else {
            return
        }
        
        if let allComponentsInCard = item.getCard()?.getComponents() as? [IComponent]  {
            if let currentComponentIndex = item.getComponent()?.index {
                if currentComponentIndex == 0 {
                    if model.isGame {
                        // 分组已变更，但游戏类不予展示，序号特殊标记
                        model.publishTimeSubIndexInGroup = -1
                    } else {
                        model.publishTimeSubIndexInGroup = 0
                    }
                    
                } else {
                    let prevComponentIndex = currentComponentIndex - 1
                    let prevComponent = allComponentsInCard[prevComponentIndex]
                    
                    if let prevItem = prevComponent.getItems()?.first,
                       let prevItemModel = prevItem.model as? Item14210Model {
                        if model.isGame {
                            if model.publishTimeDesc == prevItemModel.publishTimeDesc {
                                // 游戏类不予展示，序号需要与上一项保持一致。
                                model.publishTimeSubIndexInGroup = prevItemModel.publishTimeSubIndexInGroup
                            } else {
                                // 分组已变更，但游戏类不予展示，序号特殊标记
                                model.publishTimeSubIndexInGroup = -1
                            }
                            return
                        }
                        
                        if model.publishTimeDesc == prevItemModel.publishTimeDesc {
                            if prevItemModel.publishTimeSubIndexInGroup == -1 {
                                // 上一坑位及之前坑位均为不予展示坑位，本坑位作为首个坑位展示
                                model.publishTimeSubIndexInGroup = 0
                            } else {
                                // 与上一坑位内容重复，不需要显示
                                model.publishTimeSubIndexInGroup = prevItemModel.publishTimeSubIndexInGroup + 1
                            }
                        } else {
                            model.publishTimeSubIndexInGroup = 0
                        }
                    }
                }
            }
        }
    }
    
    /// 是否需要展示发布时间
    /// - Parameter item: 给定的坑位domainObject
    /// - Returns: 是否需要展示发布时间
    static func shouldShowPublishTimeDesc(_ item: IItem) -> Bool {
        guard let model = item.itemModel as? Item14210Model else {
            return false
        }
        
        if model.publishTimeSubIndexInGroup == 0 {
            return true
        } else {
            return false
        }
    }
    
    static func shouldShowBlankTopbar(_ item: IItem) -> Bool {
        guard isResponsiveLayoutAndIsNotSplited(item) else {
            return false
        }
        
        guard let model = item.itemModel as? Item14210Model else {
            return false
        }
        
        let coulumCount = 2
        return model.publishTimeSubIndexInGroup > 0 && model.publishTimeSubIndexInGroup < coulumCount
    }
    
    static func shouldShow21dpTopPadding(_ item: IItem) -> Bool {
        guard let model = item.itemModel as? Item14210Model else {
            return false
        }
        
        if let currentComponentIndex = item.getComponent()?.index {
            let columnCount = isResponsiveLayoutAndIsNotSplited(item) ? 2 : 1
            if model.publishTimeSubIndexInGroup >= 0 && model.publishTimeSubIndexInGroup < columnCount {
                let prevGameCount = prevGameItemContinuousCount(item)
                if currentComponentIndex - prevGameCount == model.publishTimeSubIndexInGroup {
                    return true
                }
            }
        }
        
        return false
    }
    
    static func isResponsiveLayoutAndIsNotSplited(_ item: IItem? = nil) -> Bool {
        guard ykrl_isResponsiveLayout() else {
            return false
        }
        if let itemModel = item?.itemModel as? Item14210Model {
            return !itemModel.isSplitedOrFloating
        }
        
        // 警告: 处于子线程及转屏中途，这个值不可信，会出现误判。
        let isSplitedOrFloating = YKRLLayoutManager.sharedInstance()?.layoutScreenType.contains(.splitedOrFloating) ?? false
        return !isSplitedOrFloating
    }
    
    func isResponsiveLayoutAndIsNotSplited() -> Bool {
        guard let item = self.component?.getItems()?.first else {
            return false
        }
        
        return Component14210.isResponsiveLayoutAndIsNotSplited(item)
    }
    
    static func prevGameItemContinuousCount(_ item: IItem) -> Int {
        if let allComponentsInCard = item.getCard()?.getComponents() as? [IComponent]  {
            if let currentComponentIndex = item.getComponent()?.index, currentComponentIndex > 0 {
                let result = allComponentsInCard.prefix(currentComponentIndex).reversed().prefix { aComponent in
                    if let aItemModel = aComponent.getItems()?.first?.itemModel as? Item14210Model {
                        return aItemModel.isGame
                    } else {
                        return false
                    }
                }.count
                return result
            }
        }
        
        return 0
    }

    // MARK: - 响应式特殊适配
    
    public override func listeningEventObservers() -> [EventObserver]? {
        return [
            EventObserver("OneArch.customLayout.updateLayoutCacheBefore"),
        ]
    }

    public override func onEvent(_ event: OEvent) {
        if event.name == "OneArch.customLayout.updateLayoutCacheBefore" {
            self.receiveUpdateLayoutCacheBeforeEvent(event)
        }
    }
    
    func receiveUpdateLayoutCacheBeforeEvent(_ event: OEvent) {
        guard ykrl_isResponsiveLayout() else {
            return
        }
        
        // 新分组，瀑布流布局另起一行
        if let itemModel = self.itemModel, let item = itemModel.domainObject as? IItem {
            Component14210.updatePublishTimeSubIndexInGroup(item)
            if itemModel.publishTimeSubIndexInGroup == 0 {
                self.component?.setData(NSNumber(value: 1), forKey: "yksc.data.comp.layout.forceNewLine")
            } else {
                self.component?.setData(NSNumber(value: 0), forKey: "yksc.data.comp.layout.forceNewLine")
            }
        }
    }
}
