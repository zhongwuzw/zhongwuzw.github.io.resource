//
//  Item14210.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/7/19.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku

class Item14210: NSObject, ItemDelegate {
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView()
    }
    
    func reuseView(itemView: UIView) {
        
    }
    
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14210Model.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func itemDidInit() {
        let itemState = self.item?.homeItemModel?.state ?? 0
        self.item?.homeItemModel?.extraExtend["state"] = itemState
        
        let hasPlayback = self.item?.homeItemModel?.hasPlayback ?? 0
        self.item?.homeItemModel?.extraExtend["hasPlayback"] = hasPlayback
    }
    
    required override init() {
        
    }

}

