//
//  Item14210Model.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/7/20.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku
import YKResponsiveLayout

class Item14210Model: HomeItemModel {
    
    // 发布时间（后端下发）
    var publishTimeDesc: String = ""
    
    // 是否游戏
    var isGame: Bool = false
    
    // 发布时间分组内部索引（客户端动态计算，eg. 0代表同组第一个，1代表同组第二个，如此类推）
    var publishTimeSubIndexInGroup: Int = 0
    
    // 状态字段，判断是否分屏，每次转屏后更新
    var isSplitedOrFloating: Bool = false
    
    public required init() {
        super.init()
        if (ykrl_isResponsiveLayout()) {
            NotificationCenter.default.addObserver(self, selector: #selector(handleResponseLayoutDidChange), name: Notification.Name(rawValue: "YKRLLayoutStatusDidChangeNotification"), object: nil)
        }
    }
    
    /// 响应式转屏
    @objc func handleResponseLayoutDidChange() {
        isSplitedOrFloating = YKRLLayoutManager.sharedInstance()?.layoutScreenType.contains(.splitedOrFloating) ?? false
    }
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String: Any] else {
            return
        }
        
        if let publishTimeDesc = dataInfo["publishTimeDesc"] as? String {
            self.publishTimeDesc = publishTimeDesc
        }
        
        if let reserve = self.reserveModel {
            if let type = reserve.reservationType?.uppercased(), type == "GAME" {
                self.isGame = true
                self.extraExtend["isGame"] = true
            }
        }
        
        isSplitedOrFloating = YKRLLayoutManager.sharedInstance()?.layoutScreenType.contains(.splitedOrFloating) ?? false
    }
    
}
