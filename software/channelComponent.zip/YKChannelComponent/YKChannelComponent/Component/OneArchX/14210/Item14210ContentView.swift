//
//  Item14210ContentView.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/7/19.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YoukuResource
import YKChannelPage
import YKUIComponent
import OneArch
import OneArchSupport4Youku
import OneArchSupport

class Item14210ContentView: UIView {
    
    //MARK: - Property
    lazy var circleIconView: UIView = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 9, weight: .heavy)
        label.text = "○"
        label.textColor = .ykn_primaryInfo
        return label
    }()
    
    lazy var timeLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .left
        label.textColor = .ykn_primaryInfo
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        return label
    }()
        
    lazy var contentView: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var checkboxLabel: UILabel = {
        let label = UILabel()
        label.font = YKNIconFont.sharedInstance().font(withSize: 20)
        label.textAlignment = .left
        label.textColor = .ykn_cr_2
        return label
    }()
    
    lazy var posterImageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFill
        imageView.layer.cornerRadius = YKNCorner.radius_medium()
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = YKNFont.module_headline_weight(.medium)
        label.textAlignment = .left
        label.textColor = .ykn_primaryInfo
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        return label
    }()
    
    lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .ykn_tertiaryInfo
        label.font = YKNFont.secondry_auxiliary_text()
        label.textAlignment = .left
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var livingImageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFill
        imageView.layer.masksToBounds = true
        return imageView
    }()
    
    lazy var livingLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.ykn_cw_1
        label.font = YKNFont.secondry_auxiliary_text_weight(.semibold)
        label.textAlignment = .left
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var checkButton: UIButton = {
        let btn = UIButton()
        btn.addTarget(self, action: #selector(didClickCheckButton), for: .touchUpInside)
        return btn
    }()
    
    weak var item: IItem?
    
    //MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        createSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        createSubviews()
    }
    
    //MARK: -
    func createSubviews() {
        addSubview(circleIconView)
        addSubview(timeLabel)
        addSubview(checkboxLabel)
        addSubview(contentView)
        addSubview(checkButton)
        contentView.addSubview(posterImageView)
        posterImageView.addSubview(livingLabel)
        posterImageView.addSubview(livingImageView)
        
        contentView.addSubview(titleLabel)
        contentView.addSubview(subtitleLabel)
    }
    
    func fillModel(_ model: Item14210Model) {
        self.item = model.domainObject as? IItem
        guard let item = item else {
            return
        }
        
        let layoutModel = model.layout
        
        // 显示or隐藏上线时间信息
        let shouldShowPublishTimeDesc = Component14210.shouldShowPublishTimeDesc(item)
        let shouldShowBlankTopbar = Component14210.shouldShowBlankTopbar(item)
        if shouldShowPublishTimeDesc || shouldShowBlankTopbar {
            circleIconView.frame = (layoutModel.extendExtra?["circle"] as? ImageLayoutModel)?.renderRect ?? .zero
            
            if let layout = layoutModel.extendExtra?["time"] as? TextLayoutModel {
                timeLabel.frame = layout.renderRect
                timeLabel.font = layout.font
            }
            
            if shouldShowBlankTopbar {
                circleIconView.frame = .zero
                timeLabel.text = ""
            } else {
                timeLabel.text = model.publishTimeDesc
            }
        } else {
            circleIconView.frame = .zero
            timeLabel.frame = .zero
        }

        // 主内容容器
        var topbarHeight: CGFloat = 0
        if !timeLabel.frame.equalTo(.zero) {
            topbarHeight = timeLabel.frame.maxY + YKNGap.dim_6()
        }
        
        let rectWithoutTopbar = CGRect.init(x: 0, y: topbarHeight, width: bounds.width, height: bounds.height - topbarHeight)
        contentView.frame = rectWithoutTopbar
        checkButton.frame = rectWithoutTopbar
        
        if ZhuijuEditingUtil.isEditing(item) {
            let checkboxHeight: CGFloat = 20
            let checkboxY = contentView.frame.minY + (contentView.frame.height - checkboxHeight) / 2
            checkboxLabel.frame = CGRect.init(x: 0, y: checkboxY, width: checkboxHeight, height: checkboxHeight)
            
            var offset: CGFloat = checkboxLabel.frame.maxX + YKNGap.dim_6()
            if let coverFrame = layoutModel.cover?.renderRect {
                offset -= coverFrame.minX
            }
            contentView.frame = contentView.frame.offsetBy(dx: offset, dy: 0)
            
            let isCheck = item.data(forKey: "yksc.data.item.npz.ischeck") as? Bool ?? false
            refreshUIForEdit(isCheck)
            
            checkButton.isHidden = false
        } else {
            checkButton.isHidden = true
            checkboxLabel.isHidden = true
        }
        
        // 封面图
        posterImageView.frame = layoutModel.cover?.renderRect ?? CGRect.zero
        posterImageView.ykn_setImage(withURLString: model.img,
                                     module: "nodepage",
                                     imageSize: .zero,
                                     parameters: ["fade":true],
                                     completed: nil)
        
        // 主标题
        titleLabel.frame = layoutModel.title?.renderRect ?? CGRect.zero
        titleLabel.text = model.title
        if model.isGame {
            titleLabel.textColor = .red
        } else {
            titleLabel.textColor = .ykn_primaryInfo
        }
        
        // 副标题
        subtitleLabel.frame = layoutModel.subtitle?.renderRect ?? CGRect.zero
        subtitleLabel.text = model.subtitle
        
        // 角标
        Service.mark.attach(model.mark, toView: posterImageView, layout: layoutModel.mark)
        
        // Reasons
        Service.reasons.attach(model.reasons, toView: contentView, layouts: layoutModel.reasons)
        
        
        if let lbIcon = model.extraExtend["lbIcon"] as? String,
           let lbText = model.extraExtend["lbText"] as? String {
            
            Service.summary.detach(fromView: posterImageView)
            
            livingLabel.isHidden = false
            livingImageView.isHidden = false
            
            
            let imgWidth = CGFloat(16.0)
            let imgHeight = CGFloat(12.0)
            let imgX = YKNGap.dim_5()
            let imgY = posterImageView.frame.height - imgHeight - YKNGap.dim_5()
            
            livingImageView.frame = CGRect.init(x: imgX, y: imgY, width: imgWidth, height: imgHeight)
            livingImageView.ykn_setImage(withURLString: lbIcon,
                                         module: "nodepage",
                                         imageSize: .zero,
                                         parameters: ["fade":true],
                                         completed: nil)
            
            let textHeight = YKNFont.secondry_auxiliary_text_weight(.semibold).lineHeight
            let textX = imgX + imgWidth + YKNGap.dim_4()
            let textY = imgY + (imgHeight - textHeight) / 2
            let textWidth = posterImageView.frame.width - textX - YKNGap.dim_5()
            livingLabel.frame = CGRect.init(x: textX, y: textY, width: textWidth, height: textHeight)
            livingLabel.text = lbText
            
            Service.viewInnerGradient.attach(.bottom, toView: posterImageView)
        } else {
            Service.viewInnerGradient.detach(.bottom, fromView: posterImageView)
            
            // 腰封
            Service.summary.attach(model.summary, toView: posterImageView, layout: layoutModel.summary)
            
            livingLabel.isHidden = true
            livingImageView.isHidden = true
        }
        
        // 跳转 or 弹Toast
        let state = model.extraExtend["state"] as? Int ?? 0
        let hasPlayback = model.extraExtend["hasPlayback"] as? Int ?? 0
        let tabType = ZhuijuUtil.getTabType(for: item)
        let itemType = ZhuijuUtil.getItemType(for: item)
        let toastMessage = ZhuijuUtil.getToastMessage(for: tabType, itemType: itemType, state: state)
        let jumpEnabled = ZhuijuUtil.jumpEnabled(for: tabType, itemType: itemType, state: state, hasPlayback: hasPlayback)
        
        if jumpEnabled {
            Service.action.bind(model.action, self)
        } else {
            Service.statistics.bind(model.action?.report, self, .Defalut)
            self.whenTapped {
                MessageBox.sharedInstance()?.showMessage(toastMessage)
            }
        }
    }
    
    func refreshUIForEdit(_ isCheck: Bool) {
        checkboxLabel.text = ZhuijuEditingUtil.checkboxIconText(isCheck)
        checkboxLabel.textColor = ZhuijuEditingUtil.checkboxIconTextColor(isCheck)
        checkboxLabel.isHidden = false
    }
    
    @objc func didClickCheckButton() {
        guard let item = item else {
            return
        }
        
        var isCheck = item.data(forKey: "yksc.data.item.npz.ischeck") as? Bool ?? false
        isCheck = !isCheck
        item.setData(isCheck, forKey: "yksc.data.item.npz.ischeck")
        refreshUIForEdit(isCheck)
        item.getPage()?.sendEventMessage("yksc.event.page.npz.checkItem.v2", params: ["item": item])
    }
}


