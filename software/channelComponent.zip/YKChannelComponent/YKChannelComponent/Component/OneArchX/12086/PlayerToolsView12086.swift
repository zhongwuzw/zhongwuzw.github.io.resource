//
//  PlayerToolsView12086.swift
//  YKChannelComponent
//
//  Created by wustlj on 2022/8/4.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class PlayerToolsView12086: PlayerToolsViewV2 {
    
    override func createSubviews() {
        super.createSubviews()
    }
        
    override public func fillModel(_ model: BaseItemModel?) {
        super.fillModel(model)
        
    }
    
    override func customLayout() {
        super.customLayout()
        
    }

}
