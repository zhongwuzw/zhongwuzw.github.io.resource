//
//  PlayerTools12086EventHandler.swift
//  YKChannelComponent
//
//  Created by wustlj on 2022/8/4.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchBridge
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

protocol PlayerToolsEvent12086HandlerDelegate: NSObjectProtocol {
    func didPlayerStart(_ playerModel: PlayerModel?)
    func didClickStopPlayer(_ playerModel: PlayerModel?)
    func didFinishPositiveVideoInPlayer(_ playerModel: PlayerModel?)
    func didPlayerTimeChanged(_ playerModel: PlayerModel?, time: NSInteger)
}


@objcMembers
public class PlayerTools12086EventHandler: ItemEventHandler,PlayerToolsViewableV2,PlayerStatusCallback {

    weak var  itemModel:BaseItemModel? {
        get {
            return self.item?.itemModel
        }
    }

    weak var delegate: PlayerToolsEvent12086HandlerDelegate?
    weak var shakedelegate: Item12093ShakeDelegate?
    
    var isSlientMode:Bool = true

    //是否第一次播放，针对循环播放。 主动stop后重置为true
    var isFirstPlay:Bool = true

    //MARK: Property
    lazy var playerToolsView: PlayerToolsView12086 = {
        let view = PlayerToolsView12086()
        view.clipsToBounds = true
        view.delegate = self
        return view
    }()
    
    required init() {
        super.init()
    }

    deinit {
    }
    

    override public func listeningEventObservers() -> [EventObserver]? {
        let observer1 = EventObserver(EventName.itemReuseItemView)
        return [observer1]
    }
        
    public override func onEvent(_ event: OEvent) {
        if event.name == EventName.itemReuseItemView {
            self.receiveReuseEvent(event)
        }
    }
    
    func receiveReuseEvent(_ event: OEvent) {
        self.itemModel?.playerModel?.playerDelegate = self
    }
    
    func updateSlientStatusWithPlayerStart(_ player: PlayerView) {
        if let commonSlientMode = PlayerControlManagerV2.shareInstance().commonSlientMode(self.item) {
            player.isSlientMode = commonSlientMode
        }
        self.playerToolsView.isSlientMode = player.isSlientMode
        self.playerToolsView.bindSlientStatistics()
        self.playerToolsView.slientIconUpdate()
    }
    
    
    //MARK:YKPlayerStatusDelegate
    public func didStartPlayVideoInPlayer(_ player: PlayerView) {
        guard let itemModel = itemModel else {
            return
        }
        //1.isUserInteractionEnabled
        let embedPlayerView = player.embedPlayerView
        embedPlayerView?.isUserInteractionEnabled = true

        //2.add view
        if let playBackFrame = player.model?.playBackFrame {
            let toolsFrame = CGRect.init(x: 0, y: 0, width: playBackFrame.width, height: playBackFrame.height)
            self.playerToolsView.frame = toolsFrame
        }
        self.playerToolsView.tag = 2021042305
        
        if let oldView = embedPlayerView?.viewWithTag(2021042305) {
            oldView.removeFromSuperview()
        }
        embedPlayerView?.addSubview(self.playerToolsView)
        if let adIsMutePlay = itemModel.extraExtend["adIsMutePlay"] as? Bool {
            player.isSlientMode = adIsMutePlay
            self.playerToolsView.isSlientMode = adIsMutePlay
        }
        if let commonnSlientMode = PlayerControlManagerV2.shareInstance().commonSlientMode(self.item) {
            self.playerToolsView.isSlientMode = commonnSlientMode
        }
        self.playerToolsView.fillModel(itemModel)
        enableShake()
        
        //3.slient
        self.updateSlientStatusWithPlayerStart(player)


        self.playerToolsView.hiddenSummaryInfo(true, model: itemModel)
        
        self.delegate?.didPlayerStart(player.model)
    }
    
    public func didClickStopPlayer(_ embedPlayer: PlayerView) {
        self.isFirstPlay = true
        self.playerToolsView.removeFromSuperview()
        
        self.delegate?.didClickStopPlayer(embedPlayer.model)
    }
    
    public func didFinishPositiveVideoInPlayer(_ player: PlayerView) {
        self.delegate?.didFinishPositiveVideoInPlayer(player.model)
    }
    
    public func playTimeDidChange(_ player: PlayerView) {
        self.delegate?.didPlayerTimeChanged(player.model, time: NSInteger(player.playingTime))
    }

    
    func slientModeUpdate(isSlientMode: Bool) {
        self.isSlientMode = isSlientMode
        PlayerControlManagerV2.shareInstance().updateCommonSlientMode(self.item, newMode: isSlientMode)
    }
    
    func enableShake() {
    }
    
    func disableShake() {
    }
    
    

}

