//
//  Item12086Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/2/11.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YoukuAnalytics
import NovelAdSDK

class Item12086Delegate:NSObject, ItemDelegate, ItemLifeCycleEventHandlerDelegate, PlayerToolsEvent12086HandlerDelegate, Item12093ShakeDelegate, OADFeedbackProtocol {
    
    var playFinish : Bool = false
    
    weak var containerView: Item12086ContentView?

    // 图片摇一摇
    var imgShakeView: Item12093ShakeView?
    
    var itemWrapper: ItemWrapper?
    let nadApi = NadAPI()
    var adModel: OADModel? = nil
    var isExposed = false
    var isVisibled = false
    var isActivated = true
    
    lazy var playerToolsEventHandler:PlayerTools12086EventHandler = {
        let handler =  PlayerTools12086EventHandler.init()
        handler.delegate = self
        handler.shakedelegate = self
        return handler
    }()
    
    static func create() -> ItemDelegate {
        return Item12086Delegate.init()
    }
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    func columnCount() -> CGFloat {
        if let compTag = self.item?.itemModel?.type, compTag == "12086" {
            return 1.0
        }
        return 2.0
    }
    
    func createNovelAdFeedbackModel(_ itemModel: BaseItemModel, nadApi: NadAPI, unifyAdData: [String: Any]) -> FeedbackModel {
        let feedbackModel: FeedbackModel = FeedbackModel()
        
        let defalutTitle = "就是不感兴趣"
        feedbackModel.reasons = [FeedbackItemModel.init(["title":defalutTitle, "reason":"I"])]
        feedbackModel.report = itemModel.action?.report
        feedbackModel.scene = itemModel.scene
        
        self.adModel = nadApi.getAd(unifyAdData)
        
        itemModel.feedbackModel = feedbackModel
        
        return feedbackModel
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.receiveEstimatedLayout(Double(itemWidth))
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        let handler = ItemLifeCycleEventHandler.init()
        handler.delegate = self
        return [PlayerScrollEndItemEventHandler(),
                self.playerToolsEventHandler,
                ItemPlayerProgressEventHandler(),
                handler]
    }
    
    func itemDidInit() {
        guard let itemModel = self.item?.itemModel else {
            return
        }
        if let unifyAd = itemModel.extraExtend["unifyAd"] as? [String : Any] {
            createNovelAdFeedbackModel(itemModel, nadApi: nadApi, unifyAdData: unifyAd)
            
            if let adModel = adModel {
                nadApi.adFill(adModel)
            }
        }
        
        //uploader custom
        var uploader = [String: Any]()
        uploader["name"] = self.adModel?.mainTitle ?? "广告"
        uploader["desc"] = self.adModel?.subTitle ?? "了解详情"
        uploader["icon"] = self.adModel?.logo ?? ""
        let uploadModel = UploaderModel.init(uploader, model: itemModel)
        if let _ = self.adModel?.logo {
            uploadModel.isShowHeadIcon = true
        } else {
            uploadModel.isShowHeadIcon = false
        }
        uploadModel.isCanAddFavor = false
        itemModel.uploader = uploadModel
        
        if self.adModel?.resType == "video" {
            itemModel.playerModel?.videoURL = self.adModel?.resUrl;
            itemModel.playerModel?.repeatPlay = true
        }
        
        //summary
        if let duration = self.adModel?.duration, duration > 0 {
            let m = Int(duration / 60)
            let s = duration % 60
            let ss = NSString.init(format: "%02d:%02d", m, s)
            itemModel.summary = SummaryModel.newModel(["summary": "\(ss)"])
        }
        
        itemModel.extend["shakeUrl"] = self.adModel?.actionIcon
    }
    
    func receiveEstimatedLayout(_ itemWidth: Double) {

        let itemLayout = item?.itemModel?.layout
        
        var itemHeight: Double = calcItemHeight(itemWidth)
        
        itemLayout?.renderRect = CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight)        
    }
    
    func enterDisplayArea(itemView: UIView?) {
        print("[12086] enterDisplayArea")
        if let adModel = adModel {
            
            if let itemView = itemView {
                adModel.handleCSJEvent(itemView, withClickableViews: [itemView]);
            }
            
            if !isExposed {
                isExposed = true
                self.nadApi.adExposure(adModel)
            }
        }
        
        if (!isCSJ()) {
            self.playerToolsEventHandler.enableShake()
            imgShakeView?.enableShake()
        }
        
        isVisibled = true;
    }
    
    func exitDisplayArea(itemView: UIView?) {
        print("[12086] exitDisplayArea")
        self.playerToolsEventHandler.disableShake()
        imgShakeView?.disableShake()
        
        isVisibled = false;
        
        adModel?.setAdEtpInterruptShow(true)
        
        if let itemView = itemView {
            adModel?.unregistClient(itemView, withClickableViews: [itemView])
        }
    }
    
    func didActivate() {
        isActivated = true
        
        if (isVisibled && !isCSJ()) {
            self.playerToolsEventHandler.enableShake()
            imgShakeView?.enableShake()
        }
    }
    
    func isCSJ() -> Bool {
        return adModel?.hasCsjAdm() ?? false
    }
    
    func didDeactivate() {
        isActivated = false
        
        self.playerToolsEventHandler.disableShake()
        imgShakeView?.disableShake()
        
        if isExposed {
            adModel?.setAdEtpInterruptShow(true)
        }
    }
    
    func appWillResignActive() {
        adModel?.setAdEtpInterruptShow(true)
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
//        let itemView = Item12086ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
//        return itemView
        
        if let compWithoutBorder = self.item?.getComponent()?.compModel?.extraExtend["compWithoutBorder"] as? Bool, compWithoutBorder {
            let itemView = Item12086ContentViewWithoutBorder(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            return itemView
        } else {
            let itemView = Item12086ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            return itemView
        }
    }

    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item12086ContentView else {
            return
        }
        guard let itemModel = self.item?.itemModel as? HomeItemModel else {
            return
        }
        guard let itemLayout = self.item?.itemModel?.layout else {
            return
        }

        self.containerView = itemView
        
        itemView.feedbackDelegate = self
        
        itemView.fillData(model: self.adModel, itemModel: itemModel)
                
        //埋点
        Service.statistics.bind(itemModel.action?.report, itemView, .Defalut)
//        NSLog("[feed ad] 12086 report spm:\(itemModel.action?.report?.spm) scm:\(itemModel.action?.report?.scm)")
        //跳转
        weak var weakself = self
        itemView.whenTapped {
            if let weakself = weakself {
                weakself.click(false)
            }
        }

        //负反馈
//        Service.feedback.attach(itemModel.feedbackModel, toView: itemView, morePos: .BottomRightBorder, isSupportUndo: false) {
//            if let weakself = weakself,
//               let component = weakself.item?.getComponent()
//               {
//                deleteComponentWithAnimation(component)
//                if let ad = weakself.adModel {
//                    weakself.nadApi.adClose(ad)
//                }
//            }
//        }
//        
//        if let feedbackBtn = itemView.viewWithTag(999998) {
//            itemView.superview?.accessibilityElements = [itemView, feedbackBtn]
//        }
            
        //player
        if let playerModel = itemModel.playerModel {
            Service.player.attach(playerModel, toView: itemView.contentView, displayFrame: itemView.imageViewFrame())

            playerModel.repeatPlay = false
            playerModel.isHideWaterMark = true
            
            playerModel.slientModeInPage = false
            //搜索特殊适配： 音量设置需要走页面级控制
            if let vc = item?.getPage()?.pageContext?.getViewController()  {
                let vcClassStr = NSStringFromClass(type(of: vc))
                if vcClassStr == "YKSokuSwift.NewSearchDefaultViewController" || vcClassStr == "YKSokuSwift.NewSearchDefaultPageController" ||  vcClassStr == "YKSokuSwift.YKSKDefaultPageController" ||   vcClassStr == "YKSokuSwift.YKSKDefaultViewController" {
                    playerModel.slientModeInPage = true
                }
            }
            if let cf = self.adModel?.cf {
                if cf == 1 {
                    itemModel.extraExtend["adIsMutePlay"] = false
                } else {
                    itemModel.extraExtend["adIsMutePlay"] = true
                }
            }
            if let ad_reqid = self.adModel?.reqId as? String {
                var extraExtend = playerModel.extraExtend
                if extraExtend == nil {
                    extraExtend = [String: Any]()
                }
                var userInfo = extraExtend?["userInfo"] as? [String : Any] ?? [String : Any]()
                userInfo.merge(dict: ["ad_reqid": ad_reqid])
                extraExtend?["userInfo"] = userInfo
                playerModel.extraExtend = extraExtend
            }
            //adBizInfo
            AdPlayInfoUtil.updatePlayModelExtraWithAd(playerModel: playerModel, oadModel: self.adModel)
        }
        
//        adModel?.handleCSJEvent(itemView, withClickableViews: [itemView]);
        
        addImgShake()
    }
    
    func reuseId() -> String? {
        var reuseId = "item_" + (self.item?.model?.type ?? "12086")
        if let compWithoutBorder = self.item?.getComponent()?.compModel?.extraExtend["compWithoutBorder"] as? Bool, compWithoutBorder {
            reuseId = reuseId + "_withoutBorder"
        }
        return reuseId
    }

    func calcItemHeight(_ itemWidth: Double) -> Double {
        guard let itemModel = self.item?.itemModel else {
            return 0.0
        }
        
        var h = ceil(itemWidth * RATIO_9_16)
        
        let titleString = self.adModel?.mainTitle ?? "广告"
        let titleLayout = TextLayoutModel.init()
        titleLayout.font = YKNFont.posteritem_maintitle_weight(YKNFontWeight.medium)
        
        var titleWidth = itemWidth - Double(2 * YKNGap.dim_6())
        if let _ = itemModel.uploader?.isShowHeadIcon {
            titleWidth -= Double(36 + YKNGap.dim_5())
        }
        titleLayout.boundingSize = calcStringSize(titleString, font: titleLayout.font, size: CGSize.init(width: 10000, height: 60))
        itemModel.layout.title = titleLayout

        if let s = itemModel.summary {
            itemModel.layout.summary = Service.summary.estimatedLayout(s, toViewSize: CGSize.init(width: itemWidth, height: h))
        }

        if let tw = titleLayout.boundingSize?.width, Double(tw) > titleWidth {
            h += Double(YKNGap.dim_5()) + 40.0 + 5.0 + 17.0 + Double(YKNGap.dim_6())
        } else {
            h += Double(YKNGap.dim_5()) + 20.0 + 5.0 + 17.0 + Double(YKNGap.dim_6())
        }
        if let compTag = self.item?.itemModel?.type, compTag != "12086" {
            return ceil(itemWidth * RATIO_9_16) + 85.0
        }
        return h
    }
        
    func isPageInPreload() -> Bool {
        guard let pageModel = self.item?.getPage()?.pageModel else {
            return false
        }
        if pageModel.dataState == .cache || pageModel.dataState == .default {
            return true
        }
        return false
    }

    //MARK: PlayerToolsEvent12086HandlerDelegate
    func didPlayerStart(_ playerModel: PlayerModel?) {
        print("[12086] play start")
        
        playFinish = false
        
        if let adModel = adModel {
            adModel.adPlayStart()
            adModel.adExposureEtp(OAD_ETP_PLAY_START, time: -1);
        }
    }
    
    func didFinishPositiveVideoInPlayer(_ playerModel: PlayerModel?) {
        print("[12086] play end")
        
        playFinish = true
        
        if let adModel = adModel {
            adModel.adPlayEnd()
            adModel.adExposureEtp(OAD_ETP_PLAY_END, time: -1);
        }
    }

    
    func didClickStopPlayer(_ playerModel: PlayerModel?) {
        print("[12086] play stop")
        
        if !playFinish, let adModel = adModel {
            adModel.adPlayEnd()
        }
    }
        
    func didPlayerTimeChanged(_ playerModel: PlayerModel?, time: NSInteger) {
//        print("[12086] play time = \(time)")
        
        playFinish = false
        
        if let adModel = adModel {
            adModel.adPlay(atTime: time)
            adModel.adExposureEtp(OAD_ETP_PLAY_EFFECT, time: time);
        }
    }
    
    //MARK: Item12093ShakeDelegate
    func shakeToLandingPage() {
        if isViewVisible(self.containerView) == false {
            print("[12086] shake not visible")
            return
        }
        
        if isCSJ() {
            print("[12086] no shake for csj")
            return
        }
        
        if isActivated == false {
            print("[12086] no shake for isActivated")
            OADUtil.recordShakeLoss(3, with: self.adModel, extra: ["hasFocus": "0"])
            return
        }
        
        if UIApplication.shared.applicationState != .active {
            print("[12086] no shake for background")
            OADUtil.recordShakeLoss(4, with: self.adModel, extra: ["hasFocus": "0"])
            return
        }
        
        OADFeedbackService.sharedInstance().detachFeedback();
        
        print("[12086] shake click")
        self.click(true)
    }
    
    func isViewVisible(_ view: UIView?) -> Bool {
        guard let page = self.item?.getPage() else {
            return false
        }
        
        guard let paddingTop = page.containerPaddingTop(page) else {
            return false
        }
        
        guard let itemView = view else {
            return false
        }
                        
        let topHeight = paddingTop
        let bottomHeight = YKTabbarHeight()
        let visibleArea : CGRect = CGRect.init(x: 0, y: topHeight, width: YKRLScreenWidth(), height: SCREEN_HEIGHT - topHeight - bottomHeight)
        let rect = itemView.convert(itemView.bounds, to: nil)

        if visibleArea.intersects(rect) {
            return true
        }

        return false
    }
    
    //MARK: click
    func click(_ isShake: Bool) {
        guard let adModel = adModel else {
            return
        }
        
        var params: [AnyHashable: Any] = [AnyHashable: Any]()
        if let extend = adModel.extend {
            extend.forEach { (key: AnyHashable, value: Any) in
                params[key] = value
            }
        }
        if isShake {
            params["shake"] = "1"
        } else {
            params.removeValue(forKey: "shake")
        }
        adModel.extend = params
        
        self.nadApi.adClickAction(adModel, extraParams: isShake ? ["shake": "1"] : nil)
    }
    
    //MARK: shake
    func addImgShake() {
        let shakeTag = 202304101
        let view = self.containerView?.viewWithTag(shakeTag)
        view?.removeFromSuperview()
        
        if let shakeUrl = self.item?.itemModel?.extend["shakeUrl"] as? String {
            if imgShakeView == nil {
                imgShakeView = Item12093ShakeView(frame: CGRect.init(x: 0, y: 0, width: 200, height: 100))
            }
            if let shakeView = imgShakeView, let containerView = self.containerView {
                shakeView.frame = CGRectMake(0, 0, containerView.videoImageView.width, containerView.videoImageView.height)
                shakeView.delegate = self
                shakeView.load(shakeUrl)
                shakeView.tag = shakeTag
                containerView.addSubview(shakeView)
            }
        }
    }
    
    // MARK: OADFeedbackProtocol
    func didAttachAdFeedback() {
        
    }
    
    func didDetachAdFeedback() {
        
    }
    
    func didSuccessAdFeedback() {
        if let component = item?.getComponent() {
            deleteComponentWithAnimation(component)
            if let ad = adModel {
                nadApi.adClose(ad)
            }
        }
    }
}

