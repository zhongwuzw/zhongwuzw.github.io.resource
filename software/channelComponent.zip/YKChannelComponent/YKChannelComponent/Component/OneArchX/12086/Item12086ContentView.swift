//
//  ItemPlugin12078ContentView.swift
//  YKChannelComponent
//
//  Created by better on 2021/4/15.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import YKSCBase
import NovelAdSDK
import YKUIComponent
import YKResponsiveLayout
import YoukuAnalytics
import YKSCService
import OneArchSupport4Youku
import OneArchSupport
import YKHome

class Item12086ContentView: AccessibilityView {

    weak var itemModel:BaseItemModel?
    weak var curModel:OADModel?
    weak var feedbackDelegate: OADFeedbackProtocol?

    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.ykn_primaryBackground
        view.layer.masksToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        addSubview(view)
        return view
    }()

    lazy var videoImageView: UIImageGIFView = {
        let view = createVideoImageView()
        view.isUserInteractionEnabled = true
        view.layer.masksToBounds = true
        contentView.addSubview(view)
        return view
    }()
    
    lazy var headIcon: UIImageGIFView = {
        let view = createVideoImageView()
        view.frame = CGRect.init(x: YKNGap.dim_6(), y: 0, width: 36, height: 36)
        view.layer.cornerRadius = 18
        view.layer.borderWidth = 0.5;
        view.layer.borderColor = UIColor.ykn_hideAbleSeparator.cgColor
        contentView.addSubview(view)
        return view
    }()
    
    lazy var titleLabel: MarginLabel = {
        let view = MarginLabel()
        view.textColor = .ykn_primaryInfo
        view.verticalAlignment = .top
        view.font = YKNFont.posteritem_maintitle_weight(YKNFontWeight.medium)
        view.numberOfLines = 2
        contentView.addSubview(view)
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        view.width = 200
        view.height = 17
        contentView.addSubview(view)
        return view
    }()
    
    lazy var playIconView: PlayerIconPreviewView = {
        let view = PlayerIconPreviewView()
//        self.videoImageView.addSubview(view)
        return view
    }()
    
    lazy var adLabel: UILabel = {
        let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 300, height: 16))
        label.textColor = UIColor.ykn_tertiaryInfo
        label.font = YKNFont.doublefeed_auxiliary_text()
        label.numberOfLines = 1
        label.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#129d9fa8")
        label.layer.masksToBounds = true
        label.layer.cornerRadius = 2
        label.textAlignment = NSTextAlignment.center
        contentView.addSubview(label)
        return label
    }()
    
    lazy var oadMarkView: OADMarkView = {
        let view = OADMarkView.init(frame: CGRectZero)
        view.setFont(YKNFont.doublefeed_auxiliary_text(), textColor: UIColor.ykn_tertiaryInfo, backgroundColor: UIColor.createColorWithHexRGB(colorStr: "#129d9fa8"), cornerRadius: 2, borderColor: nil, borderWidth: 0)
        contentView.addSubview(view)
        return view
    }()
    
    lazy var feedbackView: OADFeedbackMoreButton = {
        let view = OADFeedbackMoreButton.init(frame: CGRect.init(x: 0, y: 0, width: 30, height: 30))
        view.imageView?.tintColor = UIColor.ykn_quaternaryInfo;
        view.addTarget(self, action: #selector(showFeedback), for: .touchUpInside)
        contentView.addSubview(view)
        return view
    }()

    func fillData(model: OADModel?, itemModel: HomeItemModel) {
        guard let model = model else {
            return
        }
        self.curModel = model
        self.itemModel = itemModel
        //contentview
        self.contentView.frame = self.bounds
        
        //imageview
        videoImageView.frame = self.imageViewFrame()
        var imgUrl = ""
        if model.resType == "img" {
            imgUrl = model.resUrl ?? ""
        } else if model.resType == "video" {
            imgUrl = model.thumbnail ?? ""
        }
 
        videoImageView.ykn_setImage(withURLString: imgUrl,
                                    module: "",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)

        self.headIcon.top = videoImageView.bottom + YKNGap.dim_6()
        self.headIcon.isHidden = !(itemModel.uploader?.isShowHeadIcon ?? false)
        if !self.headIcon.isHidden, let url = itemModel.uploader?.icon {
            self.headIcon.ykn_setImage(withURLString: url,
                                        module: "",
                                        imageSize: CGSize.zero,
                                        parameters: nil,
                                        completed: nil)
            self.titleLabel.left = self.headIcon.right + YKNGap.dim_5()
        } else {
            self.titleLabel.left = YKNGap.dim_6()
        }
        self.titleLabel.top = videoImageView.bottom + YKNGap.dim_5()

        //playicon
        self.playIconView.frame = self.videoImageView.bounds
        
        let playerModel = itemModel.playerModel
        
        if let canPlay = playerModel?.canPlay, canPlay == true {
           self.playIconView.isHidden = false
        } else {
           self.playIconView.isHidden = true
        }

        //title
        self.titleLabel.text = model.mainTitle ?? "广告"

        var maxTitleWidth = Double(self.width) - Double(2 * YKNGap.dim_6())
        if let _ = itemModel.uploader?.isShowHeadIcon {
            maxTitleWidth -= Double(36 + YKNGap.dim_5())
        }
        
        guard let titleBoundingSize = itemModel.layout.title?.boundingSize else {
            return
        }
        if titleBoundingSize.width > CGFloat(maxTitleWidth) {
            self.titleLabel.numberOfLines = 2
            self.titleLabel.height = 40
        } else {
            self.titleLabel.numberOfLines = 1
            self.titleLabel.height = 20
        }
        self.titleLabel.width = CGFloat(maxTitleWidth)
        
        if model.isShowOADMark() {
            oadMarkView.isHidden = false
            adLabel.isHidden = true
            oadMarkView.fillData(withDspName: model.dspDisplayName ?? "", subName: model.subDspName ?? "", logoUrl: model.dspLogo ?? "")
            oadMarkView.setPaddingHorizontal(4, paddingVertical: 3, maxWidth: self.width)
            let adMarkSize = oadMarkView.getSize()
            oadMarkView.frame = CGRect(x: self.titleLabel.left, y: self.height - 9 - 18, width: adMarkSize.width, height: 18)
        } else {
            oadMarkView.isHidden = true
            adLabel.isHidden = false
            //ad corner
            if let vendorName = model.vendorName, vendorName.count > 0 {
                adLabel.text =  vendorName
            } else {
                adLabel.text = "广告"
            }
            let adLabelH : CGFloat = 18
            let adLabelW = adLabel.sizeThatFits(CGSize.init(width: self.width, height: adLabelH)).width + 8
            adLabel.frame = CGRect.init(x: self.titleLabel.left, y: self.height - 9 - adLabelH, width: adLabelW, height: adLabelH)
        }

        // 圆角+阴影
        if let tag = itemModel.type,
        tag == "12086" {
            update12086Border()
            
            Service.summary.attach(itemModel.summary, toView: videoImageView, layout: itemModel.layout.summary)
        } else {
            self.layer.borderWidth = 0
            self.titleLabel.font = YKNFont.posteritem_maintitle()
            self.titleLabel.top += 3.5
            self.titleLabel.left = 0
            self.titleLabel.width = Double(self.width) - Double(2 * YKNGap.dim_6())
            self.titleLabel.height = self.titleLabel.font.lineHeight * 2 + 1
            self.adLabel.left = 0
            self.oadMarkView.left = 0
            self.headIcon.isHidden = true
            self.playIconView.isHidden = true
            self.videoImageView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        }
        
        //subtitle
        self.subtitleLabel.text = itemModel.uploader?.desc
        if !oadMarkView.isHidden {
            self.subtitleLabel.centerY = self.oadMarkView.centerY
            self.subtitleLabel.left = self.oadMarkView.right + 9
        } else {
            self.subtitleLabel.centerY = self.adLabel.centerY
            self.subtitleLabel.left = self.adLabel.right + 9
        }

        //color
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: itemModel.scene?.sceneTitleColor())
        self.subtitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: itemModel.scene?.sceneSubTitleColor())
        self.contentView.backgroundColor = sceneUtil(.ykn_secondaryGroupedBackground, sceneColor: itemModel.scene?.sceneCardFooterBgColor())
        
        updateFeedbackView()
    }
    
    func imageViewFrame() -> CGRect {
        let w = self.frame.size.width
        let h = self.width * CGFloat(RATIO_9_16)
        return CGRect.init(x: 0, y: 0, width: w, height: h)
    }
    
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
    
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        if let tag = itemModel?.type, tag == "12086" {
            update12086Border()
        } else {
            self.layer.borderWidth = 0.0

        }
    }
    
    func update12086Border() {
        if isDark() {
            self.layer.borderWidth = 0.0
        } else {
            self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
            self.layer.borderWidth = 0.5
            self.layer.borderColor = sceneUtil(.ykn_separator, sceneColor: itemModel?.scene?.sceneCardFooterBgColor())?.cgColor
        }
    }
    
    // MARK: Feedback
    @objc func showFeedback() {
        guard let curModel = curModel else {
            return
        }
        if feedbackView.isHidden {
            return
        }
        weak var weakself = self
        OADFeedbackService.sharedInstance().attachFeedback(curModel, from: feedbackView) {
            
        } didDetach: {
            
        } successBlock: {
            weakself?.didSuccessAdFeedback()
        }
    }
    
    func didSuccessAdFeedback() {
        feedbackDelegate?.didSuccessAdFeedback()
    }
    
    func updateFeedbackView() {
        feedbackView.bottom = self.height - 3
        feedbackView.right = self.width
    }
    
    private var hitTestIsMisClick = false
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let hitView = super.hitTest(point, with: event)
        if hitView == feedbackView {
            guard let curModel = curModel else {
                return hitView
            }
            if hitTestIsMisClick {
                hitTestIsMisClick = false
                return self
            }
            if OADFeedbackService.sharedInstance().isMisClick(curModel) {
                hitTestIsMisClick = true
                return self
            }
        }
        return hitView
    }
}

class Item12086ContentViewWithoutBorder: Item12086ContentView {
    
    override func fillData(model: OADModel?, itemModel: HomeItemModel) {
        super.fillData(model: model, itemModel: itemModel)
        self.headIcon.frame = CGRect(x: 0, y: 0, width: 36, height: 36)
        self.headIcon.top = videoImageView.bottom + YKNGap.dim_6()
        self.contentView.backgroundColor = .clear
    }
    
    override func update12086Border() {
        self.layer.borderWidth = 0.0
    }
    
}
