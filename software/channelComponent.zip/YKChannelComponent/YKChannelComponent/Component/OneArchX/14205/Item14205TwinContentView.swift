//
//  Item14205TwinContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource

class Item14205TwinContentView: UIView {

    var viewA: Item14205ContentView?
    var viewB: Item14205ContentView?

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        let spacing = YKNGap.youku_line_spacing()
        let itemWidth = frame.width
        let itemHeight = (frame.height - spacing) / 2
        
        let firstItemView = Item14205ContentView.init(frame: CGRect(x: 0, y: 0, width:itemWidth, height: itemHeight))
        addSubview(firstItemView)
        viewA = firstItemView
        
        let secondY: CGFloat = itemHeight + spacing
        let secondItemView = Item14205ContentView.init(frame: CGRect(x: 0, y: secondY, width:itemWidth, height: itemHeight))
        addSubview(secondItemView)
        viewB = secondItemView
    }
    
    func fillModel(firstItemModel: Item14205Model, secondItemModel: Item14205Model?) {
        if let firstItemView = viewA {
            firstItemView.fillModel(firstItemModel)
        }
        
        if let secondItemView = viewB {
            if let secondItemModel = secondItemModel {
                secondItemView.isHidden = false
                secondItemView.fillModel(secondItemModel)
            } else {
                secondItemView.isHidden = true
            }
        }
    }
    
    class func viewHeight(_ width: CGFloat) -> CGFloat {
        let spacing = YKNGap.youku_line_spacing()
        let itemViewHeight = Item14205ContentView.viewHeight(width)
        return 2 * itemViewHeight + spacing
    }
}
