//
//  Item14205Model.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/27.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit

class Item14205Model: HomeItemModel {

    weak var nextItemModel: Item14205Model?
    
    var showMark: Bool = false
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        
        if let showMark = dataInfo["showMark"] as? Bool {
            self.showMark = showMark
        }
    }
}
