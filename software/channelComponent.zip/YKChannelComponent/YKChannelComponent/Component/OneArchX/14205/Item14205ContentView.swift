//
//  Item14205ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Item14205ContentView: UIView {

    //MARK: - Property
    weak var itemModel: Item14205Model?
    var sceneTitleColor: UIColor?
    var sceneThemeColor: UIColor?
    var sceneButtonSelectBgColor: UIColor?
    
    lazy var imageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .ykn_primaryFill
        imageView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        imageView.layer.masksToBounds = true
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_primaryInfo
        view.font = Item14205ContentView.titleLabelFont()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = Item14205ContentView.subtitleLabelFont()
        view.numberOfLines = 2
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var favorBtn: YKTrackShowView = {
        let view = YKTrackShowView.init(frame: CGRect.init(x: 0, y: 0, width: 60, height: 30))
        view.whenTapped {
            self.favorAction()
        }
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(imageView)
        addSubview(titleLabel)
        addSubview(subtitleLabel)
        addSubview(favorBtn)
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddCollectSuccessNotication), name: NSNotification.Name.init("kBSAddCollectSuccess"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelCollectSuccessNotication), name: NSNotification.Name.init("kBSCancelCollectSuccess"), object: nil)
    }
    
    func fillModel(_ itemModel: Item14205Model) {
        let layout = itemModel.layout
        self.itemModel = itemModel
        relayoutIfNeeded(layout)
        
        //填充图片
        var imgPath = itemModel.gifImg
        if imgPath == nil {
            imgPath = itemModel.img
        }
        imageView.ykn_setImage(withURLString: imgPath, module: "nodepage", imageSize: .zero, parameters: [String: Any](), completed: nil)
        Service.mark.attach(itemModel.showMark ? itemModel.mark : nil, toView: imageView, layout: layout.mark)
        
        //填充序号
        Service.rank.attach(itemModel.rankIndex, toView: imageView)
        
        if let trackShow = itemModel.trackShow {
            bindStatisticsService()
            favorBtn.isHidden = false
            updateFavorBtnUI(trackShow.isFavor ?? false)
        } else {
            favorBtn.isHidden = true
        }
        
        //填充标题 （第一行文案）
        titleLabel.text = itemModel.title
        subtitleLabel.text = itemModel.subtitle
        
        //绑定跳转、埋点
        Service.action.bind(itemModel.action, self)
        Service.statistics.bind(itemModel.action?.report, self, .Defalut)
    }
    
    private func relayoutIfNeeded(_ layout: OneArchSupport4Youku.LayoutModel) {
        imageView.frame = layout.cover?.renderRect ?? CGRect.zero
        titleLabel.frame = layout.title?.renderRect ?? CGRect.zero
        subtitleLabel.frame = layout.subtitle?.renderRect ?? CGRect.zero
        if let favorBtnLayout = layout.extendExtra?["favorBtn"] as? TextLayoutModel {
            favorBtn.frame = favorBtnLayout.renderRect
        } else {
            favorBtn.frame = CGRect.zero
        }
    }
    
    ///MARK: favor
    func updateFavorBtnUI(_ isFavor: Bool) {
        if let sceneTitleColor = self.sceneTitleColor, let sceneThemeColor = self.sceneThemeColor  {
            favorBtn.selectTextColor = sceneTitleColor
            favorBtn.selectBgColor = .clear
            favorBtn.selectBorderWidth = 1.0
            favorBtn.selectBorderColor = sceneTitleColor
            
            favorBtn.unselectTextColor = sceneThemeColor
            favorBtn.unselectBgColor = .clear
            favorBtn.unselectBorderWidth = 1.0
            favorBtn.unselectBorderColor = sceneThemeColor
        } else {
            favorBtn.selectTextColor = .ykn_tertiaryInfo
            favorBtn.selectBgColor = .ykn_seconarySeparator
            favorBtn.selectBorderWidth = 0.0
            favorBtn.selectBorderColor = .clear
            
            favorBtn.unselectTextColor = .ykn_brandInfo
            favorBtn.unselectBgColor = .ykn_border
            favorBtn.unselectBorderWidth = 1.0
            favorBtn.unselectBorderColor = .clear
        }
        
        favorBtn.update(isFavor)
    }
    
    func bindStatisticsService() {
        guard let trackShow = itemModel?.trackShow else {
            return
        }
        
        if let isFavor = trackShow.isFavor, isFavor == true {
            let actionModel =  self.itemModel?.extraExtend["uncollectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        } else {
            let actionModel = self.itemModel?.extraExtend["collectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        }
    }
    
    func favorAction() {
        guard let favor = itemModel?.trackShow,
              let isFavor = favor.isFavor
        else {
            return
        }
        
        var params = [String : Any]()
        params["isFavor"] = isFavor
        params["id"] = favor.favorId ?? ""
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channel.function.adaptor.zhuiju"), object: nil, userInfo: params)
    }
    
    @objc func handleAddCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: true)
    }
    
    @objc func handleCancelCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: false)
    }
    
    func handleNotication(notification: Notification, favored: Bool) {
        guard let userInfo = notification.userInfo,
              let targetId = userInfo["targetId"] as? String
        else {
            return
        }
        
        guard let favor = itemModel?.trackShow,
              let currentId = favor.favorId
        else {
            return

        }
        
        guard currentId == targetId else {
            return
        }
        
        favor.isFavor = favored
        updateFavorBtnUI(favor.isFavor ?? false)
        bindStatisticsService()
    }
    
    // MARK: 默认尺寸
    class func viewHeight(_ width: CGFloat) -> CGFloat {
        let baseHeight : CGFloat = 112.0
        if (ykrl_isResponsiveLayout()) {
            return floor(baseHeight * 1.5)
        }
        
        return floor(baseHeight * YKNSize.yk_icon_size_scale()) //取左侧图片高度
    }
    
    // MARK: 字体
    class func titleLabelFont() -> UIFont {
        let font = YKNFont.carditem_maintitle_weight(.medium)
        return font
    }
    
    class func subtitleLabelFont() -> UIFont {
        let font = YKNFont.posteritem_subhead()
        return font
    }

}
