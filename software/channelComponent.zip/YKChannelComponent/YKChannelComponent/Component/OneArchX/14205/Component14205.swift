//
//  Component14205.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout
import OneArchSupport4Youku

class Component14205: NSObject, ComponentDelegate {
    
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {
        if let items = self.component?.getItems() {
            for (i, item) in items.enumerated() {
                if i < items.count - 1 {
                    let nextItem = items[i + 1]
                    if let currentItemModel = item.itemModel as? Item14205Model,
                       let nextItemModel = nextItem.itemModel as? Item14205Model {
                        currentItemModel.nextItemModel = nextItemModel
                    }
                }
            }
        }
    }

    func layoutType() -> ComponentLayoutType {
        return .horizontalScroll
    }

    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        config.preferredCardSpacingTop = YKNGap.youku_module_margin_top()
        config.headerBottomMargin = 0.0
        config.rowSpacing = 0.0
        config.columnSpacing = YKNGap.youku_column_spacing() / 2 - 0.5
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        config.horizontalPaddingLeft = YKNGap.youku_margin_left()
        config.horizontalPaddingRight = YKNGap.youku_margin_right() - config.columnSpacing - 1
        config.backgroundLeftMarginOffset = 0
        config.backgroundRightMarginOffset = 0
        config.headerLeftMarginOffset = 0
        config.headerRightMarginOffset = 0
        config.backgroundTopMargin = 0
        return config
    }
    
    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {

    }
    
    func columnCount() -> CGFloat {
        // 实际以 Item14205.itemWidth() 为准。
        return 1
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}

