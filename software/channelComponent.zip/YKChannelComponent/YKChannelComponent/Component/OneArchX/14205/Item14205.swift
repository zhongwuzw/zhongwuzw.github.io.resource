//
//  Item14205.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKProtocolSDK
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout

class Item14205: NSObject, ItemDelegate {
    
    var screenWidthCache: CGFloat = 0
    
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {
        // 使得标签支持图片样式
        if let reasons = item?.itemModel?.reasons {
            for (index, reason) in reasons.enumerated() {
                if let img = reason.img, img.isEmpty == false {
                    item?.itemModel?.reasons?[index].imgEnabled = true
                }
            }
        }
        
        if let itemModel = item?.itemModel {
            //在看按钮埋点构造
            let followActionModel = ActionFactoryV2(itemModel, spmDExt: "_watching")
            if followActionModel != nil {
                itemModel.extraExtend["collectActionModel"] = followActionModel
            }
            
            let unfollowActionModel = ActionFactoryV2(itemModel, spmDExt: "_cancelwatching")
            if unfollowActionModel != nil {
                itemModel.extraExtend["uncollectActionModel"] = unfollowActionModel
            }
        }
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14205Model.self as? T.Type
    }
    
    func reuseId() -> String? {
        if let index = self.item?.index, index % 2 == 1 {
            return "Item14205Blank" //占位用另一复用id，避免交叉干扰
        }
        
        return "Item14205Normal"
    }
    
    func itemWidth(preferredWidth: CGFloat) -> CGFloat {
        //保存架构推荐的坑位高度加边距作为页面宽度，两边边距见Component14205
        screenWidthCache = preferredWidth + (YKNGap.youku_margin_left() + YKNGap.youku_margin_right() - 1 - (YKNGap.youku_column_spacing() / 2 - 0.5))

        //适配双坑位横滑布局影响，奇数坑位宽度为正常值，并且实际渲染上下结构两个坑位，偶数坑位宽度设置为1dp，但不能为0（0被当做默认值处理实际渲染时按组件配置划分）
        if let index = self.item?.index, index % 2 == 1 {
            return 1
        }
        
        return normalItemWidth()
    }
    
    func normalItemWidth() -> CGFloat {
        let screenWidth: CGFloat = screenWidthCache
        let marginLeft = YKNGap.youku_margin_left()
        let marginRight = YKNGap.youku_margin_right()
        let columnSpacing = YKNGap.youku_column_spacing()
        
        // 坑位展示数量
        var itemCountFactor: CGFloat = 1.5
        if (ykrl_isResponsiveLayout()) {
            itemCountFactor = 2.0
        }
        
        let width = (screenWidth - marginLeft - marginRight - columnSpacing) / itemCountFactor
        return width
    }
    
    func normalItemHeight(_ itemWidth: CGFloat) -> CGFloat {
        return Item14205ContentView.viewHeight(itemWidth)
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let itemHeight: CGFloat = Item14205TwinContentView.viewHeight(itemWidth)
        
        // 预布局计算需要使用实际普通坑位宽高计算
        let normalItemWidth = normalItemWidth()
        let normalItemHeight = normalItemHeight(normalItemWidth)
        estimatedLayout(CGSize.init(width: normalItemWidth, height: normalItemHeight))
        
        return itemHeight
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14205TwinContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14205TwinContentView else {
            return
        }
        guard let itemModel = self.item?.model as? Item14205Model else {
            return
        }
        
        if let index = self.item?.index, index % 2 == 1 {
            itemView.isHidden = true
            return
        }

        itemView.isHidden = false
        itemView.fillModel(firstItemModel: itemModel, secondItemModel: itemModel.nextItemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func estimatedLayout(_ size: CGSize) {
        guard let itemModel = self.item?.model as? HomeItemModel else {
            return
        }
        
        guard let layoutModel = self.item?.layout else {
            return
        }
        
        if layoutModel.boundingSize == size {
            return //重复计算跳过
        }
        
        layoutModel.boundingSize = size
        layoutModel.renderRect = CGRect.init(origin: .zero, size: size)
        layoutModel.extendExtra = [String: Any]()
        
        //封面图
        let cover = ImageLayoutModel()
        var sizeScale: CGFloat = 1.0
        if ykrl_isResponsiveLayout() {
            sizeScale = 1.5 //iPad 版为iPhone原始大小的 1.5倍（固定值）
        } else {
            sizeScale = YKNSize.yk_icon_size_scale()
        }
        let coverWidth = floor(84.0 * sizeScale)
        let coverHeight = floor(112.0 * sizeScale)
        cover.renderRect = CGRect.init(x: 0, y: 0, width: coverWidth, height: coverHeight)
        layoutModel.cover = cover
        
        //封面图角标
        if let mark = itemModel.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: cover.renderRect.size)
            layoutModel.mark = layout
        }
        
        //封面图腰封
        if let summary = itemModel.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize: cover.renderRect.size)
            layoutModel.summary = layout
        }
        
        let textLeft: CGFloat = coverWidth + (ykrl_isResponsiveLayout() ? 12.0 : 9.0)
        let textRight: CGFloat = size.width
        let textWidthMax: CGFloat = textRight - textLeft
        
        //主标题
        let title = TextLayoutModel()
        title.font = Item14205ContentView.titleLabelFont()
        title.lineNumber = 1
        
        let titleHeight: CGFloat = YKNFont.height(with: title.font, lineNumber: title.lineNumber)
        title.renderRect = CGRect.init(x: textLeft, y: 3, width: textWidthMax, height: titleHeight)
        layoutModel.title = title
                
        //副标题
        let subtitle = TextLayoutModel()
        let subtitleFont = Item14205ContentView.subtitleLabelFont()
        subtitle.font = subtitleFont
        subtitle.lineNumber = 2
        
        let subtitleMaxHeight: CGFloat = YKNFont.height(with: subtitle.font, lineNumber: subtitle.lineNumber)
        let subtitleFitHeight = calcStringHeight(itemModel.subtitle, font: subtitleFont, limitSize: CGSize.init(width: textWidthMax, height: subtitleMaxHeight))
        let subtitleY: CGFloat = title.renderRect.maxY + YKNGap.dim_4()
        subtitle.renderRect = CGRect.init(x: textLeft, y: subtitleY, width: textWidthMax, height: subtitleFitHeight)
        layoutModel.subtitle = subtitle
        
        //在追按钮
        let favor = TextLayoutModel()
        let favorSize = CGSize.init(width: 60, height: 30)
        let favorX = textLeft
        let favorY = coverHeight - favorSize.height
        favor.renderRect = CGRect.init(origin: CGPoint.init(x: favorX, y: favorY), size: favorSize)
        layoutModel.extendExtra?["favorBtn"] = favor
    }
}


