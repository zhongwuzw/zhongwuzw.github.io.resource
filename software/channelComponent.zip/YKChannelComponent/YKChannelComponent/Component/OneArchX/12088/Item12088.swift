//
//  Item12088.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

class ItemCaiZhuiDaKa: NSObject, ItemDelegate {

    var itemWrapper: ItemWrapper?
    weak var displayingItemView: Item12088ContentView?
    
    var preferredHeight: CGFloat = 0 //预计算高度，作为复用id一部分
    
    func getModelClass<T: NodeModel>() -> T.Type? {
        return Item12088Model.self as? T.Type
    }
    
    func itemDidInit() {

    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        estimatedLayout(itemWidth)
        return preferredHeight
    }
    
    func reuseId() -> String? {
        // subclass override
        return ""
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        // subclass override
        return UIView.init()
    }
    
    func reuseView(itemView: UIView) {
        // subclass override
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        let lifeCyclehandler = ItemLifeCycleEventHandler.init()
        lifeCyclehandler.delegate = self
        
        return [
            lifeCyclehandler,
            Item12088PlayerToolsEventHandler.init(),
            PlayerScrollEndItemEventHandler.init(),
        ]
    }
    
    func estimatedLayout(_ itemWidth: CGFloat) {
        // subclass override
    }
}

extension ItemCaiZhuiDaKa: ItemLifeCycleEventHandlerDelegate {
    
    func enterDisplayArea(itemView: UIView?) {
        
    }
    
    func exitDisplayArea(itemView: UIView?) {
        displayingItemView = nil
    }
    
    func didActivate() {
        
    }
    
    func didDeactivate() {
        
    }
    
    func appWillResignActive() {
        
    }
    
}

class Item12088: ItemCaiZhuiDaKa {
    
    override func estimatedLayout(_ itemWidth: CGFloat) {
        guard let itemModel = self.item?.model as? Item12088Model else {
            return
        }
        
        Item12088ContentView.estimatedLayout(itemModel: itemModel, boundingSize: CGSize.init(width: itemWidth, height: 0))
        
        guard let layoutModel = self.item?.layout else {
            return
        }
        
        let itemHeight = layoutModel.renderRect.height
        
        if let mark = itemModel.showRecommendModel?.mark {
            let showVideoImageSize = Item12088ContentView.showVideoImageViewFrame().size
            let layout = Service.mark.estimatedLayout(mark, toViewSize: showVideoImageSize)
            layoutModel.mark = layout
        }
        
        if let reason = itemModel.reason {
            let layout = Service.reasons.estimatedLayout([reason], boundingSize: .zero)
            layoutModel.reasons = layout
        }
        
        preferredHeight = ceil(itemHeight)
    }
    
    override func reuseId() -> String? {
        let reuseId = String(format: "item12088_%.0f", preferredHeight)
        return reuseId
    }
    
    override func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item12088ContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    override func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item12088ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? Item12088Model else {
            return
        }

        displayingItemView = itemView
        itemView.superview?.clipsToBounds = false //使得组件内容物穿越cell大小
        itemView.fillData(itemModel)
        
        // 埋点 & 跳转
        Service.action.bind(itemModel.action, itemView)
        
        // 角标
        Service.mark.attach(itemModel.showRecommendModel?.mark,
                            toView: itemView.showVideoImageView,
                            layout: itemModel.layout.mark)
    }
    
}
