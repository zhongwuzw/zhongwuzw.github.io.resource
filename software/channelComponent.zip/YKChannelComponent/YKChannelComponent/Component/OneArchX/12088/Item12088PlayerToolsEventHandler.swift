//
//  Item12088PlayerToolsEventHandler.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchBridge
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKSCService

@objcMembers
public class Item12088PlayerToolsEventHandler: ItemEventHandler, PlayerToolsViewableV2, PlayerStatusCallback {

    weak var itemModel:BaseItemModel? {
        get {
            return self.item?.itemModel
        }
    }

    weak var delegate: PlayerToolsEventHandlerDelegate?
    var isSlientMode:Bool = true
    var timer: Timer?

    //MARK: Property
    lazy var playerToolsView: Item12088PlayerToolsView = {
        let view = Item12088PlayerToolsView()
        view.clipsToBounds = true
        view.delegate = self
        return view
    }()
    
    required init() {
        super.init()
    }

    deinit {
        
    }
    
    override public func listeningEventObservers() -> [EventObserver]? {
        let observer1 = EventObserver(EventName.itemReuseItemView)
        let observer2 = EventObserver("yksc.event.component12088.playend")
        return [observer1, observer2]
    }
        
    public override func onEvent(_ event: OEvent) {
        if event.name == EventName.itemReuseItemView {
            self.receiveReuseEvent(event)
        } else if event.name == "yksc.event.component12088.playend" {
            self.receivePlayerPlayEndView(event)
        }
    }
    
    func receiveReuseEvent(_ event: OEvent) {
        self.itemModel?.playerModel?.playerDelegate = self
    }
    
    func receivePlayerPlayEndView(_ event: OEvent) {
        guard let itemDelegate = item?.getItemDelegate() as? Item12088,
              let itemModel = item?.itemModel,
              let itemView = itemDelegate.displayingItemView
        else {
            return
        }
        
        let target = event.params["targetItem"] as? IItem
        if target?.itemModel == itemModel {
            itemView.showPlayEndView(itemModel)
        } else {
            itemView.hidePlayEndView()
        }
    }
    
    func updateSlientStatusWithPlayerStart(_ player: PlayerView) {
        guard let itemModel = itemModel else {
            return
        }
        
        if let commonSlientMode = PlayerControlManagerV2.shareInstance().commonSlientMode(self.item) {
            player.isSlientMode = commonSlientMode
        }
        self.playerToolsView.isSlientMode = player.isSlientMode
        self.playerToolsView.bindSlientStatistics()
        self.playerToolsView.slientIconUpdate()
    }
    
    //MARK:YKPlayerStatusDelegate
    public func didStartPlayVideoInPlayer(_ player: PlayerView) {
        guard let itemModel = itemModel else {
            return
        }
        //1.isUserInteractionEnabled
        let embedPlayerView = player.embedPlayerView
        embedPlayerView?.isUserInteractionEnabled = true

        //2.add view
        if let playBackFrame = player.model?.playBackFrame {
            let toolsFrame = CGRect.init(x: 0, y: 0, width: playBackFrame.width, height: playBackFrame.height)
            self.playerToolsView.frame = toolsFrame
        }
        self.playerToolsView.tag = 2021042305
        
        if let oldView = embedPlayerView?.viewWithTag(2021042305) {
            oldView.removeFromSuperview()
        }
        embedPlayerView?.addSubview(self.playerToolsView)
        if let commonnSlientMode = PlayerControlManagerV2.shareInstance().commonSlientMode(self.item) {
            self.playerToolsView.isSlientMode = commonnSlientMode
        }
        self.playerToolsView.fillModel(itemModel)
        
        //3.slient
        self.updateSlientStatusWithPlayerStart(player)
        
        //4. timer
        self.timer = Timer.init(timeInterval: 5.0, target: self, selector: #selector(handleTimerTimeUp), userInfo: nil, repeats: false)
        if let timer = self.timer {
            RunLoop.main.add(timer, forMode: RunLoop.Mode.common)
        }
        
        self.delegate?.didPlayerStart(player.model)
    }
    
    public func didClickStopPlayer(_ embedPlayer: PlayerView) {
        self.playerToolsView.removeFromSuperview()
        
        self.delegate?.didPlayerStop(embedPlayer.model)
    }
    
    public func playTimeDidChange(_ player: PlayerView) {
        guard let playerModel = itemModel?.playerModel else {
            return
        }
        
        YKSCScreenLogUtil.printLog("12088: 播放中。pt.\(player.playingTime)   title:\(playerModel.title ?? "")    ref:[\(playerModel.sectionPlayBeginTime),\(playerModel.sectionPlayEndTime)]", color: .white)
        
        if playerModel.isSectionPlay, player.playingTime > playerModel.sectionPlayEndTime {
            player.stopPlayer()
            
            if playerModel.repeatPlay {
                player.seekTime = 0
                player.startPlayer()
            } else {
                playerModel.isPlayEnding = true
                YKSCScreenLogUtil.printLog("12088: 播放终止。pt.\(player.playingTime)   title:\(playerModel.title ?? "")    ref:[\(playerModel.sectionPlayBeginTime),\(playerModel.sectionPlayEndTime)]", color: .red)
                
                var params = [String: Any]()
                params["targetItem"] = self.item
                
                self.item?.getCard()?.sendEventMessage("yksc.event.component12088.playend", params: params, options: [.recursive, .toSubModules], userInfo: nil)
            }
        }
    }
    
    public func didFinishPositiveVideoInPlayer(_ player: PlayerView) {
        self.delegate?.didPlayerStop(player.model)
    }
    
    func slientModeUpdate(isSlientMode: Bool) {
        self.isSlientMode = isSlientMode
        PlayerControlManagerV2.shareInstance().updateCommonSlientMode(self.item, newMode: isSlientMode)
    }
    
    @objc func handleTimerTimeUp() {
        self.playerToolsView.hiddenVideoImageInfo()

        self.timer?.invalidate()
        self.timer = nil
    }
}

