//
//  Item12088PlayerToolsView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKHome
import YoukuAnalytics


@objcMembers
public class Item12088PlayerToolsView: UIView {
    
    weak var itemModel: BaseItemModel?
    var isSlientMode: Bool = true
    weak var delegate: PlayerToolsViewableV2?
    
    lazy var slientIcon: UIButton = {
        let view = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 44, height: 44))
        view.backgroundColor = .clear
        view.isUserInteractionEnabled = true
        view.setImage(UIImage.init(name: "muteVoice"), for: UIControl.State.normal)
        view.addTarget(self, action: #selector(slientIconTap), for: UIControl.Event.touchUpInside)
        return view
    }()
    
    //MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        createSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        createSubviews()
    }
    
    
    //MARK: -
    func createSubviews() {
        addSubview(slientIcon)
    }
    
    func customLayout() {
        let imageSize = 20.0
        let width = 44.0
        let height = width
        let offset = (width - imageSize) / 2
        let x: CGFloat = self.width - YKNGap.dim_6() - width + offset
        let y: CGFloat = self.height - height - YKNGap.dim_6() + offset
        slientIcon.frame = CGRect.init(x: x, y: y, width: width, height: height)
    }
    
    func fillModel(_ itemModel: BaseItemModel)  {
        self.itemModel = itemModel
        
        Service.lbTexts.attach(itemModel.lbTexts, toView: self, layouts: itemModel.layout.lbTexts)
        Service.viewInnerGradient.attach(.bottom, toView: self)

        if let player = PlayerControlManagerV2.shareInstance().currentPlayerView {
            self.isSlientMode = player.isSlientMode
        }
        
        self.slientIconUpdate()
        self.customLayout()
    }
    
    @objc func slientIconTap() {
        if let player = PlayerControlManagerV2.shareInstance().currentPlayerView {

            if self.isSlientMode {
                player.isSlientMode = false
            } else {
                player.isSlientMode = true
            }
            self.isSlientMode = player.isSlientMode
            self.slientIconUpdate()
            if let delegate = self.delegate {
                delegate.slientModeUpdate(isSlientMode: self.isSlientMode)
            }
            let arg2 = self.isSlientMode ? "volumeoff" : "volumeon"
            YoukuAnalytics.sharedInstance()?.collectALiCustomEvent(withEventID: "19999", pageName: "page_homeselect", arg1: "BigFeedVolumeState", arg2: arg2, args: nil)
        }
    }
    
    func slientIconUpdate()  {
        var image = UIImage.init(named: "unmuteVoice")
        if self.isSlientMode {
            image = UIImage.init(named: "muteVoice")
        }
        self.slientIcon.setImage(image, for: UIControl.State.normal)
    }
    
    func bindSlientStatistics() {
        if let itemModel = itemModel {
            let spmDExt = self.isSlientMode ? "_volumeon" : "_volumeoff"
            let slientActionModel = ActionFactoryV2(itemModel, spmDExt: spmDExt)
            Service.statistics.bind(slientActionModel?.report, slientIcon, .OnlyClick)
        }
    }
    
    public func hiddenVideoImageInfo() {
        Service.lbTexts.detach(fromView: self)
    }
    
}

