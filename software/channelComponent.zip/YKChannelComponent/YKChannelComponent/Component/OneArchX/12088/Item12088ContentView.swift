//
//  Item12088ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import SDWebImage
import YoukuResource
import YKResponsiveLayout
import YoukuShare

class Item12088ContentView: UIView, ItemPlugin12088ShareViewDelegate, ItemPlugin12088LikeViewDelegate {
    
    weak var itemModel: BaseItemModel?
    
    // MARK: 上区
    
    lazy var topContainer: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var showVideoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_small()
        return view
    }()
    
    lazy var showTitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_primaryInfo
        view.numberOfLines = 1
        return view
    }()
    
    lazy var showSubtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_tertiaryInfo
        view.lineBreakMode = .byTruncatingTail
        view.numberOfLines = 1
        return view
    }()
    
    lazy var showReasonLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_brandInfo
        view.numberOfLines = 1
        view.textAlignment = .center
        view.backgroundColor = UIColor.ykn_border
        view.layer.masksToBounds = true
        return view
    }()
    
    lazy var favorBtn: YKTrackShowView = {
        let view = YKTrackShowView.init(frame: CGRect.init(x: 0, y: 0, width: 60, height: 30))
        view.whenTapped {
            self.favorAction()
        }
        return view
    }()
    
    // MARK: 下区
    
    lazy var mainContainer: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_primaryInfo
        if (ykrl_isResponsiveLayout()) {
            view.numberOfLines = 1
        } else {
            view.numberOfLines = 2
        }
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.isUserInteractionEnabled = true
        return view
    }()
    
    lazy var playIconView: PlayerIconPreviewView = {
        let view = PlayerIconPreviewView()
        return view
    }()
    
    lazy var playEndView: Item12088PlayEndView = {
        let view = Item12088PlayEndView.init(frame: CGRect.zero)
        view.isHidden = true
        return view
    }()
    
    lazy var toolsContainer: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var commentView: ItemPlugin12088FunctionView = {
        let view = ItemPlugin12088FunctionView.init(frame: .zero, icon: "\u{e605}")
        return view
    }()
    
    lazy var likeView: ItemPlugin12088LikeView = {
        let view = ItemPlugin12088LikeView.init(frame: .zero, icon: "\u{e6d7}")
        view.delegate = self
        return view
    }()
    
    lazy var shareView: ItemPlugin12088ShareView = {
        let view = ItemPlugin12088ShareView.init(frame: .zero, icon: "\u{e60a}")
        view.delegate = self
        return view
    }()
    
    lazy var separatorView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.ykn_tertiaryFill
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        addSubview(mainContainer)
        
        addSubview(topContainer)
        topContainerInit()
        
        mainContainer.addSubview(titleLabel)
        mainContainer.addSubview(videoImageView)
        videoImageView.addSubview(playIconView)
        
        mainContainer.addSubview(playEndView)
        
        mainContainer.addSubview(toolsContainer)
        toolsContainer.addSubview(commentView)
        toolsContainer.addSubview(likeView)
        toolsContainer.addSubview(shareView)
        
        mainContainer.addSubview(separatorView)
    }
    
    func fillData(_ itemModel: Item12088Model) {
        relayoutIfNeeded(itemModel)
        
        let model = itemModel
        self.itemModel = model
        
        topContainerFillData(itemModel)
        
        var title = model.title
        if let previewTitle = model.preview?["title"] as? String, !previewTitle.isEmpty {
            title = previewTitle
        }
        
        //title
        if let title = title, !title.isEmpty {
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 3.0
            paragraphStyle.lineBreakMode = .byTruncatingTail

            let attributedTitle = NSMutableAttributedString.init(string: title)
            attributedTitle.addAttributes([.paragraphStyle : paragraphStyle],
                                          range: NSRange.init(location: 0, length: attributedTitle.length))
            
            titleLabel.attributedText = attributedTitle
        } else {
            titleLabel.text = ""
        }
        
        videoImageView.ykn_setImage(withURLString: model.img,
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        playEndView.isHidden = true
        model.playerModel?.isPlayEnding = false
        
        if let mark = itemModel.mark,
           let markLayout = itemModel.layout.extendExtra?["mark"] as? TextLayoutModel {
            Service.mark.attach(mark, toView: videoImageView, layout: markLayout)
        } else {
            Service.mark.detach(fromView: videoImageView)
        }
        
        if let lbtexts = itemModel.lbTexts {
            let lbTextsLayout = itemModel.layout.lbTexts
            Service.lbTexts.attach(lbtexts, toView: videoImageView, layouts: lbTextsLayout)
        } else {
            Service.lbTexts.detach(fromView: videoImageView)
        }
        
        // 推荐理由
        if let reason = itemModel.reason {
            Service.reasons.attach([reason], toView: self.mainContainer, layouts: itemModel.layout.reasons)
            
            let x: CGFloat = titleLabel.frame.minX
            let y: CGFloat = titleLabel.frame.maxY + YKNGap.dim_5()
            Service.reasons.move(to: CGPoint(x: x, y: y), inView: self.mainContainer)
        } else {
            Service.reasons.detach(fromView: self.mainContainer)
        }
        
        // 评论数
        if let comment = model.extraExtend["comments"] as? [String: Any] {
            let count = comment["count"] as? String ?? ""
            let textLayout = itemModel.layout.extendExtra?["comment_text"] as? TextLayoutModel
            commentView.fill(text: count, textLayoutV2: textLayout)
            
            let actionModel = model.extraExtend["comments_action"] as? ActionModel
            Service.action.bind(actionModel, commentView)
        }
        
        // 点赞数
        if let like = model.like {
            let icon = like.state ? "\u{e647}" : "\u{e6d7}"
            let iconColor = like.state ? UIColor.ykn_cr_2 : nil
            let textLayout = itemModel.layout.extendExtra?["like_text"] as? TextLayoutModel
            let countString = LikeUtil.stringWithlikeCount(like.count)
            likeView.fill(text: countString, textLayoutV2: textLayout, icon: icon, iconColor: iconColor)
            
            if let report = like.state ? model.extraExtend["unlike_report"] as? ReportModel : model.extraExtend["like_report"] as? ReportModel {
                Service.statistics.bind(report, self.likeView, .OnlyClick)
            } else {
                Service.statistics.bind(nil, self.likeView, .OnlyClick)
            }
        }
        
        // 分享数
        if let share = model.extraExtend["shareInfo"] as? [String: Any] {
            let count = share["shareCount"] as? String ?? ""
            let textLayout = itemModel.layout.extendExtra?["share_text"] as? TextLayoutModel
            shareView.fill(text: count, textLayoutV2: textLayout)
            
            if let report = model.extraExtend["shareInfo_report"] as? ReportModel {
                Service.statistics.bind(report, shareView, .OnlyClick)
            } else {
                Service.statistics.bind(nil, shareView, .OnlyClick)
            }
        }
        
        //player
        if let playerModel = itemModel.playerModel {
            if playerModel.canPlay {
                playIconView.isHidden = false
                Service.action.bind(self.itemModel?.action, playIconView, .OnlyClick)
            } else {
                playIconView.isHidden = true
            }
            
            if let report = model.extraExtend["play_report"] as? ReportModel {
                Service.statistics.bind(report, playIconView, .OnlyClick)
            } else {
                Service.statistics.bind(nil, playIconView, .OnlyClick)
            }
            
            let size = videoImageView.bounds.size
            Service.player.attach(playerModel, toView: videoImageView, displayFrame: CGRect.init(origin: .zero, size: size))
        }
    }
    
    func relayoutIfNeeded(_ itemModel: BaseItemModel) {
        let layoutModel = itemModel.layout
        
        topContainerRelayoutIfNeeded(itemModel)
        let topContainerLayout = layoutModel.extendExtra?["topContainer"] as? ImageLayoutModel
        topContainer.frame = topContainerLayout?.renderRect ?? .zero
        
        mainContainer.frame = layoutModel.renderRect
        
        let titleLayout = layoutModel.title
        titleLabel.frame = titleLayout?.renderRect ?? .zero
        titleLabel.font = titleLayout?.font
        
        let videoLayout = layoutModel.cover
        videoImageView.frame = videoLayout?.renderRect ?? .zero
        playIconView.frame = videoImageView.bounds
        
        let toolsContainerLayout = layoutModel.extendExtra?["toolsContainer"] as? ImageLayoutModel
        toolsContainer.frame = toolsContainerLayout?.renderRect ?? .zero
        
        let commentLayout = layoutModel.extendExtra?["comment"] as? ImageLayoutModel
        commentView.frame = commentLayout?.renderRect ?? .zero
        commentView.isHidden = commentView.frame.isEmpty
        
        let likeLayout = layoutModel.extendExtra?["like"] as? ImageLayoutModel
        likeView.frame = likeLayout?.renderRect ?? .zero
        likeView.isHidden = likeView.frame.isEmpty
        
        let shareLayout = layoutModel.extendExtra?["share"] as? ImageLayoutModel
        shareView.frame = shareLayout?.renderRect ?? .zero
        shareView.isHidden = shareView.frame.isEmpty
        
        let separatorLayout = layoutModel.extendExtra?["separator"] as? ImageLayoutModel
        separatorView.frame = separatorLayout?.renderRect ?? .zero
    }
    
    static func estimatedLayout(itemModel: Item12088Model, boundingSize: CGSize) {
        let model = itemModel
        let layoutModel = itemModel.layout
        if layoutModel.renderRect.size.width == boundingSize.width {
            return //重复计算，跳过。
        }
        
        if layoutModel.extendExtra == nil {
            layoutModel.extendExtra = [String: Any]()
        }
        
        let isResponsiveLayout = ykrl_isResponsiveLayout()
        let marginLeft: CGFloat = 0
        let marginRight: CGFloat = 0
        let mainBoundingWidth = boundingSize.width - marginLeft - marginRight
        
        let topContainerFrame = self.topContainerEstimatedLayout(itemModel: itemModel, boundingSize: boundingSize, marginRight: marginRight)
        
        let topContainerLayout = ImageLayoutModel.init()
        topContainerLayout.renderRect = topContainerFrame
        layoutModel.extendExtra?["topContainer"] = topContainerLayout
        
        let videoX = marginLeft
        let videoY = topContainerFrame.maxY + YKNGap.dim_6()
        let videoSize = mainVideoImageViewFrame(width: mainBoundingWidth).size
        let videoFrame = CGRect.init(x: videoX, y: videoY, width: mainBoundingWidth, height: videoSize.height)
        let videoLayout = ImageLayoutModel.init()
        videoLayout.renderRect = videoFrame
        layoutModel.cover = videoLayout
        
        if let mark = model.mark {
            let markLayout = Service.mark.estimatedLayout(mark, toViewSize: videoSize)
            layoutModel.extendExtra?["mark"] = markLayout
        }
        
        if let lbTexts = model.lbTexts {
            let lbTextsLayouts = Service.lbTexts.estimatedLayout(lbTexts, toViewSize: videoSize)
            
            for layout in lbTextsLayouts {
                //微调位置，设计要求定制，从原通用padding (left 6, bottom 6) 改为 (left 9, bottom 9)
                layout.renderRect = layout.renderRect.offsetBy(dx: 3, dy: -3)
            }
            
            layoutModel.lbTexts = lbTextsLayouts
        }
        
        var title = model.title
        if let previewTitle = model.preview?["title"] as? String, !previewTitle.isEmpty {
            title = previewTitle
        }
        let titleFont = YKNFont.posteritem_maintitle_weight(.semibold)
        let titleSizeSingleLine = textFitSize(title, font: titleFont, limit: .zero)
        var titleSize = titleSizeSingleLine
        if (isResponsiveLayout) {
            titleSize = CGSize.init(width: mainBoundingWidth, height: titleSizeSingleLine.height)
        } else {
            if titleSizeSingleLine.width > mainBoundingWidth {
                var titleSizeDoubleLine = textFitSize(title, font: titleFont, limit: CGSize.init(width: mainBoundingWidth, height: titleSizeSingleLine.height * 2.5))
                titleSizeDoubleLine.height += 3
                titleSize = titleSizeDoubleLine
            }
        }
        
        let titleX = marginLeft
        let titleY = videoFrame.maxY + YKNGap.youku_picture_title_spacing()
        let titleFrame = CGRect.init(x: titleX, y: titleY, width: mainBoundingWidth, height: titleSize.height)
        let titleLayout = TextLayoutModel.init()
        titleLayout.renderRect = titleFrame
        titleLayout.font = titleFont
        layoutModel.title = titleLayout
        
        let reasonHeight: CGFloat = 24
        var lastViewMaxY: CGFloat = titleFrame.maxY + (model.reason != nil ? reasonHeight : 0)
        
        var toolsContainerSubviewCount: Int = 0
        
        var commentEnabled = false
        var commentCountText = ""
        if let comment = model.extraExtend["comments"] as? [String: Any] {
            toolsContainerSubviewCount += 1 // 显示评论数
            
            let count = comment["count"] as? String ?? ""
            commentCountText = count
            commentEnabled = true
        }
        
        var likeEnabled = false
        var likeCountText = ""
        if let like = model.like {
            toolsContainerSubviewCount += 1 // 显示点赞数
            likeCountText = LikeUtil.stringWithlikeCount(like.count)
            likeEnabled = true
        }
        
        var shareEnabled = false
        var shareCountText = ""
        if let share = model.extraExtend["shareInfo"] as? [String: Any] {
            toolsContainerSubviewCount += 1 // 显示分享数
            
            let count = share["shareCount"] as? String ?? ""
            shareCountText = count
            shareEnabled = true
        }
        if toolsContainerSubviewCount > 0 {
            let toolsContainerX = 0.0
            let toolsContainerY = lastViewMaxY + YKNGap.dim_6()
            let toolsContainerFrame = CGRect.init(x: toolsContainerX, y: toolsContainerY, width: boundingSize.width, height: 30.0)
            let toolsContainerLayout = ImageLayoutModel.init()
            toolsContainerLayout.renderRect = toolsContainerFrame
            layoutModel.extendExtra?["toolsContainer"] = toolsContainerLayout
            
            lastViewMaxY = toolsContainerFrame.maxY
            
            let toolsContainerSubviewWidth: CGFloat = toolsContainerFrame.width / CGFloat(toolsContainerSubviewCount)
            let toolsContainerSubviewHeight: CGFloat = toolsContainerFrame.height
            
            var xCursor: CGFloat = 0
            if shareEnabled {
                let layout = ImageLayoutModel.init()
                layout.renderRect = CGRect.init(x: xCursor, y: 0, width: toolsContainerSubviewWidth, height: toolsContainerSubviewHeight)
                layoutModel.extendExtra?["share"] = layout
                
                let textLayout = TextLayoutModel.init()
                let textSize = textFitSize(shareCountText, font: ItemPlugin12088FunctionView.textFont(), limit: .zero)
                textLayout.renderRect = CGRect.init(origin: .zero, size: textSize)
                layoutModel.extendExtra?["share_text"] = textLayout
                
                xCursor += toolsContainerSubviewWidth
            }
            
            if commentEnabled {
                let layout = ImageLayoutModel.init()
                layout.renderRect = CGRect.init(x: xCursor, y: 0, width: toolsContainerSubviewWidth, height: toolsContainerSubviewHeight)
                layoutModel.extendExtra?["comment"] = layout
                
                let textLayout = TextLayoutModel.init()
                let textSize = textFitSize(commentCountText, font: ItemPlugin12088FunctionView.textFont(), limit: .zero)
                textLayout.renderRect = CGRect.init(origin: .zero, size: textSize)
                layoutModel.extendExtra?["comment_text"] = textLayout
                
                xCursor += toolsContainerSubviewWidth
            }
            
            if likeEnabled {
                let layout = ImageLayoutModel.init()
                layout.renderRect = CGRect.init(x: xCursor, y: 0, width: toolsContainerSubviewWidth, height: toolsContainerSubviewHeight)
                layoutModel.extendExtra?["like"] = layout
                
                let textLayout = TextLayoutModel.init()
                let textSize = textFitSize(likeCountText, font: ItemPlugin12088FunctionView.textFont(), limit: .zero)
                textLayout.renderRect = CGRect.init(origin: .zero, size: textSize)
                layoutModel.extendExtra?["like_text"] = textLayout
                
                xCursor += toolsContainerSubviewWidth
            }
        }
        
        let separatorX: CGFloat = isResponsiveLayout ? 0 : -YKNGap.youku_margin_left()
        let separatorY: CGFloat = lastViewMaxY + 15
        let separatorWidth: CGFloat = isResponsiveLayout ? boundingSize.width : (boundingSize.width + YKNGap.youku_margin_left() * 2)
        let separatorFrame = CGRect.init(x: separatorX, y: separatorY, width: separatorWidth, height: 6.0)
        let separatorLayout = ImageLayoutModel.init()
        separatorLayout.renderRect = separatorFrame
        layoutModel.extendExtra?["separator"] = separatorLayout
        
        var isWithoutSeparator = false
        if let item = itemModel.domainObject as? IItem,
           let component = item.getComponent(),
           let card = item.getCard(),
           let componentsInCard = card.getComponents()
        {
            if component.index == componentsInCard.count - 1,
               card.cardModel?.more == false
            {
                isWithoutSeparator = true //最后一个feed组件，不需要组件内分割线，接下来是下一个抽屉
            }
            
            if isResponsiveLayout,
               component.index == componentsInCard.count - 2,
               componentsInCard.count % 2 == 0,
               card.cardModel?.more == false
            {
                isWithoutSeparator = true //最后一行feed组件，不需要组件内分割线，接下来是下一个抽屉
            }
            
            if component.index == componentsInCard.count - 2 {
                let nextComponent = componentsInCard[component.index + 1]
                if nextComponent.tag == "14179" {
                    isWithoutSeparator = true //最后一个feed组件，接着是固定下发分割线，不需要组件内分割线
                }
            }
            
            if isResponsiveLayout,
               component.index == componentsInCard.count - 3,
               componentsInCard.count % 2 == 1
            {
                let nextComponent = componentsInCard[component.index + 2]
                if nextComponent.tag == "14179" {
                    isWithoutSeparator = true //最后一行feed组件，接着是固定下发分割线，不需要组件内分割线
                }
            }
        }
        if isWithoutSeparator {
            layoutModel.extendExtra?["separator"] = nil // 清空布局，表示不显示分割线。
        }
        
        let wholeWidth = boundingSize.width
        let wholeHeight = (isWithoutSeparator) ? lastViewMaxY : separatorFrame.maxY
        let wholeFrame = CGRect.init(x: 0, y: 0, width: wholeWidth, height: wholeHeight)
        layoutModel.renderRect = wholeFrame
    }
    
    static func showVideoImageViewFrame() -> CGRect {
        let x: CGFloat = 0
        var scale: CGFloat = YKNSize.yk_icon_size_scale()
        if (ykrl_isResponsiveLayout()) {
            scale = 1.5
        }
        let width = ceil(36.0 * scale)
        let height = ceil(48.0 * scale)
        return CGRect.init(origin: CGPoint.init(x: x, y: 0) , size: CGSize.init(width: width, height: height))
    }
    
    static func mainVideoImageViewFrame(width: CGFloat) -> CGRect {
        let ratio = 16.0/9.0
        return CGRect.init(origin: .zero, size: CGSize.init(width: width, height: ceil(width / ratio)))
    }
    
    func showPlayEndView(_ itemModel: BaseItemModel) {
        if shouldShowPlayEndView(itemModel) {
            playEndView.isHidden = false
            playEndView.frame = videoImageView.frame
            playEndView.fillData(itemModel)
        }
    }
    
    func shouldShowPlayEndView(_ itemModel: BaseItemModel) -> Bool {
        if let _ = itemModel.extraExtend["playLater"] as? [String: Any] {
            return true
        } else {
            return false
        }
    }
    
    func hidePlayEndView() {
        playEndView.isHidden = true
        itemModel?.playerModel?.isPlayEnding = false
    }
    
    // MARK: - ItemPlugin12088ShareViewDelegate
    func shareViewDidClick(_ view: ItemPlugin12088ShareView) {
        guard let shareModel = itemModel?.extraExtend["shareInfo"] as? [String: Any] else {
            return
        }

        let shareTitle = shareModel["shareTitle"] as? String ?? ""
        let shareLink = shareModel["shareLink"] as? String ?? ""
        let img = shareModel["img"] as? String ?? ""
        let describe = shareModel["describe"] as? String ?? ""

        let shareItem = YKShareInfoItem.init(ofOutputTypeWebWith: YKShareSourceId.privateDomain, url: shareLink, thumbnailURL: img, title: shareTitle, description: describe)

        if let shareUPassInfo = shareModel["shareUPassInfo"] as? [String: Any],
           let uPassRedirectUrl = shareUPassInfo["uPassRedirectUrl"] as? String,
           let uPassType = shareUPassInfo["uPassType"] as? String,
           let uPassTemplateText = shareUPassInfo["uPassTemplateText"] as? String
        {
            let uPassInfo = YKShareUPassInfo.init(ofUPassWithUPassRedirectUrl: uPassRedirectUrl,
                                                  uPassType: uPassType,
                                                  uPassTemplateText:uPassTemplateText)
            shareItem?.uPassInfo = uPassInfo
            shareItem?.sourceId = YKShareSourceId.searchDetailPage
        }
        
        YKShareCenter.default()?.showSharePanel(withContent: shareItem, delegate: nil)
    }

    // MARK: - ItemPlugin12088LikeViewDelegate
    func likeViewDidClick(_ view: ItemPlugin12088LikeView) {
        guard let itemModel = itemModel else {
            return
        }
        
        LikeUtilV2.didClickLike(itemModel) { result in
            if result {
                if let like = itemModel.like {
                    let icon = like.state ? "\u{e647}" : "\u{e6d7}"
                    let iconColor = like.state ? UIColor.ykn_cr_2 : nil
                    let countString = LikeUtil.stringWithlikeCount(like.count)
                    self.likeView.fill(text: countString, textLayout: nil, icon: icon, iconColor: iconColor)
                    
                    if let report = like.state ? itemModel.extraExtend["unlike_report"] as? ReportModel : itemModel.extraExtend["like_report"] as? ReportModel {
                        Service.statistics.bind(report, self.likeView, .OnlyClick)
                    } else {
                        Service.statistics.bind(nil, self.likeView, .OnlyClick)
                    }
                    
                    //动画
                    if like.state {
                        self.likeView.startLikeLOTAnimation()
                    } else {
                        self.likeView.startUnLikeLOTAnimation()
                    }
                }
            }
        }
    }
    
    // MARK: topContainer override
    class func topContainerEstimatedLayout(itemModel: Item12088Model, boundingSize: CGSize, marginRight: CGFloat) -> CGRect {
        let showRecModel = itemModel.showRecommendModel
        let layoutModel = itemModel.layout
        
        let showVideoImageFrame = showVideoImageViewFrame()
        var rightestButtonWidth: CGFloat = 0
        
        if let _ = itemModel.trackShow {
            
            //在追按钮
            let favor = TextLayoutModel()
            let favorSize = CGSize.init(width: 60, height: 30)
            let favorX = boundingSize.width - marginRight - favorSize.width
            let favorY = (showVideoImageFrame.maxY - favorSize.height) / 2
            favor.renderRect = CGRect.init(origin: CGPoint.init(x: favorX, y: favorY), size: favorSize)
            layoutModel.extendExtra?["favorBtn"] = favor
            
            rightestButtonWidth = favorSize.width
        } else {
            
            //继续看、播放按钮（与在追按钮互斥，优先级比前者低）
            let showReason = showRecModel?.reason?.title ?? ""
            let showReasonFont = YKNFont.posteritem_subhead_weight(.medium)
            let showReasonSize = textFitSize(showReason, font: showReasonFont, limit: .zero)
            let showReasonWidth = showReasonSize.width > 0 ? showReasonSize.width + 15 * 2 : 0
            let showReasonHeight = showReasonSize.height > 0 ? showReasonSize.height + 8 * 2 : 0
            let showReasonX = boundingSize.width - marginRight - showReasonWidth
            let showReasonY = (showVideoImageFrame.maxY - showReasonHeight) / 2
            let showReasonLayout = TextLayoutModel.init()
            showReasonLayout.renderRect = CGRect.init(x: showReasonX, y: showReasonY, width: showReasonWidth, height: showReasonHeight)
            showReasonLayout.font = showReasonFont
            layoutModel.extendExtra?["showReason"] = showReasonLayout
            
            rightestButtonWidth = showReasonWidth
        }
        
        let textLeftX = showVideoImageFrame.maxX + YKNGap.youku_module_margin_bottom()
        let textRightX = boundingSize.width - marginRight - rightestButtonWidth - YKNGap.dim_6()
        let textMaxWidth = max(0, textRightX - textLeftX)
        
        let showTitleFont = YKNFont.module_headline_weight(.medium)
        let showTitleHeight = ceil(YKNFont.height(with: showTitleFont, lineNumber: 1))
        
        let showSubtitleFont = YKNFont.posteritem_subhead()
        let showSubtitleHeight = ceil(YKNFont.height(with: showSubtitleFont, lineNumber: 1))
        
        let gapBetweenShowTitleAndSubtitle: CGFloat = 3
        
        let showTextTotalHeight = showTitleHeight + showSubtitleHeight + gapBetweenShowTitleAndSubtitle
        let showTitleY = (showVideoImageFrame.height - showTextTotalHeight) / 2
        
        let showTitleFrame = CGRect.init(x: textLeftX, y: showTitleY, width: textMaxWidth, height: showTitleHeight)
        let showTitleLayout = TextLayoutModel.init()
        showTitleLayout.renderRect = showTitleFrame
        showTitleLayout.font = showTitleFont
        layoutModel.extendExtra?["showTitle"] = showTitleLayout

        let showSubtitleY = showTitleFrame.maxY + gapBetweenShowTitleAndSubtitle
        let showSubtitleFrame = CGRect.init(x: textLeftX, y: showSubtitleY, width: textMaxWidth, height: showSubtitleHeight)
        let showSubtitleLayout = TextLayoutModel.init()
        showSubtitleLayout.renderRect = showSubtitleFrame
        showSubtitleLayout.font = showSubtitleFont
        layoutModel.extendExtra?["showSubtitle"] = showSubtitleLayout
        
        let unionRect = showVideoImageFrame.union(showSubtitleFrame)
        return CGRect.init(origin: .zero, size: CGSize.init(width: boundingSize.width, height: unionRect.height))
    }
    
    func topContainerInit() {
        topContainer.addSubview(showVideoImageView)
        topContainer.addSubview(showTitleLabel)
        topContainer.addSubview(showSubtitleLabel)
        topContainer.addSubview(showReasonLabel)
        topContainer.addSubview(favorBtn)
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddCollectSuccessNotication), name: NSNotification.Name.init("kBSAddCollectSuccess"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelCollectSuccessNotication), name: NSNotification.Name.init("kBSCancelCollectSuccess"), object: nil)
    }
    
    func topContainerFillData(_ itemModel: Item12088Model) {
        let showRecModel = itemModel.showRecommendModel
        
        showTitleLabel.text = showRecModel?.title
        let attributeString = NSMutableAttributedString.init()
        if let subtitle = showRecModel?.subtitle, !subtitle.isEmpty {
            attributeString.append(NSAttributedString.init(string: subtitle))
        }
        
        Service.reasons.detach(fromView: topContainer)
        
        //清除在主标题上的代发埋点
        Service.statistics.bind(nil, showTitleLabel, .OnlyExposure)
        
        var resetShowSubtitleSize = false
        if let theatre = itemModel.theatre,
           let title = theatre.title, !title.isEmpty {
            if attributeString.length > 0 {
                attributeString.append(NSAttributedString.init(string: " · "))
            }
            Service.reasons.attach([theatre], toView: topContainer, layouts: nil)
            resetShowSubtitleSize = true
            
            // 主标题代发剧场入口曝光埋点
            Service.statistics.bind(theatre.action?.report, showTitleLabel, .OnlyExposure)
        } else if let desc = showRecModel?.desc, !desc.isEmpty {
            if attributeString.length > 0 {
                attributeString.append(NSAttributedString.init(string: " · "))
            }
            
            if let descIsHighLighted = showRecModel?.descIsHighLighted, descIsHighLighted {
                attributeString.append(NSAttributedString.init(string: desc, attributes: [.foregroundColor: UIColor.ykn_secondaryInfo]))
            } else {
                attributeString.append(NSAttributedString.init(string: desc))
            }
        }
        showSubtitleLabel.attributedText = attributeString
        
        // 重置ShowSubtitleLabel、 theatreView 大小
        if resetShowSubtitleSize {
            // 剧场入口视图
            if let theatreView = topContainer.viewWithTag(19000510) {
                
                showSubtitleLabel.sizeToFit()
                let showSubtitleFrame = showSubtitleLabel.frame
                
                let x: CGFloat = showSubtitleFrame.maxX
                let y: CGFloat = showSubtitleFrame.minY + (showSubtitleFrame.size.height - theatreView.bounds.height) * 0.5
                
                Service.reasons.move(to: CGPoint.init(x: x, y: y), inView: topContainer)
                
                if let showSubtitleLayout = itemModel.layout.extendExtra?["showSubtitle"] as? TextLayoutModel {
                    let maxWidth4ShowSubtitle = max(0, (showSubtitleLayout.renderRect.size.width - theatreView.width))
                    if showSubtitleLabel.width > maxWidth4ShowSubtitle {
                        showSubtitleLabel.width = maxWidth4ShowSubtitle
                    }
                }
            }
        }
        
        showReasonLabel.text = showRecModel?.reason?.title
        showVideoImageView.ykn_setImage(withURLString: showRecModel?.img,
                                        module: "home",
                                        imageSize: CGSize.zero,
                                        parameters: nil,
                                        completed: nil)
        
        if let trackShow = itemModel.trackShow {
            bindStatisticsService()
            favorBtn.isHidden = false
            updateFavorBtnUI(trackShow.isFavor ?? false)
        } else {
            favorBtn.isHidden = true
        }
        
        if let reasonAction = showRecModel?.reason?.action {
            Service.action.bind(reasonAction, topContainer)
        } else {
            Service.action.bind(showRecModel?.action, topContainer)
        }
    }
    
    func topContainerRelayoutIfNeeded(_ itemModel: BaseItemModel) {
        let layoutModel = itemModel.layout
        showVideoImageView.frame = Item12088ContentView.showVideoImageViewFrame()
        
        let showTitleLayout = layoutModel.extendExtra?["showTitle"] as? TextLayoutModel
        showTitleLabel.frame = showTitleLayout?.renderRect ?? .zero
        showTitleLabel.font = showTitleLayout?.font
        
        let showSubtitleLayout = layoutModel.extendExtra?["showSubtitle"] as? TextLayoutModel
        showSubtitleLabel.frame = showSubtitleLayout?.renderRect ?? .zero
        showSubtitleLabel.font = showSubtitleLayout?.font
        
        let showReasonLayout = layoutModel.extendExtra?["showReason"] as? TextLayoutModel
        showReasonLabel.frame = showReasonLayout?.renderRect ?? .zero
        showReasonLabel.font = showReasonLayout?.font
        showReasonLabel.layer.cornerRadius = showReasonLabel.bounds.height / 2
        
        if let favorBtnLayout = layoutModel.extendExtra?["favorBtn"] as? TextLayoutModel {
            favorBtn.frame = favorBtnLayout.renderRect
        } else {
            favorBtn.frame = CGRect.zero
        }
    }
    
    // MARK: +追
    func updateFavorBtnUI(_ isFavor: Bool) {
        // 将来如需绑定氛围，可参考 Item14205ContentView 逻辑
        
        favorBtn.selectTextColor = .ykn_tertiaryInfo
        favorBtn.selectBgColor = .ykn_seconarySeparator
        favorBtn.selectBorderWidth = 0.0
        favorBtn.selectBorderColor = .clear
        
        favorBtn.unselectTextColor = .ykn_brandInfo
        favorBtn.unselectBgColor = .ykn_border
        favorBtn.unselectBorderWidth = 1.0
        favorBtn.unselectBorderColor = .clear
        
        favorBtn.update(isFavor)
    }
    
    func bindStatisticsService() {
        guard let trackShow = itemModel?.trackShow else {
            return
        }
        
        if let isFavor = trackShow.isFavor, isFavor == true {
            let actionModel =  self.itemModel?.extraExtend["uncollectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        } else {
            let actionModel = self.itemModel?.extraExtend["collectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        }
    }
    
    func favorAction() {
        guard let favor = itemModel?.trackShow,
              let isFavor = favor.isFavor
        else {
            return
        }
        
        var params = [String : Any]()
        params["isFavor"] = isFavor
        params["id"] = favor.favorId ?? ""
        
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channel.function.adaptor.zhuiju"), object: nil, userInfo: params)
    }
    
    @objc func handleAddCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: true)
    }
    
    @objc func handleCancelCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: false)
    }
    
    func handleNotication(notification: Notification, favored: Bool) {
        guard let userInfo = notification.userInfo,
              let targetId = userInfo["targetId"] as? String
        else {
            return
        }
        
        guard let favor = itemModel?.trackShow,
              let currentId = favor.favorId
        else {
            return

        }
        
        guard currentId == targetId else {
            return
        }
        
        favor.isFavor = favored
        updateFavorBtnUI(favor.isFavor ?? false)
        bindStatisticsService()
    }
}

private func textFitSize(_ text: String?, font: UIFont, limit: CGSize) -> CGSize {
    guard let text = text else {
        return .zero
    }

    var fitSize = NSString(string: text).boundingRect(with: limit,
                                                      options: [.usesLineFragmentOrigin, .truncatesLastVisibleLine],
                                                      attributes: [.font: font],
                                                      context: nil).size
    fitSize = CGSize(width: ceil(fitSize.width), height: ceil(fitSize.height))
    return fitSize
}

