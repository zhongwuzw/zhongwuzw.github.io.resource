//
//  Item12088Model.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku
import YoukuResource

class Item12088Model: BaseItemModel {
    
    var theatre: ReasonModel?
        
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        
        if let theatre = dataInfo["theatre"] as? [String:Any] {
            let text = theatre["text"] as? [String:Any]
            let action = theatre["action"] as? [String:Any]
            self.theatre = ReasonModel.newModel(text: text, action: action, model: self)
            self.theatre?.titleColorStr = "TOKEN_ykn_secondaryInfo"
        }
        
        if var reason = self.reason {
            reason.titleColorStr = "#F65200"
            self.reason = reason
        }
        
        if let preview = dataInfo["preview"] as? [String:Any] {
            if let begin = preview["barrageStartTime"] as? Double {
                self.playerModel?.isSectionPlay = true
                self.playerModel?.sectionPlayBeginTime = begin
            }
            
            if let end = preview["barrageEndTime"] as? Double {
                self.playerModel?.sectionPlayEndTime = end
            }
        }
        
        if let _ = self.trackShow {
            //在看按钮埋点构造
            let followActionModel = ActionFactoryV2(self, spmDExt: "_watching")
            if followActionModel != nil {
                self.extraExtend["collectActionModel"] = followActionModel
            }
            
            let unfollowActionModel = ActionFactoryV2(self, spmDExt: "_cancelwatching")
            if unfollowActionModel != nil {
                self.extraExtend["uncollectActionModel"] = unfollowActionModel
            }
        }
        
        if var comments = dataInfo["comments"] as? [String: Any] {
            if let countString = comments["count"] as? String {
                if countString == "" || countString == "0" {
                    comments["count"] = "评论"
                }
            } else if let countInt = comments["count"] as? Int {
                if countInt == 0 {
                    comments["count"] = "评论"
                }
            } else {
                comments["count"] = "评论"
            }
            
            self.extraExtend["comments"] = comments
            
            if let actionInfo = comments["action"] as? [String: Any] {
                if let actionModel = buildActionModel(actionInfo, model: self) {
                    self.extraExtend["comments_action"] = actionModel
                }
            }
        }
        
        if (dataInfo["preview"] as? [String: Any]) != nil {
            let likeAtion = ActionFactoryV2(self, spmDExt: "_play")
            if let report = likeAtion?.report {
                self.extraExtend["play_report"] = report
            }
        }
        
        if (dataInfo["like"] as? [String: Any]) != nil {
            let likeAtion = ActionFactoryV2(self, spmDExt: "_like")
            if let report = likeAtion?.report {
                self.extraExtend["like_report"] = report
            }
            
            let unlikeAction = ActionFactoryV2(self, spmDExt: "_unlike")
            if let report = unlikeAction?.report {
                self.extraExtend["unlike_report"] = report
            }
        }
        
        if var shareInfo = dataInfo["shareInfo"] as? [String: Any] {
            if let countString = shareInfo["shareCount"] as? String {
                if countString == "" || countString == "0" {
                    shareInfo["shareCount"] = "分享"
                }
            } else if let countInt = shareInfo["shareCount"] as? Int {
                if countInt == 0 {
                    shareInfo["shareCount"] = "分享"
                }
            } else {
                shareInfo["shareCount"] = "分享"
            }
            
            self.extraExtend["shareInfo"] = shareInfo
            
            let action = ActionFactoryV2(self, spmDExt: "_share")
            if let report = action?.report {
                self.extraExtend["shareInfo_report"] = report
            }
        }
        
        if let playLater = dataInfo["playLater"] as? [String: Any] {
            self.extraExtend["playLater"] = playLater
            
            let action = ActionFactoryV2(self, spmDExt: "_end")
            self.extraExtend["playLater_action"] = action
        } else {
            self.playerModel?.repeatPlay = true
        }
    }
    
}
