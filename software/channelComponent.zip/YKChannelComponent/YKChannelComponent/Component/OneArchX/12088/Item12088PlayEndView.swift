//
//  Item12088PlayEndView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Item12088PlayEndView: UIView {

    lazy var imageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.backgroundColor = .systemPink
        
        return view
    }()
    
    lazy var effectView: UIVisualEffectView = {
        let effect = UIBlurEffect.init(style: .dark)
        let view = UIVisualEffectView.init(effect: effect)
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_cw_1
        view.numberOfLines = 1
        view.textAlignment = .center
        view.font = YKNFont.posteritem_maintitle_weight(.medium)
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_cw_1
        view.numberOfLines = 1
        view.textAlignment = .center
        view.font = YKNFont.posteritem_maintitle_weight(.medium)
        view.backgroundColor = UIColor.ykn_co_2.withAlphaComponent(0.1)
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        imageView.addSubview(effectView)
        addSubview(imageView)
        
        addSubview(titleLabel)
        addSubview(subtitleLabel)
    }
    
    func fillData(_ itemModel: BaseItemModel) {
        relayoutSubViews()
        
        
        imageView.ykn_setImage(withURLString: itemModel.img,
                               module: "home",
                               imageSize: CGSize.zero,
                               parameters: nil,
                               completed: nil)
        
        if let playLater = itemModel.extraExtend["playLater"] as? [String: Any] {
            titleLabel.text = playLater["title"] as? String ?? ""
            subtitleLabel.text = playLater["subtitle"] as? String ?? ""
            
            subtitleLabel.sizeToFit()
            var subtitleSize = subtitleLabel.bounds.size
            subtitleSize.width += YKNGap.dim_10() * 2
            subtitleSize.height = 35
            
            let subtitleX = (bounds.width - subtitleSize.width) / 2
            let subtitleY = titleLabel.frame.maxY + YKNGap.dim_8()
            subtitleLabel.frame = CGRect.init(origin: CGPoint.init(x: subtitleX, y: subtitleY), size: subtitleSize)
            subtitleLabel.layer.cornerRadius = subtitleSize.height / 2
            subtitleLabel.layer.masksToBounds = true
            
        } else {
            titleLabel.text = ""
            subtitleLabel.text = ""
            
            subtitleLabel.frame = .zero
        }
        
        
        if let action = itemModel.extraExtend["playLater_action"] as? ActionModel {
            Service.action.bind(action, self, .Defalut)
        } else {
            Service.action.bind(nil, self)
        }
    }
    
    func relayoutSubViews() {
        imageView.frame = self.bounds
        effectView.frame = imageView.bounds
        
        let titleY: CGFloat = 62.0/195.0 * bounds.height
        let titleHeight: CGFloat = ceil(YKNFont.height(with: titleLabel.font, lineNumber: 1))
        titleLabel.frame = CGRect.init(x: 0, y: titleY, width: bounds.width, height: titleHeight)
    }
}

