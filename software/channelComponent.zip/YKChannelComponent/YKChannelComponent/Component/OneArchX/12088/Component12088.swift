//
//  Component12088.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/12/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku

class Component12088: NSObject, ComponentDelegate {

    var componentWrapper: ComponentWrapper?
    
    func layoutType() -> ComponentLayoutType {
        return .custom //响应式适配改多列均分（多行一列）为自定义布局。
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_line_spacing() /* 不能用token YKNGap.youku_comp_margin_bottom() */, right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.youku_module_margin_bottom()
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        config.responsiveAdjustableMinColumnCount = 2
        config.responsiveMinColumnCount = 2
        config.responsiveMaxColumnCount = 2
        return config
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseComponentModel.self as? T.Type
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        let playerEvent = PlayerScrollEndCompEventHandler()
        return [playerEvent]
    }
    
    func componentDidInit() {
        
    }
    
    // MARK: 响应式适配，组件级的UI回调转发到坑位级
    /// 渲染复用ID
    func reuseId() -> String? {
        guard let item = self.component?.getItems()?.first,
              let itemDelegate = item.getItemDelegate()
        else {
            return nil
        }
        
        return itemDelegate.reuseId()
    }

    /// item高度
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        guard let item = self.component?.getItems()?.first,
              let itemDelegate = item.getItemDelegate()
        else {
            return 0
        }
        
        return itemDelegate.itemHeight(itemWidth: itemWidth)
    }
    
    /// 初始化item view
    func createView(_ itemSize: CGSize) -> UIView {
        guard let item = self.component?.getItems()?.first,
              let itemDelegate = item.getItemDelegate()
        else {
            return UIView.init()
        }
        
        return itemDelegate.createView(itemSize)
    }

    /// 复用
    func reuseView(itemView: UIView) {
        guard let item = self.component?.getItems()?.first,
              let itemDelegate = item.getItemDelegate()
        else {
            return
        }
        
        return itemDelegate.reuseView(itemView: itemView)
    }
    
}
