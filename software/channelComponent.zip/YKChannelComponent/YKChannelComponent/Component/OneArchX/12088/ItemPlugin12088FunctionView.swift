//
//  ItemPlugin12088FunctionView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/5/20.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YKChannelBase
import OneArchSupport4Youku
import YoukuResource
import Lottie

class ItemPlugin12088FunctionView: UIView {

    lazy var iconLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_primaryInfo
        view.font = YKNIconFont.sharedInstance().font(withSize: 24)
        view.textAlignment = .center
        return view
    }()
    
    lazy var textLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_primaryInfo
        view.font = ItemPlugin12088FunctionView.textFont()
        view.numberOfLines = 1
        return view
    }()
    
    init(frame: CGRect, icon: String? = nil) {
        super.init(frame: frame)
        
        initSubviews(icon: icon)
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews(icon: String? = nil) {
        addSubview(iconLabel)
        addSubview(textLabel)
        
        if let icon = icon, !icon.isEmpty {
            iconLabel.text = icon
            iconLabel.bounds = CGRect.init(origin: .zero, size: CGSize.init(width: 24, height: 24))
        }
    }
    
    class func textFont() -> UIFont {
        return YKNFont.button_text_m()
    }
        
    func fill(text: String, textLayout: YKChannelBase.TextLayoutModel? = nil, icon: String? = nil, iconColor: UIColor? = nil) {
        if textLayout == nil {
            fill(text: text,
                 textLabelSizeToFitFlag: true,
                 textLabelSize: .zero,
                 icon: icon,
                 iconColor: iconColor)
        } else {
            fill(text: text,
                 textLabelSizeToFitFlag: false,
                 textLabelSize: textLayout?.renderRect.size ?? CGSize.zero,
                 icon: icon,
                 iconColor: iconColor)
        }
    }
    
    func fill(text: String, textLayoutV2: OneArchSupport4Youku.TextLayoutModel? = nil, icon: String? = nil, iconColor: UIColor? = nil) {
        if textLayoutV2 == nil {
            fill(text: text,
                 textLabelSizeToFitFlag: true,
                 textLabelSize: .zero,
                 icon: icon,
                 iconColor: iconColor)
        } else {
            fill(text: text,
                 textLabelSizeToFitFlag: false,
                 textLabelSize: textLayoutV2?.renderRect.size ?? CGSize.zero,
                 icon: icon,
                 iconColor: iconColor)
        }
    }
    
    private func fill(text: String, textLabelSizeToFitFlag: Bool, textLabelSize: CGSize, icon: String? = nil, iconColor: UIColor? = nil) {
        textLabel.text = text
        if let icon = icon {
            iconLabel.text = icon
            iconLabel.textColor = iconColor ?? UIColor.ykn_primaryInfo
        }
        
        if textLabelSizeToFitFlag {
            textLabel.sizeToFit()
        } else {
            textLabel.bounds.size = textLabelSize
        }
        
        let textTotalWidth = iconLabel.bounds.width + textLabel.bounds.width
        let iconX = (bounds.width - textTotalWidth) / 2
        let iconY = (bounds.height - iconLabel.bounds.height) / 2
        iconLabel.frame = CGRect.init(origin: CGPoint.init(x: iconX, y: iconY), size: iconLabel.bounds.size)
        
        let textX = iconLabel.frame.maxX + YKNGap.dim_4()
        let textY = (bounds.height - textLabel.bounds.height) / 2
        textLabel.frame = CGRect.init(origin: CGPoint.init(x: textX, y: textY), size: textLabel.bounds.size)
    }
}

protocol ItemPlugin12088LikeViewDelegate: NSObjectProtocol {
    func likeViewDidClick(_ view: ItemPlugin12088LikeView)
}

class ItemPlugin12088LikeView: ItemPlugin12088FunctionView {
    
    public weak var delegate: ItemPlugin12088LikeViewDelegate?

    public var animationFilePath: String?
    
    lazy var unLikeAnimationView: LOTAnimationView = {
        
        var path = Bundle.main.path(forResource: "DYKResources-cancel-praise-animation", ofType: "json")
        
        let view = LOTAnimationView.init(filePath:path ?? "")
        view.translatesAutoresizingMaskIntoConstraints = true
        view.contentMode = .scaleAspectFit
        view.isHidden = true
        view.frame = CGRect.init(origin: .zero, size: CGSize.init(width: 48, height: 48))
        
        return view
    }()
    
    lazy var likeAnimationView: LOTAnimationView = {
        
        var path = Bundle.main.path(forResource: "DYKResources-praise-animation", ofType: "json")
        
        let view = LOTAnimationView.init(filePath:path ?? "")
        view.translatesAutoresizingMaskIntoConstraints = true
        view.contentMode = .scaleAspectFit
        view.isHidden = true
        view.frame = CGRect.init(origin: .zero, size: CGSize.init(width: 48, height: 48))
        
        return view
    }()
    
    override func initSubviews(icon: String? = nil) {
        super.initSubviews(icon: icon)
        addSubview(unLikeAnimationView)
        
        weak var weakself = self
        self.whenTapped {
            weakself?.delegate?.likeViewDidClick(self)
        }
    }
    
    func startLikeLOTAnimation() {
        if self.likeAnimationView.superview == nil {
            //重要！！ Lottie 资源需要远程下载，不可提前初始化并addview， 延迟到首次使用时添加view
            self.addSubview(self.likeAnimationView)
        }
            
        self.likeAnimationView.center = self.iconLabel.center
        self.likeAnimationView.frame = self.likeAnimationView.frame.offsetBy(dx: 0, dy: 1)
        self.iconLabel.isHidden = true
        self.unLikeAnimationView.isHidden = true
        self.unLikeAnimationView.stop()
        
        self.likeAnimationView.isHidden = false
        self.likeAnimationView.play(){[weak self] (animationFinished: Bool) in
            self?.unLikeAnimationView.isHidden = true
            self?.likeAnimationView.isHidden = true
            self?.iconLabel.isHidden = false
        }
    }
    
    func startUnLikeLOTAnimation() {
        self.unLikeAnimationView.center = self.iconLabel.center
        self.unLikeAnimationView.frame = self.unLikeAnimationView.frame.offsetBy(dx: 0, dy: 1)
        self.iconLabel.isHidden = true
        self.unLikeAnimationView.isHidden = false
        self.likeAnimationView.isHidden = true
        self.unLikeAnimationView.play(){[weak self] (animationFinished: Bool) in
            self?.unLikeAnimationView.isHidden = true
            self?.likeAnimationView.isHidden = true
            self?.iconLabel.isHidden = false
        }
            
    }
    
}

protocol ItemPlugin12088ShareViewDelegate: NSObjectProtocol {
    func shareViewDidClick(_ view: ItemPlugin12088ShareView)
}

class ItemPlugin12088ShareView: ItemPlugin12088FunctionView {
    
    weak var delegate: ItemPlugin12088ShareViewDelegate?
    
    override func initSubviews(icon: String? = nil) {
        super.initSubviews(icon: icon)
        
        weak var weakself = self
        self.whenTapped {
            weakself?.delegate?.shareViewDidClick(self)
        }
    }
    
}
