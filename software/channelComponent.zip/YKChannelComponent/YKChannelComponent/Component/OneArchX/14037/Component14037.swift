//
//  Component14037.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout
import OneArchSupport
import OneArchSupport4Youku

class Component14037: NSObject, ComponentDelegate {
       
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeComponentModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .horizontalScroll
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        var bottom: CGFloat = YKNGap.dim_6()
        if ykrl_isResponsiveLayout() {
            bottom = 12 // 20221129版本 目标值上下距离12，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: bottom, right: 0)
        config.preferredCardSpacingTop = 6.0
        config.headerBottomMargin = 0.0
        config.rowSpacing = 0.0
        config.columnSpacing = 18.0
        config.footerTopMargin = 0.0
        config.preferredRowHeight = 0.0
        config.horizontalPaddingLeft = YKNGap.youku_margin_left()
        config.horizontalPaddingRight = YKNGap.youku_margin_right()
        config.backgroundLeftMarginOffset = 0
        config.backgroundRightMarginOffset = 0
        config.headerLeftMarginOffset = 0
        config.headerRightMarginOffset = 0
        config.backgroundTopMargin = 0
        return config
    }
    
    func columnSpacing() -> CGFloat {
        if ykrl_isResponsiveLayout() {
            var spacing:CGFloat = 40
            let containerWidth = self.component?.pageContext?.getContainerView()?.width ?? 0
            if containerWidth < 400 {
                spacing = 24;
            }
            return spacing
        }
        let itemCount = self.component?.getItems()?.count ?? 0
        if itemCount == 0 {
            return YKNGap.youku_column_spacing()
        }
        
        let itemWidth:CGFloat = 57
        var spacing:CGFloat = YKNGap.dim_7()
        
        if itemCount <= 5 {
            let n:CGFloat = CGFloat(max(itemCount - 1, 1))
            spacing = (SCREEN_WIDTH - YKNGap.youku_margin_left() - YKNGap.youku_margin_right() - CGFloat(itemCount) * itemWidth) * 1.0 / n
        } else {
            spacing = (SCREEN_WIDTH - YKNGap.margin_l() - 5.3 * itemWidth)/5
        }
        
        if spacing > 54 {
            spacing = 54
        }
        return spacing
    }

    func columnCount() -> CGFloat {
        return 3
    }
    
    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {

    }

    /// 获取item格式解析代理
    func getItemJsonExtracter() -> ItemJsonExtracter? {
        return ItemJsonExtractor14037.init()
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
