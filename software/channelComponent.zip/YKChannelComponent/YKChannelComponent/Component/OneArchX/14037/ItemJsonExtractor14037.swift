//
//  ItemJsonExtractor14037.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch

class ItemJsonExtractor14037: ItemJsonExtracter {
    // MARK: - ItemJsonExtracter

    public func getItemsJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error> {
        guard let itemsJson = componentJson?["nodes"] as? [[String: Any]] else {
            return .success([[String : Any]]()) //允许没有坑位列表
        }
        
        return .success(itemsJson)
    }

    public func getItemTag(itemJson: [String: Any]?, component: IComponent?) -> String? {
        let typeValue = itemJson?["type"]
        if let type = typeValue as? Int {
            return String(type)
        } else if let type = typeValue as? String {
            return type
        }
        return nil
    }
    
    public func getItemSubcomponentsJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error> {
        guard let compJson = componentJson, let compType = getTypeIntValue(compJson["type"]) else {
            return .success([[String : Any]]())
        }
        if let level = getTypeIntValue(compJson["level"]), level == 2 {
            if let nodes = compJson["nodes"] as? [[String: Any]] {
                var newNodes = [[String:Any]]()
                for index in 0..<nodes.count {
                    var json = nodes[index]
                    if let itemType = getTypeIntValue(json["type"]) {
                        json["type"] = String(compType) + "_" + String(itemType)
                        json["level"] = 2
                        if let subItemNodes = json["nodes"] as? [[String:Any]] {
                            var newSubItemNodes = [[String:Any]]()
                            for i in 0..<subItemNodes.count {
                                var subItemJson = subItemNodes[i]
                                if let subItemType =  getTypeIntValue(subItemJson["type"]) {
                                    subItemJson["type"] = String(itemType) + "_" + String(subItemType)
                                    if i == subItemNodes.count - 1, subItemType == 13003 {
                                        if var data = json["data"] as? [String:Any] {
                                            let hideMore = component?.compModel?.extend["hideMore"] as? Bool ?? false
                                            if !hideMore {
                                                var enter = [String:Any]()
                                                enter["text"] = "查看完整榜单"
                                                enter["action"] = (subItemJson["data"] as?[String:Any])?["action"]
                                                data["enter"] = enter
                                                json["data"] = data
                                            }
                                        }
                                    }
                                }
                                newSubItemNodes.append(subItemJson)
                            }
                            json["nodes"] = newSubItemNodes
                        }
                    }
                    newNodes.append(json)
                }
                if newNodes.count > 0 {
                    return .success(newNodes)
                }
            }
        }
        return .success([[String : Any]]())
    }
    
    func getSubitemsJson(itemJson: [String : Any]?, item: IItem?) -> Result<[[String : Any]], Error> {
        guard let subitemsJson = itemJson?["nodes"] as? [[String: Any]] else {
            return .success([[String : Any]]()) //允许没有坑位列表
        }
        
        return .success(subitemsJson)
    }
}

func getTypeIntValue(_ value: Any?) -> Int? {
    if let intValue = value as? Int {
        return intValue
    } else  if let stringValue = value as? String, stringValue.isEmpty == false {
        return Int(stringValue)
    }
    return nil
}
