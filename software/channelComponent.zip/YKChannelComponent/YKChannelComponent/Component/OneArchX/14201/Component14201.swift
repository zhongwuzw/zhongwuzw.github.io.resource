//
//  Component14201.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2023/2/7.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource

class Component14201: NSObject, ComponentDelegate {

    var componentWrapper: ComponentWrapper?

    func componentDidInit() {

    }

    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }

    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_comp_margin_bottom()
        config.footerBottomMargin = YKNGap.youku_comp_margin_bottom()
        config.responsiveAdjustableMinColumnCount = 1
        return config
    }

    func columnCount() -> CGFloat {
        return 1
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
