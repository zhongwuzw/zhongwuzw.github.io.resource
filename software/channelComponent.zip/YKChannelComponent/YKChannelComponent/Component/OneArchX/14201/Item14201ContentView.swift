//
//  Item14201ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/7/12.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import YKProtocolSDK
import YKHome

class Item14201ContentView: UIView {

    //MARK: Property
    var itemModel: BaseItemModel?
    
    lazy var iconView: UIImageView = {
        let view = UIImageView.init()
        view.backgroundColor = YKNColor.item_default_backgroundColor()
        view.layer.masksToBounds = true
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel.init()
        label.backgroundColor = .clear
        label.textAlignment = .left
        label.lineBreakMode = .byTruncatingTail
        label.font = YKNFont.posteritem_maintitle()
        label.textColor = .ykn_primaryInfo
        return label
    }()

    lazy var subtitleLabel: UILabel = {
        let label = UILabel.init()
        label.backgroundColor = .clear
        label.textAlignment = .left
        label.lineBreakMode = .byTruncatingTail
        label.font = YKNFont.posteritem_subhead()
        label.textColor = .ykn_tertiaryInfo
        return label
    }()
    
    lazy var favorView: Item14201FavorView = {
        let view = Item14201FavorView.init(frame: .zero)
        return view
    }()
    
    lazy var favorClickView: UIButton = {
        let view = UIButton.init()
        view.addTarget(self, action: #selector(favorAction), for: UIControl.Event.touchUpInside)
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(self.iconView)
        addSubview(self.titleLabel)
        addSubview(self.subtitleLabel)
        addSubview(self.favorView)
        addSubview(self.favorClickView)
        
        initLayout()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func initLayout() {
        let ml: CGFloat = 0
        let mr: CGFloat = 0
        let followBtnSize = CGSize.init(width: ceil(60 * YKNSize.yk_icon_size_scale()),
                                        height: ceil(30 * YKNSize.yk_icon_size_scale()))
        
        let itemHeight = viewFixedHeight()
        let iconSize = iconViewSize()
        let iconWidth = iconSize.width
        let iconHeight = iconSize.height
        var w: CGFloat = iconWidth
        var h: CGFloat = iconHeight
        var x: CGFloat = ml
        var y: CGFloat = (itemHeight - h) / 2
        
        iconView.frame = CGRect.init(x: x, y: y, width: w, height: h)
        iconView.layer.cornerRadius = iconCornerRadius()
        
        let labelMaxWidth = self.width - iconWidth - followBtnSize.width - (ml + mr) - (9 * 2)
        
        let titleHeight = YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
        let subtitleHeight = YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)
        let textAreaInnerGap = 4.0
        let textAreaHeight = titleHeight + subtitleHeight + textAreaInnerGap
        
        x = iconView.frame.maxX + 9
        y = (itemHeight - textAreaHeight) / 2
        w = labelMaxWidth
        h = titleHeight
        titleLabel.frame = CGRect.init(x: x, y: y, width: w, height: h)
        
        y = titleLabel.frame.maxY + textAreaInnerGap
        w = labelMaxWidth
        h = subtitleHeight
        subtitleLabel.frame = CGRect.init(x: x, y: y, width: w, height: h)
        
        w = followBtnSize.width
        h = followBtnSize.height + 36
        x = self.bounds.size.width - mr - w
        y = 0
        favorClickView.frame = CGRect.init(x: x, y: y, width: w, height: h)
        
        w = followBtnSize.width
        h = followBtnSize.height
        x = favorClickView.left
        y = (itemHeight - h) / 2
        favorView.frame = CGRect.init(x: x, y: y, width: w, height: h)
        // 暂时隐藏
        favorView.isHidden = true
        favorClickView.isHidden = true
    }
    
    func viewFixedHeight() -> CGFloat {
        let height = 48 * YKNSize.yk_icon_size_scale()
        return ceil(height)
    }
    
    func iconViewSize() -> CGSize {
        let width: CGFloat = 80 * YKNSize.yk_icon_size_scale()
        let height: CGFloat = 42 * YKNSize.yk_icon_size_scale()
        return CGSize.init(width: ceil(width), height: ceil(height))
    }
    
    func iconCornerRadius() -> CGFloat {
        let height = iconViewSize().height
        return height / 2
    }
    
    func fillData(itemModel: BaseItemModel) {
        self.itemModel = itemModel
        
        self.iconView.ykn_setImage(withURLString: itemModel.img, module: "home", imageSize: .zero, parameters: nil, completed: nil)
        self.titleLabel.text = itemModel.title
        self.subtitleLabel.text = itemModel.desc
        
        Service.action.bind(itemModel.action, self)
        
        
        let isFavor = itemModel.favor?.isFavor ?? false
        fillFavor(isFavor: isFavor)
    }
    
    func fillFavor(isFavor: Bool) {
        self.favorView.setIsFavor(flag: isFavor)
        bindFavorStatis(isFavor: isFavor)
    }
    
    // MARK: Favor
    @objc func favorAction(_ sender: Any) {
        guard let itemModel = self.itemModel else {
            return
        }
        
        guard let favor = itemModel.favor else {
            return
        }
        
        if let isFavor = favor.isFavor, isFavor {
            uncollection(favor)
        } else {
            collection(favor)
        }
    }
    
    private func collection(_ favor: FavorModel) {
        guard let isFavor = favor.isFavor,
              let favorId = favor.favorId,
              let favorType = favor.type
        else {
            return
        }
        
        weak var weakSelf = self
        let successBlock: @convention(block) () ->Void =  {
            favor.isFavor = !isFavor
            
            if let flag = favor.isFavor {
                weakSelf?.fillFavor(isFavor: flag)
            }
        }
        let castBlock = unsafeBitCast(successBlock, to: AnyObject.self)
    
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channel.function.adaptor.favor"), object: nil, userInfo: [
            "isFavor": isFavor,
            "id": favorId,
            "type": favorType,
            "callback": castBlock,
        ])
    }
    
    private func uncollection(_ favor: FavorModel) {
        guard let isFavor = favor.isFavor,
              let favorId = favor.favorId,
              let favorType = favor.type
        else {
            return
        }
        
        weak var weakSelf = self
        let successBlock: @convention(block) () ->Void =  {
            favor.isFavor = !isFavor
            
            if let flag = favor.isFavor {
                weakSelf?.fillFavor(isFavor: flag)
            }
        }
        let castBlock = unsafeBitCast(successBlock, to: AnyObject.self)
    
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channel.function.adaptor.favor"), object: nil, userInfo: [
            "isFavor": isFavor,
            "id": favorId,
            "type": favorType,
            "callback": castBlock,
        ])
    }
    
    private func bindFavorStatis(isFavor: Bool) {
        guard let mainStatisModel = itemModel?.action?.report else {
            return
        }
        
        let favorStatisModel = mainStatisModel.appendSpmD(isFavor ? "cancelmark" : "mark", replaceScmD: "other_other")
        Service.statistics.bind(favorStatisModel, favorClickView, .Defalut)
    }
}

