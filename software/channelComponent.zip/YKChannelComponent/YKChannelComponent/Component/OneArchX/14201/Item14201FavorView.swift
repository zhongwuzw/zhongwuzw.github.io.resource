//
//  Item14201FavorView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/7/12.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource

class Item14201FavorView: UIView {
    
    lazy var titleLabel: UILabel = {
        let label = UILabel.init()
        label.backgroundColor = .clear
        label.textAlignment = .center
        label.font = YKNFont.button_text()
        label.textColor = .ykn_brandInfo
        return label
    }()

    override init(frame: CGRect) {
        let width: CGFloat = 60 * YKNSize.yk_icon_size_scale()
        let height: CGFloat = 30 * YKNSize.yk_icon_size_scale()
        
        super.init(frame: CGRect.init(x: 0, y:0 ,width: ceil(width), height: ceil(height)))
        
        clipsToBounds = true
        self.layer.cornerRadius = self.height / 2.0
        
        addSubview(self.titleLabel)
        self.config(mode: 0)
        
        self.backgroundColor = .white
        self.layer.borderColor = UIColor.ykn_brandInfo.withAlphaComponent(0.3).cgColor
        self.layer.borderWidth = 1
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public func setIsFavor(flag: Bool) {
        let mode = flag ? 1 : 0
        config(mode: mode)
    }
    
    func config(mode: Int) {
        titleLabel.backgroundColor = .clear
        
        if mode != 0 {
            titleLabel.text = text(mode: mode)
            titleLabel.frame = self.bounds
            titleLabel.textColor = UIColor.ykn_tertiaryInfo
            self.backgroundColor = UIColor.ykn_elevatedSecondaryBackground
            self.layer.borderWidth = 0
        } else {
            titleLabel.text = text(mode: mode)
            titleLabel.frame = self.bounds
            titleLabel.textColor = UIColor.ykn_brandInfo
            self.backgroundColor = UIColor.ykn_buttonFill
            self.layer.borderColor = UIColor.ykn_border.cgColor
            self.layer.borderWidth = 1
        }
    }
    
    func text(mode: Int) -> String {
        if mode != 0 {
            return "已收藏"
        } else {
            return "收藏"
        }
    }

}
