//
//  Item14201.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/7/12.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource
import YKProtocolSDK

class Item14201: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    weak var displayingItemView: Item14201ContentView?
    
    
    func itemDidInit() {
        DispatchQueue.main.async {
            self.addObservers()
        }
    }
    
    func reuseId() -> String? {
        return "Item14201"
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let totalHeight = 48 * YKNSize.yk_icon_size_scale()
        return ceil(totalHeight)
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14201ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14201ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        
        displayingItemView = itemView
        itemView.fillData(itemModel: itemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    // MARK: - 通知
    func addObservers() {
        // 看单通知
        NotificationCenter.default.addObserver(self, selector: #selector(handleCollectionDidChangeNotification(_:)), name: NSNotification.Name(rawValue: kDYCollectionStatusChangeNotificationName), object: nil)
    }
    
    @objc func handleCollectionDidChangeNotification(_ notification: NSNotification) {
        guard let favor = self.item?.itemModel?.favor else {
            return
        }
        
        guard let userInfo = notification.userInfo else {
            return
        }
        
        guard shouldUpdateFavorModel(userInfo, favor: favor) else {
            return
        }
        
        let relation = userInfo["relation"] as? NSNumber
        favor.isFavor = relation?.boolValue
        
        guard shouldUpdateFavorUI(favor, view: displayingItemView) else {
            return
        }
        
        let isFavor = favor.isFavor ?? false
        displayingItemView?.fillFavor(isFavor: isFavor)
    }
    
    func shouldUpdateFavorModel(_ userInfo: [AnyHashable: Any], favor: FavorModel) -> Bool {
        guard let favorId = favor.favorId else {
            return false
        }
        
        if let showId = userInfo["showid"] as? String {
            if showId == favorId {
                return true
            }
        }
        
        if let sids = userInfo["sid"] as? String {
            let sidArr = sids.components(separatedBy: ",")
            if sidArr.count > 0 && sidArr.contains(favorId) {
                return true
            }
        }
        
        return false
    }
    
    func shouldUpdateFavorUI(_ favor: FavorModel, view: Item14201ContentView?) -> Bool {
        guard let view = view else {
            return false
        }
        
        guard let favorInView = view.itemModel?.favor else {
            return false
        }
        
        if favor.favorId == favorInView.favorId, favor.type == favorInView.type {
            return true
        }
        
        return false
    }
    
}

