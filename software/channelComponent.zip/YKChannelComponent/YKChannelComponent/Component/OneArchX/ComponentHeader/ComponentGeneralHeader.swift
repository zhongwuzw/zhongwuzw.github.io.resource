//
//  ComponentGeneralHeader.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/29.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku
import YKResponsiveLayout

class ComponentGeneralHeader: NSObject , ItemDelegate {
    
    var itemWrapper: ItemWrapper?

    var curHeaderTop: CGFloat = 0
    func itemDidInit() {
        
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }

    /// item高度
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        if self.item?.getComponent()?.compModel?.type == "18231" {
            return 31
        }
        self.curHeaderTop = headerTop()
        return (hasSubtitle() ? N_TITLE_VIEW_HEIGHT() : N_TITLE_VIEW_HEIGHT_NO_SUBTITLE()) + curHeaderTop
    }

    /// 初始化item view
    func createView(_ itemSize: CGSize) -> UIView {
        return ComponentGeneralHeaderView.init(frame: CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height - curHeaderTop))
    }

    /// 复用
    func reuseView(itemView: UIView) {
        if let itemView = itemView as? ComponentGeneralHeaderView {
            itemView.height = hasSubtitle() ? N_TITLE_VIEW_HEIGHT() : N_TITLE_VIEW_HEIGHT_NO_SUBTITLE()
            itemView.top = self.curHeaderTop
            itemView.fillData(self.item?.getComponent())
        }
    }
    
    func hasSubtitle() -> Bool {
        guard let model = self.item?.getComponent()?.model as? BaseComponentModel else {
            return false
        }
        if let subtitle = model.subtitle, subtitle.count > 0 {
            return true
        } else if let titleImg = model.titleImg, titleImg.count > 0 {
            return true
        } else {
            return false
        }
    }
    
    func N_TITLE_VIEW_HEIGHT() -> CGFloat {
        var height = CGFloat(ceil(YKNGap.youku_maintitle_subtitle_spacing() + YKNFont.height(with: YKNFont.module_headline(), lineNumber: 1) + YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1) + 11))
        
        if ykrl_isResponsiveLayout() {
            height += 3 // 20221129版本 目标值上下距离12，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        
        return height
    }
    
    func N_TITLE_VIEW_HEIGHT_NO_SUBTITLE() -> CGFloat {
        var height = CGFloat(ceil(YKNGap.youku_maintitle_subtitle_spacing() + YKNFont.height(with: YKNFont.module_headline(), lineNumber: 1) + 6))
        
        if ykrl_isResponsiveLayout() {
            height += 3 // 20221129版本 目标值上下距离12，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        
        return height
    }
    
    private func headerTop() -> CGFloat {
        var headerTop: CGFloat = 0
        if let type = self.item?.getComponent()?.model?.type, type == "14035" {
            if let config = self.item?.getPage()?.pageContext?.concurrentDataMap["14035_ConfigForDetailPage"] as? [String: CGFloat] {
                if let configTop = config["HeaderHeight"] {
                    headerTop = configTop
                }
                
                print("[14035]2 top:\(String(describing: config["HeaderHeight"])))")
            } else {
                headerTop = YKNGap.youku_module_margin_top()
            }
        }
        return headerTop
    }
}
