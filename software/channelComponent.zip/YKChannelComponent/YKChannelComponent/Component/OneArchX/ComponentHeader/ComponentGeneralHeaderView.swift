//
//  ComponentGeneralHeaderView.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/29.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import YKSCiPhoneService

class ComponentGeneralHeaderView: AccessibilityView {

    let bicIconWidth:CGFloat = 38.0
    
    lazy var bigIconImageView: UIImageGIFView = {
        let view = UIImageGIFView(frame: CGRect(x: YKNGap.youku_margin_left(),
                                                y: 0,
                                                width: bicIconWidth * ((YKNSize.yk_icon_size_scale() - 1.0) / 2.0 + 1.0),
                                                height: bicIconWidth * ((YKNSize.yk_icon_size_scale() - 1.0) / 2.0 + 1.0)))
        view.contentMode = .scaleAspectFill
        view.layer.cornerRadius = view.height / 2.0
        view.clipsToBounds = true
        return view
    }()
    
    lazy var titleArrow: UIImageView = {
        let view = UIImageView(frame: CGRect(x: 0, y: 0, width: 12 * YKNSize.yk_icon_size_scale(), height: 12 * YKNSize.yk_icon_size_scale()))
        view.image = UIImage.init(named: "ykn_more_btn")?.withRenderingMode(.alwaysTemplate)
        view.right = self.width
        view.centerY = self.height / 2.0
        return view
    }()

    lazy var titleImgView: UIImageGIFView = {
        let imageSize = 20 * YKNSize.yk_icon_size_scale()
        let view = UIImageGIFView(frame: CGRect(x: 18, y: 0.5, width: imageSize, height: imageSize))
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.isHidden = true
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel(frame: CGRect(x: 18, y: 0, width: self.width - 36 - bicIconWidth, height: YKNFont.height(with: YKNFont.module_headline_weight(.medium), lineNumber: 1)))
        view.font = YKNFont.module_headline_weight(.medium)
        view.lineBreakMode = .byTruncatingTail
        view.accessibilityTraits = .header
        return view
    }()

    lazy var subtitleLabel: UILabel = {
        let view = UILabel(frame: CGRect(x: 18, y: 22, width: self.titleLabel.width, height: YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)))
        view.font = YKNFont.posteritem_subhead()
        view.lineBreakMode = .byTruncatingTail
        return view
    }()

    lazy var moreLabel: UILabel = {
        let view = UILabel(frame: CGRect(x: 18, y: 22, width: self.titleLabel.width, height: YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)))
        view.font = YKNFont.posteritem_subhead()
        view.text = "更多"
        view.textAlignment = NSTextAlignment.right
        view.frame = CGRect(x: self.width - 9 - 12 - 30, y: 0, width: 30, height: YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1))
        view.centerY = self.titleLabel.centerY
        return view
    }()
    
    //MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        createSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        createSubviews()
    }
    
    func createSubviews() {
        addSubview(bigIconImageView)
        addSubview(titleImgView)
        addSubview(titleLabel)
        addSubview(subtitleLabel)
        addSubview(titleArrow)
        addSubview(moreLabel)
    }
    
    func fillData(_ component:IComponent?) {
        guard let model = component?.model as? BaseComponentModel else {
            return
        }
        self.backgroundColor = .clear
        self.titleLabel.text = model.title
        self.subtitleLabel.text = model.subtitle
        self.moreLabel.text = model.desc
        self.moreLabel.isHidden = (model.action == nil)
        self.titleArrow.isHidden = self.moreLabel.isHidden

        //font
        self.titleLabel.font = YKNFont.module_headline_weight(.medium)
        self.subtitleLabel.font = YKNFont.posteritem_subhead()
        self.moreLabel.font = YKNFont.posteritem_subhead()

        let bigIcon = model.titleImg ?? ""
        if bigIcon.count > 0 {
            self.bigIconImageView.isHidden = false
            self.bigIconImageView.sd_setImage(with: URL.init(string: bigIcon))
        } else {
            self.bigIconImageView.isHidden = true
        }

        let icon = model.icon ?? ""
        if icon.count > 0 {
            self.titleImgView.isHidden = false
            self.titleImgView.sd_setImage(with: URL.init(string: icon))
        } else {
            self.titleImgView.isHidden = true
        }

        if component?.compModel?.type == "18231" {
            titleLabel.font = UIFont.boldSystemFont(ofSize: 14)
            self.titleImgView.top = (title_14035_TITLE_HEIGHT() - 12) / 2.0
            self.titleImgView.width = 20
            self.titleImgView.sd_setImage(with: URL.init(string: icon)) {[weak self] img, er, ctype, url in
                guard let self = self else { return }
                if let image = img, image.size.height > 0 {
                    self.titleImgView.frame = CGRect(x: self.titleImgView.left, y: self.titleImgView.top, width: 12 * image.size.width / image.size.height, height: 12)
                    self.updateFrameWithContext()
                }
            }
        }
        
        self.updateFrameWithContext()

        //绑定跳转
        Service.action.bind(model.action, self)

        //氛围
        titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor:model.scene?.sceneCardHeaderTitleColor())
        subtitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: model.scene?.sceneSubTitleColor())
        moreLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: model.scene?.sceneCardHeaderKeywordColor())
        titleArrow.tintColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: model.scene?.sceneCardHeaderArrowColor())
    }
    
    func title_14035_TITLE_HEIGHT() -> CGFloat {
        return YKNFont.height(with:YKNFont.module_headline_weight(.medium), lineNumber: 1)
    }
    
    func updateFrameWithContext() {
        let descWidth: CGFloat = 30 //CGFloat(context.scDouble(forKey: "yksc.data.comp.prop.desc.width"))
        var x:CGFloat = 0 //context.youku_margin_left()

        if !self.bigIconImageView.isHidden {
            self.bigIconImageView.left = 0 //context.youku_margin_left()
            x = self.bigIconImageView.right + 9
        }

        self.titleImgView.left = x

        if !self.titleImgView.isHidden {
            let iconWidth: CGFloat = 24.0

            self.titleLabel.frame = CGRect(x: self.titleImgView.right + 6,
                                           y: 0,
                                           width: self.width - (descWidth + 9) - (iconWidth + 9),
                                           height: self.title_14035_TITLE_HEIGHT())
        } else {
            self.titleLabel.frame = CGRect(x: x,
                                           y: 0,
                                           width: self.width - x - (descWidth + 9),
                                           height: self.title_14035_TITLE_HEIGHT())
        }

        self.subtitleLabel.frame = CGRect(x: self.titleLabel.left,
                                          y: self.titleLabel.bottom + YKNGap.youku_maintitle_subtitle_spacing(),
                                          width: self.titleLabel.width,
                                          height: self.subtitleLabel.height)
        
        self.moreLabel.frame = CGRect(x: self.width - descWidth,
                                      y: 0,
                                      width: descWidth,
                                      height: YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1))
        self.moreLabel.centerY = self.titleLabel.centerY

        if !self.moreLabel.isHidden {
            self.titleArrow.centerY = self.moreLabel.centerY
            self.titleArrow.right = self.width

            self.moreLabel.sizeToFit()
            self.moreLabel.height = 20
            self.moreLabel.width = self.moreLabel.width + YKNGap.dim_5() * 2
            self.moreLabel.right = self.titleArrow.left
            self.moreLabel.centerY = self.titleLabel.centerY
        }
    }
}
