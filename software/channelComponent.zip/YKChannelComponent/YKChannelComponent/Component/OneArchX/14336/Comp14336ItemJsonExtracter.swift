//
//  Comp14336ItemJsonExtracter.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/3/1.
//  Copyright © 2024 Youku. All rights reserved.
//  新轮播数据处理

import Foundation
import OneArch
import XAdSDK
import YKSCService
import NovelAdSDK
import YKChannelPage

protocol Comp14336ItemJsonExtracterDelegate: NSObjectProtocol {
    func slider14336ReloadData(context: OADLunboContext)
}

@objcMembers
open class Comp14336ItemJsonExtracter: DefaultItemJsonExtracter {
    weak var component: IComponent?
    lazy var controller : OADLunboController = {
        let c = OADLunboController()
        return c
    } ()
    
    weak var delegate: Comp14336ItemJsonExtracterDelegate?
    
    // MARK: - ItemJsonExtracter
    
    open override func getItemsJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error> {
       return self.getValidJson(componentJson: componentJson, component: component)
    }
    
    open func getValidJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error>{
        var originItemsJson: [[String: Any]] = [[String: Any]]()
        if let cmsItemsJson = componentJson?["nodes"] as? [[String: Any]], cmsItemsJson.count > 0 {
            originItemsJson = cmsItemsJson
        }
        
        let usedOriginalNodes = judgeValidNodes(originItemsJson)
        let isPreload = isCacheData(componentJson)
        NSLog("[新轮播] 首页缓存状态:\(isPreload)")
        let validNodes = validNodes(nodes: usedOriginalNodes, isCache: isPreload)
        if !isPreload {
            ayncRequestAd(nodes: validNodes)
        }
        return .success(validNodes)
    }
    
    open func validNodes(nodes: [[String: Any]], isCache: Bool) -> [[String: Any]] {
        let context = OADLunboContext()
        context.jsonArray = nodes
        context.isCache = isCache
        let result = self.controller.validLunboAd(context)
        let respArr = result?.jsonArray as? [[String: Any]]
        YKSCScreenLogUtil.printLog("新轮播 数据 广告sdk校验前:\(nodes.count) 校验后:\(respArr?.count ?? 0) 缓存:\(isCache)", color: .purple)
        if let arr = respArr, arr.count > 0 {
            return SliderNewUtil.replaceItemsSpmD(arr)
        }
        
        return nodes
    }
    
    open func ayncRequestAd(nodes: [[String: Any]]) {
        let context = OADLunboContext()
        context.jsonArray = nodes
        YKSCScreenLogUtil.printLog("新轮播 数据 广告sdk请求开始 原始坑位数:\(nodes.count)", color: .purple)
        weak var weakSelf = self
        self.controller.asyncRequestAd(context) { resp, error in
            guard let respArr = resp.jsonArray as? [[String: Any]] , respArr.count > 0 else {
                YKSCScreenLogUtil.printLog("新轮播 数据 广告sdk请求回调 请求失败", color: .purple)
                return
            }
            
            YKCCUtil.runOnMainThread {
                weakSelf?.delegate?.slider14336ReloadData(context: resp)
            }
        }
    }
    
    open func isPageInPreload() -> Bool {
        if let page = self.component?.getPage()  {
            let state = page.dataState
            if state == .cache || state == .default {
                return true
            }
        }

        return false
    }
    
    func isCacheData(_ componentJson: [String: Any]?) -> Bool {
        if !disableHomeCacheFlag() {
            return YKChannelPageUtils.isCacheNode(componentJson) || isPageInPreload()
        }
        
        return isPageInPreload()
    }
    
    func judgeValidNodes(_ nodes: [[String : Any]]) -> [[String: Any]] {
        var tempNodes = [[String: Any]]()
        for (index, node) in nodes.enumerated() {
            if checkNodeIsValid(node) {
                tempNodes.append(node)
            } else {
                YKSCScreenLogUtil.printLog("新轮播 数据 校验cms数据 index:\(index) 不合法", color: .purple)
            }
        }
        return tempNodes
    }
    
    // 校验数据合法，非内容坑需有ad字段
    func checkNodeIsValid(_ node: [String: Any]) -> Bool {
        let isContentType = getTypeIntValue(node["type"]) == 14336
        if !isContentType {
            if let data = node["data"] as? [String: Any], data.count > 0, let ad = data["ad"] as? [String: Any], ad.count > 0 {} else {
                return false
            }
        }
        
        return true
    }
}
