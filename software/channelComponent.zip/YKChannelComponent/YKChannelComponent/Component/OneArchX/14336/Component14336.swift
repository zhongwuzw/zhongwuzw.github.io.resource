//
//  Component14336.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/2/28.
//  Copyright © 2024 Youku. All rights reserved.
//  首页新轮播，基于14204实现

import Foundation
import UIKit
import OneArch
import OneArchSupport
import YoukuResource
import YKHome
import YKSCService
import YKResponsiveLayout
import OneArchSupport4Youku
import YKChannelPage
import YKModeConfigFramework
import YoukuAnalytics
import YKChannel
import NovelAdSDK
import orange

let kNew14336HwRatio = 9.0 / 16.0
let kNew14336AppleAdRatio = 16.0 / 9.0

@objcMembers
class Component14336: Component14313Delegate, Comp14336ItemJsonExtracterDelegate {
    
    lazy var jsonExtracter: Comp14336ItemJsonExtracter = {
        let extracter = Comp14336ItemJsonExtracter()
        extracter.delegate = self
        extracter.component = self.component
        return extracter
    } ()
    
    var adResponseItems: [IItem]? //广告返回数据生成item
    
    override func componentDidInit() {
        (self.component?.compModel as? HomeComponentModel)?.compHwRatio = kNew14336HwRatio
        (self.component?.compModel as? HomeComponentModel)?.appleADParseRatio = kNew14336AppleAdRatio
        super.componentDidInit()
    }
    
    override func getItemJsonExtracter() -> ItemJsonExtracter? {
        return self.jsonExtracter
    }
    
    override func shouldHandle14016Ad() -> Bool { //屏蔽14016老广告逻辑
        return false
    }
    
    override func loadEventHandlers() -> [ComponentEventHandler]? {
        var array = super.loadEventHandlers()
        self.bathAdsHandler?.isNewSlider = true
    
        if removeLunboPlayerHandler() {
            array?.removeAll(where:{ $0 is LunboPlayerEventHandler})
        }
        return array
    }
    
    override func reuseId() -> String? { //大刷不复用轮播图，避免异常case
        var reuseId = "newSlider" + YKCCUtil.objAddress(self)
        let hasAdv = (self.compModel as? HomeComponentModel)?.hasAppleAD ?? false
        if ykrl_isResponsiveLayout() && hasAdv {
            reuseId += "appleAD"
        }
        return reuseId
    }
    
    override func createView(_ itemSize: CGSize) -> UIView {
        let itemView = super.createView(itemSize)
        if let sliderView = itemView as? SliderView {
            sliderView.enableCustomMode = false
            sliderView.collectionViewBg.clipsToBounds = true //容器设置圆角
            sliderView.kSectionMAX = 2
            sliderView.collectionView.clipsToBounds = true //滚动只在frame区显示
            sliderView.customPageViewPadding = UIEdgeInsets.init(top: 0, left: 0, bottom: 14, right: 12)
            sliderView.disableScrollWhenOneData = true
            sliderView.shouldJudgeScrollWhenTimerInvoked = true//保护逻辑（timer触发时，多一次判断）
        }
        clearWhenCreateSlider()
        return itemView
    }
    
    func clearWhenCreateSlider() {
        self.bathAdsHandler?.resetState()
        self.sliderViewPreviousPageIndex = -1
        self.preItemView = nil
    }
    
    override func isEnableCustomMode() -> Bool {
        return false
    }
    
    override func leftMargin() -> CGFloat {
        return YKNGap.youku_margin_left()
    }
    
    override func rightMargin() -> CGFloat {
        return YKNGap.youku_margin_right()
    }
    
    override public func itemSpacing() -> CGFloat {
        return 0
    }
    
    override public func itemSideMargin() -> CGFloat {
        return 0
    }
    
    override public func containerSideExtend() -> CGFloat {
        return 0
    }
    
    override func containerCornerRadius() -> CGFloat {
        return YKNCorner.radius_secondary_medium()
    }
    
    override func itemContentMargin(index: Int, originItemSize: CGSize) -> CGFloat {
        return 0
    }
    
    override func convertSupportRatio(_ ratio: CGFloat) -> CGFloat {
        return 16.0 / 9.0
    }
    
    override func setupPluginConfigs() {
        var allDatas = [Any]()
        
        if let adResponseItems = self.adResponseItems, adResponseItems.count > 0 { //优先取广告返回数据
            for context in adResponseItems {
                allDatas.append(context)
            }
        } else if let items = self.component?.getItems() {
            for context in items {
                allDatas.append(context)
            }
        }
      
        self.allDatas = allDatas
    }
    
    deinit {
        guard let sliderView = self.sliderView else {
            return
        }
        
        YKCCUtil.runOnMainThread {
            sliderView.removeFromSuperview()
        }
    }
    
    override func createItemView(index: Int, itemSize: CGSize) -> UIView {
        let frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
        var itemView: UIView?
        if index < self.allDatas.count {
            let data = self.allDatas[index]
            if let item = data as? IItem {
                if item.model?.type == "14314" { //广告卡
                    itemView = Item14314NewAdContentView(frame: frame)
                    YKSCScreenLogUtil.printLog("[新轮播] create index:\(index) 14314", color: .red)
                }  else if item.model?.type == "14336" { //内容卡，等待广告替换
                    itemView = Comp14204ContentView(frame: frame)
                    YKSCScreenLogUtil.printLog("[新轮播] create index:\(index) 14336", color: .red)
                }
            }
        }
        if let itemView = itemView {
            itemView.clipsToBounds = true
            return itemView
        } else {
            return UIView.init(frame: CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        }
    }
    
    override func _reuseItemView(index: Int, itemView: UIView) {
        if let itemView = itemView as? Item14314NewAdContentView { //新轮播，广告内容卡
            if index < self.allDatas.count, let item = self.allDatas[index] as? IItem {
                YKSCScreenLogUtil.printLog("[新轮播] reuse index:\(index) 14314", color: .red)
                itemView.fillData(item)
                itemView.adCotentView?.delegate = self.bathAdsHandler
                itemView.adCotentView?.feedbackProtocol = self.bathAdsHandler
                
                Service.statistics.bind(item.itemModel?.action?.report, itemView, .OnlyExposure) //产品需求，广告坑发一次自动曝光
            }
        } else {
            super._reuseItemView(index: index, itemView: itemView)
        }
    }
    
    override func content14204ViewTitleRightMagin(_ itemCount: Int) -> CGFloat {
        return CGFloat((itemCount - 1) * 6 + 9 + 12 + 12)
    }
    
    override func is14313Lunbo() -> Bool {
        return false
    }
    
    override func shouldDisableSliderScroll() -> Bool {
        var flag = super.shouldDisableSliderScroll()
        if !flag && !disableUseBatchAdHandlerPlayFlag() {
            flag = self.bathAdsHandler?.currentIsPlaying() ?? false //保护逻辑，判断一次当前正在播视频(允许orange关闭)
            NSLog("[新轮播] handler 判断禁止滚动:\(flag)")
        }
        return flag
    }
    
    func disableUseBatchAdHandlerPlayFlag() -> Bool {
        let orangeInfo = Orange.getGroupConfig(byGroupName: "yksc_config")
        return YKCCUtil.getBoolValue(orangeInfo?["newSlider14336_diablePlayFlag"]) ?? false
    }
    
    // MARK: - Comp14336ItemJsonExtracterDelegate
    
    func slider14336ReloadData(context: OADLunboContext) {
        let _jsonArr = context.jsonArray as? [[String: Any]]
        let _changedIndexArr = context.changedIndxArray as? [String]
        guard let jsonArr = _jsonArr, jsonArr.count > 0, let items = self.component?.getItems() , let changedIndexArr = _changedIndexArr else {
            return
        }
        
        let replacejsons = SliderNewUtil.replaceItemsSpmD(jsonArr)
        
        var tempItems = [IItem]()
        for (index, aJson) in replacejsons.enumerated() {
            let isReplace = changedIndexArr.contains("\(index)")
            NSLog("[新轮播] 广告回调 index:\(index) 替换:\(isReplace)")
            if !isReplace { //不替换用原始域对象
                if index < items.count {
                    NSLog("[新轮播] 广告回调 index:\(index) 不替换 使用原始域对象")
                    tempItems.append(items[index])
                    continue
                }
            }
            if let item = self.component?.getItemManager()?.createItem(aJson) {
                NSLog("[新轮播] 广告回调 index:\(index) 替换 使用创建域对象")
                tempItems.append(item)
            }
        }
        
        if tempItems.count == 0 {
            NSLog("[新轮播] 广告回调 创建items为空")
            return
        }
        
        self.adResponseItems = tempItems
        
        self.setupPluginConfigs()
        NSLog("[新轮播] 广告回调 创建items成功 count:\(tempItems.count) 开始刷新轮播图")
        self.reloadData()
    }
}

extension Component14336 {
    func removeLunboPlayerHandler() -> Bool {
        if let orangeDict = Orange.getGroupConfig(byGroupName: "YKChannelSTFeed") {
            if let openValue = orangeDict["removeLunboPlayerHandler14336"] as? String {
                if openValue == "1" {
                    return false
                }
            }
        }
        return true
    }
}
