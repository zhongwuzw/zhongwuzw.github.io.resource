//
//  Comp12139.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/12/7.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Component12139: NSObject, ComponentDelegate {
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {}

    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseComponentModel.self as? T.Type
    }

    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }

    func columnCount() -> CGFloat {
        return 1
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

    func reuseId() -> String? {
        return nil
    }
    
    public func layoutConfig() -> ComponentLayoutConfig {
        let config = ComponentLayoutConfig()
        return config
    }
}

class Item12139: NSObject, ItemDelegate {
    var itemWrapper: OneArch.ItemWrapper?
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func itemDidInit() {
        
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
    }

    
    func reuseView(itemView: UIView) {
        self.item?.itemModel?.dataCenterMap["dataIsBinded"] = true
        
        //埋点（240123，补发内容埋点）
        Service.statistics.bind(item?.itemModel?.action?.report, itemView, .OnlyExposure)
//        NSLog("[feed ad] 12139 report spm:\(item?.itemModel?.action?.report?.spm) scm:\(item?.itemModel?.action?.report?.scm)")
    }

}

