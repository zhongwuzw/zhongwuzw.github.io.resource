//
//  Item14098ReserveView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/4/12.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource

class Item14098ReserveView: UIView {

    // MARK: Property
    lazy var textLabel: UILabel = {
        let view = UILabel.init(frame: self.bounds)
        view.textAlignment = .center
        view.font = YKNFont.mediumfont_size_middle4()
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        clipsToBounds = true
        layer.cornerRadius = bounds.height / 2
        
        addSubview(textLabel)
    }
    
    func fill(isReserve: Bool) {
        textLabel.text = getText(isReserve: isReserve)
        updateUIStyle(isReserve: isReserve)
    }
    
    private func getText(isReserve: Bool) -> String {
        if isReserve {
            return "已预约"
        } else {
            return "预约"
        }
    }
    
    private func updateUIStyle(isReserve: Bool) {
        if isReserve {
            backgroundColor = UIColor.ykn_primaryGroupedBackground
            textLabel.textColor = UIColor.ykn_tertiaryInfo
        } else {
            backgroundColor = UIColor.ykn_secondaryBackground
            textLabel.textColor = UIColor.ykn_primaryInfo
        }
    }

}
