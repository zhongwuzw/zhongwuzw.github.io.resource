//
//  Item14098ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/4/11.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import YKProtocolSDK
import DYKURLRouter

class Item14098ContentView: UIView {

    //MARK: - Property
    weak var itemModel: HomeItemModel?
    
    lazy var imageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .ykn_primaryFill
        imageView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        imageView.layer.masksToBounds = true
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_primaryInfo
        view.font = Item14098ContentView.titleLabelFont()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var reasonList: ReasonListView = {
        let view = ReasonListView.init()
        return view
    }()
    
    lazy var descLabelA: UILabel = {
        return createDescLabel()
    }()
    
    lazy var descLabelB: UILabel = {
        return createDescLabel()
    }()
    
    lazy var moreDescLabel: UILabel = {
        return createDescLabel()
    }()

    lazy var actorRoleLabel: UILabel = {
        let label = createDescLabel()
        label.textColor = UIColor.ykn_recommend_info
        return label
    }()
    
    func createDescLabel() -> UILabel {
        let view = UILabel()
        view.textColor = .ykn_secondaryInfo
        view.font = Item14098ContentView.descLabelFont()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }
    
    var descLabels: [UILabel] {
        return [descLabelA, descLabelB]
    }
    
    lazy var playLabel: UILabel = {
        let view = UILabel.init(frame: CGRect.init(origin: .zero, size: CGSize.init(width: 60, height: 30)))
        view.backgroundColor = .ykn_secondaryBackground
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.mediumfont_size_middle4()
        view.textAlignment = .center
        view.text = "播放"
        
        view.layer.cornerRadius = view.bounds.height / 2
        view.layer.masksToBounds = true
        return view
    }()
    
    lazy var reserveView: Item14098ReserveView = {
        let view = Item14098ReserveView.init(frame: CGRect.init(origin: .zero, size: CGSize.init(width: 60, height: 30)))
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(reserveAction(_:)))
        view.addGestureRecognizer(tapGesture)
        
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(imageView)
        
        addSubview(titleLabel)
        addSubview(reasonList)
        addSubview(descLabelA)
        addSubview(descLabelB)
        addSubview(moreDescLabel)
//        addSubview(playLabel)
        addSubview(reserveView)
//        addSubview(actorRoleLabel)
    }
    
    func fillModel(_ itemModel: HomeItemModel, layout: OneArchSupport4Youku.LayoutModel) {
        self.itemModel = itemModel
        relayoutIfNeeded(layout)
        
        //填充图片
        var imgPath = itemModel.gifImg
        if imgPath == nil {
            imgPath = itemModel.img
        }
        imageView.ykn_setImage(withURLString: imgPath, module: "nodepage", imageSize: .zero, parameters: [String: Any](), completed: nil)
        Service.mark.attach(itemModel.mark, toView: imageView, layout: layout.mark)
        Service.summary.attach(itemModel.summary, toView: imageView, layout: layout.summary)
        
        //填充标题 （第一行文案）
        titleLabel.text = itemModel.title
        
        //填充推荐理由标签 （第二行文案）
//        Service.reasons.attach(itemModel.reasons, toView: self, layouts: layout.reasons)
        
        if let reasonList = itemModel.reasonList, reasonList.count > 0 {
            self.reasonList.fillData(itemModel.reasonList, maxWidth: layout.reasonList?.renderRect.width ?? 0)
            self.reasonList.isHidden = false
        } else {
            self.reasonList.isHidden = true
        }
        
        //填充desc
        moreDescLabel.text = itemModel.rankReason
        if let desc = itemModel.desc {
            let descParts = desc.components(separatedBy: "\n")
            for (i, aLabel) in descLabels.enumerated() {
                if i < descParts.count {
                    aLabel.isHidden = false
                } else {
                    aLabel.isHidden = true
                    continue
                }
                
                aLabel.text = descParts[i]
            }
        }
        
        //填充预约
        if let reserve = itemModel.reserveModel {
            playLabel.isHidden = true
            reserveView.isHidden = false
            
            reserveView.fill(isReserve: reserve.isReserve)
            bindReserveStatis(isFavor: reserve.isReserve)
        } else {
            playLabel.isHidden = false
            reserveView.isHidden = true
        }
        
        //演员角色信息
        actorRoleLabel.text = itemModel.actorRoleInfo
        
        //绑定跳转、埋点
        OneArchSupport.Service.action.bind(itemModel.action, self)
    }
    
    private func relayoutIfNeeded(_ layout: OneArchSupport4Youku.LayoutModel) {
        imageView.frame = layout.cover?.renderRect ?? CGRect.zero
        titleLabel.frame = layout.title?.renderRect ?? CGRect.zero
        reasonList.frame = layout.reasonList?.renderRect ?? CGRect.zero
        let extendExtra = layout.extendExtra
        if let descA = extendExtra?["descA"] as? TextLayoutModel {
            descLabelA.frame = descA.renderRect
        } else {
            descLabelA.frame = CGRect.zero
        }
        
        if let descB = extendExtra?["descB"] as? TextLayoutModel {
            descLabelB.frame = descB.renderRect
        } else {
            descLabelB.frame = CGRect.zero
        }
        
        if let moreDesc = extendExtra?["moreDesc"] as? TextLayoutModel {
            moreDescLabel.frame = moreDesc.renderRect
        } else {
            moreDescLabel.frame = CGRect.zero
        }
        
        if let play =  extendExtra?["play"] as? TextLayoutModel {
            playLabel.frame = play.renderRect
            reserveView.frame = play.renderRect
        } else {
            playLabel.frame = CGRect.zero
            reserveView.frame = CGRect.zero
        }
        
        if let actorRoleInfo = extendExtra?["actorRoleInfo"] as? TextLayoutModel {
            actorRoleLabel.frame = actorRoleInfo.renderRect
        } else {
            actorRoleLabel.frame = CGRect.zero
        }
    }
    
    // MARK: Reserve
    @objc func reserveAction(_ sender: Any) {
        guard let reserveModel = itemModel?.reserveModel else {
            return
        }
        
        if reserveModel.isReserve {
            unreserve(reserveModel)
        } else {
            reserve(reserveModel)
        }
    }
    
    private func reserve(_ reserve: ReserveModel) {
        guard let dy = DYKServiceManager.sharedInstance().service(forProtocolName: "YKDingYueProtocol") as? YKDingYueProtocol else {
            return
        }
        
        guard let params = dy.generateAddReservationParams?() else {
            return
        }
        
        let freeBizId = reserve.bizId
        let freeContentType = reserve.reservationType
        
        params.contentId = reserve.rid
        params.src = "NODE PAGE"
        
        if let freeBizId = freeBizId, !freeBizId.isEmpty,
           let freeContentType = freeContentType, !freeContentType.isEmpty {
            params.freeBizId = freeBizId
            params.freeContentType = freeContentType
        } else {
            params.bizId = DYBizId.SHOW_PRE_OR_OL
            params.contentType = DYContentType.RESERVE_SHOW
        }
    
        dy.addReservation?(params, finished: { _, _, _ in
            //do nothing
        })
    }
    
    private func unreserve(_ reserve: ReserveModel) {
        guard let dy = DYKServiceManager.sharedInstance().service(forProtocolName: "YKDingYueProtocol") as? YKDingYueProtocol else {
            return
        }
        
        guard let params = dy.generateCancelReservationParams?() else {
            return
        }
        
        let freeBizId = reserve.bizId
        let freeContentType = reserve.reservationType
        
        params.contentId = reserve.rid
        
        if let freeBizId = freeBizId, !freeBizId.isEmpty,
           let freeContentType = freeContentType, !freeContentType.isEmpty {
            params.freeBizId = freeBizId
            params.freeContentType = freeContentType
        } else {
            params.bizId = DYBizId.SHOW_PRE_OR_OL
            params.contentType = DYContentType.RESERVE_SHOW
        }
        
        dy.cancelReservation?(params, finished: { _, _, _ in
            //do nothing
        })
    }
    
    // MARK: 默认尺寸
    class func viewHeight(_ width: CGFloat) -> CGFloat {
        if ykrl_isResponsiveLayout() {
            return floor(112.0 * 1.5) //iPad 版为iPhone原始大小的 1.5倍（固定值）
        } else {
            return floor(112.0 * YKNSize.yk_icon_size_scale()) //取左侧图片高度
        }
    }
    
    // MARK: 字体
    class func titleLabelFont() -> UIFont {
        let font = YKNFont.display_s_weight(.medium)
        return font
    }
    
    class func descLabelFont() -> UIFont {
        let font = YKNFont.posteritem_subhead()
        return font
    }
    
    private func bindReserveStatis(isFavor: Bool) {
        guard let mainStatisModel = itemModel?.action?.report else {
            return
        }
        
        let reserveStatisModel = mainStatisModel.appendSpmD(isFavor ? "cancelreserve" : "reserve", replaceScmD: "other_other")
        Service.statistics.bind(reserveStatisModel, reserveView, .Defalut)
    }

}
