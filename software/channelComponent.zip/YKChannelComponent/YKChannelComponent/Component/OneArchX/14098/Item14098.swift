//
//  Item14098.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/4/11.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKProtocolSDK
import OneArchSupport
import OneArchSupport4Youku

class Item14098: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    weak var displayingItemView: Item14098ContentView?
    
    func itemDidInit() {
        DispatchQueue.main.async {
            self.addObservers()
        }
        
        // 使得标签支持图片样式
        if let reasons = item?.itemModel?.reasons {
            for (index, reason) in reasons.enumerated() {
                if let img = reason.img, img.isEmpty == false {
                    item?.itemModel?.reasons?[index].imgEnabled = true
                }
            }
        }
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeItemModel.self as? T.Type
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let itemHeight: CGFloat = Item14098ContentView.viewHeight(itemWidth)
        estimatedLayout(CGSize.init(width: itemWidth, height: itemHeight))
        
        return itemHeight
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14098ContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14098ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? HomeItemModel else {
            return
        }
        guard let layout = self.item?.layout else {
            return
        }

        displayingItemView = itemView
        itemView.fillModel(itemModel, layout: layout)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func estimatedLayout(_ size: CGSize) {
        guard let itemModel = self.item?.model as? HomeItemModel else {
            return
        }
        
        guard let layoutModel = self.item?.layout else {
            return
        }
        
        if layoutModel.boundingSize == size {
            return //重复计算跳过
        }
        
        layoutModel.boundingSize = size
        layoutModel.renderRect = CGRect.init(origin: .zero, size: size)
//        layoutModel.extendExtra = [String: Any]()
        
        var extendExtra = [String: Any]()
        //封面图
        let cover = ImageLayoutModel()
        var sizeScale: CGFloat = 1.0
        if ykrl_isResponsiveLayout() {
            sizeScale = 1.5 //iPad 版为iPhone原始大小的 1.5倍（固定值）
        } else {
            sizeScale = YKNSize.yk_icon_size_scale()
        }
        let coverWidth = floor(84.0 * sizeScale)
        let coverHeight = floor(112.0 * sizeScale)
        cover.renderRect = CGRect.init(x: 0, y: 0, width: coverWidth, height: coverHeight)
        layoutModel.cover = cover
        
        //封面图角标
        if let mark = itemModel.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: cover.renderRect.size)
            layoutModel.mark = layout
        }
        
        //封面图腰封
        if let summary = itemModel.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize: cover.renderRect.size)
            layoutModel.summary = layout
        }
        
        let textLeft: CGFloat = coverWidth + (ykrl_isResponsiveLayout() ? 12.0 : 9.0)
        var textRight: CGFloat = size.width - 60.0 - 9.0
        if itemModel.hidePlayButton {
            textRight = size.width
        }
        
        let textWidthMax: CGFloat = textRight - textLeft
        
        //主标题
        let title = TextLayoutModel()
        title.font = Item14098ContentView.titleLabelFont()
        title.lineNumber = 1
        
        let titleHeight: CGFloat = YKNFont.height(with: title.font, lineNumber: title.lineNumber)
        title.renderRect = CGRect.init(x: textLeft, y: 0, width: textWidthMax, height: titleHeight)
        layoutModel.title = title
        
        var descRowCount: Int = 0
        if let desc = itemModel.desc {
            descRowCount = desc.components(separatedBy: "\n").count
        }
        
        //推荐理由标签
        var yCursor: CGFloat = title.renderRect.maxY + 6
//        if let reasons = itemModel.reasons, !reasons.isEmpty {
//            let reasonsLayout = Service.reasons.estimatedLayout(reasons,
//                                                                position: title.renderRect.offsetBy(dx: 0, dy: title.renderRect.height + 3).origin,
//                                                                boundingSize: CGSize.init(width: textWidthMax, height: 20),
//                                                                allowIncompletion: true)
//            layoutModel.reasons = reasonsLayout
//
//            if let firstReason = reasonsLayout.first {
//                yCursor = firstReason.renderRect.maxY + 5
//            }
//        }
        if let reasonList = itemModel.reasonList, !reasonList.isEmpty {
            let layout = TextLayoutModel()
            let height = ReasonListView.titleHeight()
            layout.renderRect = CGRect.init(origin: title.renderRect.offsetBy(dx: 0, dy: title.renderRect.height + 6).origin, size: CGSize.init(width: textWidthMax, height: height))
            yCursor = layout.renderRect.maxY + 6
            layoutModel.reasonList = layout
        }
        
        //描述a
        let descAIsHidden = descRowCount < 1
        let descA = TextLayoutModel()
        descA.font = Item14098ContentView.descLabelFont()
        descA.lineNumber = 1
        
        let descHeight: CGFloat = YKNFont.height(with: descA.font, lineNumber: descA.lineNumber) + 2.0
        if descAIsHidden == false {
            let descAY: CGFloat = yCursor
            descA.renderRect = CGRect.init(x: textLeft, y: descAY, width: textWidthMax, height: descHeight)
            extendExtra["descA"] = descA
        }
        
        //描述b
        let descBIsHidden = descRowCount < 2
        let descB = TextLayoutModel()
        descB.font = descA.font
        descB.lineNumber = descA.lineNumber
        
        if descBIsHidden == false {
            let descBY: CGFloat = descA.renderRect.maxY + 5
            descB.renderRect = CGRect.init(x: textLeft, y: descBY, width: textWidthMax, height: descHeight)
            extendExtra["descB"] = descB
        }
        
        //moreDesc
        let moreDesc = TextLayoutModel()
        moreDesc.font = descA.font
        moreDesc.lineNumber = descA.lineNumber
        
        var moreDescY: CGFloat = yCursor
        if descBIsHidden == false { //有第二行desc
            moreDescY += (descHeight + 5) + (descHeight + 1)
        } else if descAIsHidden == false { //有第一行desc
            moreDescY += (descHeight + 1)
        }
        moreDesc.renderRect = CGRect.init(x: textLeft, y: moreDescY, width: textWidthMax, height: descHeight)
        extendExtra["moreDesc"] = moreDesc
        
        //播放按钮
        if itemModel.hidePlayButton == false {
            let play = TextLayoutModel()
            let playSize = CGSize.init(width: 60, height: 30)
            let playX = size.width - playSize.width
            let playY = (coverHeight - playSize.height) * 0.5
            play.renderRect = CGRect.init(origin: CGPoint.init(x: playX, y: playY), size: playSize)
            extendExtra["play"] = play
        }
        
        //演员角色信息
        if let actorRoleInfo = itemModel.actorRoleInfo, !actorRoleInfo.isEmpty {
            let layout = TextLayoutModel()
            layout.font = descA.font
            layout.lineNumber = descA.lineNumber
            
            let x: CGFloat = textLeft
            let y: CGFloat = coverHeight - descHeight - 3
            layout.renderRect = CGRect.init(x: x, y: y, width: textWidthMax, height: descHeight)
            
            extendExtra["actorRoleInfo"] = layout
        }
        DispatchQueue.main.async {
            layoutModel.extendExtra = extendExtra
        }
    }
    
    // MARK: - 通知
    func addObservers() {
        // 看单通知
        NotificationCenter.default.addObserver(self, selector: #selector(handleCollectionDidChangeNotification(_:)), name: NSNotification.Name(rawValue: kDYCollectionStatusChangeNotificationName), object: nil)
        
        // 预约通知
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddReserveNotification(_:)), name: NSNotification.Name.addReserveSuccess, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelReserveNotification(_:)), name: NSNotification.Name.cancelReserveSuccess, object: nil)
    }
    
    @objc func handleCollectionDidChangeNotification(_ notification: NSNotification) {
        guard let favor = self.item?.itemModel?.favor else {
            return
        }
        
        guard let userInfo = notification.userInfo else {
            return
        }
        
        guard shouldUpdateFavorModel(userInfo, favor: favor) else {
            return
        }
        
        let relation = userInfo["relation"] as? NSNumber
        favor.isFavor = relation?.boolValue
        
        guard shouldUpdateFavorUI(favor, view: displayingItemView) else {
            return
        }
        
        let isFavor = favor.isFavor ?? false
    }
    
    @objc func handleAddReserveNotification(_ notification: NSNotification) {
        guard let notObj = notification.object as? String else {
            return
        }
        
        guard let reserveModel = self.item?.itemModel?.reserveModel else {
            return
        }
        
        if let reserveId = reserveModel.rid, reserveId == notObj {
            reserveModel.isReserve = true
        }
        
        guard shouldUpdateReserveUI(reserveModel, view: displayingItemView) else {
            return
        }
        
        displayingItemView?.reserveView.fill(isReserve: reserveModel.isReserve)
    }
    
    @objc func handleCancelReserveNotification(_ notification: NSNotification) {
        guard let notObj = notification.object as? String else {
            return
        }
        
        guard let reserveModel = self.item?.itemModel?.reserveModel else {
            return
        }
        
        if let reserveId = reserveModel.rid, reserveId == notObj {
            reserveModel.isReserve = false
        }
        
        guard shouldUpdateReserveUI(reserveModel, view: displayingItemView) else {
            return
        }
        
        displayingItemView?.reserveView.fill(isReserve: reserveModel.isReserve)
    }
    
    func shouldUpdateFavorModel(_ userInfo: [AnyHashable: Any], favor: FavorModel) -> Bool {
        guard let favorId = favor.favorId else {
            return false
        }
        
        if let showId = userInfo["showid"] as? String {
            if showId == favorId {
                return true
            }
        }
        
        if let sids = userInfo["sid"] as? String {
            let sidArr = sids.components(separatedBy: ",")
            if sidArr.count > 0 && sidArr.contains(favorId) {
                return true
            }
        }
        
        return false
    }
    
    func shouldUpdateFavorUI(_ favor: FavorModel, view: Item14098ContentView?) -> Bool {
        guard let view = view else {
            return false
        }
        
        guard let favorInView = view.itemModel?.favor else {
            return false
        }
        
        if favor.favorId == favorInView.favorId, favor.type == favorInView.type {
            return true
        }
        
        return false
    }
    
    func shouldUpdateReserveUI(_ reserve: ReserveModel, view: Item14098ContentView?) -> Bool {
        guard let view = view else {
            return false
        }
        
        guard let reserveInView = view.itemModel?.reserveModel else {
            return false
        }
        
        if reserve.rid == reserveInView.rid, reserve.reservationType == reserveInView.reservationType {
            return true
        }
        
        return false
    }
}

