//
//  Item12113.swift
//  YKChannelComponent
//
//  Created by better on 2022/10/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item12113: NSObject, ItemDelegate, PlayerToolsEventHandlerDelegate {
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {

    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return PadBaseItemModel.self as? T.Type
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0.0
    }

    func createView(_ itemSize: CGSize) -> UIView {
        return UIView()
    }
    
    func reuseView(itemView: UIView) {

    }
    
    func getImageAspectRatio() -> CGFloat {
        return 1.0
    }

    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler(),
                self.playerToolsEventHandler,
                ItemPlayerProgressEventHandler()]
    }
    
    lazy var playerToolsEventHandler:PlayerToolsEventHandler = {
        let handler = PlayerToolsEventHandler()
        handler.delegate = self
        return handler
    }()
    
    //MARK:PlayerToolsEventHandlerDelegate
    func didPlayerStart(_ playerModel: PlayerModel?) {
        //启播时 裁剪
        //self.itemView?.bottomView.layer.masksToBounds = true
        
        showBottomBgView(false, playerModel: playerModel)
    }
    
    func didPlayerStop(_ playerModel: PlayerModel?) {
        //self.itemView?.bottomView.layer.masksToBounds = false
        
        showBottomBgView(true, playerModel: playerModel)
    }
    
    private func showBottomBgView(_ show: Bool, playerModel: PlayerModel?) {
        let bigCardTypes = ["12116", "12117", "12118"]
        guard let model = playerModel?.item?.itemModel, let type = model.type, bigCardTypes.contains(type),
              let itemView = playerModel?.itemView?.superview as? FeedBigCardItemBaeView else {
            return
        }
        
        print("[feed大卡氛围] 播放器 show:\(show) type:\(type)")
        itemView.imageView.showBottomBGView(show)
    }
}
