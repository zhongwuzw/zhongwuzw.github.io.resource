//
//  PadVideoImageView.swift
//  YKChannelComponent
//
//  Created by better on 2022/10/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent
import OneArch
import SDWebImage
import YKAdSDK

class PadVideoImageView: UIImageGIFView {

    var shadowHeight: CGFloat = 0.0

    init(frame: CGRect, shadowHeight:CGFloat) {
        super.init(frame: frame)
        self.shadowHeight = shadowHeight
        self.contentMode = .scaleAspectFill
        self.layer.masksToBounds = true
        self.addSubview(self.bottomBgView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var gradientLayerView: UIView = {
        let view = UIView.init();
        self.addSubview(view)
        view.backgroundColor = UIColor.clear
        view.frame = self.bounds
        view.height = self.shadowHeight
        view.bottom = self.height
        return view
    }()

    lazy var gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)

        self.gradientLayerView.layer.insertSublayer(layer, at: 0)
        layer.colors = gradientColors()
        layer.frame = self.gradientLayerView.bounds
        return layer
    }()
    
    lazy var bottomBgView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.alpha = 0
        return view
    }()
    
    weak var model: BaseItemModel?
    
    func fillData(item:IItem?) {
        guard let item = item, let itemModel = item.model as? BaseItemModel else {
            return
        }
        self.model = itemModel
        
        //封面图
        var icon = itemModel.gifImg ?? itemModel.img
        // 广告类型
        var isAd: Bool = false
        if let type = itemModel.type, type == "12115" {
            isAd = true
            let model: YKAdResponseModel? = itemModel.feedbackModel?.ucAdModel as? YKAdResponseModel
            let imgModel = model?.firstNativeContentImage()
            icon = imgModel?.url
        }
        self.ykn_setImage(withURLString: icon, module: nil, imageSize: .zero, parameters: nil, completed: nil)

        //shadow
        self.gradientLayer.width = self.width
        self.gradientLayerView.width = self.width
        self.gradientLayerView.bottom = self.height
        self.sendSubviewToBack(self.gradientLayerView)
        self.gradientLayerView.isHidden = isAd //广告小卡不要阴影

        //氛围层
        let width = self.width
        let height = width * (101.0 / 345.0)
        self.bottomBgView.frame = CGRect.init(x: 0, y: self.gradientLayerView.top - 18, width: width, height: height)
        
        //角标
        Service.mark.attach(isAd ? nil : itemModel.mark, toView: self, layout: item.layout?.mark)
        
        //水印
        Service.waterMark.attach(itemModel.waterMark, toView: self)
    }
    
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        self.gradientLayer.colors = gradientColors()
        fillBottomBgView()
    }
    
    func gradientColors() -> [CGColor] {
        let clr1 = UIColor.createColorWithHexRGB(colorStr: "#25252b").withAlphaComponent(0).cgColor
        let clr2 = UIColor.createColorWithHexRGB(colorStr: "#25252b").withAlphaComponent(1).cgColor
        
        let clr11 = UIColor.white.withAlphaComponent(0).cgColor
        let clr22 = UIColor.white.withAlphaComponent(1).cgColor
        
        return isDark() ? [clr1, clr2] : [clr11, clr22]
    }
    
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }

    func showBottomBGView(_ show: Bool) {
        guard let model = model else { return  }
        if let _ = model.bottomBgImgLight,let _ = model.bottomBgImgDark {
            self.bottomBgView.alpha = show ? 1 : 0
        }
    }
    
    func fillBottomBgView() {
        guard let model = model else { return  }
        bottomBgView.alpha = 0
        gradientLayerView.alpha = 1
        
        if let bottomBgImgLight = model.bottomBgImgLight,let bottomBgImgDark = model.bottomBgImgDark {
            bottomBgView.alpha = 1
            gradientLayerView.alpha = 0
            var url = URL.init(string: bottomBgImgLight)
            if isDark() {
                url = URL.init(string: bottomBgImgDark)
            }
            bottomBgView.sd_setImage(with: url) { (image:TBAnimatedImage?, error:Error?, type:SDImageCacheType, url:URL?) in
                
            }
        }
    }
}
