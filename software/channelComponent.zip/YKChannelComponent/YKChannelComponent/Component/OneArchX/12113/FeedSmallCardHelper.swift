//
//  Item12105View.swift
//  YKChannelComponent
//
//  Created by better on 2022/10/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent
import OneArch

class FeedSmallCardHelper {
    //计算大卡高度：reload仅调用一次
    static func calcBottomViewHeight(_ item:IItem?, _ itemWidth:CGFloat) -> CGFloat {
        guard let item = item, let model = item.model as? HomeItemModel else {
            return 0.0
        }
        let titleHeight = YKNFont.height(with: YKNFont.discuss_content_text_weight(.semibold), lineNumber: 1)
        let subtitleHeight = YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)
        let reasonHeight = 18 * YKNSize.yk_icon_size_scale()
        let summaryheight = subtitleHeight
        var totalHeight:CGFloat = 0.0
        totalHeight += titleHeight
        totalHeight += YKNGap.dim_4() + subtitleHeight
        totalHeight += YKNGap.dim_4() + reasonHeight
        totalHeight += YKNGap.dim_4() + 1.5 + summaryheight
        totalHeight += YKNGap.dim_7()
        return totalHeight
    }
}
