//
//  Component12113.swift
//  YKChannelComponent
//
//  Created by better on 2022/10/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKAdSDK
import OneArchSupport
import OneArchSupport4Youku
import YKModeConfigFramework

class Component12113: NSObject, ComponentDelegate {
    
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {

    }

    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom() - YKNGap.dim_6(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = 0
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
