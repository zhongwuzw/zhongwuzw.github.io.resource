//
//  Item14022.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/30.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item14022: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 70 * YKNSize.yk_icon_size_scale()
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14022ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14022ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        Service.action.bind(itemModel.action, itemView)
        itemView.fillData(itemModel: itemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }

}
