//
//  Item14022ContentView.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/30.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import SDWebImage
import YKProtocolSDK
import YKHome

class Item14022ContentView: AccessibilityView,ReserveButtonDelegate {

    //MARK: Property
    lazy var headIcon:UIImageGIFView = {
        let view = UIImageGIFView.init(frame:CGRect.init(x: 0, y: 0, width: 80 * YKNSize.yk_icon_size_scale(), height: 70 * YKNSize.yk_icon_size_scale()))
        view.backgroundColor = .clear
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        return view
    }()
    
    lazy var titleLabel:UILabel = {
        let x = self.headIcon.right + 6
        let y = self.headIcon.top + 17
        let w = self.width - 60 * YKNSize.yk_icon_size_scale() - x
        let h = 22 * YKNSize.yk_icon_size_scale()
        let label = UILabel.init(frame:CGRect.init(x: x, y: y, width: w, height: h))
        label.backgroundColor = .clear
        label.textAlignment = .left
        label.font = YKNFont.posteritem_maintitle_m_weight(.semibold)
        label.textColor = UIColor.ykn_brandInfo
        label.lineBreakMode = .byTruncatingTail
        return label
    }()

    lazy var subtitleLabel:UILabel = {
        let label = UILabel.init(frame:CGRect.init(x: titleLabel.left, y: titleLabel.bottom + 4, width: titleLabel.width, height: 14))
        label.font = YKNFont.posteritem_subhead()
        label.textColor = YKNColor.cg_3()
        label.lineBreakMode = .byTruncatingTail
        return label
    }()
    
    lazy var reserveBtn: ReserveBorderButton = {
        let view = ReserveBorderButton()
        let w = 60 * 1.0 //* YKNSize.yk_icon_size_scale()
        let h = w * 0.5
        view.frame = CGRect.init(x: self.width - w, y: self.headIcon.top + 24, width: w, height: h)
        view.centerY = self.headIcon.centerY
        view.layer.cornerRadius = h / 2.0
        
        view.delegate = self
        view.isHidden = true
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.headIcon)
        self.addSubview(self.titleLabel)
        self.addSubview(self.subtitleLabel)
        self.addSubview(self.reserveBtn)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var itemModel:BaseItemModel?
    
    func fillData(itemModel: BaseItemModel) {
        self.itemModel = itemModel
        self.backgroundColor = .clear
        self.headIcon.ykn_setImage(withURLString: itemModel.img, module: "home", imageSize: .zero, parameters: nil, completed: nil)
        self.titleLabel.text = itemModel.title
        self.subtitleLabel.text = itemModel.subtitle
        
        self.reserveBtn.isHidden = (itemModel.reserveModel == nil)
        self.reserveBtn.refresh(reserveModel: itemModel.reserveModel, scene: itemModel.scene)
        
        self.reserveBtn.right = self.width
        
        let w = self.width - self.titleLabel.left
        self.titleLabel.width = self.reserveBtn.isHidden ? w : (self.reserveBtn.left - self.titleLabel.left - 3)
        self.subtitleLabel.width = self.titleLabel.width
        
        self.subtitleLabel.textColor = sceneUtil(YKNColor.cg_3(), sceneColor: itemModel.scene?.sceneSubTitleColor())
    }
    
    func didUpdateReserveButtonFrame() {
        self.reserveBtn.top = self.headIcon.top + 24
        self.reserveBtn.right = self.width
    }
}
