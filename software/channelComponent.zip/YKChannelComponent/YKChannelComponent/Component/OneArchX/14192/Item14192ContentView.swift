//
//  Item12076ContentView.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/25.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import Lottie
import YKHome
import OneArchSupport
import OneArchSupport4Youku
import OneArch

class Item14192ContentView: AccessibilityView {
    
    weak var model:HomeItemModel?
    var sceneTitleColor: UIColor?
    var sceneThemeColor: UIColor?
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.layer.masksToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        return view
    }()
    
    lazy var headerLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.akrobatExtraBoldFont(ofSize: YKNFont.top_navbar_text().pointSize)
        view.numberOfLines = 1
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.numberOfLines = 1
        return view
    }()
    
    lazy var subtitleLabel1: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.numberOfLines = 1
        return view
    }()

    lazy var subtitleLabel2: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        return view
    }()
    
    lazy var subtitleLabel3: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_brandInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        return view
    }()
    
    lazy var favorBtn: YKTrackShowView = {
        let view = YKTrackShowView.init(frame: CGRect.init(x: 0, y: 0, width: 60, height: 30))
        view.whenTapped {
            self.favorAction()
        }
        view.isHidden = true
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddCollectSuccessNotication), name: NSNotification.Name.init("kBSAddCollectSuccess"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelCollectSuccessNotication), name: NSNotification.Name.init("kBSCancelCollectSuccess"), object: nil)
        
        self.addSubview(videoImageView)
        videoImageView.frame = CGRect.init(x: 0, y: 0, width: 84.0, height: 112.0)
        
        self.addSubview(headerLabel)
        self.addSubview(titleLabel)
        self.addSubview(subtitleLabel1)
        self.addSubview(subtitleLabel2)
        self.addSubview(subtitleLabel3)
        self.addSubview(favorBtn)
    }
    
    func relayoutIfNeeded(_ itemModel: BaseItemModel) {
        let layoutModel = itemModel.layout
        
        let videoLayout = layoutModel.cover
        videoImageView.frame = videoLayout?.renderRect ?? .zero
        
        headerLabel.frame = CGRect.init(x: 0, y: videoImageView.top - 29, width: 100, height: 20)
        
        let titleLayout = layoutModel.title
        titleLabel.frame = titleLayout?.renderRect ?? .zero
        titleLabel.font = titleLayout?.font
        
        let subtitleLayout = layoutModel.subtitle
        subtitleLabel1.frame = subtitleLayout?.renderRect ?? .zero
        subtitleLabel1.font = subtitleLayout?.font
        
        let descLayout = layoutModel.extendExtra?["desc"] as? TextLayoutModel
        subtitleLabel2.frame = descLayout?.renderRect ?? .zero
        subtitleLabel2.font = descLayout?.font
        
        let moredescLayout = layoutModel.extendExtra?["moredesc"] as? TextLayoutModel
        subtitleLabel3.frame = moredescLayout?.renderRect ?? .zero
        subtitleLabel3.font = moredescLayout?.font
        
        let trackShowButtonLayout = itemModel.layout.extendExtra?["trackShowButton"] as? TextLayoutModel
        favorBtn.frame = trackShowButtonLayout?.renderRect ?? .zero
    }
    
    func refreshScene() {
        titleLabel.textColor = sceneUtil(UIColor.ykn_primaryInfo, sceneColor: model?.scene?.sceneTitleColor())
        subtitleLabel1.textColor = sceneUtil(UIColor.ykn_secondaryInfo, sceneColor: model?.scene?.sceneSubTitleColor())
        subtitleLabel2.textColor = sceneUtil(UIColor.ykn_secondaryInfo, sceneColor: model?.scene?.sceneSubTitleColor())
        self.backgroundColor = .clear
    }
    
    func fillData(_ itemModel: HomeItemModel, _ layout: OneArchSupport4Youku.LayoutModel, _ item: IItem?) {
        model = itemModel
        guard let model = model else { return }
        
        self.sceneTitleColor = model.scene?.sceneTitleColor()
        self.sceneThemeColor = model.scene?.sceneThemeColor()
        
        headerLabel.text = model.extraExtend["lastTimeStr"] as? String
        if Item14192ContentView.getDateDayFormatString(timeStamp: Int(Date.init().timeIntervalSince1970)) == Item14192ContentView.getDateDayFormatString(timeStamp: item?.homeItemModel?.updateTime ?? 0),
           Item14192ContentView.getDateFormatString(timeStamp: Int(Date.init().timeIntervalSince1970)) > (headerLabel.text ?? "") {
            headerLabel.textColor = .ykn_tertiaryInfo
        } else {
            headerLabel.textColor = .ykn_primaryInfo
        }
        
        relayoutIfNeeded(itemModel)
        
        // 标题
        titleLabel.text = itemModel.title
        
        // 子标题
        subtitleLabel1.text = itemModel.subtitle
        subtitleLabel2.text = itemModel.desc
        subtitleLabel3.text = itemModel.moreDesc

        // 封面
        videoImageView.ykn_setImage(withURLString: itemModel.img ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)

        if model.trackShow != nil {
            bindStatisticsService()
            favorBtn.isHidden = false
        } else {
            favorBtn.isHidden = true
        }
        
        let favor = model.trackShow
        favorBtnRefresh(favor?.isFavor ?? false)
        
        // 角标
        Service.mark.attach(itemModel.mark, toView: videoImageView, layout: layout.mark)
        
        // 右下角腰封
        Service.summary.attach(itemModel.summary, toView: videoImageView, layout: layout.summary)
        
        weak var weakItem = item
        Service.action.bind(itemModel.action, self) {
        } didAction: {
            weakItem?.sendEventMessage("yksc.event.item.rec.tap", params: ["recType":"card"])
        }

        refreshScene()
    }
    
    func bindStatisticsService() {
        guard let trackShow = model?.trackShow else {
            return
        }
        
        if let isFavor = trackShow.isFavor, isFavor == true {
            let actionModel =  self.model?.extraExtend["uncollectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        } else {
            let actionModel = self.model?.extraExtend["collectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        }
    }
    
    func favorAction() {
        guard let favor = model?.trackShow,
              let isFavor = favor.isFavor
        else {
            return
        }
        
        var params = [String : Any]()
        params["isFavor"] = isFavor
        params["id"] = favor.favorId ?? ""
    
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channel.function.adaptor.zhuiju"), object: nil, userInfo: params)
    }
    
    @objc func handleAddCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: true)
    }
    
    @objc func handleCancelCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: false)
    }
    
    func handleNotication(notification: Notification, favored: Bool) {
        guard let userInfo = notification.userInfo,
              let targetId = userInfo["targetId"] as? String
        else {
            return
        }
        guard let favor = model?.trackShow,
              let currentId = favor.favorId
        else {
            return
        }
        
        guard currentId == targetId else {
            return
        }
        favor.isFavor = favored
        favorBtnRefresh(favor.isFavor ?? false)
        bindStatisticsService()
    }
    
    func favorBtnRefresh(_ isFavor: Bool) {
        if let sceneTitleColor = self.sceneTitleColor, let sceneThemeColor = self.sceneThemeColor  {
            favorBtn.selectTextColor = sceneTitleColor
            favorBtn.selectBgColor = .clear
            favorBtn.selectBorderWidth = 1.0
            favorBtn.selectBorderColor = sceneTitleColor
            
            favorBtn.unselectTextColor = sceneThemeColor
            favorBtn.unselectBgColor = .clear
            favorBtn.unselectBorderWidth = 1.0
            favorBtn.unselectBorderColor = sceneThemeColor
        } else {
            favorBtn.selectTextColor = .ykn_tertiaryInfo
            favorBtn.selectBgColor = .ykn_seconarySeparator
            favorBtn.selectBorderWidth = 0.0
            favorBtn.selectBorderColor = .clear
            
            favorBtn.unselectTextColor = .ykn_brandInfo
            favorBtn.unselectBgColor = .ykn_border
            favorBtn.unselectBorderWidth = 1.0
            favorBtn.unselectBorderColor = .clear
        }
        
        favorBtn.update(isFavor)
    }
    
    class func getDateFormatString(timeStamp: Int) -> String {
        if timeStamp < 0 {
            return ""
        }
        if timeStamp < 25 {
            return NSString.init(format: "%2d:00", timeStamp) as String
        }
        let date = Date(timeIntervalSince1970: TimeInterval(timeStamp))
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "HH:mm"
        return dateformatter.string(from: date)
    }
    
    class func getDateDayFormatString(timeStamp: Int) -> String {
        if timeStamp < 0 {
            return ""
        }
        if timeStamp < 25 {
            return NSString.init(format: "%2d:00", timeStamp) as String
        }
        let date = Date(timeIntervalSince1970: TimeInterval(timeStamp))
        let dateformatter = DateFormatter()
        dateformatter.dateFormat = "dd"
        return dateformatter.string(from: date)
    }
}
