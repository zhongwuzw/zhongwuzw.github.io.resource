//
//  Component12076.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/22.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource

class Component14192:NSObject, ComponentDelegate {
    static func create() -> ComponentDelegate {
        return Component14192.init()
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = 9.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0 //100
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return []
    }
    
    func componentDidInit() {
        
    }
    
    var componentWrapper: ComponentWrapper?
    
}
