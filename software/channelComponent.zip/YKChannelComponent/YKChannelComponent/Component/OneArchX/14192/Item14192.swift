//
//  Item12076.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/22.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKModeConfigFramework
import YoukuAnalytics

class Item14192:NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
    
    static func create() -> ItemDelegate {
        return Item14192.init()
    }
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }

    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.receiveEstimatedLayout(Double(itemWidth))
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return []
    }
    
    func itemDidInit() {
        if let title = item?.itemModel?.title, title.count > 0 {
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 3.0
            paragraphStyle.lineBreakMode = .byTruncatingTail
            let attributedTitle = NSAttributedString.init(string: title, attributes: [.paragraphStyle: paragraphStyle])
            item?.itemModel?.attributedTitle = attributedTitle
        }
   
        if let itemModel = item?.itemModel {
            
            let followActionModel = ActionFactoryV2(itemModel, spmDExt: "_watching")
            
            let unfollowActionModel = ActionFactoryV2(itemModel, spmDExt: "_cancelwatching")
            
            if followActionModel != nil {
                itemModel.extraExtend["collectActionModel"] = followActionModel
            }
            
            if unfollowActionModel != nil {
                itemModel.extraExtend["uncollectActionModel"] = unfollowActionModel
            }
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(resetCardStatus), name: Notification.Name(rawValue: "card.15027.subcard.changed"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddCollectSuccessNotication), name: NSNotification.Name.init("kBSAddCollectSuccess"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelCollectSuccessNotication), name: NSNotification.Name.init("kBSCancelCollectSuccess"), object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func handleAddCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: true)
    }
    
    @objc func handleCancelCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: false)
    }
    
    func handleNotication(notification: Notification, favored: Bool) {
        let model = self.item?.itemModel as? HomeItemModel

        guard let userInfo = notification.userInfo,
              let targetId = userInfo["targetId"] as? String
        else {
            return
        }
        guard let favor = model?.trackShow,
              let currentId = favor.favorId
        else {
            return
        }
        guard currentId == targetId else {
            return
        }
        favor.isFavor = favored
    }
    
    @objc func resetCardStatus() {
        if let container = self.item?.pageContext?.getContainerView() as? UIScrollView,
           container.contentOffset.y > 0 {
            container.setContentOffset(CGPoint.zero, animated: false)
        }
        if (self.item?.getCard()?.cardModel?.extraExtend["didScroll"] as? String) == "1" {
            self.item?.getCard()?.cardModel?.extraExtend["didScroll"] = "0"
        }
    }
    
    func receiveEstimatedLayout(_ itemWidth: Double) {
        let itemLayout = item?.itemModel?.layout
        let itemHeight = self.calcItemHeight(itemWidth)
        itemLayout?.renderRect = CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight)
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14192ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }

    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14192ContentView else {
            return
        }
        guard let itemModel = self.item?.homeItemModel else {
            return
        }
        guard let itemLayout = self.item?.itemModel?.layout else {
            return
        }
        
        itemView.fillData(itemModel, itemLayout, self.item)
        
        if (self.item?.getCard()?.cardModel?.extraExtend["didScroll"] as? String) != "1" {
            self.item?.getCard()?.cardModel?.extraExtend["didScroll"] = "1"
            if let index = self.item?.getCard()?.getSuperCard()?.getMultiTabCardCurrentCard()?.index,
               index == 0,
               let comps = self.item?.getCard()?.getComponents() {
                let now = Item14192ContentView.getDateFormatString(timeStamp: Int(Date.init().timeIntervalSince1970)).components(separatedBy: ":").first ?? ""
                let nowday = Item14192ContentView.getDateDayFormatString(timeStamp: Int(Date.init().timeIntervalSince1970))
                for comp in comps {
                    let aitem = comp.getItems()?.first
                    let hmodel = aitem?.model as? HomeItemModel
                    if Item14192ContentView.getDateDayFormatString(timeStamp: hmodel?.updateTime ?? 0) != nowday {
                        return
                    }
                    if let hh = hmodel?.extraExtend["lastTimeStr"] as? String,
                       now <= (hh.components(separatedBy: ":").first ?? "99") {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                            if let container = aitem?.pageContext?.getContainerView() as? UIScrollView,
                            var offfsetY = aitem?.getLayoutInfo().y {
                                offfsetY -= 80 + (YKFontModeManager.sharedInstance().getFontScale() - 1.0) * 25.0
                                if container.contentSize.height - offfsetY < container.height {
                                    offfsetY = container.contentSize.height - container.height
                                }
                                if abs(container.contentOffset.y - offfsetY) < 50 || offfsetY < 0 {
                                    return
                                }
                                container.setContentOffset(CGPoint.init(x: 0, y: offfsetY), animated: true)
                            }
                        }
                        break
                    }
                }
            }
        }
    }

    // MARK: 坑位布局计算
    func calcItemHeight(_ itemWidth: Double) -> Double {
        guard let itemLayout = item?.itemModel?.layout else { return 0 }
        guard let itemModel = self.item?.itemModel as? HomeItemModel else {
            return 0
        }
        
        if itemLayout.renderRect.isEmpty {
            var videoImageY: CGFloat = 0
            
            do {
                var h = 112.0
                let HHss = Item14192ContentView.getDateFormatString(timeStamp: itemModel.updateTime)
                let HH = HHss.components(separatedBy: ":").first
                if let lastHH = self.item?.getCard()?.cardModel?.extraExtend["lastTimeStr"] as? String,
                   lastHH == HH {
                    itemModel.extraExtend["lastTimeStr"] = ""
                } else if HHss.count > 0 {
                    self.item?.getCard()?.cardModel?.extraExtend["lastTimeStr"] = HH
                    itemModel.extraExtend["lastTimeStr"] = HHss
                    h += 38
                }
                if self.item?.getCard()?.getComponents()?.first === self.item?.getComponent(), h > 112.0 {
                    h -= 11
                }
                
                videoImageY = h - 112.0
                itemLayout.renderRect = .init(x: 0.0, y: 0.0, width: itemWidth, height: h)
            }
            
            itemLayout.extendExtra = [String: Any]()
            
            // 封面图
            let videoImgWidth: CGFloat = 84.0
            let videoImgHeight: CGFloat  = 112.0
            let videoLayout = ImageLayoutModel.init()
            videoLayout.renderRect = CGRect.init(x: 0, y: videoImageY, width: videoImgWidth, height: videoImgHeight)
            itemLayout.cover = videoLayout
            
            let textStartX: CGFloat = videoLayout.renderRect.maxX + 9
            let textStartY: CGFloat = videoImageY + 3
            
            // 在追按钮
            let trackShowButtonSize = CGSize.init(width: 53, height: 30)
            let trackShowButtonX = itemWidth - trackShowButtonSize.width
            let trackShowButtonLayout = TextLayoutModel.init()
            trackShowButtonLayout.renderRect = CGRect.init(x: trackShowButtonX, y: textStartY, width: trackShowButtonSize.width, height: trackShowButtonSize.height)
            itemLayout.extendExtra?["trackShowButton"] = trackShowButtonLayout
            
            let textMaxWidth = max(0, (trackShowButtonLayout.renderRect.minX - 6) - textStartX)
            
            // 主标题
            let titleLayout = TextLayoutModel.init()
            titleLayout.font = YKNFont.module_headline_weight(.medium)
            let titleHeight: CGFloat = YKNFont.height(with: titleLayout.font, lineNumber: 1)
            titleLayout.renderRect = CGRect.init(x: textStartX, y: textStartY, width: textMaxWidth, height: titleHeight)
            itemLayout.title = titleLayout
            
            
            var lastTextMaxY: CGFloat = titleLayout.renderRect.maxY
            let subtitleFont = YKNFont.posteritem_subhead()
            let subtitleHeight: CGFloat = YKNFont.height(with: subtitleFont, lineNumber: 1)
            
            // 第二行文案
            if let subtitle = itemModel.subtitle, !subtitle.isEmpty {
                let subtitleLayout = TextLayoutModel.init()
                subtitleLayout.font = subtitleFont
                subtitleLayout.renderRect = CGRect.init(x: textStartX, y: lastTextMaxY + YKNGap.dim_4(), width: textMaxWidth, height: subtitleHeight)
                itemLayout.subtitle = subtitleLayout
                lastTextMaxY = subtitleLayout.renderRect.maxY
            }
            
            // 第三行文案
            if let desc = itemModel.desc, !desc.isEmpty {
                let descLayout = TextLayoutModel.init()
                descLayout.font = subtitleFont
                descLayout.renderRect = CGRect.init(x: textStartX, y: lastTextMaxY + YKNGap.dim_4(), width: textMaxWidth, height: subtitleHeight)
                itemLayout.extendExtra?["desc"] = descLayout
                
                lastTextMaxY = descLayout.renderRect.maxY
            }
            
            // 第四行文案
            if let moredesc = itemModel.moreDesc, !moredesc.isEmpty {
                let moredescLayout = TextLayoutModel.init()
                moredescLayout.font = subtitleFont
                moredescLayout.renderRect = CGRect.init(x: textStartX, y: lastTextMaxY + YKNGap.dim_4(), width: textMaxWidth, height: subtitleHeight)
                itemLayout.extendExtra?["moredesc"] = moredescLayout
            }
            
            // 角标
            if let mark = itemModel.mark {
                let layout = Service.mark.estimatedLayout(mark, toViewSize: CGSize(width: videoImgWidth, height: videoImgHeight))
                itemLayout.mark = layout
            }
            
            // 腰封
            if let summary = itemModel.summary {
                let layout = Service.summary.estimatedLayout(summary, toViewSize:CGSize(width: videoImgWidth, height: videoImgHeight))
                itemLayout.summary = layout
            }
        }
        
        return Double(itemLayout.renderRect.height)
    }
}
