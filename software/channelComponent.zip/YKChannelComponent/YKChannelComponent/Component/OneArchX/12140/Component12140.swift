//
//  Component12140.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/12/7.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKChannel
import NovelAdSDK
import YKAdSDK

class Component12140: Component12104Delegate {
    
    override func componentDidInit() {
        
    }
    
    override func reuseId() -> String? {
        var superId = super.reuseId()
        if let _superId = superId, let compWithoutBorder = component?.compModel?.extraExtend["compWithoutBorder"] as? Bool, compWithoutBorder {
            superId = _superId + "_withoutBorder"
        }
        return superId
    }
    
    override func createView(_ itemSize: CGSize) -> UIView {
        if let compWithoutBorder = component?.compModel?.extraExtend["compWithoutBorder"] as? Bool, compWithoutBorder {
            let itemView = Item12140ContententViewWithoutBorder(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            return itemView
        } else {
            let itemView = Item12140ContententView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            return itemView
        }
    }

    override func reuseView(itemView: UIView) {
        guard let item = self.item, let itemDelegate = item.getItemDelegate() as? Item12140,
              let view = itemView as? Item12140ContententView, let _ = item.itemModel else {
            return
        }

//        weak var weakself = self
        itemDelegate.reuseView(itemView: itemView)
                
//        Service.feedback.detachFeedbackView()
//        if let oneArchPageScene = self.item?.getPage()?.pageContext?.concurrentDataMap["OneArchPageScene"] as? String, oneArchPageScene == "Detail" {
//            //通投到播放页场景是，不展示负反馈按钮
//        } else {
//            Service.feedback.attach(itemModel.feedbackModel, toView: itemView, morePos: .BottomRightBorder_ZhaoPian, isSupportUndo: false) {
//                if let weakself = weakself,
//                   let component = weakself.component
//                   {
//                    deleteComponentWithAnimation(component)
//                    itemDelegate.feedback()
//                }
//            }
//            if let feedbackBtn = itemView.viewWithTag(999998) {
//                itemView.superview?.accessibilityElements = [itemView, feedbackBtn]
//            }
//        }
        
        view.refreshBorderAndCorner(itemModel: item.itemModel)
        print("[feed ad] 12140 add corner")
    }
    
    override func layoutConfig() -> ComponentLayoutConfig {
        var config = super.layoutConfig()
        
        if let compWithoutBorder = component?.compModel?.extraExtend["compWithoutBorder"] as? Bool, compWithoutBorder {
            config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_line_spacing(), right: YKNGap.youku_margin_right())
        }
        
        return config
    }
    
    
    override func enterDisplayArea(itemView: UIView?) {
        guard let item = self.item, let itemDelegate = item.getItemDelegate() as? Item12140 else {
            return
        }
        
        itemDelegate.enterDisplayArea(itemView: itemView)
    }
    
    override func exitDisplayArea(itemView: UIView?) {
        guard let item = self.item, let itemDelegate = item.getItemDelegate() as? Item12140 else {
            return
        }
        
        itemDelegate.exitDisplayArea(itemView: itemView)
    }
    
    override func didActivate() {
        guard let item = self.item, let itemDelegate = item.getItemDelegate() as? Item12140 else {
            return
        }
        
        itemDelegate.didActivate()
    }
    
    override func didDeactivate() {
        guard let item = self.item, let itemDelegate = item.getItemDelegate() as? Item12140 else {
            return
        }
        
        itemDelegate.didDeactivate()
    }
        
}
