//
//  Item12140.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/12/7.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Item12140: Item12138 {
    override func createView(_ itemSize: CGSize) -> UIView {
        return UIView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
    }
    
    override func itemDidInit() {
        super.itemDidInit()
        
        self.contentViewLeftMagin = 9
        self.contentBottomMagin = 12
    }
}

class Item12140ContententView: ItemPlugin12077ContentView {
    func refreshBorderAndCorner(itemModel: BaseItemModel?) {
        self.clipsToBounds = true
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        self.bgView.backgroundColor = sceneUtil(UIColor.ykn_elevatedPrimaryBackground, sceneColor: itemModel?.scene?.sceneCardFooterBgColor())
        self.videoImageView.layer.cornerRadius = 0
    }
}

class Item12140ContententViewWithoutBorder: Item12140ContententView {
    
    override func refreshBorderAndCorner(itemModel: BaseItemModel?) {
        self.clipsToBounds = true
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        self.bgView.backgroundColor = sceneUtil(UIColor.clear, sceneColor: itemModel?.scene?.sceneCardFooterBgColor())
        self.videoImageView.layer.cornerRadius = 0
        self.backgroundColor = .clear
    }
    
}
