//
//  Item12093ContentView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/7/22.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import YKSCBase
import NovelAdSDK
import YKUIComponent
import YKResponsiveLayout
import YoukuAnalytics
import YKSCService
import OneArchSupport4Youku
import OneArchSupport
import YKHome

class Item12093ContentView: AccessibilityView {
    
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.ykn_primaryBackground
        view.layer.masksToBounds = true
//        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
//        view.clipsToBounds = true
        addSubview(view)
        return view
    }()

    lazy var videoImageView: UIImageGIFView = {
        let view = createVideoImageView()
        view.isUserInteractionEnabled = true
//        view.layer.masksToBounds = true
//        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        contentView.addSubview(view)
        return view
    }()
    
    lazy var headIcon: UIImageGIFView = {
        let view = createVideoImageView()
        view.frame = CGRect.init(x: YKNGap.dim_6(), y: 0, width: 36, height: 36)
        view.layer.cornerRadius = 18
        view.layer.borderWidth = 0.5;
        view.layer.borderColor = UIColor.ykn_hideAbleSeparator.cgColor
        contentView.addSubview(view)
        return view
    }()
    
    lazy var titleLabel: MarginLabel = {
        let view = MarginLabel()
        view.textColor = .ykn_primaryInfo
        view.verticalAlignment = .top
        view.font = YKNFont.posteritem_maintitle_weight(YKNFontWeight.medium)
        view.numberOfLines = 2
        contentView.addSubview(view)
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        view.width = 200
        view.height = 17
        contentView.addSubview(view)
        return view
    }()
    
    lazy var playIconView: PlayerIconPreviewView = {
        let view = PlayerIconPreviewView()
//        self.videoImageView.addSubview(view)
        return view
    }()
    
    lazy var adLabel: UILabel = {
        let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 300, height: 16))
        label.textColor = UIColor.ykn_tertiaryInfo
        label.font = YKNFont.doublefeed_auxiliary_text()
        label.numberOfLines = 1
        label.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#129d9fa8")
        label.layer.masksToBounds = true
        label.layer.cornerRadius = 2
        label.textAlignment = NSTextAlignment.center
        contentView.addSubview(label)
        return label
    }()

    func paddingLeft() -> CGFloat {
        return min(17.0, max(SCREEN_WIDTH * 15.0 / 414.0, 13.0))
    }
    
    func paddingRight() -> CGFloat {
        return paddingLeft()
    }
    
    func fillData(model: OADModel?, itemModel: HomeItemModel) {
        guard let model = model else {
            return
        }

        //contentview
        self.contentView.frame = CGRect.init(x: paddingLeft(), y: 0, width: self.bounds.width - paddingLeft() - paddingRight(), height: self.height)
        

        //imageview
        videoImageView.frame = self.imageViewFrame()
        var imgUrl = ""
        if model.resType == "img" {
            imgUrl = model.resUrl ?? ""
        } else if model.resType == "video" || model.resType == "effvideo" {
            imgUrl = model.thumbnail ?? ""
        }
 
        videoImageView.ykn_setImage(withURLString: imgUrl,
                                    module: "",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)

        self.headIcon.top = videoImageView.bottom + YKNGap.dim_6()
        self.headIcon.isHidden = !(itemModel.uploader?.isShowHeadIcon ?? false)
        if !self.headIcon.isHidden, let url = itemModel.uploader?.icon {
            self.headIcon.ykn_setImage(withURLString: url,
                                        module: "",
                                        imageSize: CGSize.zero,
                                        parameters: nil,
                                        completed: nil)
            self.titleLabel.left = self.headIcon.right + YKNGap.dim_5()
        } else {
            self.titleLabel.left = YKNGap.dim_6()
        }
        self.titleLabel.top = videoImageView.bottom + YKNGap.dim_5()

        //playicon
        self.playIconView.frame = self.videoImageView.bounds
        
        let playerModel = itemModel.playerModel
        
        if let canPlay = playerModel?.canPlay, canPlay == true {
           self.playIconView.isHidden = false
        } else {
           self.playIconView.isHidden = true
        }

        //title
        self.titleLabel.text = model.mainTitle ?? "广告"

        var maxTitleWidth = Double(self.width) - Double(2 * YKNGap.dim_6())
        if let _ = itemModel.uploader?.isShowHeadIcon {
            maxTitleWidth -= Double(36 + YKNGap.dim_5())
        }
        
        guard let titleBoundingSize = itemModel.layout.title?.boundingSize else {
            return
        }
        if titleBoundingSize.width > CGFloat(maxTitleWidth) {
            self.titleLabel.numberOfLines = 2
            self.titleLabel.height = 40
        } else {
            self.titleLabel.numberOfLines = 1
            self.titleLabel.height = 20
        }
        self.titleLabel.width = CGFloat(maxTitleWidth)
        
        //ad corner
        if let vendorName = model.vendorName, vendorName.count > 0 {
            adLabel.text =  vendorName
        } else {
            adLabel.text = "广告"
        }
        let adLabelH : CGFloat = 18
        let adLabelW = adLabel.sizeThatFits(CGSize.init(width: self.width, height: adLabelH)).width + 8
        adLabel.frame = CGRect.init(x: self.titleLabel.left, y: self.height - 9 - adLabelH, width: adLabelW, height: adLabelH)

        // 圆角+阴影
        if let tag = itemModel.type,
        (tag == "12093" || tag == "12086") {
            let maskFrame = CGRect.init(x: 0, y: 0, width: videoImageView.width, height: videoImageView.height)
            let maskPath = UIBezierPath.init(roundedRect: maskFrame,
                                             byRoundingCorners: [.topLeft, .topRight],
                                             cornerRadii: CGSize.init(width: YKNCorner.radius_secondary_medium(), height: YKNCorner.radius_secondary_medium()))
            let maskLayer = CAShapeLayer()
            maskLayer.frame = maskFrame
            maskLayer.path = maskPath.cgPath
            
            videoImageView.layer.mask = maskLayer

            contentView.yk_addBorderAndShadow(sceneBorderColor: itemModel.scene?.sceneCardFooterBgColor())
            Service.summary.attach(itemModel.summary, toView: videoImageView, layout: itemModel.layout.summary)
        } else {
            self.titleLabel.font = YKNFont.posteritem_maintitle()
            self.titleLabel.top += 3.5
            self.titleLabel.left = 0
            self.titleLabel.width = Double(self.width) - Double(2 * YKNGap.dim_6())
            self.titleLabel.height = self.titleLabel.font.lineHeight * 2 + 1
            self.adLabel.left = 0
            self.headIcon.isHidden = true
            self.playIconView.isHidden = true
            self.videoImageView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        }
        
        //subtitle
        self.subtitleLabel.text = itemModel.uploader?.desc
        self.subtitleLabel.centerY = self.adLabel.centerY
        self.subtitleLabel.left = self.adLabel.right + 9

        //color
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: itemModel.scene?.sceneTitleColor())
        self.subtitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: itemModel.scene?.sceneSubTitleColor())
        self.contentView.backgroundColor = sceneUtil(.ykn_secondaryGroupedBackground, sceneColor:
                                                        itemModel.scene?.sceneCardFooterBgColor())
    }
    
    func imageViewFrame() -> CGRect {
        let w = self.width - paddingLeft() - paddingRight()
        let h = w * CGFloat(RATIO_9_16)
        return CGRect.init(x: 0, y: 0, width: w, height: h)
    }
}
