//
//  Item12093Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/7/22.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YoukuAnalytics
import NovelAdSDK
import DYKIOSCategory

class Item12093Delegate:NSObject, ItemDelegate,PlayerToolsEventHandlerDelegate,ItemLifeCycleEventHandlerDelegate, Item12093ShakeDelegate {
    
    weak var containerView: Item12093ContentView?
    
    var itemWrapper: ItemWrapper?
    let nadApi = NadAPI()
    var adModel: OADModel? = nil
    var isExposed = false
    var isVisibled = false;
    var isActivated = true;

    lazy var playerToolsEventHandler:PlayerTools12093EventHandler = {
        let handler =  PlayerTools12093EventHandler.init()
        handler.delegate = self
        handler.shakedelegate = self
        return handler
    }()
        
    lazy var lifeCycleEventHandler:ItemLifeCycleEventHandler = {
        let handler = ItemLifeCycleEventHandler()
        handler.delegate = self
        return handler
    }()
    
    static func create() -> ItemDelegate {
        return Item12093Delegate.init()
    }
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    func columnCount() -> CGFloat {
        guard let _ = adModel else { return 0.0 }

        if let compTag = self.item?.itemModel?.type, (compTag == "12086" || compTag == "12093") {
            return 1.0
        }
        return 2.0
    }
    
    func createNovelAdFeedbackModel(_ itemModel: BaseItemModel, nadApi: NadAPI, unifyAdData: [String: Any]) -> FeedbackModel {
        let feedbackModel: FeedbackModel = FeedbackModel()
        
        let defalutTitle = "就是不感兴趣"
        feedbackModel.reasons = [FeedbackItemModel.init(["title":defalutTitle, "reason":"I"])]
        feedbackModel.report = itemModel.action?.report
        feedbackModel.scene = itemModel.scene
        
        self.adModel = nadApi.getAd(unifyAdData)
        
        itemModel.feedbackModel = feedbackModel
        
        return feedbackModel
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.receiveEstimatedLayout(Double(itemWidth))
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        guard let _ = adModel else { return 0 }
        return itemHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler(),
                self.playerToolsEventHandler,
                self.lifeCycleEventHandler,
                ItemPlayerProgressEventHandler()]
    }
    
    func itemDidInit() {
        guard let itemModel = self.item?.itemModel else {
            return
        }
        if let unifyAd = itemModel.extraExtend["unifyAd"] as? [String : Any], NadAPI.checkAdData(unifyAd) {
            createNovelAdFeedbackModel(itemModel, nadApi: nadApi, unifyAdData: unifyAd)
            
            if let adModel = adModel {
                nadApi.adFill(adModel)
            }
        }
        
        //uploader custom
        var uploader = [String: Any]()
        uploader["name"] = self.adModel?.mainTitle ?? "广告"
        uploader["desc"] = self.adModel?.subTitle ?? "了解详情"
        uploader["icon"] = self.adModel?.logo ?? ""
        let uploadModel = UploaderModel.init(uploader, model: itemModel)
        if let _ = self.adModel?.logo {
            uploadModel.isShowHeadIcon = true
        } else {
            uploadModel.isShowHeadIcon = false
        }
        uploadModel.isCanAddFavor = false
        itemModel.uploader = uploadModel
        
        if self.adModel?.resType == "effvideo" {
            itemModel.playerModel?.videoURL = self.adModel?.resUrl;
            itemModel.playerModel?.repeatPlay = true
        }
        
        //summary
        if let duration = self.adModel?.duration, duration > 0 {
            let m = Int(duration / 60)
            let s = duration % 60
            let ss = NSString.init(format: "%02d:%02d", m, s)
            itemModel.summary = SummaryModel.newModel(["summary": "\(ss)"])
        }
        
        itemModel.extend["shakeUrl"] = self.adModel?.actionIcon
        
        itemModel.extraExtend["quality"] = "hd"
        //搜索页面适配
        let isSearchPage:Bool = false
        if (isSearchPage) {
            itemModel.extend["isMutePlay"] = false
        }
        

    }
    
    func receiveEstimatedLayout(_ itemWidth: Double) {

        let itemLayout = item?.itemModel?.layout
        
        var itemHeight: Double = calcItemHeight(itemWidth)
        if let compTag = self.item?.itemModel?.type, (compTag != "12086" && compTag != "12093") {
            itemHeight += 28.0
        }
        
        itemLayout?.renderRect = CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight)
    }
    
    func enterDisplayArea(itemView: UIView?) {
        if let adModel = adModel {
            if !isExposed {
                isExposed = true
                self.nadApi.adExposure(adModel)
            }
        }
        
        self.playerToolsEventHandler.enableShake()
        
        isVisibled = true;
    }
    
    func exitDisplayArea(itemView: UIView?) {
        self.playerToolsEventHandler.disableShake()
        
        isVisibled = false;
    }
    
    func didActivate() {
        isActivated = true
        
        if (isVisibled) {
            self.playerToolsEventHandler.enableShake()
        }
    }
    
    func didDeactivate() {
        isActivated = false

        self.playerToolsEventHandler.disableShake()
    }
    
    func appWillResignActive() {
        
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item12093ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item12093ContentView else {
            return
        }
        guard let itemModel = self.item?.itemModel as? HomeItemModel else {
            return
        }
        guard let itemLayout = self.item?.itemModel?.layout else {
            return
        }
        
        self.containerView = itemView

        itemView.clipsToBounds = false
        itemView.superview?.clipsToBounds = false
        itemView.videoImageView.isHidden = false
        itemView.fillData(model: self.adModel, itemModel: itemModel)
                
        //埋点
        Service.statistics.bind(itemModel.action?.report, itemView, .Defalut)
        //跳转
        weak var weakself = self
        itemView.whenTapped {
            if let weakself = weakself {
                weakself.click(false)
            }
        }

        //负反馈
        Service.feedback.attach(itemModel.feedbackModel, toView: itemView.contentView, morePos: .BottomRightBorder, isSupportUndo: false) {
            if let weakself = weakself,
               let component = weakself.item?.getComponent()
               {
                deleteComponentWithAnimation(component)
                if let ad = weakself.adModel {
                    weakself.nadApi.adClose(ad)
                }
            }
        }
        
        if let feedbackBtn = itemView.contentView.viewWithTag(999998) {
            itemView.superview?.accessibilityElements = [itemView, feedbackBtn]
            feedbackBtn.centerY = itemView.headIcon.centerY
            self.playerToolsEventHandler.feedbackBtn = feedbackBtn
        }
            
        //player
//        itemModel.playerModel?.videoURL = "XNTg4ODI4MjE3Ng=="
        var extraExtend = itemModel.playerModel?.extraExtend
        if extraExtend == nil {
            extraExtend = [String : Any]()
            itemModel.playerModel?.extraExtend = extraExtend
        }
        itemModel.playerModel?.extraExtend?["alpha_video"] = 1
        
        if let playerModel = itemModel.playerModel {
            Service.player.attach(playerModel, toView: itemView, displayFrame: itemView.bounds)

            playerModel.repeatPlay = true
            playerModel.isHideWaterMark = true
            
            playerModel.slientModeInPage = false
            //搜索特殊适配： 音量设置需要走页面级控制
            if let vc = item?.getPage()?.pageContext?.getViewController()  {
                let vcClassStr = NSStringFromClass(type(of: vc))
                if vcClassStr == "YKSokuSwift.NewSearchDefaultViewController" || vcClassStr == "YKSokuSwift.NewSearchDefaultPageController" ||  vcClassStr == "YKSokuSwift.YKSKDefaultPageController" ||   vcClassStr == "YKSokuSwift.YKSKDefaultViewController" {
                    playerModel.slientModeInPage = true
                }
            }
            if let cf = self.adModel?.cf {
                if cf == 1 {
                    itemModel.extraExtend["adIsMutePlay"] = false
                } else {
                    itemModel.extraExtend["adIsMutePlay"] = true
                }
            }

            if let ad_reqid = self.adModel?.reqId as? String {
                var extraExtend = playerModel.extraExtend
                if extraExtend == nil {
                    extraExtend = [String: Any]()
                }
                var userInfo = extraExtend?["userInfo"] as? [String : Any] ?? [String : Any]()
                userInfo.merge(dict: ["ad_reqid": ad_reqid])
                extraExtend?["userInfo"] = userInfo
                playerModel.extraExtend = extraExtend
            }
            //adBizInfo
            AdPlayInfoUtil.updatePlayModelExtraWithAd(playerModel: playerModel, oadModel: self.adModel)
        }
    }
    
    ///PlayerToolsEventHandlerDelegate
    func didPlayerStart(_ playerModel: PlayerModel?) {
        guard let playerModel = playerModel else {
            return
        }
        if let itemView = playerModel.itemView as? Item12093ContentView {
            itemView.videoImageView.isHidden = true
        }
    }
    
    func didPlayerStop(_ playerModel: PlayerModel?) {
        guard let playerModel = playerModel else {
            return
        }
        if let itemView = playerModel.itemView as? Item12093ContentView {
            itemView.videoImageView.isHidden = false
        }
    }
    
    func calcItemHeight(_ itemWidth: Double) -> Double {
        guard let itemModel = self.item?.itemModel else {
            return 0.0
        }
        let realItemWidth = itemWidth
        let itemWidth = itemWidth - YKNGap.youku_margin_left() - YKNGap.youku_margin_right()
        var h = ceil(itemWidth * RATIO_9_16)
        
        let titleString = self.adModel?.mainTitle ?? "广告"
        let titleLayout = TextLayoutModel.init()
        titleLayout.font = YKNFont.posteritem_maintitle_weight(YKNFontWeight.medium)
        
        var titleWidth = itemWidth - Double(2 * YKNGap.dim_6())
        if let _ = itemModel.uploader?.isShowHeadIcon {
            titleWidth -= Double(36 + YKNGap.dim_5())
        }
        titleLayout.boundingSize = calcStringSize(titleString, font: titleLayout.font, size: CGSize.init(width: 10000, height: 60))
        itemModel.layout.title = titleLayout

        if let tw = titleLayout.boundingSize?.width, Double(tw) > titleWidth {
            h += Double(YKNGap.dim_5()) + 40.0 + 5.0 + 17.0 + Double(YKNGap.dim_6())
        } else {
            h += Double(YKNGap.dim_5()) + 20.0 + 5.0 + 17.0 + Double(YKNGap.dim_6())
        }
        //默认返回
        return realItemWidth * 0.66
    }
        
    func isPageInPreload() -> Bool {
        guard let pageModel = self.item?.getPage()?.pageModel else {
            return false
        }
        if pageModel.dataState == .cache || pageModel.dataState == .default {
            return true
        }
        return false
    }
    
    func shakeToLandingPage() {
        if isViewVisible(self.containerView) == false {
            print("[12093] shake not visible")
            return
        }
        
        if isActivated == false {
            print("[12093] shake not activate")
            OADUtil.recordShakeLoss(3, with: self.adModel, extra: ["hasFocus": "0"])
            return
        }
        
        print("[12093] shake click")
        self.click(true)
    }
    
    func isViewVisible(_ view: UIView?) -> Bool {

        guard let page = self.item?.getPage() else {
            return false
        }
        
        guard let paddingTop = page.containerPaddingTop(page) else {
            return false
        }
        
        guard let itemView = view else {
            return false
        }
                        
        let topHeight = paddingTop
        let bottomHeight = YKTabbarHeight()
        let visibleArea : CGRect = CGRect.init(x: 0, y: topHeight, width: YKRLScreenWidth(), height: SCREEN_HEIGHT - topHeight - bottomHeight)
        let rect = itemView.convert(itemView.bounds, to: nil)

        if visibleArea.intersects(rect) {
            return true
        }

        return false
    }
    
    //MARK: click
    func click(_ isShake: Bool) {
        guard let adModel = adModel else {
            return
        }
        
        var params: [AnyHashable: Any] = [AnyHashable: Any]()
        if let extend = adModel.extend {
            extend.forEach { (key: AnyHashable, value: Any) in
                params[key] = value
            }
        }
        if isShake {
            params["shake"] = "1"
        } else {
            params.removeValue(forKey: "shake")
        }
        adModel.extend = params
        
        self.nadApi.adClickAction(adModel, extraParams: isShake ? ["shake": "1"] : nil)
    }

}
