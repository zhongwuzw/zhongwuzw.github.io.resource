//
//  Item12093ShakeView.swift
//  YKChannelComponent
//
//  Created by wustlj on 2022/7/25.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import DYKH5SDK
import orange

protocol Item12093ShakeDelegate: NSObjectProtocol {
    func shakeToLandingPage()
}

class Item12093ShakeView: UIView, DYKH5WebViewDelegate {
    
    var nowTimeInterval: TimeInterval = 0.0
    var lastTimeInterval: TimeInterval = 0.0
    
    weak var delegate: Item12093ShakeDelegate?
    
    var shakeView: DYKH5WebView?
    
    var loadSuccessed: Bool = false
    
    var shakeEnabled: Bool = false
    var atuoWhenAppActived: Bool = false

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.backgroundColor = .clear
        self.isUserInteractionEnabled = false
        
        NotificationCenter.default.addObserver(self, selector: #selector(resignActive),
                                               name:UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(becomeActive),
                                               name:UIApplication.didBecomeActiveNotification, object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        shakeView?.frame = self.bounds
    }
        
    func load(_ url: String) {
        if shakeView == nil {
            let configuration = DYKH5WebViewConfiguration()
            configuration?.shouldInitBaichuan = false
            
            shakeView = DYKH5WebView.init(frame: self.bounds, withURL: url, configuration: configuration)
            shakeView?.delegate = self
            shakeView?.isUserInteractionEnabled = false
            shakeView?.isOpaque = false
            shakeView?.scroll().clipsToBounds = true
            shakeView?.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            shakeView?.backgroundColor = .clear
            shakeView?.scroll().backgroundColor = .clear
            
            weak var weakSelf = self
            shakeView?.registerJSBridgeHandler("DYKNadJSBridge", handlerName: "shakeToLandingPage", with: { (params: [AnyHashable : Any]?, context: WVBridgeCallbackContext) in
                weakSelf?.shakeToLandingPage()
            })
        }
        
        if !loadSuccessed {
            shakeView?.loadURL()
        }
        
        if let shakeView = shakeView {
            addSubview(shakeView)
        }
    }
  
    func webViewDidFinishLoad(_ webView: DYKH5WebView!) {
        print("[12093] [shake] load shake Success")
        
        loadSuccessed = true
        shakeView?.isHidden = false
    }
    
    func webView(_ webView: DYKH5WebView!, didFailLoadWithError error: Error!) {
        print("[12093] [shake] load shake fail")

        loadSuccessed = false
        shakeView?.isHidden = true
    }
    
    func enableShake() {
        print("[12093] [shake] enableShake")

        if let shakeView = shakeView {
            shakeView.postNotification(toJS: "WV.Event.shake.enable", withEventData: nil)
            postNotification("adshakeviewshowed", nil)
            
            shakeEnabled = true
        }
    }
    
    func disableShake() {
        if self.isHidden == true {
            return
        }
        
        print("[12093] [shake] disableShake")

        if let shakeView = shakeView {
            shakeView.postNotification(toJS: "WV.Event.shake.disable", withEventData: nil)
            postNotification("adshakeviewremoved", nil)
            
            shakeEnabled = false
        }
    }
        
    func shakeToLandingPage() {
        if UIApplication.shared.applicationState != .active {
            print("[12093] [shake] not active")
            return
        }
        
        
        nowTimeInterval = Date().timeIntervalSince1970

        if checkInterval() {
            lastTimeInterval = nowTimeInterval
            
            delegate?.shakeToLandingPage()
        } else {
            print("[12093] [shake] 间隔不足")
        }
    }
    
    @objc func resignActive() {
        atuoWhenAppActived = shakeEnabled;
        
        disableShake()
    }

    @objc func becomeActive() {
        if atuoWhenAppActived {
            atuoWhenAppActived = false
            enableShake()
        }
    }
    
    func checkInterval() -> Bool {
        let interval = shakeInterval()
        if interval == 0.0 {
            return true
        }
        
        return (nowTimeInterval - lastTimeInterval) > interval;
    }
    
    func shakeInterval()-> Double {
        if let orangeDict = Orange.getGroupConfig(byGroupName: "NovelAdSDK-iOS") {
            let interval = orangeDict["shake_v0_check_interval"]
            if let i = interval as? Double {
                return i
            } else if let i = interval as? String {
                return Double(i) ?? 1.0
            }
        }
        
        return 1.0
    }
            
}
