//
//  PlayerToolsView12093.swift
//  YKChannelComponent
//
//  Created by CC on 2022/7/25.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

public class PlayerToolsView12093: BasePlayerToolsViewV2 {
    weak var feedbackBtn:UIView?
    lazy var shakeView: Item12093ShakeView = {
        let view = Item12093ShakeView(frame: CGRect.init(x: 0, y: 0, width: 200, height: 100))
        return view
    }()
    
    override func createSubviews() {
        addSubview(shakeView)
        super.createSubviews()
    }
    
    public override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        if let feedbackBtn = feedbackBtn {
            let rect = feedbackBtn.superview?.convert(feedbackBtn.frame, to: self) ?? CGRect.zero
            if rect.contains(point) {
                return feedbackBtn
            }
        }
        return super.hitTest(point, with: event)
    }
    
    override public func fillModel(_ model: BaseItemModel?) {
        super.fillModel(model)
        
        
        if let shakeUrl = model?.extend["shakeUrl"] as? String {
            shakeView.isHidden = false
            shakeView.load(shakeUrl)
        } else {
            shakeView.isHidden = true
        }
    }
    
    override func customLayout() {
        super.customLayout()
        let slientIconW = CGFloat(24)
        let x = self.width - slientIconW - 10 - YKNGap.youku_margin_right()
        let imageWidth = self.width - YKNGap.youku_margin_left() - YKNGap.youku_margin_right()
        let imageHeight = imageWidth * RATIO_9_16
        let y = CGFloat(10)
        slientIcon.frame = CGRect.init(x: x, y: y, width: slientIconW, height: slientIconW)
        
        shakeView.frame = self.bounds
    }
}
