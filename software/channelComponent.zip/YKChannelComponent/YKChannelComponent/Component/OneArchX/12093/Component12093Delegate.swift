//
//  Component12093Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/7/22.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Component12093Delegate:NSObject, ComponentDelegate {
    
    var compPaddingTop:CGFloat = 0

    static func create() -> ComponentDelegate {
        return Component12093Delegate.init()
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: compPaddingTop, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        config.preferredCardSpacingTop = 9.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0 //100
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [PlayerScrollEndCompEventHandler()]
    }
    
    func componentDidInit() {

    }
    
    var componentWrapper: ComponentWrapper?
    
}
