//
//  PlayerTools12093EventHandler.swift
//  YKChannelComponent
//
//  Created by CC on 2022/7/25.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchBridge
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource


@objcMembers
public class PlayerTools12093EventHandler: ItemEventHandler,PlayerToolsViewableV2,PlayerStatusCallback {
    
    // 语音搜索面板将要展示
    let SKNotification_voiceViewWillShow = "YKSCSokuVoiceViewWillShow"
    // 语音搜索面板已经关闭关闭
    let SKNotification_voiceViewDidClose = "YKSCSokuVoiceViewDidClose"
    
    weak var feedbackBtn:UIView? 
    weak var  itemModel:BaseItemModel? {
        get {
            return self.item?.itemModel
        }
    }

    weak var delegate: PlayerToolsEventHandlerDelegate?
    weak var shakedelegate: Item12093ShakeDelegate?
    
    var isSlientMode:Bool = true

    //是否第一次播放，针对循环播放。 主动stop后重置为true
    var isFirstPlay:Bool = true
    
    //搜索语音开启中
    var isInSearchVoice:Bool = false
    
    //MARK: Property
    lazy var playerToolsView: PlayerToolsView12093 = {
        let view = PlayerToolsView12093()
        view.clipsToBounds = true
        view.delegate = self
        return view
    }()
    
    required init() {
        super.init()
        NotificationCenter.default.addObserver(self, selector: #selector(performVoiceViewWillShow), name: Notification.Name(rawValue: SKNotification_voiceViewWillShow), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(performVoiceViewDidClose(_:)), name: Notification.Name(rawValue: SKNotification_voiceViewDidClose), object: nil)
    }

    deinit {
    }
    

    override public func listeningEventObservers() -> [EventObserver]? {
        let observer1 = EventObserver(EventName.itemReuseItemView)
        let observer2 = EventObserver("item.event.player.stop")
        
        return [observer1, observer2]
    }
        
    public override func onEvent(_ event: OEvent) {
        if event.name == EventName.itemReuseItemView {
            self.receiveReuseEvent(event)
        } else if event.name == "item.event.player.stop" {
            self.itemPlayerStopEvent()
        }
    }
    
    func receiveReuseEvent(_ event: OEvent) {
        self.itemModel?.playerModel?.playerDelegate = self
    }
    
    func updateSlientStatusWithPlayerStart(_ player: PlayerView) {
        if let commonSlientMode = PlayerControlManagerV2.shareInstance().commonSlientMode(self.item) {
            player.isSlientMode = commonSlientMode
        }
        self.playerToolsView.isSlientMode = player.isSlientMode
        self.playerToolsView.bindSlientStatistics()
        self.playerToolsView.slientIconUpdate()
    }
    
    
    //MARK:YKPlayerStatusDelegate
    public func didStartPlayVideoInPlayer(_ player: PlayerView) {
        guard let itemModel = itemModel else {
            return
        }
        //1.isUserInteractionEnabled
        let embedPlayerView = player.embedPlayerView
        embedPlayerView?.isUserInteractionEnabled = true

        //2.add view
        if let playBackFrame = player.model?.playBackFrame {
            let toolsFrame = CGRect.init(x: 0, y: 0, width: playBackFrame.width, height: playBackFrame.height)
            self.playerToolsView.frame = toolsFrame
        }
        self.playerToolsView.tag = 2021042305
        
        if let oldView = embedPlayerView?.viewWithTag(2021042305) {
            oldView.removeFromSuperview()
        }
        embedPlayerView?.addSubview(self.playerToolsView)
        self.playerToolsView.feedbackBtn = self.feedbackBtn
        if let adIsMutePlay = itemModel.extraExtend["adIsMutePlay"] as? Bool {
            player.isSlientMode = adIsMutePlay
            self.playerToolsView.isSlientMode = adIsMutePlay
        }
        if let commonnSlientMode = PlayerControlManagerV2.shareInstance().commonSlientMode(self.item) {
            self.playerToolsView.isSlientMode = commonnSlientMode
        }
        self.playerToolsView.fillModel(itemModel)
        self.playerToolsView.shakeView.delegate = shakedelegate
        enableShake()
        
        //3.slient
        self.updateSlientStatusWithPlayerStart(player)
        if isInSearchVoice {
            player.isSlientMode = true
            self.playerToolsView.isSlientMode = player.isSlientMode
            self.playerToolsView.slientIconUpdate()
        }

        
        self.delegate?.didPlayerStart(player.model)
    }
    
    public func didClickStopPlayer(_ embedPlayer: PlayerView) {
        self.isFirstPlay = true
        self.playerToolsView.removeFromSuperview()
        
        self.delegate?.didPlayerStop(embedPlayer.model)
    }
    
    public func didFinishPositiveVideoInPlayer(_ player: PlayerView) {
        self.delegate?.didPlayerStop(player.model)
    }

    //bugfix: didstop回调时 组件已经被销毁，导致removeFromSuperview失效
    public func itemPlayerStopEvent() {
        self.playerToolsView.removeFromSuperview()
    }
    
    func slientModeUpdate(isSlientMode: Bool) {
        self.isSlientMode = isSlientMode
        PlayerControlManagerV2.shareInstance().updateCommonSlientMode(self.item, newMode: isSlientMode)
    }
    
    func enableShake() {
        playerToolsView.shakeView.enableShake()
    }
    
    func disableShake() {
        playerToolsView.shakeView.disableShake()
    }

    ///MARK: 搜索页面自定义生命周期

    @objc func performVoiceViewWillShow() {
   
        
        if let currentPlayer = PlayerControlManagerV2.shareInstance().currentPlayerView,
           let currentPlayerModel = currentPlayer.model,
           let playerModel = self.item?.itemModel?.playerModel {
            if ObjectIdentifier(playerModel) == ObjectIdentifier(currentPlayerModel) {
                isInSearchVoice = true
                //player
                currentPlayer.isSlientMode = true
                //playerTools
                self.playerToolsView.isSlientMode = currentPlayer.isSlientMode
                self.playerToolsView.slientIconUpdate()
                
            }
        }
        
    }
    
    @objc func performVoiceViewDidClose(_ noti: Notification) {
     
//        if let currentPlayer = PlayerControlManagerV2.shareInstance().currentPlayerView,
//           let currentPlayerModel = currentPlayer.model,
//           let playerModel = self.item?.itemModel?.playerModel {
//            if ObjectIdentifier(playerModel) == ObjectIdentifier(currentPlayerModel) {
//                isInSearchVoice = false
//                currentPlayer.isSlientMode = false
//                //playerTools
//                self.playerToolsView.isSlientMode = currentPlayer.isSlientMode
//                self.playerToolsView.slientIconUpdate()
//            }
//        }
    }

}
