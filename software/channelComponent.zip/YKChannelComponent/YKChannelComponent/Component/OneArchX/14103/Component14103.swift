//
//  Component14103.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/5/10.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku

class Component14103: NSObject, ComponentDelegate {
   
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {

    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        let vc = component?.getPage()?.pageContext?.getViewController()
        let top = 3.0
        config.padding = UIEdgeInsets.init(top: top, left: YKNGap.youku_margin_left(), bottom: 9, right: YKNGap.youku_margin_right())
        return config
    }

    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
