//
//  Item14103.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/5/10.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Item14103: NSObject, ItemDelegate {

    var itemWrapper: ItemWrapper?
    
    func getModelClass<T: NodeModel>() -> T.Type? {
        return HomeItemModel.self as? T.Type
    }
    
    func itemDidInit() {

    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let itemHeight: CGFloat = YKNFont.height(with: Item14103ContentView.titleLabelFont(), lineNumber: 1)
        estimatedLayout(CGSize.init(width: itemWidth, height: itemHeight))
        
        return itemHeight
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14103ContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14103ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? HomeItemModel else {
            return
        }
        
        itemView.item = self.item
        itemView.fillModel(itemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func estimatedLayout(_ size: CGSize) {
        guard let itemModel = self.item?.model as? HomeItemModel else {
            return
        }
        
        guard let layoutModel = self.item?.layout else {
            return
        }
        
        if layoutModel.boundingSize == size {
            return //重复计算跳过
        }
        
        layoutModel.boundingSize = size
        layoutModel.renderRect = CGRect.init(origin: .zero, size: size)
        
        
        var titleWidthMax = size.width
        
        if let desc = itemModel.desc, !desc.isEmpty {
            //箭头
            let arrow = ImageLayoutModel()
            let arrowWidth: CGFloat = 12
            let arrowHeight: CGFloat = 12
            let arrowX = size.width - arrowWidth
            let arrowY = (size.height - arrowHeight) * 0.5
            arrow.renderRect = CGRect.init(x: arrowX, y: arrowY, width: arrowWidth, height: arrowHeight)
            layoutModel.cover = arrow
            
            //箭头标题
            let action = TextLayoutModel()
            action.font = Item14103ContentView.titleLabelFont()
            action.lineNumber = 1
            
            let actionWidth = ceil(calcStringSize(desc, font: action.font, size: size).width)
            let actionX = arrow.renderRect.minX - actionWidth
            let actionHeight: CGFloat = size.height
            action.renderRect = CGRect.init(x: actionX, y: 0, width: actionWidth, height: actionHeight)
            layoutModel.subtitle = action
            
            titleWidthMax = max(0, action.renderRect.minX - 9)
        }
        
        //主标题
        let title = TextLayoutModel()
        title.font = Item14103ContentView.titleLabelFont()
        title.lineNumber = 1
        
        let titleHeight: CGFloat = size.height
        title.renderRect = CGRect.init(x: 0, y: 0, width: titleWidthMax, height: titleHeight)
        layoutModel.title = title
    }

}


