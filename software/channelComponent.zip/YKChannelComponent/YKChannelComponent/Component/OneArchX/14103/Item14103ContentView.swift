//
//  Item14103ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/5/10.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import SDWebImage
import YKChannelPage
import YoukuResource
import OneArchSupport
import YKResponsiveLayout
import OneArchSupport4Youku

class Item14103ContentView: UIView, RoleRankPickerViewDelegate {

    //MARK: - Property
    lazy var titleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_tertiaryInfo
        view.font = Item14103ContentView.titleLabelFont()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        view.whenTapped { [weak self] in
            self?.titleAction()
        }
        return view
    }()
    
    lazy var actionLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_tertiaryInfo
        view.font = Item14103ContentView.titleLabelFont()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var arrowImageView: UIImageView = {
        let imageView = UIImageView.init(frame: CGRect.init(origin: .zero, size: CGSize.init(width: 12, height: 12)))
        imageView.contentMode = .scaleAspectFill
        imageView.image = UIImage.init(named: "node_page_icon_14009_arrow")?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = UIColor.ykn_tertiaryInfo
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    weak var item: IItem?
    weak var model: HomeItemModel?
    
    var date: HomeDateItemModel?
    var pickerView: RoleRankPickerView?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(titleLabel)
        addSubview(actionLabel)
        addSubview(arrowImageView)
    }
    
    func fillModel(_ itemModel: HomeItemModel) {
        model = itemModel
        relayoutIfNeeded(itemModel)
                
        //填充文字
        updateTitle()
        actionLabel.text = itemModel.desc
        

        //绑定跳转、埋点
        if let ruleTitle = itemModel.extend["ruleTitle"] as? String,
           let ruleDesc = itemModel.extend["ruleDesc"] as? String {
            OneArchSupport.Service.action.bind(nil, actionLabel)
            actionLabel.whenTapped {
                let dialogA2 = YKN_dialog_a2_view.init()
                dialogA2.tipHeightToFit = true
                dialogA2.headerTitleLabel.text = ruleTitle
                dialogA2.headerTipLabel.text = ruleDesc
                
                let dialog = YKNDialog.init(customView: dialogA2)
                dialogA2.confirmBlock = {
                    dialog?.dismiss()
                }
                
                dialog?.tapBackgroundDismiss = true
                dialog?.show()
            }
            OneArchSupport.Service.statistics.bind(itemModel.action?.report, actionLabel, .Defalut)
        } else {
            actionLabel.clearTapHandler()
            OneArchSupport.Service.action.bind(itemModel.action, actionLabel)
        }
        
        //氛围适配
        titleLabel.textColor = sceneUtil(UIColor.ykn_tertiaryInfo, sceneColor: itemModel.scene?.sceneSubTitleColor())
        actionLabel.textColor = sceneUtil(UIColor.ykn_tertiaryInfo, sceneColor: itemModel.scene?.sceneSubTitleColor())
        arrowImageView.tintColor = sceneUtil(UIColor.ykn_tertiaryInfo, sceneColor: itemModel.scene?.sceneSubTitleColor())
    }
    
    private func relayoutIfNeeded(_ model: HomeItemModel) {
        let layout = model.layout
        
        //title
        titleLabel.frame = layout.title?.renderRect ?? CGRect.zero
        
        //action
        actionLabel.frame = layout.subtitle?.renderRect ?? CGRect.zero
        
        //arrowImageView
        arrowImageView.frame = layout.cover?.renderRect ?? CGRect.zero
    }
    
    // MARK: 字体
    class func titleLabelFont() -> UIFont {
        let font = YKNFont.posteritem_subhead()
        return font
    }
    
    // MARK: - RoleRankPickerViewDelegate
    
    private func titleAction() {
        if let dates = self.model?.dates, dates.count > 0 {
            guard let page = item?.getPage() as? ITabPage,
                    let superPage = page.getSuperPage(),
                    let view = superPage.pageContext?.getViewController()?.view else {
                return
            }
            
            //创建新视图
            if self.pickerView == nil {
                let pickerView = RoleRankPickerView.init(frame: view.bounds, dates: dates)
                pickerView.delegate = self
                self.pickerView = pickerView
            }
            self.pickerView?.showInView(view)
        }
    }
    
    func didSelectItemInfo(_ itemInfo: [String : Any]) {
        if let page = item?.getPage() {
            date = itemInfo["date"] as? HomeDateItemModel
            //更新title
            updateTitle()
            //更新pageContext
            updateBizContext(itemInfo)
            //触发请求
            page.triggerFirstPageRequest()
        }
    }
    
    func updateBizContext(_ itemInfo:[String: Any]) {
        if let pageDelegate = item?.getPage()?.getPageDelegate() as? NodePageYKVBangNormalProxy {
            var tmpItemInfo = [String: Any]()
            tmpItemInfo["date"] = date?.key
            tmpItemInfo["dimension"] = itemInfo["dimension"] as? String
            pageDelegate.extParams = tmpItemInfo
        }
    }
    
    func updateTitle() {
        if let itemModel = model, let dates = itemModel.dates, dates.count > 0 {
            titleLabel.font = YKNIconFont.sharedInstance().font(withSize: 12)
            var title = "今天"
            //拼接部分
            var subtitle = ""
            if let mTitle = model?.title, mTitle.count > 0{
                subtitle =  " " + mTitle
            }
            //完整标题
            if let tmpModel = date {
                let realTime = tmpModel.realTime
                title = (tmpModel.label ?? "") + (realTime ? subtitle : "")
            } else {
                title = title + subtitle
            }
            titleLabel.text = title + " \u{e6d3}"
            
        } else {
            titleLabel.font = Item14103ContentView.titleLabelFont()
            titleLabel.text = model?.title
        }
    }
    
}
