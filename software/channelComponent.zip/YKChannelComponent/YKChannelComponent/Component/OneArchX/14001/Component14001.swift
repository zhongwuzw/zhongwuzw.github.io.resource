//
//  Component14001.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/28.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import YKSCService
import YKDowngradeSDK
import orange
import YKChannelPage
import YKHome

class Component14001: NSObject, ComponentDelegate {
   
    var componentWrapper: ComponentWrapper?
    var javisHandler: JarvisRecommendedHandler?

    var newLayoutTypeIsClosed: Bool { //记录新布局类型被关闭
        return self.judgeNewLayoutTypeIsClosed()
    }
    
    func componentDidInit() {
        if let componentModel = self.component?.model as? BaseComponentModel {
            componentModel.extraExtend["aspectRatio"] = 1.78
        }
        self.javisHandler = JarvisRecommendedHandler(self)
    }
    
    func getItemJsonExtracter() -> ItemJsonExtracter? {
        let jsonExtracter = ItemJsonExtractor14001.init()
        jsonExtracter.component = self.component
        return jsonExtracter
    }

    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Component14001Model.self as? T.Type
    }
    
    var printed = false
    func layoutType() -> ComponentLayoutType {
        // 支持orange关闭
        let isClosed = self.newLayoutTypeIsClosed
        
        if !printed {
            printed = true
            YKSCScreenLogUtil.printLog("[热播大卡] 14001 使用\(isClosed ? "老" : "新")布局", color: .red)
        }
        
        // 当前回到主线程，javis存数据（只存一次）
        self.javisHandler?.saveUsedDomainDataIfNeeded()
        
        return isClosed ? .columnAverage : .columnAverageMixed
    }

    func isShowBackground() -> Bool {
        return false
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.youku_module_margin_top()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        if ykrl_isResponsiveLayout() {
            config.rowSpacing = 18 // 20221129版本 目标值18，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        if ykrl_isResponsiveLayout() {
            config.footerTopMargin = -9.0 // 20221129版本 目标值上下距离18，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        config.footerBottomMargin = YKNGap.youku_comp_margin_bottom()
        return config
    }

    func columnCount() -> CGFloat {
        return 2
    }

    /// 是否展示组件尾
    func isShowFooter() -> Bool {
        guard let componentModel = self.component?.model as? BaseComponentModel else {
            return false
        }
        if let change = componentModel.change, change.changeOnDrawer == true {
            return false
        }
        if componentModel.enter != nil || componentModel.change != nil {
            return true
        }
        return false
    }

    func footerTag() -> String? {
        return "comp.generic.footer"
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [PlayerScrollEndCompEventHandler()]
    }

    var judgedValue = -1 //只处理一次
    // 布局类型支持orange控制
    func judgeNewLayoutTypeIsClosed() -> Bool {
//        if ykrl_isResponsiveLayout() {
//            return true
//        }
        
        if judgedValue != -1 { //判断过直接返回
            return judgedValue == 1
        }
        
        var orangeInfo = Orange.getGroupConfig(byGroupName: "yksc_config")
//        orangeInfo = [String : Any]()
//        orangeInfo?["home_comp14001_diable_new_layout_type_set"] = "selection,TV"
        
        var returnResult = false
        if let disableSet = orangeInfo?["home_comp14001_diable_new_layout_type_set2"] as? String, disableSet.count > 0 { // 按如下格式配置："selection,TV,"
            if disableSet.contains("all") {
                returnResult = true
            } else {
                let usedArr = disableSet.components(separatedBy: ",")
                
                var nodeKey = self.component?.getPage()?.pageModel?.nodeKey
                let nodeKey2 = (self.component?.getPage()?.getPageInitialModel() as? BasePageModel)?.nodeKey
                
                let isSelection = self.isSelectionPage() //精选nodeKey较多，统一成一个
                if isSelection {
                    nodeKey = "selection"
                }
                
//                YKSCScreenLogUtil.printLog("[热播大卡] 14001 orange信息 set:\(disableSet) nodeK:\(String(describing: nodeKey)) nodeK2:\(String(describing: nodeKey2)) 是精选:\(isSelection)", color: .red)
                
                let result = usedArr.contains(where: { str in
                    return nodeKey == str || nodeKey2 == str
                })
                
                returnResult = result
            }
        }
        
        self.judgedValue = returnResult ? 1 : 0
        
        return returnResult
    }
    
    func isSelectionPage() -> Bool {
        return self.component?.getPage()?.pageContext?.concurrentDataMap["yksc.data.page.prop.cms.channel.isSelection"] as? Bool ?? false
    }
}

class Item14001: BaseItemDelegate, ItemAddPageScrollEventHandlerDelegate {
    var hasJudgeRendered: Bool = false
    var newPreviewHandler: Item14001SuperPreviewHandler?
    
    override func loadEventHandlers() -> [ItemEventHandler]? {
        let playerHandler = PlayerScrollEndItemEventHandler()
        var superHandlers = super.loadEventHandlers()
        superHandlers?.append(playerHandler)
        
        if !ykrl_isResponsiveLayout() &&
            !shouldDowngrade() &&
            self.item?.getPage()?.dataState == .network &&
            self.canShowPreview() {
            let handler = Item14001SuperPreviewHandler.init()
            self.newPreviewHandler = handler
            superHandlers?.append(handler)
            
            let scrollHandler = ItemAddPageScrollEventHandler()
            scrollHandler.delegate = self
            
            superHandlers?.append(scrollHandler)
        }
        
        if CustomBehaviorPageService.shareInstance().isEnabelCustomClientAIReport() {
            let handler = ItemClientAIEventHandler()
            superHandlers?.append(handler)
        }
        
        return superHandlers
    }
    
    override func createView(_ itemSize: CGSize) -> UIView {
        if hasSubNodes() {
            let itemView = BaseMultiItemContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            return itemView
        } else {
            let itemView = Item14001ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            return itemView
        }
    }
    
    override func reuseView(itemView: UIView) {
        super.reuseView(itemView: itemView)
        //reuse涉及到复用问题， player必须重新attach
        if let playerModel = self.item?.itemModel?.playerModel, let itemView = itemView as? BaseItemContentView {
            let imageSize = itemView.videoImageView.size
            Service.player.attach(playerModel, toView: itemView.videoImageView, displayFrame: CGRect.init(origin: CGPoint.zero, size: imageSize))
        }
        // 大剧预览
        self.showPreviewIfNeeded(itemView: itemView)
        
        // 补充pv埋点参数，用index0是否渲染来标记
        guard hasJudgeRendered == false, let index = self.item?.index, index == 0 else {
            return
        }
        
        hasJudgeRendered = true
        
        if isSelectionChannel(self.item), let pageModel = self.item?.getPage()?.pageModel {
            let renderType = buildRenderTypeValue(pageModel)
            pageModel.pvModel?.extend["14001renderType"] = renderType
            print("[pv extra] renderType: \(renderType)")
            
            judgeAndReportFirstPagePaint()
        }
    
        if let playerModel = self.item?.itemModel?.playerModel, let itemView = itemView as? BaseItemContentView {
            let imageSize = itemView.videoImageView.size
            Service.player.attach(playerModel, toView: itemView.videoImageView, displayFrame: CGRect.init(origin: CGPoint.zero, size: imageSize))
        }
    }
    
    override func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14001Model.self as? T.Type
    }

    func isSelectionChannel(_ item: IItem?) -> Bool {
        guard let page = item?.getPage() else {
            return false
        }
        
        let nodeKey = page.pageModel?.nodeKey
        let isSelection = nodeKey == "SELECTION" || nodeKey == "NUSELECTION" || nodeKey == "SELECTIONYOUNG"
        return isSelection
    }
    
    func buildRenderTypeValue(_ pageModel: BasePageModel) -> Int {
        var renderType: Int = 0
        if pageModel.dataState == .network {
            renderType = 3
        } else if pageModel.dataState == .cache || pageModel.dataState == .default { //缓存数据
            renderType = 2
        }
        
        if let isBundleData = pageModel.config.getStringValue("isHomeAssetsData"), isBundleData == "1" { //使用bundle数据
            renderType = 1
        }
        
        return renderType
    }
    
    // MARK: - 80%渲染clue埋点
    static var firstPagePaintReported = false
    func judgeAndReportFirstPagePaint() {
        if Item14001.firstPagePaintReported {
            return
        }
        
        let s = CFAbsoluteTimeGetCurrent()
        Item14001.firstPagePaintReported = true
        
        DispatchQueue.main.async {
            let e = CFAbsoluteTimeGetCurrent()
            NSLog("[首页80%渲染] 开始上报 c:\(e) b:\(s) d:\((e-s) * 1000)")
            HomeClueHelper.sharedInstance().reportFirstPagePaint()
        }
    }
    
    // MARK: -超级预览
    
    func showPreviewIfNeeded(itemView: UIView) {
        guard let handler = self.newPreviewHandler else {
            return
        }
        
        handler.reuseViewEvent()
    }
    
    // MARK: - 判断每日显示次数
    let dailyCountKey = "kItem14001NewPreviewHandler_dailyCount"
    let saveCountKey = "kItem14001NewPreviewHandler_savedDate"
    
    func canShowPreview() -> Bool {
        guard let itemModel = self.item?.model as? Item14001Model , let superPreviewModel = itemModel.superPreviewModel else {
            return false
        }
        
        let currentDate = self.dateFormatter.string(from: Date())
        let todayShowNum = self.todayPreviewNum(currentDate)
        let serverTotalNum = superPreviewModel.limit
        YKSCScreenLogUtil.printLog("[热播大剧] 今日已看\(todayShowNum)次 总共可看\(serverTotalNum)次", color: .green)
        if serverTotalNum > 0 && serverTotalNum > todayShowNum , let vid = superPreviewModel.videoId, vid.isEmpty == false {
            return true
        }
        
        return false
    }
    
    lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    } ()
    
    func savePreviewNum() {
        let currentDate = self.dateFormatter.string(from: Date())
        var dailyCount = todayPreviewNum(currentDate)
        dailyCount += 1
        
        UserDefaults.standard.set(dailyCount, forKey: dailyCountKey)
        UserDefaults.standard.set(currentDate, forKey: saveCountKey)
    }
    
    func todayPreviewNum(_ currentDate: String) -> Int {
        var dailyCount = 0
        let savedDate = UserDefaults.standard.string(forKey: saveCountKey)
        if savedDate != currentDate {
            dailyCount = 0
        } else {
            dailyCount = UserDefaults.standard.integer(forKey: dailyCountKey)
        }
        print("[热播大剧] 今日观看次数：\(dailyCount)")
        return dailyCount
    }
    
    func shouldDowngrade() -> Bool {
        return YKDowngradeManager.canDowngradeFunction("44", withDefaultLevel: .LOW_END_DEVICE)
    }
    
    // MARK: - 生命周期override
    
    override func willActivate() {
        
    }
    
    override func didActivate() {
        super.didActivate()
        self.newPreviewHandler?.didActivate()
    }

    override func didDeactivate() {
        super.didDeactivate()
        self.newPreviewHandler?.didDeactivate()
    }
    
    override func appWillResignActive() {
        super.appWillResignActive()
        self.newPreviewHandler?.appWillResignActive()
    }
    
    // MARK: - ItemAddPageScrollEventHandlerDelegate
    
    /// 容器滚动
    func containerDidScroll(_ scrollView: UIScrollView) {
        self.newPreviewHandler?.handleScrolling(scrollView)
    }
    
    /// 拖拽容器已结束
    func containerDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if !decelerate {
            handleScrollEnded(scrollView)
        }
    }
    
    /// 容器滚动减速结束
    func containerDidEndDecelerating(_ scrollView: UIScrollView) {
        handleScrollEnded(scrollView)
    }
    
    func handleScrollEnded(_ scrollView: UIScrollView) {
        self.newPreviewHandler?.handleScrollEnded(scrollView)
    }
}

class ItemJsonExtractor14001: DefaultItemJsonExtracter {
    // MARK: - ItemJsonExtracter
    weak var component: IComponent? = nil
    
    lazy var dailyLimitService: BizDailyLimitService = {
        return BizDailyLimitService(dailyCountKey: "kItem13017BigCard_dailyCount", saveDateKey: "kItem13017BigCard_savedDate")
    } ()
    
    override func getItemsJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error> {
        guard let itemsJson = componentJson?["nodes"] as? [[String: Any]], itemsJson.count > 0 else {
            return .success([[String : Any]]()) //允许没有坑位列表
        }
        
        var newJson = self.hanleResponseJson(itemsJson: itemsJson)
        if let dataInfo = componentJson?["data"] as? [String: Any],
           let ykAdvertConfig = dataInfo["ykAdvertConfig"] as? [String:Any], ykAdvertConfig.count > 0,
            self.component?.getPage()?.dataState == .network {
            if let index = YKCCUtil.getIntValue(ykAdvertConfig["index"]), index > 0 && index <= newJson.count {
                var itemJson = newJson[index-1]
                itemJson["type"] = 14338 //映射成新类型, 14001 -> 14338
                newJson[index-1] = itemJson
            }
        }
        return .success(newJson)
    }
    
    // MARK: - 热播大剧数据处理
    
    func hanleResponseJson(itemsJson: [[String : Any]]) -> [[String : Any]] {
        // 网络数据
        guard !self.shouldDowngrade() && !ykrl_isResponsiveLayout() &&
                ((self.component?.getComponentDelegate() as? Component14001)?.newLayoutTypeIsClosed == false) && //新布局类型关闭
                self.component?.getPage()?.dataState == .network else {
            print("[热播大卡] json解析 直接返回原数据")
            return itemsJson
        }
        
        print("[热播大卡] json解析 处理大卡数据")
        var result = [[String : Any]]()
        var hasBigCardData = false
        for (index, itemJson) in itemsJson.enumerated() {
            if bigCardIndexValid(index: index),  // index正确
                let bigCardData = itemBigCardData(itemJson: itemJson), // 有数据
               let limit = getTypeIntValue(bigCardData["limit"]) {
                // 频控处理
                self.dailyLimitService.limit = limit
                (self.component?.compModel as? Component14001Model)?.item13017DLService = self.dailyLimitService //暂存service
                if self.dailyLimitService.canShowOnce("热播大卡") { // 满足频控
                    hasBigCardData = true
                    // 构建新json数据
                    let newJson = self.build13017ItemJson(itemJson: itemJson, bigCard: bigCardData)
                    result.append(newJson)
                } else {
                    result.append(itemJson)
                }
                
            } else {
                result.append(itemJson)
            }
        }
        
        // 移除最后一个
        if hasBigCardData {
            if result.count % 2 == 0 { //偶数个数据，需删除一条
                result.removeLast()
                YKSCScreenLogUtil.printLog("[热播大卡] 删除最后一条 总:\(result.count)", color: .green)
            }
        }
        return result
    }
    
    func build13017ItemJson(itemJson: [String: Any], bigCard: [String: Any]) -> [String: Any] {
        var newJson = itemJson
        newJson["type"] = 13017
        
        let data = itemJson["data"] as? [String: Any]
        var newData = [String: Any]()
        newData["action"] = data?["action"]
        newData["feedback"] = data?["feedback"]
        newData["feedbackV2"] = data?["feedbackV2"]
        for (k,v) in bigCard {
            newData[k] = v
        }
        
        let extend = ["scrollAutoPlay": "1"]
        newData["extend"] = extend
        
        newJson["data"] = newData
        return newJson
    }
    
    // MARK: - 数据校验
    
    func bigCardIndexValid(index: Int) -> Bool {
        let valid = (index % 2) == 0
//        print("[热播大卡] index:\(index) 合法:\(valid)")
        return valid
    }
    
    func itemBigCardData(itemJson: [String: Any]) -> [String: Any]? {
        if let data = itemJson["data"] as? [String: Any], data.count > 0 {
            if let bigCard = data["bigCard"] as? [String: Any], bigCard.count > 0,
               let preview = bigCard["preview"] as? [String: Any], let vid = preview["vid"] as? String, vid.count > 0,
                let img = bigCard["img"] as? String, img.count > 0 { //有vid、有封面图
                print("[热播大卡] bigCardData:\(bigCard)")
                return bigCard
            }
        }
        
        return nil
    }
    
    func shouldDowngrade() -> Bool {
        return YKDowngradeManager.canDowngradeFunction("44", withDefaultLevel: .LOW_END_DEVICE)
    }
}
