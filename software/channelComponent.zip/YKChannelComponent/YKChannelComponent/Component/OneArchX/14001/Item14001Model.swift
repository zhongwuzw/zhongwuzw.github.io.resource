//
//  Item14001Model.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/12/8.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku

class Item14001Model: BaseItemModel {
    var superPreviewModel: Item14001SuperPreviewModel?
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        if let cmsInfo = cmsInfo, let data = cmsInfo["data"] as? [String : Any] {
            if let superPreview = data["superPreview"] as? [String: Any] {
                self.superPreviewModel = Item14001SuperPreviewModel.init(superPreview)
                
                let actionModel = self.action?.copy() as? ActionModel
                let previewId = self.superPreviewModel?.videoId
                let newReport = actionModel?.report?.replaceSpmD(spmd: "superpreview")
                if let scm = newReport?.scm, scm.isEmpty == false, let index = scm.lastIndex(of: "."), let previewId = previewId {
                    let scm1 = scm.prefix(upTo: index)
                    let newScm = scm1 + ".\(previewId)"
                    newReport?.args?["scm"] = newScm
                }
                actionModel?.report = newReport
                self.superPreviewModel?.actionModel = actionModel
    
                self.superPreviewModel?.playerModel = createPlayerModel()
            }
        }
    }
    
    func createPlayerModel() -> PlayerModel? {
        let playerModel = PlayerModel(nil, itemModel: self)
        playerModel.item = self.domainObject as? IItem
        playerModel.itemModel = self
        playerModel.playerId = self.superPreviewModel?.videoId
        return playerModel
    }
}


class Item14001SuperPreviewModel {
    var ratio: CGFloat = 0
    var videoId: String?
    
    var imgUrl: String?
    var endImgUrl: String?
    var limit: Int = 0
    var title: String?
    var subtitle: String?
    var logoUrl: String?
    var crossImgUrl: String? //十字架图片
    
    var isTwoItems: Bool = false
    var animationStartFrame: CGRect = .zero
    var animationStartVideoFrame: CGRect = .zero
    var animationEndFrame: CGRect = .zero
    var animationEndBgViewFrame: CGRect = .zero //如果self不动，bgView动，结束时frame
    var animationEndVideoFrame: CGRect = .zero
    var logoOriginSize: CGSize = .zero
    var animationEndLogoSize: CGSize = .zero
    
    var itemIndex: Int = -1
    var hasValidFrame: Bool = false
    
    var actionModel: ActionModel?
    var playerModel: PlayerModel?
    
    public init(_ json: [String:Any]) {
        ratio = json["ratio"] as? CGFloat ?? 0
        imgUrl = json["imgUrl"] as? String
        endImgUrl = json["endImgUrl"] as? String
        limit = json["limit"] as? Int ?? 0
        title = json["title"] as? String
        subtitle = json["subtitle"] as? String
        logoUrl = json["logoUrl"] as? String
        crossImgUrl = json["crossImgUrl"] as? String
        
        if let vid = json["videoId"] as? NSNumber {
            self.videoId = vid.stringValue
        } else if let vid = json["videoId"] as? String {
            self.videoId = vid
        }
        
        if (ratio - 133) < (360 - ratio) {
            isTwoItems = false
        } else {
            isTwoItems = true
        }
    }
}

/*
 {
   "superPreview": {
     "ratio": 177 ,  //如16:9，计算规则16 * 100 / 9； //4坑的1200*876，2坑的1200*330
     "videoId": "XM===", //视频vid
     "imgUrl": "http://sfjlajfwjejlwfl;wfljwljflaw", //首帧图
     "endImgUrl": "http://lfajlijwlejflif", //尾帧图
     "limit": 3, //每日曝光次数
     "title": "标题",
     "subtitle": "副标题",
     "logoUrl": "节目logo",
     "crossImgUrl" : "" //十字架封面图
   }
 }
 */
