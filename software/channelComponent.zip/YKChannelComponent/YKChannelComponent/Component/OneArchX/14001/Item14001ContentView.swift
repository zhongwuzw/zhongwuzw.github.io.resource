//
//  Item14001ContentView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/3/25.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKChannelPage

class Item14001ContentView: BaseItemContentView {
    override func fillData(item: IItem?, ratio: CGFloat) {
        super.fillData(item: item, ratio: ratio)
        
        guard item?.getPage()?.dataState == .network  else { //只上报网络数据
            return
        }
        
        let exposeType = homeReboManualExpose()
        if exposeType == 2 { //关闭自动埋点
            if !(item?.itemModel?.isJarisReplaceItem ?? false) {
                Service.action.bind(nil, self.videoImageView)
                Service.action.bind(item?.itemModel?.action, self, .OnlyClick)
            }
        }
        
        if exposeType != 0 { //支持手动埋点
            var dict = [String: Any]()
            dict["itemView"] = self
            dict["actionModel"] = item?.itemModel?.action
            self.item?.getPage()?.sendEventMessage("home.event.page.manualExpose", params: dict)
        }
    }
}
