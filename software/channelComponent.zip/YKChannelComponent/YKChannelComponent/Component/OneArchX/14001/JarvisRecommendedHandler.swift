//
//  JarvisRecommendedHandler.swift
//  YKChannelComponent
//
//  Created by better on 2023/3/30.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKEdgeAI
import YKSCService
import YKChannelPage
import orange
import YoukuAnalytics

/**
 >算法回传：
 https://aliyuque.antfin.com/aone638902/fbwlh5/ukgwkic542b1st72#aFVPy
 端智能最新返回结果接口

 >cms调用:
 "bizContext" : {
 "replaceContext" : {
 "lastClickItem": "SHOW:123456", //端智能提供，客户端透传
 "lastSearchQuery": "搜索词", //端智能提供，客户端透传
 "visiblePositions": "1,2,3,4", //客户端提供
 "currentItems": "SHOW:123456,SHOW:234567" //客户端提供
 }
 }
 "session": {}
 注：
 1. 端上透传算法下的 ex_data->data 属性到 replaceContext
 2. 端上拼接字段->replaceContext：
 "visiblePositions": "1,2,3,4",
 "currentItems": "SHOW:123456,SHOW:234567"
 3. 端上透传抽屉session，与bizContext同级
 
 */

class JarvisRecommendedHandler {
    
    weak var delegate: ComponentDelegate?
    
    var component: IComponent? {
        get {
            return self.delegate?.component
        }
    }
    
    var disableFixedCrashCode: Bool = false
    
    var comp_itemsStr: String?
    var card_noDuplicateItemsStr: String?
    var usedDomainDataSaved: Bool = false
    
    public required init(_ delegate: ComponentDelegate?) {
        self.delegate = delegate
        NotificationCenter.default.addObserver(self, selector: #selector(homeControllerDidActive), name: Notification.Name(rawValue:"homeVCDidAppearNotify"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(homeAutoRefreshTriggered), name: Notification.Name(rawValue:"home.autorefresh.triggered"), object: nil)
        
        let orangeInfo = Orange.getGroupConfig(byGroupName: "yksc_config")
        self.disableFixedCrashCode = YKCCUtil.getBoolValue(orangeInfo?["comp14001_disableJavisFixCrashCode"]) ?? false
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    var triggerAutoRefreshWhenActive = false
    @objc func homeAutoRefreshTriggered() {
        triggerAutoRefreshWhenActive = true
    }
    
    @objc func homeControllerDidActive() {
        if disableByOrange() {
            return
        }
        if triggerAutoRefreshWhenActive {
            YKSCScreenLogUtil.printLog("[端智能] trigger failed when 15min autorefresh triggered", color: .green)
            triggerAutoRefreshWhenActive = false
            return
        }
        let isPageActive = self.component?.pageContext?.isPageActive() ?? false
        let type = self.component?.model?.type ?? ""
        let bizKkey = self.component?.getPage()?.pageModel?.requestModel?.nodeKey ?? ""
        YKSCScreenLogUtil.printLog("[端智能] home vc active (\(isPageActive)-\(bizKkey)-\(type))", color: .green)
        if isPageActive {
            triggerGavisAIEvent()
        }
    }
    
    func disableByOrange() -> Bool {
        //默认关闭
        let orangeInfo = Orange.getGroupConfig(byGroupName: "YKHome_Selection_Common")
        let disableJarvisAi = orangeInfo?["disableJarvisAi"] as? String
        if (disableJarvisAi != nil), disableJarvisAi == "disable" {
            return true
        }
        return false
    }
    
    func saveUsedDomainDataIfNeeded() {
        guard !disableFixedCrashCode && !usedDomainDataSaved else {
            return
        }
        
        self.usedDomainDataSaved = true
        
        self.comp_itemsStr = self.getComponentItems(component: self.component)
        self.card_noDuplicateItemsStr = self.noDuplicateItems()
        
        print("[端智能] new 暂存 c:\(comp_itemsStr) cc:\(self.card_noDuplicateItemsStr)")
    }
    
    func triggerGavisAIEvent() {
        let cardIndex = self.component?.getCard()?.index ?? 0
        guard let replaceItem = self.component?.compModel?.config.getBoolValue("replaceItem"), replaceItem == true else {
            YKSCScreenLogUtil.printLog("[端智能] trigger failed replaceItem:\(0), card:\(cardIndex)", color: .green)
            return
        }
        
        guard let visiblePositions = visiblePositions(), visiblePositions.count > 0 else {
            YKSCScreenLogUtil.printLog("[端智能] trigger failed visible == 0, card:\(cardIndex)", color: .green)
            return
        }
        
        YKSCScreenLogUtil.printLog("[端智能] trigger success, card:\(cardIndex) visible:\(visiblePositions)", color: .green)
        
        /* test code
        //{"component_instance_id":"90883","drawerid":"24856","lastClickItem":"SHOW:622480","lastSearchQuery":""}
        self.requestRecommendContents([
            "component_instance_id": "90883",
            "drawerid":"24856",
            "lastClickItem":"SHOW:622480",
            "lastSearchQuery":""
        ])
        return;
         */
        
        /**javis 参数*
        submodule：homepage_behavior_dai_rec
        algtype：AlgoType.PUSH
        algsubtype：AlgoSubType.RE_RANK_LONG_VIDEO
         */
        //print("[jarvis] visible items \(visiblePositions()) \(currentItems())")
        YKSCScreenLogUtil.printLog("[端智能]: Jarvis发起请求 card:\(self.component?.getCard()?.index ?? 0)", color: .green)
        var jarvisTrigger:YKEdgeJarvisTrigger?
        jarvisTrigger = YKEDefaultEdger.shared().jarvisTrigger
        jarvisTrigger?.addBehaviourAction(withPageName: "page_homeselect",
                                              utEventId: "66200",
                                              actionType: "call_algo_model",
                                              actionName: "push",
                                              subActionType: "long_video",
                                              query: ["ext_params":["subModel":"homepage_behavior_dai_rec"]],
                                              extParams:[String:Any](), callback: {[weak self] resultCode, resultDict in
            guard let self = self else {
                return
            }
            YKSCScreenLogUtil.printLog("[端智能]: Jarvis请求完成 code:\(resultCode) result:\(resultDict)", color: .green)
            let result = resultDict["result"] as? [String:Any]
            if let status = result?["status"] as? Int, status == -1 {
                YKSCScreenLogUtil.printLog("[端智能]: Jarvis发起请求 拦截 status:\(status)", color: .green)
                return
            }
            let ext_data = result?["ext_data"] as? [String:Any]
            if let data = ext_data?["data"] as? [String:Any] {
                DispatchQueue.main.async {
                    self.requestRecommendContents(data)
                }
            }
        })
    }
    
    func requestRecommendContents(_ jarvisParams:[String:Any]?) {
        let api = buildReqAPI()
        let params = buildRequestParams(jarvisParams)
        let requestString = "[端智能] cms 发起请求, api:\(api), params: \(params)"
        print(requestString)
        YKSCScreenLogUtil.printLog(requestString, color: .green)
        self.component?.pageContext?.request(api: api, method: "POST", paramaters: params, headers: nil, timeout: 3.0, success: {[weak self] result in
            guard let self = self else {
                return
            }
            print("[端智能] cms request success \(result)")
            self.processReplaceItems(result)
        }, failure: { error in
            print("[端智能] cms request error \(error)")
        })
    }
    
    func processReplaceItems(_ result: [String:Any]?) {
        guard let compJson = parseComponnetJson(result) else {
            print("[replace] no compjson")
            return
        }
        guard let newNodes = compJson["nodes"] as? [[String:Any]] else {
            print("[replace] no nodes")
            return
        }
        guard let itemManager = self.component?.getItemManager() else {
            return
        }
        
        guard let newItems = itemManager.createItems(newNodes) else {
            print("[replace] create items failed")
            return
        }
        
        guard var oldItems = self.component?.getItems() else {
            return
        }
        guard oldItems.count == newItems.count else {
            print("[replace] not equals")
            return
        }
        var replacePosition = [Int]()
        var newReplaceItems = [IItem]()
        for index in 0..<oldItems.count {
            let newItem = newItems[index]
            if canReplace(newItem) {
                oldItems[index] = newItem
                newReplaceItems.append(newItem)
                newItem.itemModel?.isJarisReplaceItem = true
                newItem.itemModel?.animateWhenReuse = true
                replacePosition.append(index + 1)
            }
        }

        YKSCScreenLogUtil.printLog("[端智能] replacePosition \(replacePosition)", color: .green)

        if replacePosition.count == 0 {
            return
        }
        
        let resultItems = oldItems
        
        if JarvisRecommendedHandler.enableSendJarvisStatictis {
            let nodeKey = self.component?.getPage()?.pageModel?.nodeKey ?? "NULL"
            let bizKey = self.component?.getPage()?.pageModel?.requestModel?.bizKey ?? "NULL"
            let replaceItem = replacePosition.map { (ele) -> String in
                String(ele)
            }.joined(separator: ",")
            YoukuAnalytics.sharedInstance().collectALiCustomEvent(withEventID: "19999", pageName: "ReboAiRecommend", arg1: "ai_recommed_replaced", arg2: nil, args: ["nodeKey" : nodeKey, "bizKey": bizKey, "replaceItem":replaceItem])
        }
        /* 批量刷新*/
        self.component?.getItemManager()?.batchUpdateItems(batchUpdateBlock: { items in
            return (resultItems, newReplaceItems)
        }, animated: false, completion: { error in
            print("[replace] replace finish")
        })
    }
    
    func canReplace(_ item:IItem?) -> Bool {
        guard let data = item?.model?.data else {
            return false
        }
        let replace = data["replace"] as? Int ?? 0
        return replace == 1
    }
    
    func parseComponnetJson(_ result: [String:Any]?) -> [String:Any]? {
        //->data -> mscode -> data
        guard let data = result?["data"] as? [String:Any] else {
            return nil
        }
        let mscode = requestModel?.mscode ?? "2019061000"
        guard let mscodeJson = data[mscode] as? [String:Any] else {
            return nil
        }
        guard let compJson = mscodeJson["data"] as? [String:Any] else {
            return nil
        }
        return compJson
    }
    
    var requestModel: RequestModel? {
        get {
            return component?.compModel?.requestModel
        }
    }
    
    func buildRequestParams(_ jarvisParams:[String:Any]?) -> [String: Any] {
        
        var requestParams = [String: Any]()

        //接口版本
        requestParams["api_version"] = "1.0"
        
        //业务参数
        requestParams["ms_codes"] = requestModel?.mscode ?? "2019061000"
        
        requestParams["debug"] = 0
        requestParams["device"] = "IPHONE"
        
        let params = NSMutableDictionary.init()
        
        params["bizKey"] = requestModel?.bizKey ?? requestParamsDefaultBizKey()
        params["nodeKey"] = requestModel?.nodeKey ?? "SELECTION"
        params["pageSize"] = 10
        params["pageNo"] = 1
        params["session"] = buildSession()
        params["bizContext"] = buildBizContext(jarvisParams)
        
        params["debug"] = "0"
        params["gray"] = "0"
        params["device"] = "IPHONE"

        requestParams["params"] =  getJSONStringFromDictionary(dictionary: params)

        return requestParams
    }
    
    //MARK: - private
    func buildReqAPI() -> String {
        if let apiName = requestModel?.apiName , apiName.isEmpty == false {
            return apiName
        }
        return "mtop.youku.columbus.home.query"
    }
    
    func buildSession() -> String? {
        if let session = requestModel?.session as? NSDictionary , session.allKeys.count > 0 {
            return getJSONStringFromDictionary(dictionary: session)
        }
        return nil
    }
    
    func buildBizContext(_ jarvisParams:[String:Any]?) -> String? {

        let tempDict = NSMutableDictionary.init()
        if let originContext = requestModel?.bizContext as? [String : Any], originContext.keys.count > 0 {
            for (k, v) in originContext {
                tempDict[k] = v
            }
        }
        
        // extra extend
        if let requestModel = component?.compModel?.requestModel {
            tempDict.addEntries(from: requestModel.extraExtend)
        }
        
        // replaceContext
        let replaceContext = NSMutableDictionary.init()
        if let jarvisParams = jarvisParams {
            replaceContext.addEntries(from: jarvisParams)
        }
        if let visiblePositions = visiblePositions() {
            replaceContext["visiblePositions"] = visiblePositions
        }
        if let currentItems = (disableFixedCrashCode ? currentItems() : self.comp_itemsStr) {
            replaceContext["currentItems"] = currentItems
        }
        if let noDuplicateItems = (disableFixedCrashCode ? noDuplicateItems() : self.card_noDuplicateItemsStr) {
            replaceContext["noDuplicateItems"] = noDuplicateItems
        }

        tempDict["replaceContext"] = replaceContext

        print("[jarvis] replaceContext \(replaceContext)")

        // 优酷广告参数
        //tempDict["ykAdParams"] = buildBizContextParams_ykAdParam()
        
        if tempDict.allKeys.count > 0 {
            return getJSONStringFromDictionary(dictionary: tempDict)
        }
        
        return nil
    }
    
    //"visiblePositions": "1,2,3,4",
    func visiblePositions() -> String? {
        guard let items = self.component?.getItems() else {
            return nil
        }
        var numbers = [String]()
        for item in items {
            if isItemVisible(item) {
                numbers.append("\(item.index + 1)")
            }
        }
        let result = numbers.joined(separator:",")
        return result
    }

    //"currentItems": "SHOW:123456,SHOW:234567"
    func currentItems() -> String? {
        return getComponentItems(component: self.component)
    }
    
    func getComponentItems(component: IComponent?) -> String? {
        guard let items = component?.getItems() else {
            return nil
        }
        var itemsInfo = [String]()
        for item in items {
            if let itemInfo = item.itemModel?.data?["itemInfo"] as? String, itemInfo.count > 0 {
                itemsInfo.append(itemInfo)
            }
        }
        let currentItems = itemsInfo.joined(separator: ",")
        return currentItems
    }
    
    func noDuplicateItems() -> String? {
        guard let card = self.component?.getCard() else {
            return nil
        }
        guard let cards = self.component?.getPage()?.getCards(), cards.count > 0 else {
            return nil
        }
        var cardItems = [String]()
        let curCardIndex = card.index
        for index in 0..<curCardIndex {
            let tmpCard = cards[index]
            if let tmpComponens = tmpCard.getComponents(), tmpComponens.count > 0 {
                var componentItems = [String]()
                for tmpComp in tmpComponens {
                    if let items = getComponentItems(component: tmpComp), items.count > 0 {
                        componentItems.append(items)
                    }
                }
                if componentItems.count > 0 {
                    cardItems.append(componentItems.joined(separator: ","))
                }
            }
        }
        
        return cardItems.joined(separator: ";")
    }
    
    func isItemVisible(_ item:IItem?) -> Bool {
        guard let container = item?.pageContext?.getContainerView() as? UICollectionView else {
            return false
        }
        guard let layoutInfo = item?.getLayoutInfo() else {
            return false
        }
        guard let pageConfig = item?.getPage()?.getPageDelegate()?.layoutConfig() else {
            return false
        }
        let offsetY = container.contentOffset.y
        
        let y1 = layoutInfo.y
        let y2 = layoutInfo.y + (layoutInfo.width * 0.5625)
        
        let screenY1 = y1 - offsetY
        let screenY2 = y2 - offsetY
        
        let minY = pageConfig.containerPadding.top
        let maxY = container.height - pageConfig.containerPadding.bottom

        print("[jarvis] visible index:\(item?.index) [\(screenY1)-\(screenY2)]  [\(minY) - \(maxY)]")

        if screenY1 > minY, screenY2 < maxY {
            return true
        } else {
            return false
        }
    }
}

extension JarvisRecommendedHandler {
    static let enableSendJarvisStatictis:Bool = {
        return enableSendJarvisStatictisOrange()
    }()
    static func enableSendJarvisStatictisOrange() -> Bool {
        //orange
        if let orangeDict = Orange.getGroupConfig(byGroupName: "YKChannelSTFeed") {
            if let openValue = orangeDict["enableSendReboJarvisStatictis"] as? String {
                if openValue == "0" {
                    return false
                } else if openValue == "1" {
                    return true
                }
            }
        }
        return true
    }
}
