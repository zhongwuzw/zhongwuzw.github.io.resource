//
//  ReverseRoundedLineView.swift
//  DemoApp
//
//  Created by chao chen on 2023/11/28.
//

import UIKit
import YoukuResource
import OneArchSupport4Youku

class ReverseRoundedLineView: UIView {
    var currentIsDark: Bool = false
    var sceneBgColor: UIColor? = nil
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .clear
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override var frame: CGRect {
        didSet {
            if !CGRectEqualToRect(frame, .zero) {
                self.setupLayers()
            }
        }
    }
    var layerAdded: Bool = false
    
    func setupLayers(force: Bool = false) {
        guard (!layerAdded || force) else {
            return
        }
        
        print("[热播大剧] setupLayers ")
        layerAdded = true
        
        let cornerRadius: CGFloat = YKNCorner.radius_secondary_medium()
        let whiteLineSpace: CGFloat = 6
        let lineSpace = whiteLineSpace / 2.0
        
        let width = self.width
        let height = self.height

        //左上
        let pathLeftTop = UIBezierPath.init(roundedRect: CGRect.init(x: 0, y: 0, width: width / 2.0 - lineSpace, height: height / 2.0 - lineSpace), byRoundingCorners: .allCorners, cornerRadii: CGSize.init(width: cornerRadius, height: cornerRadius))
        var p1 = CGPoint.init(x: 0, y: 0)
        var p2 = CGPoint.init(x: 0, y: height / 2.0 - lineSpace)
        var p3 = CGPoint.init(x: width / 2.0 - lineSpace, y: height / 2.0 - lineSpace)
        var p4 = CGPoint.init(x: width / 2.0 - lineSpace, y: 0)
        drawRoundRectBorder(pathLeftTop, cornerRadius: cornerRadius, p1: p1, p2: p2, p3: p3, p4: p4)
        self.layer.addSublayer(createLayerWith(pathLeftTop))

        //右上
        let pathRightTop = UIBezierPath.init(roundedRect: CGRect.init(x: width / 2.0 + lineSpace, y: 0, width: width / 2.0 - lineSpace, height: height / 2.0 - lineSpace), byRoundingCorners: .allCorners, cornerRadii: CGSize.init(width: cornerRadius, height: cornerRadius))
        
        p1 = CGPoint.init(x: width / 2.0 + lineSpace , y: 0)
        p2 = CGPoint.init(x: width / 2.0 + lineSpace, y: height / 2.0 - lineSpace)
        p3 = CGPoint.init(x: width, y: height / 2.0 - lineSpace)
        p4 = CGPoint.init(x: width, y: 0)
        drawRoundRectBorder(pathRightTop ,cornerRadius:cornerRadius, p1: p1, p2: p2, p3: p3, p4: p4)
        self.layer.addSublayer(createLayerWith(pathRightTop))

        //左下
        let pathLeftBottom = UIBezierPath.init(roundedRect: CGRect.init(x: 0, y: height / 2.0 + lineSpace, width: width / 2.0 - lineSpace, height: height / 2.0 - lineSpace), byRoundingCorners: .allCorners, cornerRadii: CGSize.init(width: cornerRadius, height: cornerRadius))
        p1 = CGPoint.init(x: 0, y: height / 2.0 + lineSpace)
        p2 = CGPoint.init(x: 0, y: height)
        p3 = CGPoint.init(x: width / 2.0 - lineSpace, y: height)
        p4 = CGPoint.init(x: width / 2.0 - lineSpace, y: height / 2.0 + lineSpace)
        drawRoundRectBorder(pathLeftBottom ,cornerRadius:cornerRadius, p1: p1, p2: p2, p3: p3, p4: p4)
        self.layer.addSublayer(createLayerWith(pathLeftBottom))
        
        //右下
        let pathRightBottom = UIBezierPath.init(roundedRect: CGRect.init(x: width / 2.0 + lineSpace, y: height / 2.0 + lineSpace, width: width / 2.0 - lineSpace, height: height / 2.0 - lineSpace), byRoundingCorners: .allCorners, cornerRadii: CGSize.init(width: cornerRadius, height: cornerRadius))
        p1 = CGPoint.init(x: width / 2.0 + lineSpace, y: height / 2.0 + lineSpace)
        p2 = CGPoint.init(x: width / 2.0 + lineSpace, y: height)
        p3 = CGPoint.init(x: width, y: height)
        p4 = CGPoint.init(x: width, y: height / 2.0 + lineSpace)
        drawRoundRectBorder(pathRightBottom ,cornerRadius:cornerRadius, p1: p1, p2: p2, p3: p3, p4: p4)
        self.layer.addSublayer(createLayerWith(pathRightBottom))

        let path = UIBezierPath()
        //中间横线
        path.move(to: CGPoint.init(x: 0, y: height/2.0 - lineSpace))
        path.addLine(to: CGPoint.init(x: width, y: height/2.0 - lineSpace))
        path.addLine(to: CGPoint.init(x: width, y: height/2.0 + lineSpace))
        path.addLine(to: CGPoint.init(x: 0, y: height/2.0 + lineSpace))
        path.addLine(to: CGPoint.init(x: 0, y: height/2.0 - lineSpace))
        
        //中间竖线 上下
        path.move(to: CGPoint.init(x: width / 2.0 - lineSpace, y: 0))
        path.addLine(to: CGPoint.init(x: width / 2.0 - lineSpace, y: height / 2.0 - lineSpace))
        path.addLine(to: CGPoint.init(x: width / 2.0 + lineSpace, y: height / 2.0 - lineSpace))
        path.addLine(to: CGPoint.init(x: width / 2.0 + lineSpace, y: 0))
        path.addLine(to: CGPoint.init(x: width / 2.0 - lineSpace, y: 0))
        
        path.move(to: CGPoint.init(x: width / 2.0 - lineSpace, y: height / 2.0 + lineSpace))
        path.addLine(to: CGPoint.init(x: width / 2.0 - lineSpace, y: height))
        path.addLine(to: CGPoint.init(x: width / 2.0 + lineSpace, y: height))
        path.addLine(to: CGPoint.init(x: width / 2.0 + lineSpace, y: height / 2.0 + lineSpace))
        path.addLine(to: CGPoint.init(x: width / 2.0 - lineSpace, y: height / 2.0 + lineSpace))
        
        path.fill()
        // 绘制路径
        self.layer.addSublayer(createLayerWith(path))
        self.currentIsDark = self.isDark()
        print("[热播大剧] setupLayers finished")
    }
    
    func drawRoundRectBorder(_ path:UIBezierPath, cornerRadius:CGFloat, p1:CGPoint, p2:CGPoint, p3:CGPoint, p4:CGPoint ) {
        path.addLine(to: p1)
        path.addLine(to: p2)
        path.addLine(to: p3)
        path.addLine(to: p4)
        path.addLine(to: p1)
        path.fill()
    }
    
    func createLayerWith(_ path: UIBezierPath) -> CAShapeLayer {
        let layer = CAShapeLayer.init()
        layer.fillColor = self.useColor().cgColor
        layer.strokeColor = self.useColor().cgColor
        layer.lineWidth = 0.5
        layer.path = path.cgPath
        layer.frame = self.bounds
        return layer
    }
    
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        guard self.currentIsDark != self.isDark(), let layers = self.layer.sublayers, layers.count > 0 else {
            return
        }
        
        weak var weakSelf = self
        DispatchQueue.main.async {
            guard let self = weakSelf else {
                return
            }
            
            print("[热播大剧] 暗黑变化 改颜色 isDark:\(self.isDark()) color:\(self.useColor().cgColor)")
            
            for layer in layers {
                layer.removeFromSuperlayer()
                print("[热播大剧] 暗黑变化 layer:\(layer)移除")
            }
            
            self.setupLayers(force: true)
        }
    }
    
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
    
    func useColor() -> UIColor {
        return sceneUtil(.ykn_primaryBackground, sceneColor: self.sceneBgColor) ?? .ykn_primaryBackground
    }
}
