//
//  Item14001PreviewView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/12/8.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent
import YKCMSComponent
import YKDowngradeSDK
import PromptControl
import YoukuAnalytics
import YKSCService
import GodViewTracker
import YKChannelPage
import orange
import YKChannel
import YKHome

class Item14001PreviewView: UIView, PlayerStatusCallback, ChannelCompDelayDoWrapperDelegate {
    weak var item: IItem?
    
    weak var popReuest: PCLayerRequest?
    weak var handler: Item14001SuperPreviewHandler?
    
    var hasReleased: Bool = false //标记移除
    var hasFilledData: Bool = false
    
    lazy var bgView: UIView = {
        let view = UIView.init(frame: .zero)
        return view
    } ()
    
    lazy var logoImageView: UIImageGIFView = { //名称logo
        let view = UIImageGIFView.init(frame: CGRect.init(x: 0, y: 0, width: 205, height: 80))
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        return view
    }()
    
    lazy var titleLabel: MarginLabel = {
        let view = MarginLabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.verticalAlignment = .top
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    lazy var coverImageView: UIImageGIFView = { //封面图
        let view = UIImageGIFView.init(frame:CGRect.zero)
        view.isUserInteractionEnabled = true
        view.clipsToBounds = true
        view.contentMode = .scaleAspectFill
        view.backgroundColor = .clear
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var endCoverImageView: UIImageGIFView = { //封面图
        let view = UIImageGIFView.init(frame:CGRect.zero)
        view.isUserInteractionEnabled = true
        view.clipsToBounds = true
        view.contentMode = .scaleAspectFill
        view.backgroundColor = .clear
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.isHidden = true
        return view
    }()
    
    lazy var crossView: ReverseRoundedLineView = {
        let view = ReverseRoundedLineView.init(frame: CGRect.zero)
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var playFinishedWrapper: ChannelCompDelayDoWrapper = {
        let wr = ChannelCompDelayDoWrapper.init()
        wr.delegate = self
        return wr
    }()
    
    lazy var startToPlayDelayWrapper: ChannelCompDelayDoWrapper = {
        let wr = ChannelCompDelayDoWrapper.init()
        wr.delegate = self
        return wr
    } ()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        YKSCScreenLogUtil.printLog("[热播大剧] view:\(YKCCUtil.objAddress(self)) init", color: .green)
        
        addSubview(self.bgView)
        bgView.addSubview(self.coverImageView)
        bgView.addSubview(self.endCoverImageView)
        bgView.addSubview(self.titleLabel)
        bgView.addSubview(self.subtitleLabel)
        addSubview(self.crossView)
        addSubview(self.logoImageView)
        
        NotificationCenter.default.addObserver(self, selector: #selector(receiveAppleAdClosed), name: NSNotification.Name.init(rawValue: "home.sliderNewComponentAppleAd.closed"), object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        YKSCScreenLogUtil.printLog("[热播大剧] view:\(YKCCUtil.objAddress(self)) deinit", color: .green)
        stopPlayer()
    }
    
    var hasShow: Bool = false
    
    var hasFillData: Bool = false
    var coverImgLoadFinished: Bool = false
    var endCoverImgLoadFinished: Bool = false
    var pullDrawerHasScrollFinished: Bool {
        return self.handler?.pullDrawerHasScrollFinished ?? false
    }
    var popLayerCanShowPlayer: Bool = false
    var appleAdClosedNotification: Bool = false
    
    var playerStartCallBack: Bool = false //标记起播回调
    var playerFinishedCallback: Bool = false // 标记播放结束或失败回调
    
    func fillData(_ item: IItem?) {
        guard
            let item = self.item,
            let itemModel = item.model as? Item14001Model, let superviewModel = itemModel.superPreviewModel else {
            return
        }
        
        self.item = item
        
        weak var weakSelf = self
        if let imgUrl = superviewModel.imgUrl, imgUrl.isEmpty == false {
            coverImageView.sd_setImage(with: URL.init(string: imgUrl), module: "home", placeholderImage: nil) { image, error, cacheType, imgUrl in
                if let rImage = image , rImage.size.width > 0 && rImage.size.height > 0 {
                    weakSelf?.coverImageView.image = rImage
                    
                    weakSelf?.coverImgLoadFinished = true
                    
                    YKSCScreenLogUtil.printLog("[热播大剧] 首帧图加载成功", color: .green)
                    weakSelf?.readyToShow()
                } else {
                    YKSCScreenLogUtil.printLog("[热播大剧] 首帧图加载失败，无法开始动画，移除view", color: .green)
                    weakSelf?.releaseViews()
                }
            }
        } else {
            coverImageView.image = nil
            YKSCScreenLogUtil.printLog("[热播大剧] 首帧图url为空，无法开始动画，移除view", color: .green)
            weakSelf?.releaseViews()
        }
        
        if let endImgUrl = superviewModel.endImgUrl, endImgUrl.isEmpty == false {
            endCoverImageView.sd_setImage(with: URL.init(string: endImgUrl), module: "home", placeholderImage: nil) { image, error, cacheType, imgUrl in
                if let rImage = image , rImage.size.width > 0 && rImage.size.height > 0 {
                    weakSelf?.endCoverImageView.image = rImage
                    weakSelf?.endCoverImgLoadFinished = true
                    
                    YKSCScreenLogUtil.printLog("[热播大剧] 尾帧图加载成功", color: .green)
                    weakSelf?.readyToShow()
                } else {
                    YKSCScreenLogUtil.printLog("[热播大剧] 尾帧图加载失败，无法开始动画，移除view", color: .green)
                    weakSelf?.releaseViews()
                }
            }
        } else {
            endCoverImageView.image = nil
            YKSCScreenLogUtil.printLog("[热播大剧] 尾帧图url为空，无法开始动画，移除view", color: .green)
            weakSelf?.releaseViews()
        }
        
        if let logoUrl = superviewModel.logoUrl, logoUrl.isEmpty == false {
            logoImageView.sd_setImage(with: URL.init(string: logoUrl), module: "home", placeholderImage: nil) { image, error, cacheType, imgUrl in
                if let rImage = image , rImage.size.width > 0 && rImage.size.height > 0 {
                    weakSelf?.logoImageView.image = rImage
                    weakSelf?.updateLogoFrameWhenloadSuc(rImage.size)
                }
            }
        } else {
            logoImageView.image = nil
        }
        
        // title
        self.titleLabel.numberOfLines =  1
        self.titleLabel.text = superviewModel.title
        
        // subtitle
        self.subtitleLabel.text = superviewModel.subtitle
        
        // 氛围
        let scene = itemModel.scene
        self.bgView.backgroundColor = sceneUtil(.ykn_primaryBackground, sceneColor: item.getPage()?.pageModel?.scene?.sceneBgColor())
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: scene?.sceneTitleColor())
        self.subtitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: scene?.sceneSubTitleColor())
        self.crossView.sceneBgColor = item.getPage()?.pageModel?.scene?.sceneBgColor()
        
        // 跳转
        Service.action.bind(itemModel.superPreviewModel?.actionModel, self, .OnlyClick, willAction: nil) {
            weakSelf?.releaseViews()
        }
        
        // 更新布局
        self.updateSubviewsLayout()
        
        self.playerFinishedCallback = false
        self.playerStartCallBack = false
        
        self.hasFilledData = true
        self.alpha = 0
        
        self.readyToShow()
    }
    
    func updateSubviewsLayout() {
        guard let superPreviewModel = getSuperPreviewModel() else {
            return
        }
        
        self.bgView.frame = self.bounds
        // 图片
        let imageSize = superPreviewModel.animationStartVideoFrame.size
        coverImageView.frame = superPreviewModel.animationStartVideoFrame
        endCoverImageView.frame = coverImageView.frame
        
        self.crossView.frame = coverImageView.frame
        
        // 主标题
        let titleY = imageSize.height + YKNGap.youku_picture_title_spacing()
        titleLabel.frame = CGRect.init(x: 0,
                                       y: titleY,
                                       width: self.width,
                                       height: YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1))
        
        // 副标题
        let subtitleWidth:CGFloat = titleLabel.width
        let subtitleY = titleLabel.bottom
        + YKNGap.youku_maintitle_subtitle_spacing()
        subtitleLabel.frame = CGRect.init(x: 0,
                                          y: subtitleY,
                                          width: subtitleWidth,
                                          height: YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1))
        
        // logo位置
        let isTwoItems = superPreviewModel.isTwoItems
        var shouldSetLogoFrame = true
        if isTwoItems && !CGRectEqualToRect(logoImageView.frame, .zero) { //setImag设置过了，就不再设置
            shouldSetLogoFrame = false
        }
        
        if shouldSetLogoFrame {
            let logoSize = superPreviewModel.logoOriginSize
            var logoFrame = CGRect.zero
            if isTwoItems {
                logoFrame = CGRect.init(x: imageSize.width - logoSize.width - 12, y: 0, width: logoSize.width, height: logoSize.height)
            } else {
                logoFrame = CGRect.init(x: (imageSize.width - logoSize.width) / 2, y: 0, width: logoSize.width, height: logoSize.height)
            }
            logoImageView.frame = logoFrame
            logoImageView.bottom = imageSize.height - 9
        }
        
        // 十字架位置
        self.crossView.isHidden = isTwoItems
        
    }
    
    func updateLogoFrameWhenloadSuc(_ logoSize: CGSize) {
        guard let superPreviewModel = self.getSuperPreviewModel(), superPreviewModel.isTwoItems else { //2坑需要处理
            return
        }
        
        let useSize = YKCCUtil.calImgSize(logoSize, superPreviewModel.logoOriginSize)
        let logoFrame = CGRect.init(x: self.width - useSize.width - 12, y: 0, width: useSize.width, height: useSize.height)
        logoImageView.frame = logoFrame
        logoImageView.bottom = superPreviewModel.animationStartVideoFrame.height - 9
    }
    
    func updateSelfFrameWhenPositionMoved() {
        self.handler?.calPreviewViewLayoutInfo(isUpdate: true)
        
        if let frame = self.getSuperPreviewModel()?.animationStartFrame {
            self.frame = frame //更新frame
        }
    }
    
    @objc func receiveAppleAdClosed(notification: Notification) {
        self.appleAdClosedNotification = true
        YKSCScreenLogUtil.printLog("[热播大剧] 收到vb关闭通知 开始显示动画", color: .green)
//        self.readyToShow()
    }
    
    func readyToShow() {
        guard !self.hasShow && !self.hasReleased && self.hasFilledData &&
                self.popLayerCanShowPlayer && self.pullDrawerHasScrollFinished &&
                self.coverImgLoadFinished && self.endCoverImgLoadFinished && isPageInActive() && viewIsVisible(true) else {
            YKSCScreenLogUtil.printLog("[热播大剧] 动画未开始 h:\(self.hasShow) r:\(self.hasReleased) h:\(self.hasFilledData) p:\(self.popLayerCanShowPlayer) d:\(self.pullDrawerHasScrollFinished) c:\(self.coverImgLoadFinished) e:\(self.endCoverImgLoadFinished) a:\(isPageInActive()) v:\(viewIsVisible(true)) ad:\(!YKAppleADManager.sharedInstance().hasAppleAD || appleAdClosedNotification)", color: .green)
            return
        }
        
        YKSCScreenLogUtil.printLog("[热播大剧] 开始动画", color: .green)
        self.hasShow = true
        self.handler?.hasShow = true
        
        self.beforeStartAnimation()
        
        // player
        self.startPlayer()
        
        // 开始动画
        self.startAnimation()
        
        // 手动曝光
        self.sendExpose()
        
        // 保存播放次数
        (self.item?.getItemDelegate() as? Item14001)?.savePreviewNum()
    }
    
    // MARK：- 状态
    
    func isPageInActive() -> Bool {
        return self.item?.pageContext?.isPageActive() ?? false
    }
    
    func viewIsVisible(_ isStartShow: Bool = false) -> Bool {
        let topHeight: CGFloat = item?.getPage()?.getPageDelegate()?.layoutConfig().containerPadding.top ?? homeContainerPaddingTop()
        let bottomHeight: CGFloat = YKTabbarHeight()
        let containerViewSize = self.item?.getPage()?.pageContext?.getContainerView()?.size ?? CGSize.init(width: SCREEN_WIDTH, height: SCREEN_HEIGHT)
        
        let visibleFrame : CGRect = CGRect.init(x: 0, y: topHeight, width: containerViewSize.width, height: containerViewSize.height - topHeight - bottomHeight)
        var selfAbsoluteFrame = self.convert(self.bounds, to: nil)
        if selfAbsoluteFrame.origin.x < 0 || selfAbsoluteFrame.origin.x > visibleFrame.width { //加水平方向保护
            selfAbsoluteFrame = CGRect(origin: CGPoint(x: 0, y: selfAbsoluteFrame.origin.y), size: selfAbsoluteFrame.size)
        }
        
        var visible = false
        let isTwoItems = self.isTwoItems()
        if isStartShow {
            if isTwoItems { //二坑位还是完全漏出展示
                visible = visibleFrame.contains(selfAbsoluteFrame)
                print("[热播大剧] 校验view位置 v:\(visibleFrame) p:\(selfAbsoluteFrame) is:\(visible)")
            } else {
                let viewVisibleHeight = min(visibleFrame.maxY, selfAbsoluteFrame.maxY) - max(visibleFrame.minY, selfAbsoluteFrame.minY)
                visible = viewVisibleHeight >= (selfAbsoluteFrame.height / 2)
                print("[热播大剧] 校验view位置 v:\(visibleFrame) p:\(selfAbsoluteFrame) vi:\(viewVisibleHeight) is:\(visible)")
            }
        } else {
            visible = visibleFrame.intersects(selfAbsoluteFrame)
            print("[热播大剧] 校验view位置 v:\(visibleFrame) p:\(selfAbsoluteFrame) is:\(visible)")
        }
        return visible
    }
    
    func currentIsShowing() -> Bool {
        return self.hasShow && !self.hasReleased
    }
    
    func isTwoItems() -> Bool {
        return self.getSuperPreviewModel()?.isTwoItems ?? false
    }
    
    // MARK: - 播控
    
    func startPlayer() {
        guard let playerModel = getPlayerModel() else {
            return
        }
        
        YKSCScreenLogUtil.printLog("[热播大剧] \(YKCCUtil.objAddress(self)) startPlayer", color: .green)
        playerModel.playBackFrame = self.coverImageView.frame
        playerModel.itemView = self.coverImageView
        playerModel.playerDelegate = self
        playerModel.controlType = .LunboPlay
        PlayerControlManagerV2.shareInstance().startPlayer(playerModel)
        
        self.startToPlayDelayWrapper.delayTimeDo(5)
    }
    
    func stopPlayer() {
        guard let playerModel = getPlayerModel() else {
            return
        }
        
        if PlayerControlManagerV2.shareInstance().currentPlayerView?.model == playerModel {
            YKSCScreenLogUtil.printLog("[热播大剧] \(YKCCUtil.objAddress(self)) stopPlayer", color: .green)
            PlayerControlManagerV2.shareInstance().stopPlayer(playerModel)
        } else {
            YKSCScreenLogUtil.printLog("[热播大剧] \(YKCCUtil.objAddress(self)) stopPlayer return", color: .green)
        }
    }
    
    // MARK: PlayerStatusCallback
    func didStartPlayVideoInPlayer(_ player: PlayerView) {
        YKSCScreenLogUtil.printLog("[热播大剧] \(YKCCUtil.objAddress(self)) 视频开始", color: .green)
        self.startToPlayDelayWrapper.cancelDelayDo()
        
        let orangeInfo = Orange.getGroupConfig(byGroupName: "yksc_config")
        let config = orangeInfo?.yk_bool_opt("item14001PreviewDisableFinsishDelayBlock") ?? false
        if !config {
            self.playFinishedWrapper.delayTimeDo(15)
        }
    }
    
    func didFinishPositiveVideoInPlayer(_ player: PlayerView) {
        YKSCScreenLogUtil.printLog("[热播大剧] \(YKCCUtil.objAddress(self)) 视频结束", color: .green)
        
        self.willEndAnimation()
        self.endAnimation()
        self.playFinishedWrapper.cancelDelayDo()
    }
    
    func player(_ player: PlayerView, playError errorCode: Int) {
        YKSCScreenLogUtil.printLog("[热播大剧] \(YKCCUtil.objAddress(self)) 视频错误:\(errorCode)", color: .green)
        
        self.willEndAnimation()
        self.endAnimation()
        self.playFinishedWrapper.cancelDelayDo()
    }
    
    func playTimeDidChange(_ player: PlayerView) {
        YKSCScreenLogUtil.printLog("[热播大剧] \(YKCCUtil.objAddress(self)) 视频播放中:\(player.playingTime)s", color: .green)
    }
    
    func getSuperPreviewModel() -> Item14001SuperPreviewModel? {
        return (self.item?.model as? Item14001Model)?.superPreviewModel
    }
    
    func getPreviewId() -> String? {
        return getSuperPreviewModel()?.videoId
    }
    
    func getPlayerModel() -> PlayerModel? {
        return getSuperPreviewModel()?.playerModel
    }
    
    // MARK: - 动画
    func beforeStartAnimation() {
        self.alpha = 1
        self.bgView.alpha = 0
        self.logoImageView.alpha = 0
        self.crossView.alpha = 0
    }
    
    func startAnimation() {
        weak var weakSelf = self
        var bgAniFinishedFlag = false
        var logoAniFinishedFlag = false
        
        // bg动画
        let bgAniFinishedBlock = {
            guard bgAniFinishedFlag == false, let self = weakSelf else {
                return
            }
            bgAniFinishedFlag = true
            
            self.bgView.alpha = 1
            self.crossView.alpha = 1
        }
        
        UIView.animate(withDuration: 0.45, delay: 0, options: UIView.AnimationOptions.curveEaseInOut, animations: {
            guard let self = weakSelf else {
                return
            }
            
            self.bgView.alpha = 1
            self.crossView.alpha = 1
        }) { finished in
            if finished {
                YKSCScreenLogUtil.printLog("[热播大剧] 渐现动画结束", color: .green)
                bgAniFinishedBlock()
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.55) {
            if bgAniFinishedFlag == false {
                YKSCScreenLogUtil.printLog("[热播大剧] 渐现动画结束【兜底】", color: .green)
                bgAniFinishedBlock()
            }
        }
        
        // logo动画
        let logoFinishedBlock = {
            guard logoAniFinishedFlag == false, let self = weakSelf else {
                return
            }
            logoAniFinishedFlag = true
            
            self.logoImageView.alpha = 1
        }
        
        //400ms后开始
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            guard let self = weakSelf else {
                return
            }
            
            UIView.animate(withDuration: 0.45, delay: 0, options: UIView.AnimationOptions.curveEaseInOut, animations: {
                self.logoImageView.alpha = 1
            }) { finished in
                if finished {
                    YKSCScreenLogUtil.printLog("[热播大剧] 渐现logo动画结束", color: .green)
                    logoFinishedBlock()
                }
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
            if logoAniFinishedFlag == false {
                YKSCScreenLogUtil.printLog("[热播大剧] 渐现logo动画结束【兜底】", color: .green)
                logoFinishedBlock()
            }
        }
    }
    
    func willEndAnimation() {
        self.coverImageView.isHidden = true
        self.endCoverImageView.isHidden = false
        //        self.backgroundColor = self.bgView.backgroundColor
        self.bgView.backgroundColor = UIColor.clear //切回外框背景，防止露馅
//        self.endCoverImageView.addSubview(self.logoImageView)
        self.addSubview(self.titleLabel)
        self.addSubview(self.subtitleLabel)
    }
    
    func endAnimation() {
        // 收起动画
        // 1.十字架原位置渐隐
        // 2.封面及logo同步缩小及渐隐，logo一直处于封面水平中间位置
        weak var weakSelf = self
        var aniFinishedFlag = false
        
        let animationBlock = {
            guard let self = weakSelf else {
                return
            }
            
            self.crossView.alpha = 0
            self.titleLabel.alpha = 0
            self.subtitleLabel.alpha = 0
            self.logoImageView.alpha = 0
            self.updateViewsLayoutByEndAnimation()
        }
        
        let aniFinishedBlock = {
            guard aniFinishedFlag == false, let self = weakSelf else {
                return
            }
            aniFinishedFlag = true
            animationBlock()
            
            self.endAlphaAnimation()
        }
        
        UIView.animate(withDuration: 0.45, delay: 0, options: UIView.AnimationOptions.curveEaseInOut, animations: {
            animationBlock()
        }) { finished in
            if finished {
                YKSCScreenLogUtil.printLog("[热播大剧] 缩放动画结束", color: .green)
                aniFinishedBlock()
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.55) {
            if aniFinishedFlag == false {
                YKSCScreenLogUtil.printLog("[热播大剧] 缩放动画结束【兜底】", color: .green)
                aniFinishedBlock()
            }
        }
    }
    
    func endAlphaAnimation() {
        weak var weakSelf = self
        var aniFinishedFlag = false
        
        let aniFinishedBlock = {
            guard aniFinishedFlag == false, let self = weakSelf else {
                return
            }
            aniFinishedFlag = true
            
            self.bgView.alpha = 0
            
            self.releaseViews()
        }
        
        UIView.animate(withDuration: 0.3, delay: 0, options: UIView.AnimationOptions.curveEaseInOut, animations: {
            guard let self = weakSelf else {
                return
            }
            
            self.bgView.alpha = 0
        }) { finished in
            if finished {
                YKSCScreenLogUtil.printLog("[热播大剧] 渐隐动画结束", color: .green)
                aniFinishedBlock()
            }
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            if aniFinishedFlag == false {
                YKSCScreenLogUtil.printLog("[热播大剧] 渐隐动画结束【兜底】", color: .green)
                aniFinishedBlock()
            }
        }
    }
    
    func updateViewsLayoutByEndAnimation() {
        guard let superPreviewModel = getSuperPreviewModel() else {
            return
        }
        
        let imgFrame = superPreviewModel.animationEndVideoFrame
        let bgViewFrame = superPreviewModel.animationEndBgViewFrame
        
        self.bgView.frame = bgViewFrame
        self.endCoverImageView.frame = imgFrame
    }
    
    // MARK: - 内存释放
    
    func releaseViews() {
        YKSCScreenLogUtil.printLog("[热播大剧] view:\(YKCCUtil.objAddress(self)) 移除", color: .green)
        
//        print("[热播大剧] release before----------")
//        let cs = Thread.callStackSymbols
//        for c in cs {
//            print("[热播大剧] \(c)")
//        }
        hasReleased = true
        guard self.superview != nil || self.alpha != 0 else {
            return
        }
        
        self.alpha = 0
        self.removeFromSuperview()
        
        self.stopPlayer()
        
        PCLayerManager.sharedInstance().remove(self.popReuest)
        
        self.startToPlayDelayWrapper.cancelDelayDo()
        self.playFinishedWrapper.cancelDelayDo()
        
        self.handler?.removePostionMovedObserver()
    }
    
    // MARK: - 兜底逻辑 ChannelCompDelayDoWrapperDelegate
    
    func wrapperDelayDo(_ wrapper: ChannelCompDelayDoWrapper) {
        if wrapper == self.startToPlayDelayWrapper { // 加载超时保护
            YKSCScreenLogUtil.printLog("[热播大剧] \(YKCCUtil.objAddress(self)) 触发起播保护", color: .green)
            self.willEndAnimation()
            self.endAnimation()
        } else if wrapper == self.playFinishedWrapper { //播放结束保护
            YKSCScreenLogUtil.printLog("[热播大剧] \(YKCCUtil.objAddress(self)) 触发播放结束保护", color: .green)
            self.willEndAnimation()
            self.endAnimation()
        }
    }
    
    func sendExpose() {
        if let report = self.getSuperPreviewModel()?.actionModel?.report {
            YoukuAnalytics.sharedInstance()?.collectALiCustomEvent(withEventID: "2201",
                                                                   pageName: report.pageName,
                                                                   arg1: nil,
                                                                   arg2: nil,
                                                                   args:report.args)
            YKSCScreenLogUtil.printLog("[热播大剧] \(YKCCUtil.objAddress(self)) 手动曝光", color: .green)
        }
    }
}
