//
//  Component14001Model.swift
//  YKChannelComponent
//
//  Created by better on 2023/3/31.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku

class Component14001Model: BaseComponentModel {
    weak var item13017DLService: BizDailyLimitService? = nil // 保存频控service，在jsonExtracter中创建
}
