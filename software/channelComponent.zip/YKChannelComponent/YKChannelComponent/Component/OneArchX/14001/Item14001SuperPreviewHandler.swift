//
//  Item14001SuperPreviewHandler.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/12/8.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import orange
import YKSCService
import PromptControl
import YKHome
import YKDowngradeSDK
import NovelAdSDK

let Item14001SuperPreviewTag = 2023120817
class Item14001SuperPreviewHandler: ItemEventHandler , PCLayerRequestDelegate {
    var contentView: UIView?
    var previewView: Item14001PreviewView?
    var dataError: Bool = false
    var hasShow: Bool = false
    
    var hasReused: Bool = false
    var needTryOpenPop: Bool = false
    var hasTryShowPreview: Bool = false
    var hasShowPreview: Bool = false

    var pullDrawerHasScrollFinished: Bool = true
    
    required init() {
        super.init()
        
        print("[热播大剧] handler \(self) init")
        registObserver()
    }
    
    deinit {
        print("[热播大剧] handler \(self) deinit")
        NotificationCenter.default.removeObserver(self)

        if let popRequest = popRequest {
            DispatchQueue.main.async {
                PCLayerManager.sharedInstance().remove(popRequest)
            }
        }

        if let previewView = previewView {
            DispatchQueue.main.async {
                previewView.releaseViews()
            }
        }
        
        self.removePostionMovedObserver()
    }
    
    func registObserver() {
        NotificationCenter.default.addObserver(self, selector: #selector(receiveHomeVcWillDisappearNotification(_:)), name: Notification.Name(rawValue: "HomeViewControllerWillDisappearNotification"), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(receivePullDrawerScrollHasFinshed), name: NSNotification.Name("home.pullDrawer.scrollHasFinished"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(receiveSplashViewRemovedNotification(_:)), name: Notification.Name(rawValue: "splashviewremoved"), object: nil)

        weak var weakSelf = self
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { //兜底逻辑，避免通知收不到
            guard let self = weakSelf, !self.pullDrawerHasScrollFinished else {
                return
            }
            
            self.receivePullDrawerScrollHasFinshed()
        }
    }
    
    func removeObserver() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func receivePullDrawerScrollHasFinshed() {
        YKSCScreenLogUtil.printLog("[热播大剧] 新feed滚动结束通知", color: .red)
        self.pullDrawerHasScrollFinished = true
        
        previewView?.readyToShow()
    }
    
    @objc func receiveVBStartEvent(_ notification: Notification?) {
        NotificationCenter.default.removeObserver(self, name: Notification.Name(rawValue: "com.youku.ad.home.bannerAd.showFourSquare"), object: nil)

//        guard let userInfo = notification?.userInfo else {
//            return
//        }
//        vbStarted = true
//        var adShould = userInfo["xx"] as? Bool ?? true
//        if !needTryOpenPop {
//            if adShould {
//                needTryOpenPop = false
//            } else {
//                needTryOpenPop = true
//            }
//        }
//        tryOpenPopLayerIfNeeded()
//        
        
        let allowShowFourSquare:Bool = NadResourceManager.sharedInstance().allowShowFourSquare
        let forceHideFourSquare:Bool = NadResourceManager.sharedInstance().forceHideFourSquare
        
        YKSCScreenLogUtil.printLog("[热播大剧] 广告字段通知 是否强制隐藏四宫格:\(forceHideFourSquare), 是否允许同屏:\(allowShowFourSquare)", color: .green)
        if !forceHideFourSquare, allowShowFourSquare, hasTryShowPreview {
            startShowPreview()
        }
    }
    
    func reuseViewEvent() {
        weak var weakSelf = self
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.33) {
            guard let weakSelf = weakSelf else {return}
            YKSCScreenLogUtil.printLog("[热播大剧] reuseViewEvent", color: .green)
            weakSelf.hasReused = true
            weakSelf.showPreviewIfNeeded()
            weakSelf.tryOpenPopLayerIfNeeded()
        }

    }
    
    func showPreviewIfNeeded() {
        guard !self.dataError, self.isPageInActive(), self.previewView == nil, !self.hasShow else {
            return
        }

        self.calPreviewViewLayoutInfo()
        guard let superPreViewModel = self.getSuperPreviewModel(), superPreViewModel.hasValidFrame,
            let listView = self.item?.getPage()?.pageContext?.getContainerView() as? UICollectionView else {
            self.dataError = true
            return
        }
        self.dataError = false
        
        if let view = listView.viewWithTag(Item14001SuperPreviewTag) {
            view.removeFromSuperview()
        }
        
        self.createPreviewView(startFrame: superPreViewModel.animationStartFrame, superView: listView)
        self.previewView?.fillData(self.item)
        
        // 注册位置变化
        self.registPositionMovedObserver()
    }
    
    func createPreviewView(startFrame: CGRect, superView: UICollectionView) {
        let view = Item14001PreviewView.init(frame: startFrame)
        view.handler = self
        view.item = self.item
        view.tag = Item14001SuperPreviewTag
        superView.addSubview(view)
        self.previewView = view
    }
    
    func tryOpenPopLayerIfNeeded() {
        
        guard previewView != nil  else {
            return
        }
        if !isPageInActive() {
            return
        }
        if !hasReused {
            return
        }
        if hasTryShowPreview {
            return
        }
        let superVC = YKHomeModeManager.sharedInstance().homeViewController
        let isSplashViewRemoved = superVC?.isSplashViewRemoved as? Bool ?? true
        if !isSplashViewRemoved {  //开始播放
            return
        }
        
        let allowShowFourSquare:Bool = NadResourceManager.sharedInstance().allowShowFourSquare
        let forceHideFourSquare:Bool = NadResourceManager.sharedInstance().forceHideFourSquare
        YKSCScreenLogUtil.printLog("[热播大剧] 广告字段读取 是否强制隐藏四宫格:\(forceHideFourSquare), 是否允许同屏:\(allowShowFourSquare)", color: .green)

        if forceHideFourSquare {
            return
        }
        
        hasTryShowPreview = true
        
        self.popRequest = self.newPopRequest
        self.popRequest?.layer = self.previewView
        self.previewView?.popReuest = self.popRequest
        PCLayerManager.sharedInstance().tryOpen(self.popRequest)
        
        if allowShowFourSquare {
            startShowPreview()
        } else {
            NotificationCenter.default.removeObserver(self, name: Notification.Name(rawValue: "com.youku.ad.home.bannerAd.showFourSquare"), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(receiveVBStartEvent(_:)), name: Notification.Name(rawValue: "com.youku.ad.home.bannerAd.showFourSquare"), object: nil)
        }
    }
    
    func getSuperPreviewModel() -> Item14001SuperPreviewModel? {
        if let itemModel = item?.model as? Item14001Model , let superPreviewModel = itemModel.superPreviewModel {
            return superPreviewModel
        }
        
        return nil
    }
    
    // MARK: - frame 计算
    func calPreviewViewLayoutInfo(isUpdate: Bool = false) {
        guard let item = self.item, let list = item.getPage()?.pageContext?.getContainerView() as? UICollectionView,
              let superPreviewModel = self.getSuperPreviewModel(),
              let compLayoutConfig = self.item?.getComponent()?.getComponentDelegate()?.layoutConfig(), let itemLayoutInfo = self.item?.getLayoutInfo() else {
            return
        }
        
        let itemIndex = item.index
        
        let isTwoItems = superPreviewModel.isTwoItems
        let padding = compLayoutConfig.padding
        let rowSpacing = compLayoutConfig.rowSpacing
        let columnSpacing = compLayoutConfig.columnSpacing
        
        var x: CGFloat = 0
        var y: CGFloat = 0
        let width: CGFloat = list.width - padding.left - padding.right
        var height: CGFloat = 0
        
        let itemLayoutW: CGFloat = itemLayoutInfo.width
        let calVideoH: CGFloat = calVideoImageHeight(itemLayoutW)
        
        var startFrame: CGRect = .zero
        var endFrame: CGRect = .zero
        var startVideoFrame : CGRect = .zero
        var endVideoFrame: CGRect = .zero
        var endBgViewFrame: CGRect = .zero
        
        let logoSize: CGSize = calLogoSize(isTwoItems: isTwoItems)
        
        if isTwoItems {
            superPreviewModel.itemIndex = itemIndex
            
            height = itemLayoutInfo.height
            x = padding.left
            y = itemLayoutInfo.y
            
            startFrame = CGRect.init(x: x, y: y, width: width, height: height)
            endFrame = CGRect.init(x: itemLayoutInfo.x, y: y, width: itemLayoutInfo.width, height: itemLayoutInfo.height)
            startVideoFrame = CGRect.init(x: 0, y: 0, width: width, height: calVideoH)
            endVideoFrame = CGRect.init(x: 0, y: 0, width: itemLayoutInfo.width, height: calVideoH)
            
            let isLeftIndex = (itemIndex % 2) == 0
            endBgViewFrame = CGRect.init(x: isLeftIndex ? 0 : (columnSpacing + itemLayoutW), y: 0, width: itemLayoutInfo.width, height: itemLayoutInfo.height)
        } else {
            
            guard itemIndex >= 0 && itemIndex <= 3 else {
                YKSCScreenLogUtil.printLog("[热播大剧] 4坑位给得index超过4，只能是前4个", color: .red)
                return
            }
            
            superPreviewModel.itemIndex = itemIndex
            
            height = itemLayoutInfo.height * 2 + rowSpacing
            x = padding.left
            
            if itemIndex <= 1 {
                y = itemLayoutInfo.y
            } else {
                y = itemLayoutInfo.y - itemLayoutInfo.height - rowSpacing
            }
            
            startFrame = CGRect.init(x: x, y: y, width: width, height: height)
            endFrame = CGRect.init(x: itemLayoutInfo.x, y: y, width: itemLayoutInfo.width, height: itemLayoutInfo.height)
            let useHeight = height - (itemLayoutInfo.height - calVideoH)
            startVideoFrame = CGRect.init(x: 0, y: 0, width: width, height: useHeight)
            endVideoFrame = CGRect.init(x: 0, y: 0, width: itemLayoutInfo.width, height: calVideoH)
            
            let isLeftIndex = (itemIndex % 2) == 0
            let isTopLine = (itemLayoutInfo.y == y)
            endBgViewFrame = CGRect.init(x: isLeftIndex ? 0 : (columnSpacing + itemLayoutW), y: isTopLine ? 0 : (rowSpacing + itemLayoutInfo.height), width: itemLayoutInfo.width, height: itemLayoutInfo.height)
        }
        
//        YKSCScreenLogUtil.printLog("[热播大剧] layoutInfo: x=\(itemLayoutInfo.x) y=\(itemLayoutInfo.y) w=\(itemLayoutInfo.width) h=\(itemLayoutInfo.height) s:\(startFrame) e:\(endFrame) s1:\(startVideoFrame) e1:\(endVideoFrame)", color: .red)
        superPreviewModel.animationStartFrame = startFrame
        superPreviewModel.animationEndFrame = endFrame
        superPreviewModel.animationStartVideoFrame = startVideoFrame
        superPreviewModel.animationEndVideoFrame = endVideoFrame
        superPreviewModel.animationEndBgViewFrame = endBgViewFrame
        superPreviewModel.logoOriginSize = logoSize
        superPreviewModel.hasValidFrame = true
    }
    
    func calVideoImageHeight(_ itemWidth: CGFloat) -> CGFloat {
        var ratio = 1.78
        if let componentModel = self.item?.getComponent()?.model as? BaseComponentModel,
           let aspectRatio = componentModel.extraExtend["aspectRatio"] as? Double,
            aspectRatio > 0 {
            ratio = aspectRatio
        }
        return ceil(itemWidth / ratio)
    }
    
    func calLogoSize(isTwoItems: Bool) -> CGSize {
        return isTwoItems ? CGSize(width: 140, height: 40) : CGSize(width: 205, height: 80)
    }
    
    func calLogoNewSize(ratio: CGFloat, originSize: CGSize) -> CGSize {
        guard ratio != 0 else {
            return .zero
        }
        
        let whRatio = originSize.width / originSize.height
        let newW = originSize.width / ratio
        return CGSize.init(width: newW, height: newW / whRatio)
    }
    
    // MARK: - life cycle
    
    func appDidBecomeActive() {
        self.didActivate()
    }
    
    func appWillResignActive() {
        self.removeIfNeeded()
    }
    
    func didActivate() {
        YKSCScreenLogUtil.printLog("[热播大剧] didActivate", color: .green)
        guard previewView != nil && (previewView?.pullDrawerHasScrollFinished ?? false) else {
            return
        }
        
        self.tryOpenPopLayerIfNeeded()
    }
    
    func didDeactivate() {
        YKSCScreenLogUtil.printLog("[热播大剧] didDeactivate", color: .green)
        guard previewView != nil && (previewView?.pullDrawerHasScrollFinished ?? false) else {
            return
        }
        
        self.removeIfNeeded()
    }
    
    func handleScrolling(_ scrollView: UIScrollView) {
        if let previewView = self.previewView, previewView.currentIsShowing() , !previewView.viewIsVisible() {
            YKSCScreenLogUtil.printLog("[热播大剧] 滚动超出屏幕 view移除", color: .red)
            self.releaseViews()
        }
    }
    
    func handleScrollEnded(_ scrollView: UIScrollView) {
        if let previewView = self.previewView, !previewView.hasReleased && !previewView.hasShow, previewView.viewIsVisible(true) {
            YKSCScreenLogUtil.printLog("[热播大剧] 滚动进入屏幕 尝试播放", color: .red)
            previewView.readyToShow()
        }
    }
    
    func isPageInActive() -> Bool {
        return self.item?.pageContext?.isPageActive() ?? false
    }
    
    func releaseViews() {
        if previewView != nil {
            previewView?.releaseViews()
            previewView = nil
        }
    }
    
    // MARK: - 弹层管理
    
    var popRequest:PCLayerRequest? = nil
    lazy var newPopRequest: PCLayerRequest? = {
//        let request = PCLayerRequest(layerID: "LAYER_ID_HOME_LUNBO_THEATRE_GUIDE")
        let request = PCLayerRequest(layerID: "LAYER_ID_HOME_HOT_QUADRUPLE")
        request?.delegate = self
        return request
    } ()
    
    // PCLayerRequestDelegate
    var splashViewRemovedObsAdded: Bool = false
    func onReady(_ request: PCLayerRequest!) {
        YKSCScreenLogUtil.printLog("[热播大剧] onReady", color: .green)
        tryStartShowPreview()
    }
    
    func onForceRemoved(_ request: PCLayerRequest!) {
        YKSCScreenLogUtil.printLog("[热播大剧] onForceRemoved", color: .green)
        if popRequest?.layer != nil {
            self.releaseViews()
            popRequest?.layer = nil
        }
    }
    
    func onWaiting(_ request: PCLayerRequest!) {
        YKSCScreenLogUtil.printLog("[热播大剧] onWaiting", color: .green)
    }
    
    func tryStartShowPreview() {
        YKSCScreenLogUtil.printLog("[热播大剧] tryStartShowPreview", color: .green)
        let superVC = YKHomeModeManager.sharedInstance().homeViewController
        let isSplashViewRemoved = superVC?.isSplashViewRemoved as? Bool ?? true
        if isSplashViewRemoved {  //开始播放
            YKSCScreenLogUtil.printLog("[热播大剧] onReady startShowPreview", color: .green)
            startShowPreview()
        } else {
            NotificationCenter.default.removeObserver(self, name: Notification.Name(rawValue: "splashviewremoved"), object: nil)
            NotificationCenter.default.addObserver(self, selector: #selector(receiveSplashViewRemovedNotification(_:)), name: Notification.Name(rawValue: "splashviewremoved"), object: nil)
        }
    }
    
    func startShowPreview() {
        guard let previewView = self.previewView else {
            return
        }
        if self.hasShowPreview {
            return
        }
        self.hasShowPreview = true
        previewView.popLayerCanShowPlayer = true
        previewView.readyToShow()
    }
    
    @objc func receiveSplashViewRemovedNotification(_ notif: Notification?) {
        YKSCScreenLogUtil.printLog("[热播大剧] 开屏移除通知", color: .green)
        if splashViewRemovedObsAdded {
            YKSCScreenLogUtil.printLog("[热播大剧] 开屏移除通知 已经处理 不处理", color: .green)
            return
        }
        splashViewRemovedObsAdded = true
        NotificationCenter.default.removeObserver(self, name: Notification.Name(rawValue: "splashviewremoved"), object: nil)
        
        tryOpenPopLayerIfNeeded()
//        startShowPreview()
    }
    
    @objc func receiveHomeVcWillDisappearNotification(_ notif: Notification?) {
        YKSCScreenLogUtil.printLog("[热播大剧] 首页离开通知", color: .green)
        removeIfNeeded()
    }
    
    func removeIfNeeded() {
        if let previewView = previewView , previewView.currentIsShowing() {
            self.releaseViews()
        }
    }
    
    // MARK: - 监听位置变化
    
    private var contentSizeObservation: NSKeyValueObservation?
    func registPositionMovedObserver() {
        guard let collectionView = self.item?.getPage()?.pageContext?.getContainerView() as? UICollectionView, self.contentSizeObservation == nil else {
            return
        }
        
        weak var weakSelf = self
        contentSizeObservation = collectionView.observe(\.contentSize, options: [.old, .new]) { [weak self] collectionView, change in
            if let newSize = change.newValue, let oldSize = change.oldValue {
                print("[热播大剧] 位置变化 新的contentSize: \(newSize) 旧的contentSize: \(oldSize)")
                if !CGSizeEqualToSize(newSize, oldSize) {
                    print("[热播大剧] 位置变化后 更新frame")
                    weakSelf?.previewView?.updateSelfFrameWhenPositionMoved()
                }
           }
       }
    }
    
    func removePostionMovedObserver() {
        self.contentSizeObservation?.invalidate()
        self.contentSizeObservation = nil
    }
}
