//
//  Item14338.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/6/5.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import OneArch
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import orange
import NovelAdSDK

let ITEM_14338_CMS_TAG = 202406112
let ITEM_14338_AD_TAG = 202406113

class Item14338: Item14001, ItemLifeCycleEventHandlerDelegate {
    var cmsView: Item14001ContentView?
    var adView: OADItemView?
    
    let api = NadAPI()
    var adModel: OADModel?
    
    var isVisible: Bool = false
    var isActived: Bool = true

    weak var containerView: UIView?
    
    lazy var lifeCycleEventHandler:ItemLifeCycleEventHandler = {
        let handler = ItemLifeCycleEventHandler()
        handler.delegate = self
        return handler
    }()
    
    override func loadEventHandlers() -> [ItemEventHandler]? {
        var handlers = super.loadEventHandlers()
        handlers?.append(lifeCycleEventHandler)
        return handlers
    }
    
    override func disableLongPress() -> Bool {
        return true
    }

    override func itemDidInit() {
        super.itemDidInit()
        
        guard let compModel = self.item?.getComponent()?.compModel else {
            return
        }
        
        if let config = compModel.data?["ykAdvertConfig"] as? [String : Any],
            let adParams =  config["adParams"] as? [String : Any] {
            let adType = YKCCUtil.getIntValue(adParams["p"]) ?? 0
            print("[oad] [14338] adType = \(adType)")
            
            if adType > 0 {
                api.requestAdData(withAdType: adType) { (_ adModel: OADModel?, _ error: Error?) in
                    self.adModel = adModel
                    adModel?.setEnableExposureOnce(true)
                    
                    print("[oad] [14338] adModel = \(String(describing: adModel))")
                    DispatchQueue.main.async { [weak self] in
                        guard let self = self else {
                            return
                        }
                        self.updateAdView()
                    }
                }
            }
        }
    }
    
    override func createView(_ itemSize: CGSize) -> UIView {
        let itemView = UIView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        
        if adView == nil {
            print("[oad] [14338] create adView")
            adView = OADItemView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            adView?.tag = ITEM_14338_AD_TAG
        }
        if let adView = adView {
            adView.frame = CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
            itemView.addSubview(adView)
        }
        
        if cmsView == nil {
            print("[oad] [14338] create cmsView")
            cmsView = Item14001ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            cmsView?.tag = ITEM_14338_CMS_TAG
        }
        if let cmsView = cmsView {
            cmsView.frame = CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
            itemView.addSubview(cmsView)
        }
        
        cmsView?.isHidden = false
        adView?.isHidden = true
        
        return itemView;
    }
    
    override func reuseView(itemView: UIView) {
        guard let _ = self.item?.model as? BaseItemModel else {
            return
        }
                
        self.containerView = itemView
        
        prepareView(itemView: itemView)
                
        if let adModel = adModel {
            adView?.isHidden = false
            cmsView?.isHidden = true
            
            UIView.performWithoutAnimation {
                adView?.setup(model: adModel, ratio: getImageAspectRatio(), item: self.item)
            }
            
            // 尝试曝光
            tryExpose()
        } else {
            adView?.isHidden = true
            cmsView?.isHidden = false

            if let preDelegate = cmsView?.item?.getItemDelegate() as? BaseItemDelegate {
                preDelegate.itemView = nil
            }
            UIView.performWithoutAnimation {
                cmsView?.fillData(item:self.item, ratio:getImageAspectRatio())
            }
        }
    }
        
    override func reuseId() -> String? {
        return "Item14338.item.reuseid"
    }
    
    //MARK:
    
    func prepareView(itemView: UIView) {
        // 复用后，重新获取View
        if cmsView == nil {
            print("[oad] [14338] get cmsView [prepareView]")
            cmsView = itemView.viewWithTag(ITEM_14338_CMS_TAG) as? Item14001ContentView
        }
        if cmsView == nil {
            print("[oad] [14338] create cmsView [prepareView]")
            cmsView = Item14001ContentView(frame: CGRect(x: 0, y: 0, width: itemView.size.width, height: itemView.size.height))
            cmsView?.tag = ITEM_14338_CMS_TAG
        }
        
        if adView == nil {
            print("[oad] [14338] get adView [prepareView]")
            adView = itemView.viewWithTag(ITEM_14338_AD_TAG) as? OADItemView
        }
        if adView == nil {
            print("[oad] [14338] create adView [prepareView]")
            adView = OADItemView(frame: CGRect(x: 0, y: 0, width: itemView.size.width, height: itemView.size.height))
            adView?.tag = ITEM_14338_AD_TAG
        }

        // pad旋转屏后，subview被移除
        if let cmsView = cmsView {
            if let view = itemView.viewWithTag(ITEM_14338_CMS_TAG), view != cmsView {
                print("[oad] [14338] remove cmsView [prepareView]")
                view.removeFromSuperview()
            }
            
            itemView.addSubview(cmsView)
            cmsView.frame = CGRectMake(0, 0, itemView.size.width, itemView.size.height)
        }
        if let adView = adView {
            if let view = itemView.viewWithTag(ITEM_14338_AD_TAG), view != adView {
                print("[oad] [14338] remove adView [prepareView]")
                view.removeFromSuperview()
            }
            
            itemView.addSubview(adView)
            adView.frame = CGRectMake(0, 0, itemView.size.width, itemView.size.height)
        }
    }
    
    func updateAdView() {
        if let adModel = adModel, let containerView = containerView {
            print("[oad] [14338] async prepareView")

            prepareView(itemView: containerView)
            
            cmsView?.isHidden = true
            adView?.isHidden = false
                        
            UIView.performWithoutAnimation {
                adView?.setup(model: adModel, ratio: getImageAspectRatio(), item: self.item)
            }
            
            tryExpose()
        }
    }
    
    func tryExpose() {
        if isVisible && isActived {
            adModel?.adExposure()
        }
    }
    
    override func enterDisplayArea(itemView: UIView?) {
        isVisible = true
        
        tryExpose()
    }
    
    override func exitDisplayArea(itemView: UIView?) {
        isVisible = false
    }
    
    override func didActivate() {
        isActived = true
    }
    
    override func didDeactivate() {
        isActived = false
    }
    
    override func appWillResignActive() {}
    
}
