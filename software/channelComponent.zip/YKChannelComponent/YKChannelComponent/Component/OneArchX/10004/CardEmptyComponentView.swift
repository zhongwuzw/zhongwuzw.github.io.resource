//
//  CardEmptyComponentView.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/21.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

enum CardEmptyType: Int {
    case loading = 0
    case noData = 1
    case noNetwork = 2
}

class CardEmptyComponentView: AccessibilityView {

    weak var component: IComponent?
    
    lazy var centerRefreshView: DefaultCenterRefreshView = {
        let view = DefaultCenterRefreshView.init(frame: self.bounds)
        return view
    }()

    var requestErrorView: DefaultRequestErrorView?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .clear
        self.addSubview(self.centerRefreshView)
        NotificationCenter.default.addObserver(self, selector: #selector(loadingStateChanged), name: NSNotification.Name("card.event.loading.state.changed"), object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(_ component: IComponent?) {
        self.component = component
        refresh()
    }
    
    func refresh() {
        let type = getEmptyType()
        
        self.centerRefreshView.isHidden = true
        
        if type == .loading {
            self.requestErrorView?.removeFromSuperview()
            self.requestErrorView = nil
            
            self.centerRefreshView.isHidden = false
            self.centerRefreshView.startAnimating()
            self.sendCardFirstPageRequest()
        } else {
            self.requestErrorView?.removeFromSuperview()
            let view = DefaultRequestErrorView.init(frame: self.bounds)
            self.addSubview(view)
            self.requestErrorView = view
            let error = (type == CardEmptyType.noNetwork) ? OneArchError.notReachable : OneArchError.ignorableEmpty
            self.requestErrorView?.showWithError(error)
            view.clickCallback = {[weak self] in
                self?.clearEmptyType()
                self?.refresh()
                self?.sendCardFirstPageRequest()
            }
        }
    }
    
    @objc func loadingStateChanged() {
        refresh()
    }
    
    func clearEmptyType() {
        guard let card = self.component?.getCard(), let cardModel = card.model as? BaseCardModel else {
            return
        }
        cardModel.extraExtend["emptyType"] = "loading"
    }
    
    func getEmptyType() -> CardEmptyType {
        guard let card = self.component?.getCard(), let cardModel = card.model as? BaseCardModel else {
            return .loading
        }
        let type = (cardModel.extraExtend["emptyType"] as? String) ?? "loading"
        if type == "loading" {
            return .loading
        } else if type == "noData" {
            return .noData
        } else if type == "noNetwork" {
            return .noNetwork
        }
        return .loading
    }
    
    func sendCardFirstPageRequest() {
        guard let card = self.component?.getCard() else {
            return
        }
        card.triggerFirstPageRequest()
        print("[jbp] send firstpage request \(card.index)")
    }
    
}

class CardNoDataComponentView: CardEmptyComponentView {
    
    override func refresh() {
        self.centerRefreshView.isHidden = true
        self.requestErrorView?.removeFromSuperview()
        
        let view = CardNoDataErrorView.init(frame: self.bounds)
        addSubview(view)
        view.showWithError()
        
        self.requestErrorView = view
    }
    
}

class CardNoDataErrorView: DefaultRequestErrorView {
    
    func showWithError() {
        self.ykn_showBigErrorType(.empty, message: "未获取到相关内容哦", params: nil, target: self, selector: nil)
    }
    
}
