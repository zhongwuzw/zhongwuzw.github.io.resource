//
//  Card10004New.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/11/23.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Card10004New: Card10004 {
    
}
