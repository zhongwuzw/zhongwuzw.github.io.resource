//
//  ComponentCardEmpty.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/21.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class CardEmptyComponent:NSObject, ComponentDelegate {

    var componentWrapper: ComponentWrapper?

    func componentDidInit() {}

    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        return ComponentLayoutConfig()
    }

    func columnCount() -> CGFloat {
        return 1.0
    }

    /// 加载事件处理器
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

    /// item高度（custom布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 400
    }

    /// 初始化item view（custom布局使用）
    func createView(_ itemSize: CGSize) -> UIView {
        return CardEmptyComponentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
    }

    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        guard let view = itemView as? CardEmptyComponentView else {
            return
        }
        view.fillData(self.component)
        print("[jbp] CardEmptyComponent reuse")

        //隐藏footer
        DispatchQueue.main.asyncAfter(deadline:.now() + 0.02) {
            self.component?.getPage()?.hidePageFooter()
        }
    }

    func itemViewClicked() {
        print("[OneArch] itemViewClicked")
    }
}

class CardNoDataComponent: CardEmptyComponent {
    
    override func createView(_ itemSize: CGSize) -> UIView {
        return CardNoDataComponentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
    }
    
}
