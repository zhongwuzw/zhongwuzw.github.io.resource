//
//  Item14102ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/5/7.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import YKResponsiveLayout
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item14102ContentView: UIView, ItemImmersionBackgroundViewContainer {

    //MARK: - Property
    lazy var imageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    lazy var contentView: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var iconImageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .ykn_primaryFill
        imageView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        imageView.layer.masksToBounds = true
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    lazy var bottomRoundSpacingView: UIView = {
        let view = UIView()
        
        view.backgroundColor = UIColor.ykn_primaryBackground
        
        let maskFrame = CGRect.init(x: 0, y: 0, width: self.width, height: 50)
        let maskPath = UIBezierPath.init(roundedRect: maskFrame,
                                         byRoundingCorners: [.topLeft, .topRight],
                                         cornerRadii: CGSize.init(width: 14, height: 14))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = maskFrame
        maskLayer.path = maskPath.cgPath
        
        view.layer.mask = maskLayer
        
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(imageView)
        addSubview(contentView)
        addSubview(bottomRoundSpacingView)
        contentView.addSubview(iconImageView)

        imageView.frame = self.bounds
        
        let statusBarOffset = STATUSBAR_HEIGHT - 20
        contentView.frame = CGRect.init(x: 0, y: statusBarOffset, width: self.width, height: self.height - statusBarOffset)
        
        let iconHeight: CGFloat = 38
        let offset: CGFloat = 44
        let iconY = contentView.height - iconHeight - offset + nodePageHeaderCompoenentBottomRoundSpacingHeight()
        iconImageView.frame = CGRect.init(x: 0, y: iconY, width: contentView.width, height: iconHeight)
    }
    
    func fillData(_ itemModel: Item14102Model) {
        // fill image
        var params = [String : Any]()
        params["fade"] = true
        let imageURL = itemModel.gifImg ?? itemModel.img
        imageView.ykn_setImage(withURLString: imageURL, module: "nodepage", imageSize: .zero, parameters: params, completed: nil)
        
        let iconURL = itemModel.icon
        weak var weakself = self

        params = [String : Any]()
        params["fade"] = true
        params["placeholderColor"] = UIColor.clear
        
        let w: CGFloat = self.width
        let h: CGFloat = nodePageHeaderCompoenentBottomRoundSpacingHeight()
        let x: CGFloat = 0
        let y: CGFloat = self.height - h
        
        bottomRoundSpacingView.frame = CGRect.init(x: x, y: y, width: w, height: h)
        bottomRoundSpacingView.backgroundColor = UIColor.ykn_primaryBackground
        
        // fill icon
        iconImageView.ykn_setImage(withURLString: iconURL, module: "nodepage", imageSize: .zero, parameters: params) { (image, error, info) in
            if let strongSelf = weakself,
               let image = image,
               image.size.height > 0 {
                
                let imageRenderHeight: CGFloat = 38
                //先恢复正常
                var offset: CGFloat = 44
                let y = strongSelf.contentView.height - imageRenderHeight - offset
                strongSelf.iconImageView.frame = CGRect.init(x: 0, y: y, width: strongSelf.width, height: imageRenderHeight)
            }
        }

        //绑定跳转、埋点
        Service.action.bind(itemModel.action, self)
    }

    // MARK: ItemImmersionBackgroundViewContainer
    func immersionBackgroundView() -> UIView {
        return imageView
    }
    
}
