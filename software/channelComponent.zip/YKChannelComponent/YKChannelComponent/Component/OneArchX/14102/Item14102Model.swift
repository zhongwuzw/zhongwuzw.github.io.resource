//
//  Item14102Model.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/5/7.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku
import YoukuResource

class Item14102Model: BaseItemModel {
    
    var rankOption: [[String: Any]]? {
        get {
            return self.extraExtend["rankOption"] as? [[String:Any]]
        }
    }
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        
        if let manualRank = dataInfo["manualRank"] as? [String:Any] ,
           let rankOption = manualRank["rankOption"] as? [[String:Any]] {
            
            
            var newRankOption = [[String: Any]]()
            
            let normalFont: UIFont = YKNFont.posteritem_maintitle()
            let normalTextAttrs: [NSAttributedString.Key: Any] = [.font: normalFont,
                                                                  .foregroundColor: UIColor.createColorWithHexRGB(colorStr: "#FFF9F2")]
            
            let highlightFont: UIFont = YKNFont.akrobatFont(ofSize: 16)
            let highlightTextAttrs: [NSAttributedString.Key: Any] = [.font: highlightFont,
                                                                     .foregroundColor: UIColor.createColorWithHexRGB(colorStr: "#FFF9F2")]
            
            let pattern = "[0-9]*\\+?"
            for aRankOption in rankOption {
                if let firstLine = aRankOption["firstLine"] as? String,
                   let secondLine = aRankOption["secondLine"] as? String {
                    
                    var aMultiRankOption = [String: Any]()
                    aMultiRankOption.merge(aRankOption) { _, new in
                        new
                    }
                    
                    let text = firstLine + " " + secondLine
                    
                    //构建富文本
                    let attributedText = NSMutableAttributedString.init(string: text, attributes: normalTextAttrs)
                    if let regex = try? NSRegularExpression.init(pattern: pattern, options: .caseInsensitive) {
                        let matchResult = regex.matches(in: text, options: .reportProgress, range: NSRange.init(text.startIndex..<text.endIndex, in: text))
                        for aMatchResult in matchResult {
                            attributedText.addAttributes(highlightTextAttrs, range: aMatchResult.range)
                        }
                    }
                    aMultiRankOption["attributedText"] = attributedText
                    
                    //计算富文本最佳尺寸
                    var textFitSize = attributedText.boundingRect(with: CGSize.init(width: 1000, height: 1000), options: .usesFontLeading, context: nil).size
                    textFitSize.width = ceil(textFitSize.width)
                    textFitSize.height = ceil(textFitSize.height)
                    aMultiRankOption["attributedTextFitSize"] = textFitSize
                    
                    newRankOption.append(aMultiRankOption)
                }
            }
            self.extraExtend["rankOption"] = newRankOption
        }
    }
    
}
