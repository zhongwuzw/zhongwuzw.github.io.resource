//
//  Item14102.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/5/7.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout

class Item14102: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T: NodeModel>() -> T.Type? {
        return Item14102Model.self as? T.Type
    }
    
    func itemDidInit() {

    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return backgroundImageSize().height + nodePageHeaderCompoenentBottomRoundSpacingHeight()
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14102ContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14102ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? Item14102Model else {
            return
        }

        itemView.fillData(itemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [
            ItemImmersionBackgroundAdapterPlugin()
        ]
    }
    
    func backgroundImageSize() -> CGSize {
        var itemHeight: CGFloat = 126.0
        if ykrl_isResponsiveLayout() {
            itemHeight = 150
            return .init(width: YKRLScreenWidth(), height: itemHeight)
        }
        let statusBarOffset = YKStatusBarHeight() - 20
        itemHeight += statusBarOffset
        return .init(width: YKRLScreenWidth(), height: itemHeight)
    }

}

