//
//  CustomPagingCollectionViewFlowLayout.swift
//  YKChannelComponent
//
//  Created by CC on 2022/10/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource

class CustomPagingCollectionViewFlowLayout:UICollectionViewFlowLayout {
    var lastOffset: CGPoint = .zero
    var pageSpace = 100.0
    var endPageSpace = 0.0

    override init() {
        super.init()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func prepare() {
        super.prepare()
        self.collectionView?.decelerationRate = .fast
    }
    
    override func targetContentOffset(forProposedContentOffset proposedContentOffset: CGPoint, withScrollingVelocity velocity: CGPoint) -> CGPoint {
        guard let collectionView = self.collectionView else {
            return proposedContentOffset
        }
        let offsetMax = collectionView.contentSize.width - (collectionView.width + self.sectionInset.right + self.minimumLineSpacing)
        let offsetMin = 0.0
        
        if lastOffset.x < offsetMin {
            lastOffset.x = offsetMin
        } else if lastOffset.x > offsetMax {
            lastOffset.x = offsetMax
        }
        
        let offsetForCurrentPointX = abs(proposedContentOffset.x - lastOffset.x)
        print("cc targetContentOffset offsetForCurrentPointX:\(offsetForCurrentPointX), lastOffset:\(lastOffset)")
        print("cc targetContentOffset proposedContentOffset:\(proposedContentOffset.x)")
//        let collectionViewWidth = self.collectionView?.width ?? 0
//        let contentSizeW = self.collectionView?.contentSize.width ?? 0
//        if lastOffset.x + collectionViewWidth >= contentSizeW {
//            let newProposedContentOffset = CGPoint.init(x: lastOffset.x, y: lastOffset.y)
//            return newProposedContentOffset
//        }
        
        let velocityX = velocity.x
        
        let direction:Bool = (proposedContentOffset.x - lastOffset.x) > 0
        
        var newProposedContentOffset = CGPoint.zero
        if (offsetForCurrentPointX > pageSpace/8.0) && (lastOffset.x >= offsetMin) && (lastOffset.x <= offsetMax) {
            var pageFactor = Int(0)
            if velocityX != 0 {
                pageFactor = abs(Int(velocityX))
            } else {
                pageFactor = abs(Int(offsetForCurrentPointX / pageSpace))
            }
            
            pageFactor = pageFactor < 1 ? 1: (pageFactor < 2 ? 1: 2)

            var pageOffsetX = pageSpace * CGFloat(pageFactor)
            //更多坑位宽度与其他坑位不同，这段逻辑不再具有普适性
            //左侧吸附对齐-从最右侧向左划动时触发
            if lastOffset.x == offsetMax && direction == false {
                //展示列数取整
                let column = Int(collectionView.width / pageSpace)
                //右侧空白区域大小 去掉左右边距后
                let spacing = collectionView.width - Double(column) * pageSpace - YKNGap.youku_margin_left() - YKNGap.youku_margin_right()
                //更多坑位宽度 减去右侧宽度，就是要左移到距离
                let endOffset = endPageSpace - spacing - 6
                if pageFactor > 1 {
                    pageOffsetX = endOffset + CGFloat(pageFactor - 1) * pageSpace
                } else {
                    pageOffsetX = endOffset
                }
            }
            newProposedContentOffset = CGPoint.init(x: lastOffset.x + (direction ? pageOffsetX : -pageOffsetX), y: proposedContentOffset.y)
            
        } else {
            newProposedContentOffset = CGPoint.init(x: lastOffset.x, y: lastOffset.y)
        }
        lastOffset.x = newProposedContentOffset.x
        print("cc targetContentOffset newOffset:\(newProposedContentOffset), originOffset:\(proposedContentOffset)")
        return newProposedContentOffset
    }
}
