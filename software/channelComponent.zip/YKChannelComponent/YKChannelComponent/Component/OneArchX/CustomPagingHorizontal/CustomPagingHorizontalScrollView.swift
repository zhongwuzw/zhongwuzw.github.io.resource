//
//  CustomPagingHorizontalScrollView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/10/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
//import SwiftUI

class CustomPagingHorizontalScrollView: UIView, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {

    weak var delegate: HorizontalScrollViewDelegate?

    var itemDatas: [Any]?

    lazy var customCollectionViewLayout:CustomPagingCollectionViewFlowLayout = {
        let layout = CustomPagingCollectionViewFlowLayout.init()
        layout.scrollDirection = .horizontal
        layout.minimumInteritemSpacing = 0 //YKNGap.youku_column_spacing()
        layout.minimumLineSpacing = 0
        layout.sectionInset = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        return layout
    }()
    lazy var collectionView: UICollectionView = {
        var frame = containerFrame()
        frame.origin.x = 0
        frame.origin.y = 0
        
        let collectionView = UICollectionView.init(frame: frame, collectionViewLayout: self.customCollectionViewLayout)
        if #available(iOS 11.0, *) {
            collectionView.contentInsetAdjustmentBehavior = .never
        }
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .clear
        collectionView.showsVerticalScrollIndicator = false
        collectionView.showsHorizontalScrollIndicator = false
        return collectionView
    }()

    //paging
    var beginDragOffset:CGFloat?

    var beginDragIndex:NSIndexPath?
    var currentIndexPath:NSIndexPath?
    var endDragIndex:NSIndexPath?

    var currentPageIndex:Int?
    var beginDraggingPositionX:CGFloat?

    
    func containerFrame() -> CGRect {
        return self.bounds
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.collectionView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func reload(delegate: HorizontalScrollViewDelegate?, datas: [Any]?) {
        self.delegate = delegate
        self.itemDatas = datas
        self.collectionView.frame = self.containerFrame()
        self.collectionView.contentInset = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        self.collectionView.reloadData()
    }
    
    // MARK: collection delegate
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.itemDatas?.count ?? 0
    }

    public func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        var itemSize = getItemSize(row: indexPath.row)
        itemSize.width += YKNGap.youku_column_spacing()
        return itemSize
    }

    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if let delegate = self.delegate {
            return UIEdgeInsets.init(top: delegate.topMargin(), left: delegate.leftMargin(), bottom: delegate.bottomMargin(), right: delegate.rightMargin() - YKNGap.youku_column_spacing())
        } else {
            return UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        }
    }

    let CELL_TAG = 202106082
    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let delegate = self.delegate else {
            collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: "UNKOWN")
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "UNKOWN", for: indexPath)
            return cell
        }
        let identifier = delegate.itemIdentifier(index: indexPath.row)
        collectionView.register(UICollectionViewCell.self, forCellWithReuseIdentifier: identifier)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath)
        
        var itemview = cell.viewWithTag(CELL_TAG)
        if itemview == nil {
            let newView = delegate.createItemView(index: indexPath.row, itemSize: getItemSize(row: indexPath.row))
            newView.tag = CELL_TAG
            cell.addSubview(newView)
            itemview = newView
        }
        if let itemview = itemview {
            //VIEW复用
            let itemSize = getItemSize(row: indexPath.row)
            itemview.frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
            delegate.reuseItemView(index: indexPath.row, itemView: itemview)
        }
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        delegate?.horizontalScrollWillDisplayItem(indexPath.row)
    }
    
    func collectionView(_ collectionView: UICollectionView, didEndDisplaying cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        delegate?.horizontalScrollEndDisplayItem(indexPath.row)
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {

    }

    func scrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        delegate?.horizontalScrollViewWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset.pointee)
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        delegate?.scrollViewDidScroll(scrollView)
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        handleScrollEndEvent(scrollView)
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        handleScrollEndEvent(scrollView)
    }
    
    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        handleScrollEndEvent(scrollView)
    }
    
    private func handleScrollEndEvent(_ container:UIScrollView) {
        guard let collectionView = container as? UICollectionView  else {
            return
        }
        // 获取当前可见的indexpath
        let visibleIndexPaths = collectionView.indexPathsForVisibleItems
        if visibleIndexPaths.isEmpty {
            delegate?.horizontalScrollDidEndScroll(nil, collectionView: collectionView)
            return
        }
        delegate?.horizontalScrollDidEndScroll(visibleIndexPaths, collectionView: collectionView)
    }
    
    func getItemSize(row: Int) -> CGSize {
        if let delegate = self.delegate {
            return delegate.itemSize(index: row)
        } else {
            return CGSize.init(width: 100, height: 100)
        }
    }
    
    //size
//    func caculateOffsetXAtIndexPath(_ indexPath:NSIndexPath) {
//
//        let itemCount = self.itemDatas.count
//        if (itemCount == 0) {
//            return 0
//        }
//        let offsetX = 0.0
//        let spacing = self.collectionViewLayout.minimumLineSpacing;
//        let itemWidth = self.collectionViewLayout.itemSize.width;
//
//        offsetX = (itemWidth + spacing) * (indexPath.row + indexPath.section * itemCount);
//        offsetX -= ((self.collectionView.frame.size.width - [self viewOffsetX] * 2) - self.collectionViewLayout.itemSize.width)/2.0f;
//
////        offsetX -= [self viewOffsetX];
//        return offsetX;
//    }
//    func caculateIndexPathWithOffsetX(_ indexPath:NSIndexPath) {
//        let itemCount = self.itemDatas.count
//        if (itemCount == 0) {
//            return NSIndexPath.init(index: 0)
//        }
//        let spacing = self.collectionViewLayout.minimumLineSpacing
//        let itemWidth = self.collectionViewLayout.itemSize.width
//        if (itemWidth < 0.001) {
//            return NSIndexPath.init(index: 0)
//        }
//
//        let midOffsetX = offsetX
//        midOffsetX = offsetX + self.collectionViewLayout.leftPadding + itemWidth / 2.0f
//    //    midOffsetX += [self viewOffsetX];
//        let itemIndex = (Int)(midOffsetX/ (itemWidth + spacing));
//
//        let section = 0
//        let row = Int(itemIndex % itemCount)
//
//        return NSIndexPath.forRow(row, inSection: section)
//    }
}
