//
//  Item14206.swift
//  YKChannelComponent
//
//  Created by CC on 2022/12/29.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

class Item14206: NSObject, ItemDelegate {
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView()
    }
    
    func reuseView(itemView: UIView) {
        
    }
    
    var itemWrapper: ItemWrapper?
    
    static func create() -> ItemDelegate {
        return Item14206.init()
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func itemDidInit() {

    }
    
    required override init() {
        
    }
}
