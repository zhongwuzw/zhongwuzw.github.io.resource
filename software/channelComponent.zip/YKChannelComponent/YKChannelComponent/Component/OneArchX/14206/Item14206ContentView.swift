//
//  Item14206ContentView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/12/29.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

public protocol Item14206ContentViewDelegate: NSObjectProtocol {
    
    func itemView14206DidClickLogin()
    
}

class Item14206ContentView: AccessibilityView {

    //MARK: - Property
    weak var delegate: Item14206ContentViewDelegate?
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.numberOfLines = 1
        self.addSubview(view)
        return view
    }()

    lazy var gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]  //0 30 44 51
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 1.0, y: 0.0)
        layer.cornerRadius = 15

        layer.colors = [UIColor.ykn_cb_3.cgColor, UIColor.ykn_cb_4.cgColor]
        layer.frame = CGRect.init(x: 0.0, y: 0.0, width: 56.0, height: 30.0)
        return layer
    }()

    
    lazy var loginBtn: UIButton = {
        let view = UIButton.init(frame: CGRect.init(x: 0.0, y: 0.0, width: 53.0, height: 30.0))
        view.titleLabel?.font = YKNFont.posteritem_subhead()
       
        view.setTitle("登录", for: UIControl.State.normal)
        var titleColor = UIColor.white
        view.setTitleColor(titleColor, for: UIControl.State.normal)
        
        view.layer.cornerRadius = 15
        view.clipsToBounds = true
        view.addTarget(self, action: #selector(didClickLoginBtn), for: .touchUpInside)

        view.layer.insertSublayer(gradientLayer, at: 0)
        self.addSubview(view)
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fill(_ model: BaseItemModel?, loginIconText:String?, loginDesc:String?) {

        guard let model = model else {
            return
        }

        //1. bind action
        Service.statistics.bind(model.action?.report, self, .Defalut)

        // login text
        let text = loginIconText ?? "登录"
        self.loginBtn.setTitle(text, for: .normal)
        self.titleLabel.text = loginDesc ?? "登录看更多精彩，追剧动态早知道"

        //3. layout
        self.loginBtn.width = model.layout.subtitle?.renderRect.width ?? 53
        self.loginBtn.right = self.right - 12
        self.loginBtn.centerY = self.height / 2.0
        
        self.titleLabel.frame = CGRect.init(x: 12, y: 0, width: self.width - 12 - loginBtn.width - 12, height: YKNFont.height(with: titleLabel.font, lineNumber: 1))
        self.titleLabel.centerY = self.height / 2.0
        
        //4. color
        let scene = model.scene
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: scene?.sceneTitleColor())
        self.backgroundColor = sceneUtil(.ykn_primaryBackground, sceneColor: scene?.sceneBgColor())
        
        yk_addBorderAndShadow(sceneBorderColor: nil)
        self.layer.cornerRadius = 9.0
    }

    @objc func didClickLoginBtn() {
        delegate?.itemView14206DidClickLogin()
    }

}
