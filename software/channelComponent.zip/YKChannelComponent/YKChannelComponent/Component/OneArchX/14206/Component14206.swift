//
//  Component14206.swift
//  YKChannelComponent
//
//  Created by CC on 2022/12/29.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout
import YKModeConfigFramework
import OneArchSupport
import OneArchSupport4Youku
import DYKNavigator

class Component14206: NSObject, ComponentDelegate {

    var componentWrapper: ComponentWrapper?
    var preferredItemHeight: CGFloat = 0

    func componentDidInit() {

    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeComponentModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.youku_column_spacing()
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }

    /// item高度
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        guard let itemModel = component?.getItems()?.first?.itemModel else {
            return 0
        }
        if let compModel = component?.compModel as? HomeComponentModel, let text = compModel.loginIconText {
            let size = calcStringSize(text, font:  YKNFont.posteritem_subhead(), size: CGSize.init(width: 300, height: 20))
            let layout = TextLayoutModel.init()
            layout.renderRect = CGRect.init(x: 0, y: 0, width: size.width + 30, height: size.height)
            itemModel.layout.subtitle = layout
        }
        let itemHeight = 51.0
        return itemHeight
    }

    /// 初始化item view
    func createView(_ itemSize: CGSize) -> UIView {
        return Item14206ContentView.init(frame: CGRect.init(origin: .zero, size: itemSize))
    }

    /// 复用
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14206ContentView else {
            return
        }
        
        guard let compModel = component?.compModel as? HomeComponentModel else {
            return
        }

        guard let itemModel = component?.getItems()?.first?.itemModel  else {
            return
        }
        
        itemView.delegate = self
        itemView.fill(itemModel, loginIconText: compModel.loginIconText, loginDesc: compModel.loginDesc)
    }
    
    func reuseId() -> String? {
        return String.init("Component14206-ReuseId")
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
    
}

extension Component14206: Item14206ContentViewDelegate {
    
    func itemView14206DidClickLogin() {
        let successBlock: @convention(block) () ->Void =  {
            // 登录成功后刷新页面
            self.component?.getPage()?.triggerFirstPageRequest()
        }
        let castBlock = unsafeBitCast(successBlock, to: AnyObject.self)
        
        let navparam = DYKNavigatorParamers.init()
        navparam.openType = NSDYKNavigatorOpenType.push
        navparam.nativParamers = ["successBlock": successBlock, "src": "LoginFromYoukuComponent14206"]
        DYKNavigatorManager.sharedInstance().openURL("youku://UserLogin", navigatorParams: navparam)
    }

}


