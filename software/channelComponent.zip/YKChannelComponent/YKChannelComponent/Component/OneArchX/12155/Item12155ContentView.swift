//
//  Item12155ContentView.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/8/20.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import SDWebImage
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKUIComponent
import DYKNetwork_YK
import UTDID
import YKHome
import YKChannelPage
import YoukuAnalytics

protocol Item12155TagItemViewDelegate: NSObjectProtocol {
    func didSelectedTagItemView(_ item:IItem?, interestTag:String)
    func didUnSelectedTagItemView(_ item:IItem?, interestTag:String)
}

class Item12155TagItemView : UIView {
    static var padding:CGFloat = 9.0
    static var font:UIFont = UIFont.systemFont(ofSize: 11)
    static var statusLabelWidth:CGFloat = 8.0

    weak var delegate:Item12155TagItemViewDelegate?
    weak var item:IItem?
    var isSelected:Bool = false
    
    lazy var statusLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.textColor = .ykn_primaryInfo
        view.numberOfLines = 1
        view.textAlignment = .center
        view.lineBreakMode = .byTruncatingTail
        view.font = YKNIconFont.sharedInstance().font(withSize: 8)
        view.backgroundColor = UIColor.clear
        return view
    }()
    lazy var titleLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.textColor = .ykn_primaryInfo
        view.numberOfLines = 1
        view.textAlignment = .center
        view.lineBreakMode = .byTruncatingTail
        view.font = Item12155TagItemView.font
        view.backgroundColor = UIColor.clear
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.layer.masksToBounds = true
        self.backgroundColor = UIColor.ykn_brandInfo.withAlphaComponent(0.05)
        self.addSubview(statusLabel)
        self.addSubview(titleLabel)
        weak var weakSelf = self
        self.whenTapped {
            weakSelf?.clickTagEvent()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(_ item: IItem?) {
        self.item = item
        guard let item = item, let itemModel = item.model as? Item12155Model else {
            return
        }
        
        self.isSelected = itemModel.selected
        titleLabel.text = itemModel.tagName

        updateSelectedStatus()
        
        let padding = Item12155TagItemView.padding
        let statusLabelWidth = Item12155TagItemView.statusLabelWidth
        let height = Item12155TagItemView.itemHeight()
        let width = Item12155TagItemView.titleWidth(self.width)
        statusLabel.frame = CGRect(x: padding, y: 0, width: statusLabelWidth, height: height)
        titleLabel.frame = CGRect.init(x: statusLabel.right, y: 0, width: width, height: height)
        
        self.layer.cornerRadius = height * 0.5
    }
    
    func clickTagEvent() {
        self.isSelected = !self.isSelected
        updateSelectedStatus()
        
        let itemModel = item?.itemModel as? Item12155Model
        var interestTag = ""
        if let tagName = itemModel?.tagName  {
            interestTag = tagName
        }
        if let showId = itemModel?.showId {
            interestTag = interestTag + "_" + showId
        }
        if self.isSelected {
            self.delegate?.didSelectedTagItemView(self.item, interestTag: interestTag)
        } else {
            self.delegate?.didUnSelectedTagItemView(self.item, interestTag: interestTag)
        }
    }
    
    func updateSelectedStatus() {
        if let title = self.item?.itemModel?.title {
            let preText = isSelected ? "\u{e682}" : "\u{e662}"
            let newtitle = preText + title
            statusLabel.text = preText
        } else {
            statusLabel.text = ""
        }
        if self.isSelected {
            self.statusLabel.textColor = .white
            self.titleLabel.textColor = .white
            self.backgroundColor = UIColor.ykn_brandInfo
        } else {
            self.statusLabel.textColor = .ykn_primaryInfo
            self.titleLabel.textColor = .ykn_primaryInfo
            self.backgroundColor = UIColor.ykn_brandInfo.withAlphaComponent(0.12)
        }
        let itemModel = self.item?.itemModel as? Item12155Model
        itemModel?.selected = self.isSelected
    }
    
    class func itemHeight() -> CGFloat {
        return 29.0
    }
    
    class func itemWidth(_ item:IItem) -> CGFloat {
        guard let itemModel = item.itemModel as? Item12155Model else { return 0 }
        let title = itemModel.tagName ?? ""
        let itemHeight = Item12155TagItemView.itemHeight()
        let textSize = calcStringSize(title, font: Item12155TagItemView.font, size: CGSize(width: 300, height: itemHeight))
        if textSize.width < 1 {
            return 0
        }
        let width = textSize.width + Item12155TagItemView.statusLabelWidth + Item12155TagItemView.padding * 2
        return width
    }
    
    class func titleWidth(_ itemWidth:CGFloat) -> CGFloat {
        return itemWidth - Item12155TagItemView.statusLabelWidth - Item12155TagItemView.padding * 2
    }
}

class Item12155ContentView : UIView, Item12155TagItemViewDelegate {
    
    var darkBgImg:String = "https://liangcang-material.alicdn.com/prod/upload/51591bbcbd87417aada1613c8ea8088e.webp.png"
    var lightBgImg:String = "https://liangcang-material.alicdn.com/prod/upload/edd860fe8e1b4cb89850b5e5fa285fe1.webp.png"
    
    var lastReplaceTimeStamp:TimeInterval = 0
    var defaultTags:[String] = [String]()
    var selectedTags:[String] {
        return self.compModel?.selectedTags ?? defaultTags
    }
    weak var component:IComponent?
    var compModel:Component12155Model? {
        get {
            return self.component?.compModel as? Component12155Model
        }
    }
    var page:IPage? {
        return component?.getPage()
    }
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.textColor = .ykn_primaryInfo
        view.numberOfLines = 1
        view.textAlignment = .left
        view.lineBreakMode = .byTruncatingTail
        view.font = PingFangSCMediumFont(16)
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.textColor = .ykn_secondaryInfo
        view.numberOfLines = 1
        view.textAlignment = .left
        view.lineBreakMode = .byTruncatingTail
        view.font = PingFangSCRegularFont(12)
        return view
    }()
    
    lazy var bgImgView: UIImageGIFView = {
        let view = UIImageGIFView.init()
        view.contentMode = .scaleAspectFill
        view.backgroundColor = UIColor.clear
        view.clipsToBounds = false
        return view
    }()
    
    lazy var tagContainerView: UIView = {
        let view = UIView.init()
        view.backgroundColor = UIColor.clear
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.clipsToBounds = true
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        self.backgroundColor = .ykn_elevatedPrimaryBackground
        
        self.addSubview(bgImgView)
        self.addSubview(titleLabel)
        self.addSubview(subtitleLabel)
        self.addSubview(tagContainerView)
        self.setupTagItemViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupTagItemViews() {
        for _ in 0...8 {
            let tagItemView = Item12155TagItemView.init(frame: .zero)
            tagItemView.delegate = self
            self.tagContainerView.addSubview(tagItemView)
        }
    }
    
    func getBgImg() -> String {
        if isDarkMode() {
            return self.darkBgImg
        } else {
            return self.lightBgImg
        }
    }
    
    func fillData(_ component: IComponent?) {
        self.component = component
        guard let component = component, let compModel = component.compModel else {
            return
        }
        Service.statistics.bind(compModel.action?.report, self, .OnlyExposure)

        let height = (300.0 / 510.0) * self.width
        bgImgView.frame = CGRect(x: 0, y: 0, width: self.width, height: height)
        bgImgView.sd_setImage(with: URL(string: getBgImg())) { (image: UIImage?, error: Error?, type: SDImageCacheType, url: URL?) in
        }
        
        titleLabel.text = compModel.title ?? "没找到想看的？"
        subtitleLabel.text = compModel.subtitle ?? "点选 定制专属的兴趣推荐"
        
        if let layout = compModel.layout.title {
            titleLabel.frame = layout.renderRect
        }
        if let layout = compModel.layout.subtitle {
            subtitleLabel.frame = layout.renderRect
        }
        if let tagContainerLayout =  compModel.layout.extendExtra?["tagContainer"] as? TextLayoutModel {
            self.tagContainerView.frame = tagContainerLayout.renderRect
        }
        
        let tagContainerSubviews = self.tagContainerView.subviews
        if let items = component.getItems() {
            var index = 0
            for item in items {
                if let layout = item.itemModel?.layout, let extendExtra = layout.extendExtra {
                    if index >= 0 , index < tagContainerSubviews.count {
                        if let tagItemView = tagContainerSubviews[index] as? Item12155TagItemView {
                            tagItemView.frame = layout.renderRect
                            tagItemView.fillData(item)
                            tagItemView.delegate = self
                            index += 1
                        } else {
                            let tagItemView = tagContainerSubviews[index]
                            tagItemView.frame = .zero
                        }
                    } else {
                        let tagItemView = Item12155TagItemView.init(frame: layout.renderRect)
                        tagItemView.delegate = self
                        self.tagContainerView.addSubview(tagItemView)
                        tagItemView.fillData(item)
                    }
                }
            }
        }
    }
    
    func didSelectedTagItemView(_ item: (any IItem)?, interestTag: String) {
        NSLog("selectedTag:\(interestTag), currentTags:\(self.selectedTags), self:\(self)")
        guard let compModel = compModel else { return }
        
        if let report = compModel.action?.report {
            let pageName = report.pageName ?? ""
            let spm = report.spm ?? ""
            let scm = report.scm ?? ""
            let controlName = report.controlName ?? ""
            let trackInfoDic = report.trackInfoDic ?? [String:Any]()
            let args = report.args ?? [String:Any]()

            YoukuAnalytics.sharedInstance().collectSPMPageClick(withPage: pageName, controlName: controlName, spm: spm, extend: ["track_info": trackInfoDic, "scm": scm, "spm": spm, "args": args])

        }
        if !compModel.selectedTags.contains(interestTag) {
            compModel.selectedTags.append(interestTag)
        }
        self.sendSaveInterestTagsRequest()
        self.requestMorePage()
    }
    
    func didUnSelectedTagItemView(_ item: (any IItem)?, interestTag: String) {
        NSLog("unselectedTag:\(interestTag), currentTags:\(self.selectedTags), self:\(self)")
        guard let compModel = compModel else { return }

        compModel.selectedTags.removeAll { (element) -> Bool in
            return element == interestTag
        }
        self.sendSaveInterestTagsRequest()
        self.requestMorePage()
    }
    
    func interestTagsStr() -> String {
        var str:String = ""
        for tag in self.selectedTags {
            if str != "" {
                str += ","
            }
            str += tag
        }
        return str
    }
    
    func currentItemsStr() -> String {
        var str:String = ""
        var count:Int = 0
        if let components = self.component?.getCard()?.getComponents() {
            for comp in components {
                if count >= 14 {
                    break
                }
                let value = getComponetRecInfoStr(comp)
                if str != "" {
                    str += ","
                }
                str += value
                count += 1
            }
        }
        return str
    }
    func getComponetRecInfoStr(_ component:IComponent?) -> String {
        var str:String = ""
        if let items = component?.getItems() {
            for item in items {
                if let itemModel = item.itemModel, let recInfo = itemModel.recInfo {
                    var value:String = ""
                    if let itemType = recInfo.itemType {
                        value = itemType
                    }
                    if let itemId = recInfo.itemId {
                        value = value + ":" + itemId
                    }
                    if str != "" {
                        str += ","
                    }
                    str += value
                }
            }
        }
        return str
    }
    
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: any NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
        weak var weakSelf = self
        DispatchQueue.main.async {
            guard let weakSelf = weakSelf else {return}
            weakSelf.bgImgView.sd_setImage(with: URL(string: weakSelf.getBgImg())) { (image: UIImage?, error: Error?, type: SDImageCacheType, url: URL?) in
            }
        }
    }
    
    class func estimatedLayout(_ itemWidth:CGFloat, component: IComponent) {
        let compModel = component.compModel
        let layout = compModel?.layout
        if layout?.extendExtra == nil {
            layout?.extendExtra = [String:Any]()
        }
        
        let topPadding:CGFloat = 12.0
        let titleHeight:CGFloat = 22.0
        let titleBottom:CGFloat = 3.0
        let titleLayout = TextLayoutModel()
        titleLayout.renderRect = CGRect(x: 9.0, y: topPadding, width: itemWidth - 18.0, height: titleHeight)
        layout?.title = titleLayout
        
        let subtitleHeight:CGFloat = 17.0
        let subtitleBottom:CGFloat = 9.0
        
        let subtitleLayout = TextLayoutModel()
        subtitleLayout.renderRect = CGRect(x: 9.0, y: topPadding + titleHeight + titleBottom, width: itemWidth - 18.0, height: subtitleHeight)
        layout?.subtitle = subtitleLayout
        
        let topContainerHeight = topPadding + titleHeight + titleBottom + subtitleHeight + subtitleBottom
        
        let tagLeft:CGFloat = 9.0
        let tagRight:CGFloat = 9.0
        let tagBottom:CGFloat = 6.0
        let tagItemHeight:CGFloat = 29.0
        var lineNum:Int = 1
        var curLineWidth:CGFloat = tagLeft
        
        if let items = component.getItems() {
            for item in items {
                let height = Item12155TagItemView.itemHeight()
                let width = Item12155TagItemView.itemWidth(item)
                item.itemModel?.layout.renderRect = CGRect.init(x: 0, y: 0, width: width, height: height)
            }
            var curX:CGFloat = tagLeft
            for item in items {
                if let layout = item.itemModel?.layout {
                    if layout.extendExtra == nil {
                        layout.extendExtra = [String:Any]()
                    }
                    let height = layout.renderRect.height
                    let width = layout.renderRect.width
                    if let tagWidth = item.itemModel?.layout.renderRect.width {
                        if curLineWidth + tagWidth + 2 <= itemWidth {
                            let y:CGFloat = CGFloat(lineNum - 1) * (height + tagBottom)
                            layout.renderRect = CGRect(x: curLineWidth, y: y, width: width, height: height)
                            
                            curLineWidth = curLineWidth + tagWidth + tagRight
                            layout.extendExtra?["line"] = lineNum
                        } else {
                            lineNum += 1
                            curLineWidth = tagLeft
                            curX = tagLeft
                            if curLineWidth + tagWidth + tagRight <= itemWidth {
                                let y:CGFloat = CGFloat(lineNum - 1) * (height + tagBottom)
                                layout.renderRect = CGRect(x: curLineWidth, y: y, width: width, height: height)

                                curLineWidth = curLineWidth + tagWidth + tagRight
                                layout.extendExtra?["line"] = lineNum
                            } else {
                                continue
                            }
                        }
                    }
                }
            }
        }
        
        let tagContainerHeight:CGFloat = CGFloat(lineNum) * tagItemHeight + max(0, (CGFloat(lineNum) - 1) * tagBottom)
        let tagContainerBottom:CGFloat = 15.0

        let tagContainerLayout = TextLayoutModel()
        tagContainerLayout.renderRect = CGRect(x: 0, y: topContainerHeight, width: itemWidth, height: tagContainerHeight)
        layout?.extendExtra?["tagContainer"] = tagContainerLayout
        
        let itemHeight:CGFloat = topContainerHeight + tagContainerHeight + tagContainerBottom
        layout?.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)
    }
}

extension Item12155ContentView {
    
    func sendSaveInterestTagsRequest() {
        
        var parameters = [String: Any]()
        parameters["api_version"] = "1.0"
        parameters["appId"] = "38443"

        var params = [String: Any]()
        params["data_type"] = "user_interest_tags"
        params["utdid"] = UTDevice.utdid()
        params["_input_charset"] = "utf-8"

        params["tag_info"] = interestTagsStr()
        
        if let paramsJson = try? JSONSerialization.data(withJSONObject: params, options: .prettyPrinted) {
            let jsonString = String.init(data: paramsJson, encoding: String.Encoding.utf8)
            parameters["params"] = jsonString
        }
        
        let requestModel = DYKHttpRequestModel()
        requestModel.enableMtop = true
        requestModel.requestURL = "mtop.youku.dai.rcmd.handleTppDataService"
        requestModel.paramDict = parameters
        
        YKJSONClient.sharedMtop().request(withHttpModel: requestModel) {[weak self] (task:YKResponseTask?, response:Any?) in
            guard let self = self else {return}
            if let response = response as? [String: Any] {
            }
            
        } failure: { (task:YKResponseTask?, error:Error?)  in
           
        }
    }
    
    func requestMorePage() {
        guard let component = self.component else { return  }
        
        let compIndex = component.index
        
        if self.selectedTags.count == 0 {
            return
        }
        
        var parameters = getMorePageRequest()
        
        let requestModel = DYKHttpRequestModel()
        requestModel.enableMtop = true
        requestModel.requestURL = "mtop.youku.columbus.home.module"
        requestModel.requestMethod = "POST"
        requestModel.paramDict = parameters
        
        weak var weakSelf = self
        YKJSONClient.sharedMtop().request(withHttpModel: requestModel) { (task:YKResponseTask?, response:Any?) in
            if let response = response as? [String: Any],
               let data = response["data"] as? [String: Any] {
                weakSelf?.replaceComponent(data)
            }
            
        } failure: { (task:YKResponseTask?, error:Error?)  in

        }
    }
    
    func replaceComponent(_ data:[String: Any]) {
        guard let component = self.component else { return  }
        let compIndex = component.index
        
        let nowTimeStamp = NSDate().timeIntervalSince1970 * 1000
        if nowTimeStamp - lastReplaceTimeStamp < 1000 {
            NSLog("[12155] replaceComponent failed - 距离上次刷新时间过近 \(nowTimeStamp - lastReplaceTimeStamp)")
            return
        }
        
        weak var weakSelf = self
        if let msData = data["2019061000"] as? [String: Any] {
            if let card = msData["data"] as? [String: Any] {
                if let compNodes = card["nodes"] as? [[String: Any]] {
                    var nodeCount = compNodes.count
                    var newNodes = compNodes
                    var standardCount:Int = 4
                    if nodeCount > standardCount {
                        if let array = compNodes.prefix(standardCount) as? [[String: Any]] {
                            newNodes = array
                            nodeCount = standardCount
                        } else {
                            nodeCount = 0
                        }
                    }
                    if nodeCount == 0 || nodeCount > standardCount {
                        return
                    }
                    guard let newReplaceComps = self.component?.getCard()?.getComponentManager()?.createComponents(newNodes) else {
                        return
                    }
                    let newReplaceCount = newReplaceComps.count
                    if nodeCount != newReplaceCount {
                        return
                    }
                    
                    self.component?.getCard()?.getComponentManager()?.batchUpdateComponentsNew(batchUpdateBlock: { originalComps in
                        let originalCount = originalComps.count
                        if originalCount > compIndex + nodeCount {
                            var newCompsList = [IComponent]()
                            var index = 0
                            for comp in originalComps {
                                if index <= compIndex {
                                    newCompsList.append(comp)
                                } else if index > compIndex, index <= compIndex + nodeCount {
                                    let replaceIndex = index - compIndex - 1
                                    if replaceIndex >= 0 , replaceIndex < newReplaceCount {
                                        let replaceComp = newReplaceComps[replaceIndex]
                                        newCompsList.append(replaceComp)
                                    }
                                } else {
                                    newCompsList.append(comp)
                                }
                                index += 1
                            }
                            return newCompsList
                        } else {
                            return originalComps
                        }
                    }, reloadAll: false, noReload: false, animated: true, completion: { _ in
                        MessageBox.sharedInstance()?.showMessage("已为您呈现相关兴趣内容~")
                        weakSelf?.lastReplaceTimeStamp = NSDate().timeIntervalSince1970 * 1000
                    })
                }
            }
        }
    }
    
    //feed.
    func getMorePageRequest() -> [String: Any] {
        let page = self.component?.getPage()
        var requestParams = [String: Any]()

        //接口版本
        requestParams["api_version"] = "1.0"
        requestParams["device"] = "IPHONE"
        
        //业务参数
        requestParams["ms_codes"] = page?.pageModel?.requestModel?.mscode ?? "2019061000"
        
        requestParams["debug"] = 0
        
        let params = NSMutableDictionary.init()
        
        params["pageNo"] = 1
        params["device"] = "IPHONE"
        
        params["bizKey"] = page?.pageModel?.requestModel?.bizKey ?? (YKHomeRequestHelper.bizKey() ?? requestParamsDefaultBizKey())
        params["nodeKey"] = page?.pageModel?.requestModel?.nodeKey ?? "SELECTION"
        
        
        let provider = CustomSelectionPageRequestParamsProvider.init()
        provider.page = page
        
        if let compModel = self.component?.compModel as? Component12155Model, let session = compModel.session as? NSDictionary {
            params["session"] = getJSONStringFromDictionary(dictionary: session)
        }
        
        let bizContextDict = provider.buildBizContext(false, bizKey: params["bizKey"] as? String)
        var extParams = bizContextDict["extParams"] as? [String: Any]
        if extParams == nil {
            extParams = [String: Any]()
        }
        extParams?["interest_tags"] = interestTagsStr()
        extParams?["currentItems"] = currentItemsStr()
        if let extParams = extParams {
            bizContextDict["extParams"] = extParams
        }
        
        var bizContextStr:String = ""
        if bizContextDict.allKeys.count > 0 {
            bizContextStr = getJSONStringFromDictionary(dictionary: bizContextDict) ?? ""
        }
        params["bizContext"] = bizContextStr
        
        params["showNodeList"] = 0
        params["debug"] = "0"
        params["gray"] = "0"
        
        requestParams["params"] = getJSONStringFromDictionary(dictionary: params)

        requestParams["h265Support"] = "1"
        return requestParams
    }
        
}
