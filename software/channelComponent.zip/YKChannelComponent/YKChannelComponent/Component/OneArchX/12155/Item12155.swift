//
//  Item12155.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/8/20.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport4Youku

class Item12155:NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item12155Model.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    func columnCount() -> CGFloat {
        return 2.0
    }

    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func itemDidInit() {
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView()
    }

    func reuseView(itemView: UIView) {
        
    }
}
