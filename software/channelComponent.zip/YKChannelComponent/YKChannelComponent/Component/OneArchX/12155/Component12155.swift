//
//  Component12155.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/8/20.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout

class Component12155: NSObject, ComponentDelegate {
    
    func componentDidInit() {
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Component12155Model.self as? T.Type
    }

    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.dim_6()
        let margin = YKNGap.youku_margin_left()
        let bottom = YKNGap.youku_column_spacing()
        
        if ykrl_isResponsiveLayout() {
            config.padding = UIEdgeInsets.init(top: 0, left: margin, bottom: bottom, right: margin)
        } else {
            config.padding = UIEdgeInsets.init(top: 0, left: margin, bottom: bottom, right: margin)
        }
        return config
    }
    
    func columnCount() -> CGFloat {
        return 2
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
    
    var componentWrapper: ComponentWrapper?
    
    func createView(_ itemSize: CGSize) -> UIView {
        return Item12155ContentView.init(frame: CGRect(origin: .zero, size: itemSize))
    }

    func reuseView(itemView: UIView) {
        guard let contentView = itemView as? Item12155ContentView else {
            return
        }
        contentView.fillData(self.component)
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.estimatedLayout(itemWidth)
        
        guard let componentModel = self.component?.compModel else {
            return 0
        }

        return componentModel.layout.renderRect.height
    }
    
    func estimatedLayout(_ itemWidth: Double) {
        guard let component = self.component, let componentModel = component.compModel else {
            return
        }
        Item12155ContentView.estimatedLayout(itemWidth, component: component)
    }

}

