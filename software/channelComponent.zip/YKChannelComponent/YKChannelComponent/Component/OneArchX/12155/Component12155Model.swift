//
//  Component12155Model.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/8/20.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku

class Component12155Model: BaseComponentModel {
    public var session: [String: Any]?
    public var selectedTags:[String] = [String]()

    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        guard let data = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        if let value = data["session"] as? [String: Any] {
            self.session = value
        }
    }
}

class Item12155Model: BaseItemModel {
    public var tagName: String?
    public var showId: String?
    public var selected: Bool = false
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        guard let data = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        if let value = data["tagName"] as? String {
            self.tagName = value
        }
        if let value = data["showId"] as? String {
            self.showId = value
        } else if let value = data["showId"] as? Int {
            self.showId = String(value)
        }
    }
}
