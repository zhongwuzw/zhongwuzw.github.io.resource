//
//  Item14105ContentView.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/9/14.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Item14105ContentView: UIView {

    //MARK: - Property
        
    lazy var titleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_primaryInfo
        view.font = Item14105ContentView.titleLabelFont()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_tertiaryInfo
        view.font = Item14105ContentView.titleLabelFont()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var avatarImageView: UIImageView = {
        let imageView = UIImageView.init(frame: CGRect.init(origin: .zero, size: CGSize.init(width: 30, height: 30)))
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = UIColor.init(white: 0.89, alpha: 1)
        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(titleLabel)
        addSubview(subtitleLabel)
        addSubview(avatarImageView)
    }
    
    func fillModel(_ itemModel: HomeItemModel) {
        relayoutIfNeeded(itemModel)
        
        //填充头像
        avatarImageView.ykn_setImage(withURLString: itemModel.img,
                                     module: "nodepage",
                                     imageSize: .zero,
                                     parameters: nil,
                                     completed: nil)
                
        //填充文字
        titleLabel.text = itemModel.title
        subtitleLabel.text = itemModel.subtitle

        //绑定跳转、埋点
        Service.action.bind(itemModel.action, self)
        
        //氛围适配
        titleLabel.textColor = sceneUtil(UIColor.ykn_primaryInfo, sceneColor: itemModel.scene?.sceneTitleColor())
        subtitleLabel.textColor = sceneUtil(UIColor.ykn_tertiaryInfo, sceneColor: itemModel.scene?.sceneSubTitleColor())
    }
    
    private func relayoutIfNeeded(_ model: HomeItemModel) {
        let layout = model.layout
        
        //title
        titleLabel.frame = layout.title?.renderRect ?? CGRect.zero
        
        //action
        subtitleLabel.frame = layout.subtitle?.renderRect ?? CGRect.zero
        
        //arrowImageView
        avatarImageView.frame = layout.cover?.renderRect ?? CGRect.zero
        avatarImageView.layer.cornerRadius = avatarImageView.height / 2
        avatarImageView.layer.masksToBounds = true
    }
    
    // MARK: 字体
    class func avatarHeight() -> CGFloat {
        let height: CGFloat = 30.0 * YKNSize.yk_icon_size_scale()
        return ceil(height)
    }
    
    class func titleLabelFont() -> UIFont {
        let font = YKNFont.carditem_maintitle()
        return font
    }
    
    class func subtitleLabelFont() -> UIFont {
        let font = YKNFont.posteritem_subhead()
        return font
    }

    class func preferredItemViewHeight() -> CGFloat {
        //主标题
        let titleFont = Item14105ContentView.titleLabelFont()
        let titleHeight: CGFloat = ceil(YKNFont.height(with: titleFont, lineNumber: 1))

        //副标题
        let subtitleFont = Item14105ContentView.subtitleLabelFont()
        let subtitleHeight: CGFloat = ceil(YKNFont.height(with: subtitleFont, lineNumber: 1))
        
        let gap: CGFloat = 5.0
        
        let avatarHeight = Item14105ContentView.avatarHeight()
        return max(avatarHeight, titleHeight + gap + subtitleHeight)
    }
}
