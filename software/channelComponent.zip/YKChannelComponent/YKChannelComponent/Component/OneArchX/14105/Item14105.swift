//
//  Item14105.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/9/14.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Item14105: NSObject, ItemDelegate {

    var itemWrapper: ItemWrapper?
    
    func getModelClass<T: NodeModel>() -> T.Type? {
        return HomeItemModel.self as? T.Type
    }
    
    func itemDidInit() {

    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let itemHeight: CGFloat = Item14105ContentView.preferredItemViewHeight()
        estimatedLayout(CGSize.init(width: itemWidth, height: itemHeight))
        
        return itemHeight
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14105ContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14105ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? HomeItemModel else {
            return
        }

        itemView.fillModel(itemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func estimatedLayout(_ size: CGSize) {
        guard let layoutModel = self.item?.layout else {
            return
        }
        
        if layoutModel.boundingSize == size {
            return //重复计算跳过
        }
        
        layoutModel.boundingSize = size
        layoutModel.renderRect = CGRect.init(origin: .zero, size: size)
        
        let avatarHeight: CGFloat = Item14105ContentView.avatarHeight()
        let gap: CGFloat = 7.0
        var titleWidthMax = size.width - avatarHeight - gap
        
        let avatar = ImageLayoutModel()
        let avatarWidth: CGFloat = avatarHeight
        let avatarX: CGFloat = 0
        let avatarY: CGFloat = 0
        avatar.renderRect = CGRect.init(x: avatarX, y: avatarY, width: avatarWidth, height: avatarHeight)
        layoutModel.cover = avatar
        
        do {
            let textX: CGFloat = avatarWidth + gap
            
            //主标题
            let title = TextLayoutModel()
            let titleFont = Item14105ContentView.titleLabelFont()
            title.font = titleFont
            title.lineNumber = 1
            
            let titleHeight: CGFloat = YKNFont.height(with: titleFont, lineNumber: 1)
            title.renderRect = CGRect.init(x: textX, y: 0, width: titleWidthMax, height: titleHeight)
            layoutModel.title = title

            //副标题
            let subtitle = TextLayoutModel()
            let subtitleFont = Item14105ContentView.subtitleLabelFont()
            subtitle.font = subtitleFont
            subtitle.lineNumber = 1
            
            let subtitleHeight: CGFloat = YKNFont.height(with: subtitleFont, lineNumber: 1)
            let subtitleY: CGFloat = titleHeight + 5
            subtitle.renderRect = CGRect.init(x: textX, y: subtitleY, width: titleWidthMax, height: subtitleHeight)
            layoutModel.subtitle = subtitle
        }
    }

}
