//
//  Item14168.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/9/6.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout

class Item14168: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T: NodeModel>() -> T.Type? {
        return BaseItemModel.self as? T.Type
    }
    
    func itemDidInit() {

    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let itemHeight: CGFloat = 30
        return itemHeight
    }
    
    func itemWidth() -> CGFloat {
        guard let itemModel = item?.itemModel else {
            return 0
        }
        
        var itemWidth: CGFloat = textFitSize(itemModel.title, font: YKNFont.font_size_middle4(), limit: .zero).width
        if itemWidth > 0 {
            itemWidth += (2 * YKNGap.dim_7())
        }
        return itemWidth
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14168ContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14168ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }

        itemView.fillModel(itemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func estimatedLayout(_ size: CGSize) {
        guard let layoutModel = self.item?.layout else {
            return
        }
        
        if layoutModel.boundingSize == size {
            return //重复计算跳过
        }
        
        var itemHeight: CGFloat = 0
        itemHeight += ceil(60 * YKNSize.yk_icon_size_scale())
        
        let newSize = CGSize.init(width: size.width, height: itemHeight)
        layoutModel.boundingSize = newSize
        layoutModel.renderRect = CGRect.init(origin: .zero, size: newSize)
        layoutModel.extendExtra = [String: Any]()
    }
    
    private func textFitSize(_ text: String?, font: UIFont, limit: CGSize) -> CGSize {
        guard let text = text else {
            return .zero
        }

        var fitSize = NSString(string: text).boundingRect(with: limit,
                                                          options: [.usesLineFragmentOrigin, .truncatesLastVisibleLine],
                                                          attributes: [.font: font],
                                                          context: nil).size
        fitSize = CGSize(width: ceil(fitSize.width), height: ceil(fitSize.height))
        return fitSize
    }
}

