//
//  Component14168.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/9/6.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource

class Component14168: NSObject, ComponentDelegate {

    var componentWrapper: ComponentWrapper?
    
    func componentDidInit() {
        
    }
    
    func layoutType() -> ComponentLayoutType {
        return .horizontalScroll
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        config.preferredCardSpacingTop = 0.0
        config.headerBottomMargin = 0.0
        config.rowSpacing = 0.0
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.horizontalPaddingLeft = YKNGap.youku_margin_left()
        config.horizontalPaddingRight = YKNGap.youku_margin_right()
        config.backgroundLeftMarginOffset = 0
        config.backgroundRightMarginOffset = 0
        config.headerLeftMarginOffset = 0
        config.headerRightMarginOffset = 0
        config.backgroundTopMargin = 0
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
    
}
