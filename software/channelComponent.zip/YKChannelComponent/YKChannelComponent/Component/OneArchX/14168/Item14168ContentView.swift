//
//  Item14168ContentView.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/9/6.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKNodePage

class Item14168ContentView: UIView {

    //MARK: - Property
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .ykn_primaryInfo
        label.font = YKNFont.font_size_middle4()
        label.textAlignment = .center
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        label.isUserInteractionEnabled = true
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(titleLabel)
        titleLabel.frame = self.bounds
        titleLabel.autoresizingMask = .flexibleWidth
        
        self.layer.borderColor = UIColor.createColorWithHexRGB(colorStr: "9d9fa8").withAlphaComponent(0.3).cgColor
        self.layer.borderWidth = 1;
        self.layer.cornerRadius = bounds.height / 2;
    }
    
    func fillModel(_ itemModel: BaseItemModel) {
        // fill texts
        titleLabel.text = itemModel.title
        
        Service.action.bind(itemModel.action, self, willAction: nil) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                if let title = itemModel.title {
                    YKNPRCSSearchHistoryUtil.sharedInstance().popHistoryWord(title)
                }
            }
        }
    }

}

