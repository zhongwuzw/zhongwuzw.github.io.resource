//
//  CardHomeTopMovie.swift
//  YKChannelComponent
//
//  Created by better on 2023/3/17.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku

/*
 "data" : {
   "twoLevelTitle" : "松手进入深夜放映厅",
   "pullTitle" : "下拉进入深夜放映厅",
   "extend" : {
     "scrollAutoPlay" : "0"
   },
   "subtitle" : "22点-06点限时开放",
   "title" : "深夜放映厅",
   "guideTitle" : "下拉一下",
   "pullSubtitle" : "每天22点精彩开启",
   "@primary" : "EP516121"
 },
 */

class Card15034Model: BaseCardModel {
    
    var pullTitle: String?
    var twoLevelTitle: String?
    var pullSubtitle: String?
    
    var guideTitle: String?
    var guideImg: String?
    var guideTxImg: String?

    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        if let dataInfo = cmsInfo?["data"] as? [String:Any] {
            self.pullTitle = dataInfo["pullTitle"] as? String
            self.twoLevelTitle = dataInfo["twoLevelTitle"] as? String
            self.pullSubtitle = dataInfo["pullSubtitle"] as? String
            
            self.guideTitle = dataInfo["guideTitle"] as? String
            self.guideImg = dataInfo["guideImg"] as? String
            self.guideTxImg = dataInfo["guideTxImg"] as? String
        }
    }
}

class Card15034: BaseCardDelegate {
    override func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Card15034Model.self as? T.Type
    }
    
    override func isShowHeader() -> Bool {
        return false
    }
}
