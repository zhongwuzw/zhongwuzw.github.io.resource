////
////  ComponentTopMovieView.swift
////  YKChannelComponent
////
////  Created by better on 2023/3/8.
////  Copyright © 2023 Youku. All rights reserved.
////
//
//import UIKit
//import OneArch
//import OneArchSupport
//import OneArchSupport4Youku
//import YKHome
//import SwiftUI
//import YoukuResource
//import YKChannelPage
//import YKChannel
//import YoukuAnalytics
//import Lottie
//import PromptControl
//import YKSCService
//import YKUIComponent
//import orange
//
//class ComponentTopMovieView: UIView,PCLayerRequestDelegate,CAAnimationDelegate {
//    
//    //poplayer是否正在展示
//    //    var inPopLayerDisplay = false
//    
//    var isSplashViewRemoved = false
//    var isSplashViewRemovedTimeStamp = -1.0
//    //接入poplayer
//    var toastLayerRequest: PCLayerRequest?
//    var requestFlag = false
//    //引导正在展示
//    var isShowGuideView = false {
//        didSet {
//            if !isShowGuideView {
//                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "home.topMovieComponent.guide.dismiss"), object: nil)
//            } else {
//                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "home.topMovieComponent.guide.show"), object: nil)
//            }
//        }
//    }
//    //需要展示引导
//    var isNeedScrollConainer = true
//    //引导-主动滚动后的offset
//    var guideOriginOffset:CGPoint = .zero
//    //引导-基于初始值向下滚动的offset:51.0 引导高度147
//    //改为offset 90， 186
//    var guideScrollOffset = 89.0
//    
//    //播放器是否已经起播
//    var isStarted = false
//    
//    weak var cardModel:Card15034Model?
//    
//    var lunboOffsetY: CGFloat = 0.0 //轮播图置顶container对应的offset
//    var initPositionY: CGFloat = 0.0 //播放器初始位置(相对屏幕坐标)
//    
//    ///scale 从上到下的滑动过程是1.0 -> 0.0
//    var animationStartScale = (1.0 - 40.0 / 90.0)
//    var animationEndScale = (1.0 - 70.0 / 90.0)
//    var guidePositionAnimation:CAKeyframeAnimation?
//    
//    weak var component: IComponent?
//    
//    lazy var backgroundView: UIView = {
//        let view = UIView.init()
//        view.backgroundColor = .clear
//        view.clipsToBounds = true
//        return view
//    }()
//    
//    lazy var bottomCurveView: UIView = {
//        let view = UIView.init()
//        view.backgroundColor = .clear
//        view.clipsToBounds = true
//        return view
//    }()
//    
//    lazy var playerContainer: UIView = {
//        let view = UIView()
//        view.contentMode = .scaleAspectFill
//        view.clipsToBounds = false
//        view.backgroundColor = .clear
//        return view
//    }()
//    
//    lazy var guideContainer: UIView = {
//        let view = UIView.init()
//        view.backgroundColor = .clear
//        view.clipsToBounds = true
//        return view
//    }()
//    
//    lazy var guideImageView: ComponentTopMovieGuideView = {
//        let guideImageView = ComponentTopMovieGuideView()
//        guideImageView.contentMode = .scaleAspectFill
//        guideImageView.clipsToBounds = false
//        guideImageView.isHidden = true
//        return guideImageView
//    }()
//    
//    lazy var titleLabel: UILabel = {
//        let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 200, height: 17))
//        label.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.posteritem_subhead().pointSize)
//        label.textColor = .white
//        label.textAlignment = .center
//        label.isUserInteractionEnabled = true
//        label.isHidden = true
//        label.alpha = 0.7
//        return label
//    }()
//    
//    lazy var subtitleLabel: UILabel = {
//        let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 200, height: 17))
//        label.font = YKNFont.posteritem_subhead()
//        label.textColor = .white.withAlphaComponent(0.5)
//        label.textAlignment = .center
//        label.isUserInteractionEnabled = true
//        label.isHidden = true
//        label.alpha = 0.7
//        return label
//    }()
//    
//    lazy var titleAnimationView: LOTAnimationView = {
//        let dict = YKHomeZipUtil.loadJsonZip("topmovie-title-animation") as? [String: Any]
//        let path = dict?["path"] as? String ?? ""
////        var path = Bundle.main.path(forResource: "DYKResources-bright-animation", ofType: "json") ?? ""
//        
//        let view = LOTAnimationView.init(filePath:path)
//        view.translatesAutoresizingMaskIntoConstraints = true
//        view.contentMode = .scaleAspectFit
//        view.isHidden = true
//        view.frame = CGRect.init(origin: .zero, size: CGSize.init(width: 135.0, height: 39.0))
//        return view
//    }()
//    
//    weak var container: UICollectionView?
//    weak var lunboBackgroundView: UIView?
//    
//    override init(frame: CGRect) {
//        super.init(frame: frame)
//        
//        //底部画曲线的颜色填充部分
//        self.addSubview(self.bottomCurveView)
//        
//        self.addSubview(self.backgroundView)
//        //self.addSubview(self.bottomView)
//        
//        //播放器层级
//        self.backgroundView.addSubview(self.playerContainer)
//        
//        
//        self.backgroundView.addSubview(self.titleLabel)
//        //        self.backgroundView.addSubview(self.subtitleLabel)
//        
//        self.backgroundView.addSubview(self.guideContainer)
//        self.guideContainer.addSubview(self.guideImageView)
//        
//        self.backgroundView.addSubview(self.titleAnimationView)
//        
//        self.backgroundView.frame = CGRect.init(x: 0, y: 0, width: self.width, height: 200)
//        self.backgroundView.bottom = self.height - 50
//        
//        NotificationCenter.default.addObserver(self, selector: #selector(receiveScaleChangedNotification(_:)), name: Notification.Name(rawValue: "home.event.topmove.position"), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(receiveAlphaChangedNotification(_:)), name: Notification.Name(rawValue:"home.topMovieComponent.alpha.changed"), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(receiveSplashViewRemovedNotification(_:)), name: Notification.Name(rawValue: "splashviewremoved"), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(clickTabTriggerRerefreshNoti(_:)), name: Notification.Name(rawValue:"KChannelPage.clickTabTriggerRerefreshNoti.topMovieMode.preload"), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(receiveHomePageActiveStateWillChangeNotification(_:)), name: Notification.Name(rawValue:"HomeScrollViewWillHorizontalScroll"), object: nil)
//        
//    }
//    
//    deinit {
//        print("[top movie] removeShakerAnimation deinit")
//        removeShakerAnimation()
//        removeToastLayerRequest()
//        NotificationCenter.default.removeObserver(self)
//    }
//    
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
//    func fillData(_ cardModel:Card15034Model?) {
//        guard let cardModel = cardModel else { return }
//        self.cardModel = cardModel
//        if let title = cardModel.pullTitle {
//            titleLabel.text = title
//        }
//        if let subtitle = cardModel.pullSubtitle {
//            subtitleLabel.text = subtitle
//        }
//        guideContainer.frame = guideImageViewFrame()
//        guideImageView.frame = guideContainer.bounds
//        guideImageView.fillData(cardModel)
//        
//        titleLabel.width = self.width - 30
//        subtitleLabel.width = self.width - 30
//        
//        self.playerContainer.frame = guideImageViewFrame()
//        
//        //test
////#if DEBUG
////        isNeedScrollConainer = true
////        isShowGuideView = false
////#endif
//        self.requestFlag = false
//        //        self.addToastLayerRequest()
//        
//        DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
//            guard let self = self else { return }
//            if self.isShowGuideView {
//                return
//            }
//            if self.getIsSplashViewRemoved() {
//                self.addToastLayerRequestNow()
//            }
//        }
//        
//        titleAnimationView.frame = CGRect.init(x: 0, y: 0, width: 135.0, height: 39)
//        titleAnimationView.bottom = self.titleLabel.top
//        titleAnimationView.centerX = self.backgroundView.width / 2.0
//        
//        removeShakerAnimation()
//        
//        scaleChanged(1.0, container: self.container, containerColor: nil, lunboBackgroundView: self.lunboBackgroundView)
//    }
//    
//    @objc func receiveScaleChangedNotification(_ notif: Notification?) {
//        guard let userInfo = notif?.userInfo else {
//            return
//        }
//        guard let maxScale = userInfo["maxScale"] as? CGFloat else {
//            return
//        }
//        
//        let card = self.cardModel?.domainObject as? ICard
//        let pageModel = card?.getPage()?.pageModel as? SelectionPageModel
//        let inLoadingState = pageModel?.inLoadingState ?? false
//        if inLoadingState {
//            return
//        }
//        
//        if let dataState = self.component?.getPage()?.pageModel?.dataState, dataState != .network {
//            scaleChanged(1.0, container: self.container, containerColor: nil, lunboBackgroundView: self.lunboBackgroundView)
//            return
//        }
//        
//        let container = userInfo["container"] as? UICollectionView
//        self.container = container
//        let containerColor = userInfo["containerColor"] as? UIColor
//        let lunboBackgroundView = userInfo["lunboBackgroundView"] as? UIView
//        self.lunboBackgroundView = lunboBackgroundView
//        scaleChanged(maxScale, container: container, containerColor: containerColor, lunboBackgroundView: lunboBackgroundView)
//    }
//    
//    @objc func receiveAlphaChangedNotification(_ notif: Notification?) {
//        guard let userInfo = notif?.userInfo else {
//            return
//        }
//        guard let alpha = userInfo["alpha"] as? CGFloat else {
//            return
//        }
//        if let dataState = self.component?.getPage()?.pageModel?.dataState, dataState != .network {
//            return
//        }
//        let card = self.cardModel?.domainObject as? ICard
//        let pageModel = card?.getPage()?.pageModel as? SelectionPageModel
//        let inLoadingState = pageModel?.inLoadingState ?? false
//        if inLoadingState {
//            return
//        }
//        
//        self.isHidden = alpha == 0
//    }
//    
//    func reuse() {
//        isShowGuideView = false
//        initPositionY = self.calcInitPlayerPosition()
//        //        ImmersivePageManager.shared.setAlpha(0.0)
//
//        self.guideOriginOffset = CGPoint.init(x: 0, y: -124.0)
//    }
//    
//    func calcInitPlayerPosition() -> CGFloat {
//        let extend = heightExtend(maxScale: 1.0)
//        let h1 = extend - 9.0
//        let h2 = h1 - 0.0
//        let bgInnerCompHeight = self.height - h2
//        var bgHeight = bgInnerCompHeight - self.lunboOffsetY
//        bgHeight = max(bgHeight, 0.0)
//        return bgHeight/2.0
//    }
//    
//    func scaleChanged(_ maxScale: CGFloat, container: UICollectionView?, containerColor:UIColor?, lunboBackgroundView: UIView?) {
//        guard let container = container else {
//            return
//        }
//        
//        if let dataState = self.component?.getPage()?.pageModel?.dataState, dataState != .network {
//            return
//        }
//        
//        self.container = container
//        
//        let extend = heightExtend(maxScale: maxScale)
//        let radius: CGFloat = 14 * (1.0 - maxScale)
//        let h1 = extend - 9.0
//        let h2 = h1 - radius
//        
//        let bgInnerCompHeight = self.height - h2
//        var bgHeight = bgInnerCompHeight - container.contentOffset.y
//        bgHeight = max(bgHeight, 0.0)
//        self.backgroundView.height = bgHeight
//        self.backgroundView.bottom = self.height - h2
//                
//        //更新子容器frame
//        self.guideContainer.frame = self.backgroundView.bounds
//        self.playerContainer.frame = self.backgroundView.bounds
//        self.guideImageView.frame = self.guideContainer.bounds
//        
//        //标题、副标题文字、frame、hidden控制
//        progressTitleFrame(maxScale, container: container, radius: radius)
//        
//        //播放器
//        progressControlPlayer(maxScale)
//        
//        //进入落地页进度
//        progressEnterPage(maxScale, container: container)
//        
//        //标题 lottie动画播放
//        progressTitleAnimation(maxScale, container: container)
//        
//        
//        //底部弧线
//        progressQuadCurve(maxScale, container: container, containerColor: containerColor, lunboBackgroundView: lunboBackgroundView)
//    }
//    
//    func heightExtend(maxScale: CGFloat) -> CGFloat {
//        let topExtend = CONSTANT.LUNBO_BIGCARD_EXTEND_TOP
//        let heightExtend = (topExtend - 15) * maxScale + 15
//        return heightExtend
//    }
//    
//    func progressQuadCurve(_ maxScale:CGFloat, container:UIScrollView, containerColor:UIColor?, lunboBackgroundView: UIView?) {
//        guard let lunboBackgroundView = lunboBackgroundView else { return  }
//        let card = self.cardModel?.domainObject as? ICard
//        let pageModel = card?.getPage()?.pageModel as? SelectionPageModel
//        let inLoadingState = pageModel?.inLoadingState ?? false
//        if inLoadingState {
//            return
//        }
//
//        if isShowGuideView {
//            if maxScale >= 0.1 {
//                removeShakerAnimation()
//            }
//            if self.guideImageView.alpha < 1.0 {
//                self.backgroundColor = .clear
//            } else {
////                self.backgroundColor = containerColor
//            }
//
//        } else {
//            self.backgroundColor = .clear
//        }
////        YKSCScreenLogUtil.printLog("[top movie] progressQuadCurve maxScale:\(maxScale), guideOriginOffset:\(guideOriginOffset)", color: .red)
//        print("[top movie] progressQuadCurve maxScale:\(maxScale), guideOriginOffset:\(guideOriginOffset)")
//
//        let frame = self.backgroundView.bounds
//        var controlPadding = 0.0
//        
//        //20(0)---70(25)---90(35)---110(45)
//        //start:20 end:110, total:90
//        let maxCurveHeight = 45.0
//        let totalOffset = 90.0
//        let startOffset = 70.0
//        if maxScale <= 0.778 {
//            let originY = self.guideOriginOffset.y + startOffset
//            let curY = container.contentOffset.y
//            var scale = abs(originY - curY) / totalOffset
//            scale = min(1, scale)
//            controlPadding = controlPadding + maxCurveHeight * scale
//            print("[top movie] progressQuadCurve controlPadding:\(controlPadding), scale:\(scale)")
////            YKSCScreenLogUtil.printLog("[top movie] progressQuadCurve controlPadding:\(controlPadding), scale:\(scale)", color: .red)
//        }
//
////        self.bottomCurveView.isHidden = false
//
//        //底部填充色
////        self.bottomCurveView.backgroundColor = containerColor
////        self.bottomCurveView.backgroundColor = .clear
////        var guideAddBottom = 25.0
////        if !isShowGuideView {
////            guideAddBottom = 0.0
////        }
////        let curveViewH = min(controlPadding, maxCurveHeight) + guideAddBottom
////        self.bottomCurveView.frame = CGRect.init(x: 0, y: 0, width: self.width, height: curveViewH)
////        self.bottomCurveView.bottom = self.backgroundView.bottom + guideAddBottom
//        
//        
//        let top = 0.0
//        let bottom = frame.height - controlPadding
//        let left = 0.0
//        let right = frame.width
//        
//        ///底部填充色 弧线 贴近轮播的部分
//        let bottomMaskPath = UIBezierPath()
//        //左上角为起点
//        bottomMaskPath.move(to: CGPoint.init(x: 0, y: 0))
//        //右上角为终点 画弧线，弧线控制点居中 底部
//        bottomMaskPath.addQuadCurve(to: CGPoint.init(x: lunboBackgroundView.width, y: 0), controlPoint: CGPoint.init(x: lunboBackgroundView.width / 2.0, y: controlPadding + 8))
////        bottomMaskPath.addCurve(to: CGPoint.init(x: self.bottomCurveView.width, y: 0), controlPoint1: CGPoint.init(x: bottomCurveView.width * 0.6, y: controlPadding), controlPoint2: CGPoint.init(x: bottomCurveView.width * 0.4, y: controlPadding))
//        bottomMaskPath.addLine(to: CGPoint.init(x: lunboBackgroundView.width, y: lunboBackgroundView.height))
//        bottomMaskPath.addLine(to: CGPoint.init(x: 0, y: lunboBackgroundView.height))
//        bottomMaskPath.addLine(to: .zero)
//        let bottomMaskLayer = CAShapeLayer()
//        bottomMaskLayer.frame = lunboBackgroundView.bounds
//        bottomMaskLayer.path = bottomMaskPath.cgPath
//        lunboBackgroundView.layer.mask = bottomMaskLayer
//
//        
//        ///上面的矩形弧线
//        let maskPath = UIBezierPath()
//        //左下角为起点
//        maskPath.move(to: CGPoint.init(x: left, y: bottom))
//        //右下角为终点 画弧线，弧线控制点居中
//        maskPath.addQuadCurve(to: CGPoint.init(x: right, y: bottom), controlPoint: CGPoint.init(x: frame.width / 2.0, y: bottom + controlPadding + 8))
//        //右下角到右上角
//        maskPath.addLine(to: CGPoint.init(x: right, y: top))
//        //右上角到左上角
//        maskPath.addLine(to: CGPoint.init(x: left, y: top))
//        //左上角到左下角 圈起来
//        maskPath.addLine(to: CGPoint.init(x: left, y: bottom))
//        let maskLayer = CAShapeLayer()
//        maskLayer.frame = self.backgroundView.bounds
//        maskLayer.path = maskPath.cgPath
//        self.backgroundView.layer.mask = maskLayer
//    }
//    
//    func progressTitleFrame(_ maxScale:CGFloat, container:UIScrollView, radius: CGFloat) {
//        //引导已经展示
//        if isShowGuideView {
//            self.titleLabel.isHidden = true
//            self.subtitleLabel.isHidden = true
//            //计算透明度
//            let totalOffset = abs(guideScrollOffset)
//            let originY = self.guideOriginOffset.y
//            let curY = container.contentOffset.y
//            print("[top movie] progressTitleFrame originY:\(originY), curY:\(curY), totalOffset:\(totalOffset)")
//            if curY < originY {
//                var scale = (originY - curY) / 40
//                scale = min(1, scale)
//                self.guideImageView.alpha = 1 - scale
//                print("[top movie] progressTitleFrame scale:\(scale), alpha:\(self.guideImageView.alpha), ")
//                if self.guideImageView.alpha < 0.001 {
//                    isShowGuideView = false
//                    self.guideImageView.isHidden = true
//                }
//            }
//            //归位
//            if curY >= originY + totalOffset {
//                print("[top movie] progressTitleFrame endAlpha")
//                isShowGuideView = false
//                self.guideImageView.isHidden = true
//            }
//            
//            self.titleLabel.bottom = self.backgroundView.height - 12 - radius
//            self.titleLabel.centerX = self.backgroundView.width / 2.0
//
//        } else {
//            self.titleLabel.isHidden = false
//            self.subtitleLabel.isHidden = false
//            
//            //标题变化
//            if maxScale <= 0.001 {
//                self.subtitleLabel.isHidden = true
//                if let twoLevelTitle = cardModel?.twoLevelTitle {
//                    self.titleLabel.text = twoLevelTitle + " \u{e707}"
//                } else {
//                    self.titleLabel.text = ""
//                }
//                
//                self.titleLabel.bottom = self.backgroundView.height - 12 - radius
//                self.titleLabel.centerX = self.backgroundView.width / 2.0
//            } else {
//                self.subtitleLabel.isHidden = false
//                if let pullTitle = cardModel?.pullTitle {
//                    self.titleLabel.text = pullTitle + " \u{e707}"
//                } else {
//                    self.titleLabel.text = ""
//                }
//                
//                self.titleLabel.bottom = self.backgroundView.height - 12 - radius
//                self.titleLabel.centerX = self.backgroundView.width / 2.0
//                
//                self.subtitleLabel.bottom = self.titleLabel.top - 3
//                self.subtitleLabel.centerX = self.backgroundView.width / 2.0
//                        
//                if maxScale >= 1.0 {
//                    self.subtitleLabel.isHidden = true
//                    self.titleLabel.isHidden = true
//                }
//            }
//        }
//    }
//    
//    func progressEnterPage(_ maxScale:CGFloat, container:UIScrollView) {
//        // 透明度
////        let alpha = min((1.0 - maxScale) * 90 / 45.0, 1.0)
////        ImmersivePageManager.shared.setAlpha(alpha)
//        // 进入落地页进度
//        let progress = calcInterpolationValue(p1: self.lunboOffsetY, p1Value: 0.0, p2: -container.height, p2Value: 1.0, x:container.contentOffset.y)
//        let playerHeight: CGFloat = container.width * 7.0 / 8.0 // ImmersivePageManager.shared.playerView?.height ?? 0.0
//        var playerPosProgress = calcInterpolationValue(p1: playerHeight, p1Value: 0.0, p2: container.height, p2Value: 1.0, x: self.backgroundView.height)
//        playerPosProgress = max(playerPosProgress, 0.0)
//        playerPosProgress = min(playerPosProgress, 1.0)
//        ImmersivePageManager.shared.pageLoadingProgress(progress: progress, playerPosProgress: playerPosProgress, isDragging:container.isDragging)
//    }
//
//    func animationDidStart(_ anim: CAAnimation) {
//        print("[top movie] animationDidStart \(NSDate.timeIntervalSinceReferenceDate)")
//    }
//    
//    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
//        print("[top movie] removeShakerAnimation animationDidStop \(NSDate.timeIntervalSinceReferenceDate)")
//        removeShakerAnimation()
//    }
//}
//
/////MARK:开屏广告
//extension ComponentTopMovieView {
//    
//    @objc func clickTabTriggerRerefreshNoti(_ notif: Notification?) {
//        removeShakerAnimation()
//        receiveSplashViewRemovedNotification(notif)
//    }
//    
//    @objc func receiveSplashViewRemovedNotification(_ notif: Notification?) {
//        guard let card = cardModel?.domainObject as? ICard else { return  }
//        let superVC = card.getPage()?.pageContext?.concurrentDataMap["pageInitInfo.superViewController"] as? HomeViewController
//        isSplashViewRemoved = superVC?.isSplashViewRemoved as? Bool ?? true
//        isSplashViewRemovedTimeStamp = NSDate.timeIntervalSinceReferenceDate
//        
//        //收到通知时未展示过引导
//        if isSplashViewRemoved && !isShowGuideView {
//            //展示引导
//            DispatchQueue.main.asyncAfter(deadline: .now() + 2) { [weak self] in
//                guard let self = self else { return }
//                if self.isShowGuideView {
//                    return
//                }
//                if self.getIsSplashViewRemoved() {
//                    self.addToastLayerRequestNow()
//                }
//            }
//        }
//    }
//    
//    func getIsSplashViewRemoved() -> Bool {
//        let card = cardModel?.domainObject as? ICard
//        let superVC = card?.getPage()?.pageContext?.concurrentDataMap["pageInitInfo.superViewController"] as? HomeViewController
//        isSplashViewRemoved = superVC?.isSplashViewRemoved as? Bool ?? false
//        return isSplashViewRemoved
//    }
//
//}
/////MARK:播放器逻辑
//extension ComponentTopMovieView {
//    func progressControlPlayer(_ maxScale:CGFloat) {
//        if getIsSplashViewRemoved() {
//            if maxScale >= 1.0 {
//                stopPlayer()
//            } else {
//                let now
//                
//                
//                = NSDate.timeIntervalSinceReferenceDate
//                if now - isSplashViewRemovedTimeStamp > 0.5 {
//                    startPlayer()
//                }
//            }
//        }
//    }
//    func startPlayer() {
//        if isStarted {
//            return
//        }
//        
//        if !shouldDisableJudge() {
//            if (container?.isDragging ?? false) || (container?.isTracking ?? false) || (container?.isDecelerating ?? false) {} else {
//                print("[Immersive] isDragging false return")
//                return
//            }
//        }
//        
//        isStarted = true
//        ImmersivePageManager.shared.startPlayer(nil, nil)
//    }
//    func stopPlayer() {
//        isStarted = false
//        ImmersivePageManager.shared.stopPlayer()
//    }
//    
//    func shouldDisableJudge() -> Bool {
//        let orangeInfo = Orange.getGroupConfig(byGroupName: "yksc_config")
//        return orangeInfo?["disableImmersivePlayerJudge"] as? Bool ?? false
//    }
//}
//
/////MARK:引导相关
//extension ComponentTopMovieView {
//    func showNewUserGuideView() {
//        if !canShowViewByLimit() {
//            return
//        }
//        //进入过二级页
//        if isEnterPage() {
//            return
//        }
//        if !isPageInActive() {
//            return
//        }
//
//        let card = self.cardModel?.domainObject as? ICard
//        let pageModel = card?.getPage()?.pageModel as? SelectionPageModel
//        let inLoadingState = pageModel?.inLoadingState ?? false
//        let curOffset = self.container?.contentOffset ?? .zero
//        let isLunboInTopState = curOffset.y == lunboOffsetY
//        let hasAppleAD = YKAppleADManager.sharedInstance().hasAppleAD
//        if isNeedScrollConainer && !inLoadingState  && isLunboInTopState && !hasAppleAD {
//            //状态更新
//            isShowGuideView = true
//            isNeedScrollConainer = false
//            markShowFlag()
//            sendShowGuideStatistic()
//            
//            var newOffset = self.container?.contentOffset ?? .zero
//            newOffset.y -= guideScrollOffset
//            self.guideOriginOffset = newOffset
//
//            self.guideImageView.isHidden = false
//            self.guideImageView.alpha = 0
//            
//            self.container?.setContentOffset(newOffset, animated: true)
//            UIView.animate(withDuration: 0.3) {
//                self.guideImageView.alpha = 1.0
////                self.container?.contentOffset = newOffset
//            } completion: { (state: Bool) in
////                self.container?.contentOffset = newOffset
//                self.guideImageView.alpha = 1.0
//                self.guideImageView.loadTitleImage()
//                self.startShakerAnimation()
//                print("[top movie] showNewUserGuideView playing finish")
//            }
////            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { [weak self] in
////                guard let self = self else { return  }
////                self.startShakerAnimation()
////            }
//            //4s后收起引导,引导动画时间0.3+0.45*6 = 3s, 3+4=7s
//            var dismissTime = 3.1
////            #if DEBUG
////            dismissTime = 500
////            #endif
//            DispatchQueue.main.asyncAfter(deadline: .now() + dismissTime) { [weak self] in
//                guard let self = self else { return  }
//                self.tryDismissNewUserGuideView(true)
//            }
//        }
//    }
//    
//    func tryDismissNewUserGuideView(_ animation:Bool) {
//        let showTime = UserDefaults.standard.double(forKey: showDateKey())
//        let curTime = NSDate.timeIntervalSinceReferenceDate
//        if curTime - showTime > 2.0 {
//            self.dimissNewUserGuideView(animation)
//        } else {
//            DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) { [weak self] in
//                guard let self = self else { return  }
//                self.dimissNewUserGuideView(true)
//            }
//        }
//    }
//    
//    func dimissNewUserGuideView(_ animation:Bool) {
//        print("[top movie] removeShakerAnimation dismissGuide begin~~~ ")
//        //引导已经消失了-拖拽过
//        if !self.isShowGuideView {
//            return
//        }
//        //滚动中，不触发动画 滚动结束后引导会自动消失
//        if let containerView = self.container {
//            if containerView.isDragging || containerView.isDecelerating {
//                print("[top movie] removeShakerAnimation dismissGuide container is scroll")
//                return
//            }
//        }
//
//        var offset = self.guideOriginOffset
//        offset.y += self.guideScrollOffset
//        
//        self.container?.setContentOffset(offset, animated: animation)
//        
//        removeToastLayerRequest()
//        
//        print("[top movie] removeShakerAnimation dismissGuide")
//        self.removeShakerAnimation()
//    }
//    
//    @objc func receivePageLoadingBeforeNotification(_ notif: Notification?) {
//        self.tryDismissNewUserGuideView(false)
//    }
//    
//    @objc func receiveHomePageActiveStateWillChangeNotification(_ notif: Notification?) {
//        self.tryDismissNewUserGuideView(false)
//    }
//    
//    func guideImageViewFrame() -> CGRect {
//        let w = self.frame.size.width
//        let h = self.width * CGFloat(0.5625)
//        return CGRect.init(x: 0, y: 0, width: w, height: h)
//    }
//    
//    func isEnterPage() -> Bool {
//        return ImmersivePageManager.shared.isEnterPage
//    }
//    
//    func sendShowGuideStatistic() {
//        YoukuAnalytics.sharedInstance()?.collectALiCustomEvent(withEventID: "2201",
//                                                               pageName: "page_homeselect",
//                                                               arg1: nil,
//                                                               arg2: nil,
//                                                               args:["spm":"a2h04.8165646.feedtoast.showhalltoast"])
//    }
//    
//    ///标记Flag：每一天展示一次
//    func canShowViewByLimit() -> Bool {
////        return true
////        #if DEBUG
////        return true
////        #endif
//        let interval = UserDefaults.standard.double(forKey: showDateKey())
//        if interval > 0 {
//            let date = Date(timeIntervalSinceReferenceDate: interval)
//            // 存在记录的日期，校验是否为当天
//            if Calendar.current.isDateInToday(date) {
//               return false
//            } else {
//                //非当天，执行展示
//                return true
//            }
//        }
//        //从没有展示过
//        return true
//    }
//    
//    func markShowFlag() {
//        //刷新日期
//        UserDefaults.standard.setValue(Date.timeIntervalSinceReferenceDate, forKey: showDateKey())
//        UserDefaults.standard.synchronize()
//    }
//    
//    func showDateKey() -> String {
//        let suffix = "com.youku.comp.topMovie.show.date"
//        return suffix
//    }
//    
//    func getCard() -> ICard? {
//        if let card = self.cardModel?.domainObject as? ICard {
//            return card
//        }
//        return nil
//    }
//    
//    func isPageInActive() -> Bool {
//        if let page = self.getCard()?.getPage() {
//            if let state = page.activeState, state == true {
//                return true
//            }
//        }
//        return false
//    }
//}
//
/////poplayer
//extension ComponentTopMovieView {
//    
//    func addToastLayerRequest() {
//        if self.requestFlag {
//            return
//        }
//        if !canShowViewByLimit() {
//            return
//        }
//        self.removeToastLayerRequest()
//        self.requestFlag = true
//        
//        createLayerRequestIfNeeded()
//        PCLayerManager.sharedInstance().tryOpen(self.toastLayerRequest)
//        //test
////        #if DEBUG
////        showNewUserGuideView()
////        #endif
//    }
//    
//    func removeToastLayerRequest() {
//        if toastLayerRequest != nil {
//            PCLayerManager.sharedInstance().remove(toastLayerRequest)
//            toastLayerRequest?.layer = nil
//            toastLayerRequest = nil
//        }
//    }
//    
//    @objc func addToastLayerRequestNow() {
//        addToastLayerRequest()
////        self.createLayerRequestIfNeeded()
////        PCLayerManager.sharedInstance().tryOpen(self.toastLayerRequest)
//    }
//    
//    func createLayerRequestIfNeeded() {
//        if  toastLayerRequest == nil {
//            toastLayerRequest = PCLayerRequest.init(layerID: "LAYER_ID_HOME_MOVIE_SECOND_FLOOR_GUIDE")
//            toastLayerRequest?.delegate = self
//        }
//    }
//    
//    // MARK: - PCLayerDelegate
//    
//    func onReady(_ request: PCLayerRequest?) {
//        showNewUserGuideView()
//        print("[top movie] pop ready \(request)， self:\(self.toastLayerRequest)")
//        print("[top movie] pop ready \(Date.timeIntervalSinceReferenceDate)")
////        MessageBox.sharedInstance()?.showMessage("[top movie] pop ready")
//    }
//    
//    func onForceRemoved(_ request: PCLayerRequest?) {
//        print("[top movie] pop remove \(request)， self:\(self.toastLayerRequest)")
//        print("[top movie] pop remove \(Date.timeIntervalSinceReferenceDate)")
////        MessageBox.sharedInstance()?.showMessage("[top movie] pop remove")
//
//        if request == self.toastLayerRequest {
//            self.requestFlag = false
//            tryDismissNewUserGuideView(true)
//            if toastLayerRequest?.layer != nil {
//                toastLayerRequest?.layer.removeFromSuperview()
//                toastLayerRequest?.layer = nil
//            }
//        }
//    }
//}
//
/////Lottie动画、引导弹跳动画
//extension ComponentTopMovieView {
//    func progressTitleAnimation(_ maxScale:CGFloat, container:UIScrollView) {
//        print("[top movie] titleAnimationView Pre maxScale:\(maxScale), start:\(animationStartScale), end:\(animationEndScale),  contentOffsetY:\(container.contentOffset.y)")
////        titleAnimationView.isHidden = true
//        //max是从大到小的过程，start在上，end在下，所以start>maxScale>end
//        if maxScale <= animationStartScale && maxScale >= animationEndScale {
//            let totalScale = fabs(animationStartScale - animationEndScale)
//            let subScale = fabs(maxScale - animationStartScale)
//            if totalScale > 0 {
//                let realAniScale = subScale / totalScale
//                titleAnimationView.frame = CGRect.init(x: 0, y: 0, width: 135.0, height: 39)
//                titleAnimationView.bottom = self.titleLabel.top
//                titleAnimationView.centerX = self.backgroundView.width / 2.0
//                titleAnimationView.isHidden = false
//                titleAnimationView.alpha = 1.0
//                titleLabel.alpha = 0.7
//                titleAnimationView.animationProgress = realAniScale
//                print("[top movie] titleAnimationView Playing progress:\(realAniScale), maxScale:\(maxScale), contentOffsetY:\(container.contentOffset.y)")
//            }
//        } else if maxScale > animationStartScale {
//            titleAnimationView.isHidden = false
//            let viewWidth = 135.0
//            let viewHeight = 39.0
////            titleAnimationView.frame = CGRect.init(x: 0, y: 0, width: viewWidth, height: viewHeight)
////            titleAnimationView.bottom = self.titleLabel.top
////            titleAnimationView.centerX = self.backgroundView.width / 2.0
//            let totalScale = fabs(1 - animationStartScale)
//            var subScale = fabs(maxScale - animationStartScale)
//            if totalScale > 0 {
//                var realScale = subScale / totalScale
//                realScale = min(1.0, realScale)
//                realScale = 1.0 - realScale
//                titleAnimationView.alpha = realScale
//                titleLabel.alpha = realScale * 0.7
//
//                titleAnimationView.frame = CGRect.init(x: 0, y: 0, width: viewWidth * realScale, height: viewHeight * realScale)
//                titleAnimationView.bottom = self.titleLabel.top
//                titleAnimationView.centerX = self.backgroundView.width / 2.0
//                titleAnimationView.animationProgress = 0.0
//                print("[top movie] titleAnimationView alpha:\(realScale)")
//            }
//        } else  if maxScale < animationEndScale {
//            titleAnimationView.frame = CGRect.init(x: 0, y: 0, width: 135.0, height: 39)
//            titleAnimationView.bottom = self.titleLabel.top
//            titleAnimationView.centerX = self.backgroundView.width / 2.0
//            titleAnimationView.isHidden = false
//            titleAnimationView.alpha = 1.0
//            titleLabel.alpha = 0.7
//            titleAnimationView.animationProgress = 1.0
//            
//            print("[top movie] titleAnimationView End maxScale:\(maxScale), contentOffsetY:\(container.contentOffset.y)")
//        }
//    }
//    
//    func loadAnimationJson() {
//        let json = YKHomeZipUtil.loadJsonZip("topmovie-title-animation")
//    }
//    
//    func startShakerAnimation() {
//        removeShakerAnimation()
//        print("[top movie] removeShakerAnimation startShakerAnimation")
//
//        guard let container = container else {return}
//        if guidePositionAnimation == nil {
//            guidePositionAnimation = CAKeyframeAnimation.init(keyPath: "position")
//            guidePositionAnimation?.delegate = self
//        }
//        guard let guidePositionAnimation = guidePositionAnimation else { return  }
//        let height = 19.0
////        let currentTX = self.transform.ty
//        let currentPosition = container.layer.position
//        var targetPosition = currentPosition
//        targetPosition.y = targetPosition.y - height
//        guidePositionAnimation.duration = 2.7
////        animation.values = [currentTX, currentTX - height, currentTX]
//        guidePositionAnimation.values = [currentPosition, targetPosition, currentPosition
//                                         , targetPosition, currentPosition
//                                         , targetPosition, currentPosition]
//        guidePositionAnimation.keyTimes = [0, 0.166, 0.333,
//                                           0.5, 0.666,
//                                           0.833, 1.0]
//        guidePositionAnimation.timingFunctions = [CAMediaTimingFunction.init(name: .easeInEaseOut), CAMediaTimingFunction.init(name: .easeInEaseOut),
//                                     CAMediaTimingFunction.init(name: .easeInEaseOut), CAMediaTimingFunction.init(name: .easeInEaseOut),
//                                     CAMediaTimingFunction.init(name: .easeInEaseOut), CAMediaTimingFunction.init(name: .easeInEaseOut)]
//        guidePositionAnimation.repeatCount = 1
//        container.layer.add(guidePositionAnimation, forKey: "kTopMovieGuideShakerAnimationKey")
////        MessageBox.sharedInstance()?.showMessage("-----startAni")
//    }
//    
//    func removeShakerAnimation() {
//        print("[top movie] removeShakerAnimation end")
////        MessageBox.sharedInstance()?.showMessage("removeAni")
//        container?.layer.removeAnimation(forKey: "kTopMovieGuideShakerAnimationKey")
//        guidePositionAnimation = nil
//    }
//}
//
