////
////  ComponentTopMovie.swift
////  YKChannelComponent
////
////  Created by better on 2023/3/8.
////  Copyright © 2023 Youku. All rights reserved.
////
//
//import UIKit
//import OneArch
//import YoukuResource
//import OneArchSupport4Youku
//import YKResponsiveLayout
//import SwiftUI
//import YKSCService
//import YKHome
//import YKChannelPage
//
//class ComponentTopMovie: NSObject, ComponentDelegate,ComponentLifeCycleDelegate {
//    weak var itemView:ComponentTopMovieView?
//    
//    func enterDisplayArea(itemView: UIView?) {
//        
//    }
//    
//    func exitDisplayArea(itemView: UIView?) {
//        
//    }
//    
//    func willDeactivate() {
////        print("[top movie] willDeactivate dismiss:\(self.itemView)")
////        self.itemView?.dimissNewUserGuideView(false)
//    }
//    
//    func didActivate() {
//        
//    }
//    
//    func didDeactivate() {
//        
//    }
//    
//   
//    var componentWrapper: ComponentWrapper?
//    weak var handler:CardGeneraHeaderHandler?
//    var titleWidth : CGFloat = 0.0
//    lazy var lifeCycleEventHandler:ComponentLifeCycleEventHandler = {
//        let handler = ComponentLifeCycleEventHandler()
//        handler.delegate = self
//        return handler
//    }()
//    
//    func componentDidInit() {
//    }
//    
//    func layoutType() -> ComponentLayoutType {
//        return .custom
//    }
//    
//    func layoutConfig() -> ComponentLayoutConfig {
//        var config = ComponentLayoutConfig()
//        config.padding = .zero
//        return config
//    }
//    
//    func columnCount() -> CGFloat {
//        return 1
//    }
//    
//    func loadEventHandlers() -> [ComponentEventHandler]? {
//        return [self.lifeCycleEventHandler]
//    }
//
//    /// item高度
//    func itemHeight(itemWidth: CGFloat) -> CGFloat {
//        return 90.0
//    }
//    
//    /// 初始化item view
//    func createView(_ itemSize: CGSize) -> UIView {
//        let frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
//        let view = ComponentTopMovieView.init(frame: frame)
//        return view
//    }
//
//    /// 复用
//    func reuseView(itemView: UIView) {
//        guard let topMovieView = itemView as? ComponentTopMovieView else {
//            return
//        }
//        guard let container = self.component?.pageContext?.getContainerView() as? UICollectionView else {
//            return
//        }
//        
//        if let dataState = self.component?.getPage()?.pageModel?.dataState, dataState != .network {
//            return
//        }
//        self.itemView = topMovieView
//        
//        print("[top movie] reuseView:\(self.itemView)")
//
//        let lunboY = getSelectionPageLunboY(self.component?.getPage())
//        topMovieView.lunboOffsetY = lunboY - container.contentInset.top
//        topMovieView.component = self.component
//
//        topMovieView.backgroundColor = .clear
//        topMovieView.superview?.clipsToBounds = false
//        
//        topMovieView.reuse()
//        
//        let cardModel = component?.getCard()?.cardModel as? Card15034Model
//        topMovieView.fillData(cardModel)
//    }
//
//}
//
