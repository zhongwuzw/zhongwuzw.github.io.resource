//
//  ComponentTopMovieGuideView.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/3/20.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class ComponentTopMovieGuideView: UIView {

    weak var cardModel:Card15034Model?

    lazy var guideImageView: UIImageGIFView = {
        let guideImageView = UIImageGIFView()
        guideImageView.contentMode = .scaleAspectFill
        guideImageView.clipsToBounds = false
        return guideImageView
    }()

    lazy var guideTitleImageView: UIImageGIFView = {
        let guideImageView = UIImageGIFView()
        guideImageView.contentMode = .scaleAspectFill
        guideImageView.clipsToBounds = false
        guideImageView.loopCount = 1
        guideImageView.backgroundColor = .clear
        return guideImageView
    }()

    lazy var subtitleLabel: UILabel = {
        let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 200, height: 17))
        label.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.posteritem_subhead().pointSize)
        label.textColor = .white.withAlphaComponent(0.5)
        label.textAlignment = .center
        label.isUserInteractionEnabled = true
        return label
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.clipsToBounds = true
        self.addSubview(self.guideImageView)
//        guideImageView.addSubview(self.guideTitleImageView)
        addSubview(self.subtitleLabel)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
    }

    override var frame: CGRect {
        didSet {
            self.layoutCustomViews()
        }
    }

    func layoutCustomViews() {
        guideImageView.frame = self.bounds

        guideTitleImageView.frame = guideTitleImageViewFrame()
        let imageH = max(1, guideImageViewFrame().height)
        let scaleH = 20.0 / imageH
        guideTitleImageView.top = 20
        guideTitleImageView.centerX = self.guideImageView.width / 2.0

        subtitleLabel.frame = CGRect.init(x: 0, y: 0, width: self.width - 30, height: 21)
//        subtitleLabel.top = guideTitleImageView.centerY + 10
        subtitleLabel.bottom = self.height - 27.0
        subtitleLabel.centerX = self.width / 2.0
    }

    func fillData(_ cardModel:Card15034Model?) {
        self.cardModel = cardModel
        guideImageView.frame = guideImageViewFrame()
        let imgUrl = cardModel?.guideImg
        guideImageView.ykn_setImage(withURLString:imgUrl,
                               module: "",
                               imageSize: .zero,
                               parameters: [String: Any](),
                               completed: nil)

        if let subtitle = cardModel?.pullTitle {
            subtitleLabel.text = subtitle + "\u{e707}"
        }

        self.layoutCustomViews()
    }

    func loadTitleImage() {
        guideTitleImageView.frame = guideTitleImageViewFrame()
        if let titleImgUrl = cardModel?.guideTxImg, let url = URL.init(string: titleImgUrl) {

            guideTitleImageView.sd_setImage(with: url) { (image: UIImage?, error: Error?, type: SDImageCacheType, url: URL?) in
            }
        }
        layoutCustomViews()
    }


    func guideImageViewFrame() -> CGRect {
        let w = self.frame.size.width
//        let h = 147.0
        let h = 223.0

        return CGRect.init(x: 0, y: 0, width: w, height: h)
    }

    func guideTitleImageViewFrame() -> CGRect {
        let h = 127.0
        let w = 205.0
        return CGRect.init(x: 0, y: 0, width: w, height: h)
    }
}
