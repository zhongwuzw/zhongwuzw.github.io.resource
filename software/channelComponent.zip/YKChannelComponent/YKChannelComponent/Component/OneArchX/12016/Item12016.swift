//
//  Item12016.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/7/27.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch

class Item12016: BaseDFItemDelegate {

    override func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item12016Model.self as? T.Type
    }

}
