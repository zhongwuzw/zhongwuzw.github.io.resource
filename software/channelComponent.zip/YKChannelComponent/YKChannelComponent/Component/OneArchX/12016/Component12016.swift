//
//  Component12016.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/7/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku

class Component12016: BaseDFComponentDelegate {
    
    var itemHeight4ReuseId: CGFloat = 0
    
    override func itemHeight(itemWidth: CGFloat) -> CGFloat {
        guard let item = usedItem(),
              let itemModel = item.model as? Item12016Model,
              let componentModel = component?.model as? BaseComponentModel
        else {
            return 0
        }
        
        let aspectRatio: CGFloat = itemModel.imgRatio ?? (componentModel.imgRatio ?? 3.0 / 4.0)
        var itemHeight = ceil(itemWidth / aspectRatio)

        if itemModel.reasonStyle == 1 {
            itemHeight += 97
        } else {
            itemHeight += 82
        }
        
        itemHeight4ReuseId = itemHeight
        estimatedLayout(itemWidth)
        return itemHeight
    }
    
    func reuseId() -> String? {
        return "Component12016_reuseId_\(itemHeight4ReuseId)"
    }
    
    override func createView(_ itemSize: CGSize) -> UIView {
        return Item12016ContentView.init(frame: CGRect.init(origin: .zero, size: itemSize))
    }
    
    
    func estimatedLayout(_ itemWidth: CGFloat) {
        guard let item = usedItem(),
              let itemModel = item.model as? Item12016Model
        else {
            return
        }
        
        if let reason = itemModel.reasons?.first,
           let reasonText = reason.title {
            
            let limitWidth: CGFloat = max(0, itemWidth - 18 - 12)
            let limitHeight: CGFloat = 18
            let limitSize = CGSize.init(width: limitWidth, height: limitHeight)
            
            if itemModel.layout.extendExtra == nil {
                itemModel.layout.extendExtra = [String: Any]()
            }
            
            if itemModel.reasonStyle == 0 {
                let textFitSize = calcStringSize(reasonText, font: UIFont.systemFont(ofSize: 10), size: limitSize)
                let size = CGSize.init(width: textFitSize.width + 4, height: 16)
                let layout = TextLayoutModel.init()
                layout.renderRect = CGRect.init(origin: .zero, size: size)
                
                itemModel.layout.extendExtra?["reason"] = layout
            }
            
            if itemModel.reasonStyle == 1 {
                let textFitSize = calcStringSize(reasonText, font: UIFont.systemFont(ofSize: 12), size: limitSize)
                let layout = TextLayoutModel.init()
                layout.renderRect = CGRect.init(origin: .zero, size: textFitSize)
                
                itemModel.layout.extendExtra?["reason"] = layout
            }
        }
        
    }
    
}
