//
//  Item12016ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/7/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

class Item12016ContentView: BaseDFItemContentView {
    
    //MARK: Property
    lazy var videoImageView: BaseVideoImageView = {
        let view = BaseVideoImageView(frame: .zero)
        view.clipsToBounds = true
        view.layer.cornerRadius = 0
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle_weight(.medium)
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_tertiaryInfo
        view.font = UIFont.systemFont(ofSize: 12)
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var reasonLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_tertiaryInfo
        view.layer.borderWidth = 0.5
        view.layer.borderColor = UIColor.ykn_tertiaryInfo.cgColor
        view.layer.cornerRadius = 4
        view.layer.masksToBounds = true
        view.font = UIFont.systemFont(ofSize: 10)
        view.numberOfLines = 1
        view.textAlignment = .center
        return view
    }()
    
    lazy var separationLine: UIView = {
        let view = UIView.init()
        view.backgroundColor = UIColor.ykn_elevatedSecondaryBackground
        return view
    }()
    
    lazy var reasonLabelStyle1: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_tertiaryInfo
        view.font = UIFont.systemFont(ofSize: 12)
        view.numberOfLines = 1
        return view
    }()
    
    lazy var reasonArrowLabel: UILabel = {
        let view = UILabel.init(frame: CGRect.init(origin: .zero, size: CGSize.init(width: 12, height: 12)))
        view.text = "\u{e60f}"
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNIconFont.sharedInstance().font(withSize: 12)
        view.numberOfLines = 1
        return view
    }()
    
    lazy var reasonActionView: UIView = {
        let view = UIView.init()
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(videoImageView)
        self.addSubview(titleLabel)
        self.addSubview(subtitleLabel)
        self.addSubview(separationLine)
        self.addSubview(reasonLabel)
        self.addSubview(reasonLabelStyle1)
        self.addSubview(reasonArrowLabel)
        self.addSubview(reasonActionView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func fillData(_ item: IItem?) {
        super.fillData(item)
        guard let item = item, let itemModel = item.model as? Item12016Model,
              let compModel = item.getComponent()?.model as? HomeComponentModel else {
            return
        }
        
        let ratio = itemModel.imgRatio ?? (compModel.imgRatio ?? 3 / 4.0)
        // image
        self.videoImageView.size = CGSize.init(width: self.width, height: self.width / ratio)
        self.videoImageView.fillData(item: item)

        //title
        self.titleLabel.text = itemModel.title
        
        //subtitle
        if itemModel.subtitleAttributedString == nil {
            if let categoryText = itemModel.categoryText,
               let categoryTextColor = itemModel.categoryTextColor,
               let subtitle = itemModel.subtitle {
                
                let font: UIFont = UIFont.systemFont(ofSize: 12)
                let allText = "\(categoryText)·\(subtitle)"
                let attrString = NSMutableAttributedString.init(string: allText)
                let part1Range = NSRange.init(allText.range(of: categoryText)!, in: allText)
                let part2Range = NSRange.init(allText.range(of: "·\(subtitle)")!, in: allText)
                let subtitleTextColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: itemModel.scene?.sceneCardFooterTitleColor()) ?? UIColor.black
                
                attrString.addAttributes([.foregroundColor: categoryTextColor,
                                          .font: font
                                         ],
                                         range: part1Range)

                attrString.addAttributes([.foregroundColor: subtitleTextColor,
                                          .font: font
                                         ],
                                         range: part2Range)
                
                itemModel.subtitleAttributedString = attrString
            }
        }
        
        if let subtitleAttributedString = itemModel.subtitleAttributedString {
            self.subtitleLabel.attributedText = subtitleAttributedString
        } else {
            self.subtitleLabel.text = itemModel.subtitle
        }
        
        if let reason = itemModel.reasons?.first {
            if itemModel.reasonStyle == 1 {
                self.reasonLabelStyle1.text = reason.title
                
                Service.action.bind(reason.action, reasonActionView, .Defalut)
            } else {
                self.reasonLabel.text = reason.title
            }
        }
           
        
        relayoutSubViews(itemModel)
        
        //氛围
        updateScene(itemModel)
        
        //绑定事件
        Service.action.bind(itemModel.action, self)
        
        //负反馈
        Service.feedback.attach(itemModel.feedbackModel, toView: self, morePos: .BottomRightBorder, isSupportUndo: false) {
            item.getComponent()?.getItemManager()?.removeItem(item: item, animated: true)
        }
        
        // 预览视频
        if let playerModel = itemModel.playerModel {
            Service.player.attach(playerModel, toView: self, displayFrame: videoImageView.bounds)
        }
    }
    
    func updateScene(_ itemModel: BaseDFItemModel) {
        let scene = itemModel.scene
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: scene?.sceneTitleColor())
        self.separationLine.backgroundColor = sceneUtil(.ykn_elevatedSecondaryBackground, sceneColor: scene?.sceneSeparatorColor())
        self.reasonLabel.textColor =  sceneUtil(.ykn_tertiaryInfo, sceneColor: scene?.sceneCardFooterTitleColor())
        self.reasonLabel.layer.borderColor =  sceneUtil(.ykn_tertiaryInfo, sceneColor: scene?.sceneCardFooterTitleColor())?.cgColor
        self.reasonLabelStyle1.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: scene?.sceneCardFooterTitleColor())
        self.reasonArrowLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: scene?.sceneCardFooterTitleColor())
    }
    
    func relayoutSubViews(_ itemModel: Item12016Model) {
        let titleLabelX: CGFloat = YKNGap.dim_6()
        let titleLabelY: CGFloat = self.videoImageView.bottom + YKNGap.dim_5()
        let titleLabelWidth: CGFloat = max(0, self.bounds.size.width - YKNGap.dim_6() * 2)
        let titleLabelHeight = self.titleLabel.font.lineHeight
        self.titleLabel.frame = CGRect.init(x: titleLabelX, y: titleLabelY, width: titleLabelWidth, height: titleLabelHeight)
        
        
        let subtitleLabelX: CGFloat = titleLabelX
        let subtitleLabelY: CGFloat = self.titleLabel.bottom
        let subtitleLabelWidth: CGFloat = titleLabelWidth
        let subtitleLabelHeight: CGFloat = 17
        self.subtitleLabel.frame = CGRect.init(x: subtitleLabelX, y: subtitleLabelY, width: subtitleLabelWidth, height: subtitleLabelHeight)
        
        self.separationLine.isHidden = true
        self.reasonLabel.isHidden = true
        self.reasonLabelStyle1.isHidden = true
        self.reasonArrowLabel.isHidden = true
        self.reasonActionView.isHidden = true
        
        if let reason = itemModel.reasons?.first {
            if itemModel.reasonStyle == 0 {
                self.reasonLabel.isHidden = false
                
                let layout = itemModel.layout.extendExtra?["reason"] as? TextLayoutModel
                let size = layout?.renderRect.size ?? CGSize.zero
                let x: CGFloat = titleLabelX
                let y: CGFloat = bounds.size.height - 12 - size.height
                self.reasonLabel.frame = CGRect.init(origin: CGPoint.init(x: x, y: y), size: size)
            } else {
                self.separationLine.isHidden = false
                self.reasonLabelStyle1.isHidden = false
                self.reasonArrowLabel.isHidden = false
                self.reasonActionView.isHidden = false
                
                repeat {
                    let size = CGSize.init(width: titleLabelWidth, height: 1)
                    let x: CGFloat = titleLabelX
                    let y: CGFloat = subtitleLabel.frame.maxY + 16
                    self.separationLine.frame = CGRect.init(origin: CGPoint.init(x: x, y: y), size: size)
                } while (false)
                
                repeat {
                    let layout = itemModel.layout.extendExtra?["reason"] as? TextLayoutModel
                    let size = layout?.renderRect.size ?? CGSize.zero
                    let x: CGFloat = titleLabelX
                    let y: CGFloat = bounds.size.height - 12 - size.height
                    self.reasonLabelStyle1.frame = CGRect.init(origin: CGPoint.init(x: x, y: y), size: size)
                    
                } while (false)
                
                repeat {
                    let size = self.reasonArrowLabel.bounds.size
                    let x: CGFloat = self.reasonLabelStyle1.frame.maxX
                    let y: CGFloat = self.reasonLabelStyle1.frame.minY + (self.reasonLabelStyle1.frame.height - size.height) / 2
                    self.reasonArrowLabel.frame = CGRect.init(origin: CGPoint.init(x: x, y: y), size: size)
                    
                } while (false)
                
                
                self.reasonActionView.frame = self.reasonLabelStyle1.frame.insetBy(dx: -10, dy: -10)
            }
        }
    }
}

