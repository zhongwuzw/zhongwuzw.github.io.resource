//
//  Item12016Model.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/7/27.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku

class Item12016Model: BaseDFItemModel {
    
    var categoryText: String?
    var categoryTextColor: UIColor?
    
    var subtitleAttributedString: NSAttributedString?
    
    var reasonStyle: Int = 0

    override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        guard let dataInfo = cmsInfo?["data"] as? [String: Any] else {
            return
        }
        
        if let category = dataInfo["category"] as? [String: Any],
           let text = category["text"] as? String,
           let colorString = category["color"] as? String {
            
            var color = UIColor.createColorWithHexRGB(colorStr: colorString)
            if color == .clear {
                color = .black
            }
            
            categoryText = text
            categoryTextColor = color
        }
        
        if let reason = reasons?.first {
            if reason.action != nil {
                reasonStyle = 1
            }
        }
    }
    
}
