//
//  BaseComponentDelegate.swift
//  YKChannelComponent
//
//  Created by CC on 2021/11/9.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import Foundation
import OneArch
import OneArchSupport4Youku

public class BaseComponentDelegate:NSObject, ComponentDelegate {
    
    public var componentWrapper: ComponentWrapper?
    
    public func componentDidInit() {
        
    }
    
    public func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseComponentModel.self as? T.Type
    }

    public func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    public func columnCount() -> CGFloat {
        return 1
    }
    
    public func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
    
    public func reuseId() -> String? {
        return nil
    }
    
}
