//
//  ComponentHoriScrollLayoutBaseDelegate.swift
//  YKChannelComponent
//
//  Created by better on 2022/2/9.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout

class ComponentHoriScrollLayoutBaseDelegate: NSObject, ComponentDelegate {

    var componentWrapper: ComponentWrapper?
    
    func componentDidInit() {
        
    }
    
    func layoutType() -> ComponentLayoutType {
        return .horizontalScroll
    }
    
    func columnCount() -> CGFloat {
        return 3
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
        
    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        if let collectionView = itemView.subviews.first as? UICollectionView {
            collectionView.contentOffset = CGPoint.init(x: 0, y: 0)
        }
    }
}
