//
//  BaseVideoImageView.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/2.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import SDWebImage
import YKSCBase
import Lottie
import YKUIComponent
import OneArchSupport
import OneArchSupport4Youku

class BaseVideoImageView: UIImageGIFView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.contentMode = .scaleAspectFill
        self.clipsToBounds = true
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(item:IItem?) {
        guard let item = item, let itemModel = item.model as? BaseItemModel else {
            return
        }
        //封面图
        let icon = itemModel.gifImg ?? itemModel.img
        self.ykn_setImage(withURLString: XCDNSTRING(icon), module: nil, imageSize: .zero, parameters: nil, completed: nil)
        if icon?.count == 0 {
            self.backgroundColor = .ykn_primaryFill
        }

        //水印
        Service.waterMark.attach(itemModel.waterMark, toView: self)

        //角标
        Service.mark.attach(itemModel.mark, toView: self, layout: item.layout?.mark)
        
        //下方各角标
        attachBottomCorners(item: item)
    }
    
    func attachBottomCorners(item: IItem?) {
        guard let item = item, let itemModel = item.model as? BaseItemModel else {
            return
        }
        
        //右下角
        Service.summary.attach(itemModel.summary, toView: self, layout: item.layout?.summary)

        //排行角标 及 左下角
        let rankIndex = itemModel.rankInvolved ? (item.index + 1) : 0
        if rankIndex <= 0 {
            Service.lbTexts.attach(itemModel.lbTexts, toView: self, layouts: item.layout?.lbTexts)
            
            // 适配评分氛围(会员频道等场景)
            if let sceneColor = itemModel.scene?.sceneScoreColor(),
               itemModel.summary?.textType == .score,
               let label = self.viewWithTag(19000010) as? UILabel
            {
                label.textColor = sceneColor
            }
        } else {
            Service.lbTexts.detach(fromView: self)
        }
        
        Service.rank.attach(rankIndex, toView: self)
    }
    
    func detachBottomCorners(item: IItem?) {
        Service.summary.detach(fromView: self)
        Service.lbTexts.detach(fromView: self)
        Service.rank.detach(fromView: self)
    }

}
