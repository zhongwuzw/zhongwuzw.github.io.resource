//
//  BaseItemLifeCycleHandler.swift
//  YKChannelComponent
//
//  Created by better on 2022/9/22.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch

protocol BaseItemLifeCycleHandlerDelegate: NSObjectProtocol {
    func didActivate()
    func didDeactivate()
    func appDidBecomeActive()
    func appWillResignActive()
}

class BaseItemLifeCycleHandler: ItemEventHandler, IPageLifeCycleEventHandler {
    weak var delegate: BaseItemLifeCycleHandlerDelegate?
    
    //MARK: - IPageLifeCycleEventHandler
    public func viewDidLoad() {
        
    }
    
    public func willActivate() {
        
    }
    
    public func didActivate() {
        startSliding()
        self.delegate?.didActivate()
    }
    
    public func willDeactivate() {
    }
    
    public func didDeactivate() {
        stopSliding()
        self.delegate?.didDeactivate()
    }
    
    public func pageDealloc() {
        
    }
    
    public func appDidBecomeActive() {
        startSliding()
        self.delegate?.appDidBecomeActive()
    }
    
    public func appWillResignActive() {
        stopSliding()
        self.delegate?.appWillResignActive()
    }
    
    //MARK:- private
    
    func stopSliding() {
        guard let itemDelegate = self.item?.getItemDelegate() as? BaseItemDelegate else {
            return
        }
        itemDelegate.itemView?.stopBarrageAnimation()
    }
    
    func startSliding() {
        guard let itemDelegate = self.item?.getItemDelegate() as? BaseItemDelegate else {
            return
        }
        itemDelegate.itemView?.showBarrageWhenActive()
    }
}
