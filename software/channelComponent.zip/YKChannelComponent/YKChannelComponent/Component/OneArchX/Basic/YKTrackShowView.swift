//
//  YKTrackShowView.swift
//  YKChannelComponent
//
//  Created by wustlj on 2021/7/22.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import YKUIComponent

public class YKTrackShowView : UIView {
    
    public override var isAccessibilityElement: Bool {
        get {
            return true
        }
        set {
            
        }
    }
        
    public override var accessibilityLabel: String? {
        get {
            return YKHomeAccessbilityHelperView.accessibilityLabel(with: self) + "，按钮"
        }
        set {
            
        }
    }

    private var isFavor: Bool = false
    
    public var selectTextColor: UIColor = .ykn_tertiaryInfo
    public var selectBgColor: UIColor = .ykn_seconarySeparator
    public var selectBorderWidth: CGFloat = 0.0
    public var selectBorderColor: UIColor = .clear

    public var unselectTextColor: UIColor = .ykn_brandInfo
    public var unselectBgColor: UIColor = .ykn_border
    public var unselectBorderWidth: CGFloat = 1.0
    public var unselectBorderColor: UIColor = .clear
    
    lazy var titleLabel: UILabel = {
        let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 20, height: 20))
        label.textAlignment = .center
        label.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.posteritem_subhead().pointSize)
        label.isUserInteractionEnabled = true
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        layer.masksToBounds = true
        layer.cornerRadius = frame.size.height / 2
        addSubview(titleLabel)
        
        update(isFavor)
        
        NotificationCenter.default.addObserver(self, selector: #selector(darkModeIsChanged), name: .YKNThemeDidChange, object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func update(_ state : Bool) {
        isFavor = state
        
        if isFavor {
            titleLabel.text = "在追"
            
            layer.borderWidth = selectBorderWidth
            layer.borderColor = selectBorderColor.cgColor
            backgroundColor = selectBgColor
            titleLabel.textColor = selectTextColor
            
        } else {
            titleLabel.text = "\u{0000e662}追"
            
            layer.borderWidth = unselectBorderWidth
            layer.borderColor = unselectBorderColor.cgColor
            backgroundColor = unselectBgColor
            titleLabel.textColor = unselectTextColor
        }
        
        setNeedsLayout()
    }
    
    public override func layoutSubviews() {
        titleLabel.frame = CGRect.init(x: 0, y: 0, width: self.width, height: self.height)
    }
    
    @objc func darkModeIsChanged() {
        //暗黑模式切换，重刷UI
        update(isFavor)
   }
}

public class YKTrackFollowView : YKTrackShowView {
    private var isFollow: Bool = false
    
    override func update(_ state : Bool) {
        isFollow = state
        
        if isFollow {
            titleLabel.text = "已关注"
            
            layer.borderWidth = selectBorderWidth
            layer.borderColor = selectBorderColor.cgColor
            backgroundColor = selectBgColor
            titleLabel.textColor = selectTextColor
        } else {
            titleLabel.text = "\u{e662}关注"
            
            layer.borderWidth = unselectBorderWidth
            layer.borderColor = unselectBorderColor.cgColor
            backgroundColor = unselectBgColor
            titleLabel.textColor = unselectTextColor
        }
        
        setNeedsLayout()
    }
}
