//
//  ReserveBorderButton.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/4/17.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import YKSCiPhoneService
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YKProtocolSDK
import YKHome

///描边按钮样式,只有样式 不处理逻辑
class ReserveBorderButton: ReserveButton {
    
    override init() {
        super.init()
        
        self.backgroundColor = .ykn_border
        self.clipsToBounds = true
        self.setTitleFont(YKNFont.posteritem_subhead())
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.clear.cgColor
        self.isUserInteractionEnabled = true
        
        
        weak var weakSelf = self
        self.whenTapped {
            weakSelf?.reserveBtnTap()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func refresh(reserveModel:ReserveModel?, scene:SceneModel?) {
        self.reserveModel = reserveModel
        self.scene = scene
        // image
        if let icon = reserveModel?.icon, let url = URL.init(string: icon) {
            self.imageView.sd_setImage(with: url, completed: {[weak self] img, error, type, url in
                self?.imageView.image = self?.imageView.image?.withRenderingMode(.alwaysTemplate)
                self?.imageView.tintColor = .ykn_brandInfo
            })
        }
        
        refreshButtonStatus()
    }
    
    override func refreshButtonFrame() {
        super.refreshButtonFrame()
    }
    
    override func refreshButtonStatus() {
        guard let reserveModel = reserveModel else {
            return
        }
        //icon默认隐藏
        self.imageView.isHidden = true
        let reserved = reserveModel.isReserve
        
        if !reserved {
       
            if let title = reserveModel.text {
                self.setTitle(title)
                if let icon = reserveModel.icon, let url = URL.init(string: icon) {
                    self.imageView.isHidden = false
                    self.imageView.tintColor = .ykn_brandInfo
                }
            } else {
                self.setTitle("预约")
            }
            self.setTitleColor(UIColor.ykn_brandInfo)
            if isDark() {
                self.backgroundColor = .ykn_seconarySeparator
                self.layer.borderWidth = 0
            } else {
                self.backgroundColor = .clear
                self.layer.borderWidth = 1
                self.layer.borderColor = UIColor.ykn_brandInfo.withAlphaComponent(0.3).cgColor
            }
        } else {
            let titleColor = sceneUtil(UIColor.ykn_tertiaryInfo, sceneColor: scene?.sceneButtonTextColor())
            self.setTitle("已预约")
            self.setTitleColor(titleColor)
            self.layer.borderColor = UIColor.clear.cgColor
            self.backgroundColor = sceneUtil(.ykn_seconarySeparator, sceneColor: scene?.sceneButtonSelectBgColor())
        }
        bindStatisticsService()
        refreshButtonFrame()
    }
    
    //逻辑移植自组件14022
    @objc func reserveBtnTap() {
        guard let reserveModel = reserveModel else {
            return
        }
        
        weak var weakSelf = self
        if reserveModel.isReserve == true {
            YKSCFollowManager.cancelReserve(reserveModel.json) { (isSuccess: Bool) in
                if isSuccess {
                    if let weakSelf = weakSelf {
                        reserveModel.isReserve = false
                        weakSelf.bindStatisticsService()
                        weakSelf.refreshButtonStatus()
                    }
                }
            }
        } else {
            YKSCFollowManager.reserve(reserveModel.json) { (isSuccess: Bool) in
                if isSuccess {
                    if let weakSelf = weakSelf {
                        reserveModel.isReserve = true
                        weakSelf.bindStatisticsService()
                        weakSelf.refreshButtonStatus()
                    }
                }
            }
        }
    }
    
//    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
//        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
//        refreshButtonStatus()
//    }
    
}
