////
////  ReasonLabelView.swift
////  YKChannelComponent
////
////  Created by tonggui on 2024/2/4.
////  Copyright © 2024 Youku. All rights reserved.
////
//
//import Foundation
//import UIKit
//import YoukuResource
//import OneArchSupport
//import OneArchSupport4Youku
//import YKResponsiveLayout
//
////标签类型
//public enum ReasonLabelType: String {
//    case reserve = "RESERVE" //预约
//    case heat = "HEAT"  //热度
//    case track = "TRACK" //百万加追
//    case prize = "PRIZE" //奖项
//}
//
//public class ReasonLabelView: UIView {
//    
//    
//    lazy var titleLabel: UILabel = {
//        let view = UILabel()
//        //view.textColor = UIColor.ykn_primaryInfo
//        view.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.module_headline_linktext().pointSize)
//        view.numberOfLines = 1
//        view.textAlignment = .center
//        view.contentMode = .center
//        return view
//    }()
//    
//    weak var label: LabelModel?
//    
//    init() {
//        super.init(frame: CGRect.zero)
//        self.layer.cornerRadius = 3.0
//        self.clipsToBounds = true
//        //self.backgroundColor = UIColor.ykn_elevatedPrimaryGroupedBackground
//        self.addSubview(titleLabel)
//    }
//    
//    required init?(coder: NSCoder) {
//        fatalError("init(coder:) has not been implemented")
//    }
//    
//    public func fillModel(_ label: LabelModel?) {
//        self.label = label
//        
//        guard let labelText = label?.text as? LabelTextModel else {
//            return
//        }
//        
//        guard let titile = labelText.title else {
//            return
//        }
//        
//        //只有两种类型有icon
//        if let iconType = label?.iconType {
//            if iconType == ReasonLabelType.reserve.rawValue {
//                titleLabel.text = "\u{e71e}" + titile
//            } else if iconType == ReasonLabelType.heat.rawValue {
//                titleLabel.text = "\u{e6c4}" + titile
//            } else if iconType == ReasonLabelType.prize.rawValue {
//                titleLabel.text = "\u{e721}" + titile
//            } else if iconType == ReasonLabelType.track.rawValue {
//                titleLabel.text = "\u{e722}" + titile
//            } else {
//                titleLabel.text = titile
//            }
//        } else {
//            titleLabel.text = titile
//        }
//        
//        if let colorLevel = labelText.colorLevel {
//            if colorLevel == 1 {
//                titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#ff4a50")
//                self.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#ff4a50").withAlphaComponent(0.08)
//            } else if colorLevel == 2 {
//                titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#f65200")
//                self.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#f65200").withAlphaComponent(0.08)
//            } else if colorLevel == 3 {
//                titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#fc9f00")
//                self.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#fc9f00").withAlphaComponent(0.08)
//            } else {
//                
//                titleLabel.textColor = UIColor.ykn_primaryInfo
//                self.backgroundColor = UIColor.ykn_elevatedPrimaryGroupedBackground
//            }
//        }
//        refreshFrame()
//        Service.action.bind(self.label?.action, self)
//    }
//    
//    public func fillModel(_ label: LabelModel?, _ extendParams: [String : Any]?) {
//        self.label = label
//
//        guard let labelText = label?.text as? LabelTextModel else {
//            return
//        }
//        
//        guard let titile = labelText.title else {
//            return
//        }
//        
//        if let iconType = label?.iconType {
//            if iconType == ReasonLabelType.reserve.rawValue {
//                titleLabel.text = "\u{e71e}" + titile
//            } else if iconType == ReasonLabelType.heat.rawValue {
//                titleLabel.text = "\u{e6c4}" + titile
//            } else if iconType == ReasonLabelType.prize.rawValue {
//                titleLabel.text = "\u{e721}" + titile
//            } else if iconType == ReasonLabelType.track.rawValue {
//                titleLabel.text = "\u{e722}" + titile
//            } else {
//                titleLabel.text = titile
//            }
//        } else {
//            titleLabel.text = titile
//        }
//        
//        if let colorLevel = labelText.colorLevel {
//            if colorLevel == 1 {
//                titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#ff4a50")
//                self.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#ff4a50").withAlphaComponent(0.08)
//            } else if colorLevel == 2 {
//                titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#f65200")
//                self.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#f65200").withAlphaComponent(0.08)
//            } else if colorLevel == 3 {
//                titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#fc9f00")
//                self.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#fc9f00").withAlphaComponent(0.08)
//            } else {
//                //拓展信息，现在只有背景色是否适配氛围
//                if let isLightBackground = extendParams?["isLightBackground"] as? Bool{
//                    if isLightBackground {
//                        titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
//                        self.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#777777")
//                    } else {
//                        titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#eaeaea")
//                        self.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#25252b")
//                    }
//                } else {
//                    titleLabel.textColor = UIColor.ykn_primaryInfo
//                    self.backgroundColor = UIColor.ykn_elevatedPrimaryGroupedBackground
//                }
//            }
//        }
//        refreshFrame()
//        Service.action.bind(self.label?.action, self)
//    }
//    
//    func refreshFrame() {
//        titleLabel.sizeToFit()
//        let viewHeight = ReasonLabelView.titleHeight()
//
//        let textHeight = YKNFont.height(with: YKNFont.module_headline_linktext(), lineNumber: 1)
//        titleLabel.frame = CGRect(x: 6.0, y: ceil((viewHeight - textHeight)/2) + 1, width: titleLabel.width, height: titleLabel.height)
//        let width = titleLabel.width + 12.0
//        self.frame = CGRect(x: 0, y: 0, width: width, height: viewHeight)
//    }
//    
//    class func titleHeight() -> CGFloat {
//        return 18.0
//    }
//}
//
//public class ReasonListView: UIView {
//    public var reasonList:[LabelModel]?
//    var labels = [UIView]()
//
//    public func fillData(_ reasonList:[LabelModel]?, maxWidth:CGFloat) {
//        self.reasonList = reasonList
//        guard let reasonList = reasonList else {
//            return
//        }
//        for label in labels {
//            label.removeFromSuperview()
//        }
//        labels.removeAll()
//        
//        for labelModel in reasonList {
//            let label = ReasonLabelView()
//            label.fillModel(labelModel)
//            if let title = label.titleLabel.text, !title.isEmpty{
//                labels.append(label)
//            }
//        }
//        refreshLabels(maxWidth)
//    }
//    
//    public func fillData(_ itemModel:BaseItemModel?, maxWidth:CGFloat) {
//        guard let itemModel = itemModel else {
//            return
//        }
//        
//        guard let reasonList = itemModel.reasonList, reasonList.count > 0 else {
//            return
//        }
//        
//        self.reasonList = reasonList
//        
//        let isLightBackground = itemModel.scene?.sceneNavIsLightBackground()
//        var params = [String: Any]()
//        params["isLightBackground"] = isLightBackground
//        
//        for label in labels {
//            label.removeFromSuperview()
//        }
//        labels.removeAll()
//        
//        for labelModel in reasonList {
//            let label = ReasonLabelView()
//            label.fillModel(labelModel, params)
//            if let title = label.titleLabel.text, !title.isEmpty{
//                labels.append(label)
//            }
//        }
//        refreshLabels(maxWidth)
//    }
//    
//    func refreshLabels(_ maxWidth:CGFloat) {
//        var distence = maxWidth
//        var gap: CGFloat = 0
//        let x: CGFloat = 0
//        let y: CGFloat = 0
//        let spacing = ReasonListView.reasonItemSpacing()
//        
//        var maxHeight:CGFloat = 0
//        for label in labels {
//            if distence > label.width + YKNGap.youku_column_spacing() {
//                self.addSubview(label)
//                label.frame = CGRect(x: x + gap, y: y, width: label.width, height: label.height)
//                maxHeight = max(maxHeight, label.height)
//                gap += label.width + spacing
//                distence -= label.width + spacing
//            }
//        }
//        if self.height < maxHeight {
//            self.height = maxHeight
//        }
//        self.width = maxWidth
//    }
//    class func reasonItemSpacing() -> CGFloat {
//        if ykrl_isResponsiveLayout() {
//            return 9.0
//        }
//        return 6.0
//    }
//    class func titleHeight() -> CGFloat {
//        return ReasonLabelView.titleHeight()
//    }
//}
