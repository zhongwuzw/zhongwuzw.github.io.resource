//
//  BaseReasonView.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/3.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import YKSCiPhoneService
import OneArchSupport
import OneArchSupport4Youku

class BaseReasonView: UIView {
    
    var useClientArrow: Bool = true
    var reasonModel: ReasonModel?
    let arrowSize:CGFloat = 12.0 * YKNSize.yk_icon_size_scale()

    lazy var iconImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_brandInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        return view
    }()
    
    lazy var arrowLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_brandInfo
        view.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.posteritem_subhead().pointSize)
        view.numberOfLines = 1
        view.text = "\u{e60f}"
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        clipsToBounds = true
        addSubview(iconImageView)
        addSubview(titleLabel)
        addSubview(arrowLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(_ model:BaseItemModel) {
        if model.config.getIntValue("useClientArrow") == 1 {
            useClientArrow = true
        } else {
            useClientArrow = false
        }
        
        if let reason = model.reason {
            self.isHidden = false
            
            reasonModel = reason
            
            //标题
            self.titleLabel.text = reason.title
            self.titleLabel.textColor = reason.titleColor
            
            //icon
            if let iconURLString = reason.icon, iconURLString.isEmpty == false {
                iconImageView.sd_setImage(with: URL.init(string: iconURLString))
                iconImageView.isHidden = false
            } else {
                iconImageView.image = nil
                iconImageView.isHidden = true
            }
            
            //跳转
            Service.action.bind(reason.action, self)
            if let _ = reason.action, useClientArrow {
                self.arrowLabel.isHidden = false
            } else {
                self.arrowLabel.isHidden = true
            }
            sizeToFit()
        } else {
            self.isHidden = true
        }
        
        reLayoutSubviews()
    }
    
    override func sizeToFit() {
        super.sizeToFit()

        let textSize = calcStringSize(titleLabel.text, font: titleLabel.font, size: .zero)
        var width = textSize.width + ((reasonModel?.icon?.isEmpty ?? true) ? 0 : 17)
        if let _ = reasonModel?.action, useClientArrow {
            let arrowWidth: CGFloat = arrowSize
            width += arrowWidth
        }
        self.frame = CGRect.init(x: self.origin.x, y: self.origin.y, width: width, height: self.height)
    }

    private func reLayoutSubviews() {
        var frame = titleLabel.frame
        if let icon = reasonModel?.icon, icon.isEmpty == false {
            iconImageView.frame = CGRect.init(x: 0, y: (self.frame.size.height - 14) / 2, width: 14, height: 14)
            frame.origin.x = 14 + 3;
        }
        
        let arrowSize = CGSize.init(width: arrowSize, height: self.frame.size.height)
        if let _ = reasonModel?.action, useClientArrow {
            frame.origin.y = 0
            frame.size.width = self.frame.size.width - frame.origin.x - 0 - arrowSize.width
            frame.size.height = self.frame.size.height
            
            titleLabel.frame = frame
            arrowLabel.frame = CGRect.init(x: titleLabel.right, y: 0, width: arrowSize.width, height: arrowSize.height)
        } else {
            frame.origin.y = 0
            frame.size.width = self.frame.size.width - frame.origin.x - 0
            frame.size.height = self.frame.size.height
            
            titleLabel.frame = frame
        }
    }
}
