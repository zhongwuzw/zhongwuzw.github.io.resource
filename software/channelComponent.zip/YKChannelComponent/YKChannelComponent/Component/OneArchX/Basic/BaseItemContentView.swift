//
//  BaseItemContentView.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/28.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import SDWebImage
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent
import YKChannelPage
import YKHome
import YKResponsiveLayout

class BaseItemContentView: AccessibilityView {

    //MARK: Property
    lazy var videoImageView: BaseVideoImageView = {
        return BaseVideoImageView(frame: .zero)
    }()
    
    lazy var titleLabel: MarginLabel = {
        let view = MarginLabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.verticalAlignment = .top
        view.numberOfLines = 2
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(videoImageView)
        self.addSubview(titleLabel)
        self.addSubview(subtitleLabel)
        
        NotificationCenter.default.addObserver(self, selector: #selector(receiveSplashViewRemovedNotification(_:)), name: Notification.Name(rawValue: "splashviewremoved"), object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self, name: Notification.Name(rawValue: "splashviewremoved"), object: nil)
    }
    
    weak var item:IItem?
    var animateCount = 0
    func fillData(item:IItem?, ratio:CGFloat) {
        
        self.item = item
    
        guard let itemModel = item?.model as? BaseItemModel,
              let compModel = item?.getComponent()?.model as? BaseComponentModel else {
            return
        }
        // image
        self.videoImageView.size = CGSize.init(width: self.width, height: ceil(self.width / ratio))
        self.videoImageView.fillData(item: item)

        //title
        self.titleLabel.frame = item?.layout?.title?.renderRect ?? CGRect.zero
        self.titleLabel.numberOfLines = compModel.enableNewLine ? 2 : 1
        if (compModel.enableNewLine) {
            self.titleLabel.text = nil
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 2.0
            paragraphStyle.lineBreakMode = .byTruncatingTail
            let attributedTitle = NSAttributedString.init(string: itemModel.title ?? "", attributes: [.paragraphStyle: paragraphStyle])
            self.titleLabel.attributedText = attributedTitle
        } else {
            self.titleLabel.attributedText = nil
            self.titleLabel.text = itemModel.title
        }

        //subtitle
        self.subtitleLabel.isHidden = compModel.enableNewLine
        if !compModel.enableNewLine {
            self.subtitleLabel.frame = item?.layout?.subtitle?.renderRect ?? .zero
            fillSubtitle(model: itemModel)
        }

        //推荐理由（单项，老旧能力，G桶在用）
        var useSingleReason = false
        if let reason = itemModel.reason,
           let reasonTitle = itemModel.reason?.title, reasonTitle.count > 0, compModel.enableNewLine == false {
            subtitleLabel.isHidden = true
            useSingleReason = true
            Service.reasons.attach([reason], toView: self, layouts: item?.layout?.reasons)
        }
        
        // 推荐理由（多项）, 单项适用时，多项停用
        if useSingleReason == false {
            Service.reasons.attach(itemModel.reasons, toView: self, layouts: item?.layout?.reasons)
        }

        //氛围
        let scene = itemModel.scene
        self.backgroundColor = .clear //sceneUtil(.clear, sceneColor: scene?.sceneBgColor())
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: scene?.sceneTitleColor())
        self.subtitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: scene?.sceneSubTitleColor())
        
        //绑定事件
        if itemModel.isJarisReplaceItem {
            videoImageView.isUserInteractionEnabled = false
            Service.action.bind(nil, self.videoImageView)
            Service.action.bind(itemModel.action, self, .OnlyClick)
        } else {
            if let cardModel = item?.getCard()?.cardModel,
               let reportRelyOnPicture = cardModel.config.getStringValue("reportRelyOnPictureExposure"),
               reportRelyOnPicture == "1" {
                videoImageView.isUserInteractionEnabled = true
                Service.action.bind(itemModel.action, self.videoImageView)
                Service.action.bind(itemModel.action, self, .OnlyClick)
            } else {
                videoImageView.isUserInteractionEnabled = false
                Service.action.bind(nil, self.videoImageView)
                Service.action.bind(itemModel.action, self)
            }
        }
        
        //feedback
        itemModel.feedbackModel?.supportUndoMask = true

        //barrage
        showBarrage()
    }
    
    private func isSplashViewRemoved() -> Bool {
        return YKHomeModeManager.sharedInstance()?.homeViewController.isSplashViewRemoved ?? false
    }
    
    public func showBarrage() {
        weak var weakself = self
        guard let itemModel = item?.model as? BaseItemModel else {
            return
        }
        Service.barrage.detach(fromView: self.videoImageView)
        if (itemModel.dynamicReasons != nil) {
            animateCount += 1
            DispatchQueue.main.asyncAfter(deadline:.now() + 2.0) {
                self.animateCount -= 1
                if self.animateCount == 0 {
                    weakself?.doShowBarrage()
                }
            }
        }
    }
    
    public func showBarrageWhenActive() {
        guard let itemModel = item?.model as? BaseItemModel else {
            return
        }
        self.videoImageView.attachBottomCorners(item: item)
        //barrage
        showBarrage()
    }
    
    public func stopBarrageAnimation() {
        guard let itemModel = item?.model as? BaseItemModel else {
            return
        }
        Service.barrage.detach(fromView: self.videoImageView)
        self.videoImageView.attachBottomCorners(item: item)
    }
    
    private func doShowBarrage() {
        
        guard let itemModel = item?.model as? BaseItemModel, let item = self.item else {
            return
        }

        Service.barrage.detach(fromView: self.videoImageView)
        
        let isSplashViewRemoved = isSplashViewRemoved()
        if !isSplashViewRemoved {
            return
        }

        if (itemModel.dynamicReasons != nil) {
            self.videoImageView.detachBottomCorners(item: item)
            
            weak var weakself = self
            Service.barrage.attach(itemModel.dynamicReasons, toView: self.videoImageView, sizes:itemModel.dynamicReasonsSizes, animateFinish: {
                self.videoImageView.attachBottomCorners(item: item)
                //循环播放
                weakself?.showBarrage()
            })
        }
    }
    
    @objc func receiveSplashViewRemovedNotification(_ notif: Notification?) {
        showBarrageWhenActive()
//        Service.barrage.detach(fromView: self.videoImageView)
//        guard let itemModel = item?.model as? BaseItemModel else {
//            return
//        }
//        if (itemModel.dynamicReasons != nil) {
//            Service.summary.detach(fromView: self.videoImageView)
//            Service.lbTexts.detach(fromView: self.videoImageView)
//            Service.barrage.attach(itemModel.dynamicReasons, toView: self.videoImageView, sizes:itemModel.dynamicReasonsSizes, animateFinish: { [self] in
//                //右下角
//                Service.summary.attach(itemModel.summary, toView: self.videoImageView, layout: self.item?.layout?.summary)
//                //左下角
//                Service.lbTexts.attach(itemModel.lbTexts, toView: self.videoImageView, layouts: self.item?.layout?.lbTexts)
//            })
//        }
    }

    private func fillSubtitle(model:BaseItemModel) {
        if let interactionLabelWidths = model.extraExtend["interactionLabel.widths"] as? [CGFloat],
           let interactionLabelTexts = model.extraExtend["interactionLabel.texts"] as? [String],
           let firstLabelWidth = interactionLabelWidths.first,
           0.1 ... width ~= firstLabelWidth {
            var text = ""
            for i in 0 ..< interactionLabelWidths.count {
                if interactionLabelWidths[i] > width {
                    break
                }
                text = interactionLabelTexts[i]
            }
            subtitleLabel.text = text
        } else {
            subtitleLabel.text = model.subtitle
        }
    }
    
    //MARK: - Animation Image
    func startAnimating() {
        if !videoImageView.isAnimating {
            videoImageView.startAnimating()
        }
    }
    
    func stopAnimating() {
        if videoImageView.isAnimating {
            videoImageView.stopAnimating()
        }
    }
}
