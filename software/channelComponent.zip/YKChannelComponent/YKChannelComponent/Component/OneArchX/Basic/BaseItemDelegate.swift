//
//  BaseItemDelegate.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/28.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class BaseItemDelegate: NSObject, ItemDelegate, BaseItemLifeCycleHandlerDelegate {

    var itemWrapper: ItemWrapper?
    
    weak var multiItemContentView: BaseMultiItemContentView?
    weak var itemView: BaseItemContentView?
    
    func itemDidInit() { //子线程
        // 使得标签支持图片样式
        if let reasons = item?.itemModel?.reasons {
            for (index, reason) in reasons.enumerated() {
                if let img = reason.img, img.isEmpty == false {
                    item?.itemModel?.reasons?[index].imgEnabled = true
                }
            }
        }
        
        if let reason = item?.itemModel?.reason {
            if let img = reason.img, img.isEmpty == false {
                item?.itemModel?.reason?.imgEnabled = true
            }
        }
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        guard let _ = self.item?.model as? BaseItemModel else {
            return 0.0
        }

        return preCaculateLayout(itemWidth, self.item)
    }
    
    func forceSingleColumn() -> Bool {
        return false
    }

    func getImageAspectRatio() -> CGFloat {
        guard let componentModel = self.item?.getComponent()?.model as? BaseComponentModel else {
            return 1.78
        }
        guard let aspectRatio = componentModel.extraExtend["aspectRatio"] as? Double else {
            return 1.78
        }
        return CGFloat(aspectRatio)
    }
    
    func videoImageSize(_ itemWidth: CGFloat) -> CGSize {
        var ratio = 1.78
        if let componentModel = self.item?.getComponent()?.model as? BaseComponentModel,
           let aspectRatio = componentModel.extraExtend["aspectRatio"] as? Double,
            aspectRatio > 0 {
            ratio = aspectRatio
        }
        return CGSize.init(width: itemWidth, height: ceil(itemWidth / ratio))
    }

    /// 坑位高度计算（供子类重写）
    func getItemHeight(itemWidth: CGFloat,videoImageHeight: CGFloat, textAreaHeight: CGFloat) -> CGFloat {
        return videoImageHeight + textAreaHeight
    }
    
    /// 文本区域高度（含spacing）
    func textAreaHeight(itemWidth: CGFloat) -> CGFloat {
        guard let component = self.item?.getComponent(),
              let item = self.item,
              let itemModel = item.model as? BaseItemModel,
              let compModel = component.model as? BaseComponentModel
        else {
            return 0
        }
        
        let model = itemModel
        var totalHeight: CGFloat = 0
        
        if (model.title?.count ?? 0) == 0 {
            return 0
        }
        
        let hasReasons: Bool = (model.reasons?.count ?? 0) > 0
        if hasReasons {
            //有推荐理由一律按2行标题（主副标题）+ 1行推荐理由布局，总体高度需要双对齐列卡片
            totalHeight = 30 + ceil(38.0 * YKNSize.yk_icon_size_scale())

        } else {
            let noSubtitle: Bool = model.subtitle?.count == 0
            let noReason: Bool = model.reason?.title?.count == 0
            let hasActionReason: Bool = model.reason?.action != nil
            let noInteractionLabels: Bool = model.extraExtend.yk_string("interactionLabel").isEmpty
            if compModel.enableNewLine {
                let titleSize = calcStringSize(model.title ?? "", font: YKNFont.posteritem_maintitle(), size: .zero)
                if titleSize.width < itemWidth {
                    totalHeight = textHeightOnyOneLineTitle()
                } else {
                    totalHeight = textHeightWithSubtitle()
                }
            } else if hasActionReason {
                totalHeight = textHeightWithActionReason()
            } else if noSubtitle && noReason && noInteractionLabels {
                totalHeight = textHeightOnyOneLineTitle()
            } else {
                totalHeight = textHeightWithSubtitle()
            }
        }
        return totalHeight
    }
    
    func textHeightOnyOneLineTitle() -> CGFloat {
        return YKNGap.youku_picture_title_spacing()
            + YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
            + YKNGap.youku_maintitle_subtitle_spacing()
    }
    
    func textHeightWithSubtitle() -> CGFloat {
        return YKNGap.youku_picture_title_spacing()
            + YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
            + YKNGap.youku_maintitle_subtitle_spacing()
            + YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)
    }
    
    func textHeightWithActionReason() -> CGFloat {
        var actionReasonHeight: CGFloat = 18 //预估值
        if let reason = item?.itemModel?.reason, reason.action != nil {
            actionReasonHeight = ReasonView.estimatedPartsSize(reason).size.height //准确值
        }
        
        return YKNGap.youku_picture_title_spacing()
            + YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
            + YKNGap.youku_maintitle_subtitle_spacing()
            + actionReasonHeight
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        if hasSubNodes() {
            let itemView = BaseMultiItemContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            return itemView
        } else {
            let itemView = BaseItemContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            return itemView
        }
    }
    
    func reuseView(itemView: UIView) {
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }

        if hasSubNodes() {
            guard let itemView = itemView as? BaseMultiItemContentView else {
                return
            }
            multiItemContentView = itemView
            
            itemView.component = self.item?.getComponent()
            itemView.fillData(self.item?.getSubItems(), ratio: getImageAspectRatio())
        } else {
            guard let itemView = itemView as? BaseItemContentView else {
                return
            }
            if let preDelegate = itemView.item?.getItemDelegate() as? BaseItemDelegate {
                preDelegate.itemView = nil
            }
            self.itemView = itemView
            UIView.performWithoutAnimation {
                itemView.fillData(item:self.item, ratio:getImageAspectRatio())
            }
        }
        
        if itemModel.isJarisReplaceItem, itemModel.animateWhenReuse {
            itemModel.animateWhenReuse = false
            DispatchQueue.main.async {
                itemView.alpha = 0.0
                UIView.animate(withDuration: 0.5, delay: 0) {
                    itemView.alpha = 1.0
                }
            }
            //手动发一次曝光
            if let report = itemModel.action?.report {
                YoukuAnalytics.sharedInstance()?.collectALiCustomEvent(withEventID: "2201",
                                                                       pageName: report.pageName,
                                                                       arg1: nil,
                                                                       arg2: nil,
                                                                       args:report.args)
            }
        }
    }
    
    func reuseId() -> String? {
        if let itemModel = self.item?.model as? BaseItemModel {
            if itemModel.isJarisReplaceItem {
                return "BaseItemDelegate.item.reuseid.jarvis"
            }
        }

        if hasSubNodes() {
            return "BaseItemDelegate.multiItem.reuseid"
        } else {
            return "BaseItemDelegate.item.reuseid"
        }
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        if hasSubNodes() {
            return [BaseMultiItemEventHandler.init()]
        }
        
        var handlers = [ItemEventHandler]()
        if !disableLongPress() {
            handlers.append(LongPressPreviewItemEventHandler())
        }
        let lifeHanlder = BaseItemLifeCycleHandler()
        lifeHanlder.delegate = self
        handlers.append(lifeHanlder)

        return handlers
    }
    
    func disableLongPress() -> Bool {
        return false
    }
    
    //MARK: - private
    
    func preCaculateLayout(_ itemWidth: CGFloat, _ item: IItem?) -> CGFloat {
        guard let tempItemModel = item?.itemModel else {
            return 0
        }
        
        // 封面图
        let imageSize = videoImageSize(itemWidth)
        let coverLayout = ImageLayoutModel.init()
        coverLayout.boundingSize = imageSize
        coverLayout.renderRect = CGRect(origin: .zero, size: imageSize)
        item?.layout?.cover = coverLayout
        
        //cache
        if let mark = tempItemModel.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: imageSize)
            item?.layout?.mark = layout
        }
        
        if let summary = tempItemModel.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize:imageSize)
            item?.layout?.summary = layout
        }
        
        if let lbTexts = tempItemModel.lbTexts {
            let layout = Service.lbTexts.estimatedLayout(lbTexts, toViewSize:imageSize)
            item?.layout?.lbTexts = layout
        }
        //主标题
        let titleLayout = TextLayoutModel.init()
        let titleY = imageSize.height + YKNGap.youku_picture_title_spacing()
        titleLayout.renderRect = CGRect.init(x: 0,
                                             y: titleY,
                                             width: imageSize.width,
                                             height: ceil(38.0 * YKNSize.yk_icon_size_scale()))
        item?.layout?.title = titleLayout
        
        let subtitleWidth:CGFloat = self.item?.itemModel?.feedbackModel != nil ? (imageSize.width - 15) : imageSize.width

        //副标题
        let subtitleLayout = TextLayoutModel.init()
        let subtitleY = imageSize.height
            + YKNGap.youku_picture_title_spacing()
            + YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
            + YKNGap.youku_maintitle_subtitle_spacing()
        subtitleLayout.renderRect = CGRect.init(x: 0,
                                                y: subtitleY,
                                                width: subtitleWidth,
                                                height: YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1))
        item?.layout?.subtitle = subtitleLayout
        
        //item height
        let textAreaH = Double(ceil(textAreaHeight(itemWidth:itemWidth)))
        let itemHeight = getItemHeight(itemWidth: itemWidth, videoImageHeight: imageSize.height, textAreaHeight: textAreaH)

        //推荐理由
        if let reasons = tempItemModel.reasons {
            let boundingSize = CGSize.init(width: CGFloat(subtitleWidth), height: CGFloat.greatestFiniteMagnitude)
            var layout = Service.reasons.estimatedLayout(reasons, boundingSize: boundingSize)
            let position = CGPoint.init(x: 0, y: itemHeight - Double(layout.first?.renderRect.size.height ?? 0))
            layout = Service.reasons.estimatedLayout(reasons, position: position, boundingSize: boundingSize)
            item?.layout?.reasons = layout
        } else if let reason = tempItemModel.reason { //单个推荐理由，布局预计算
            let boundingSize = CGSize.init(width: CGFloat(subtitleWidth), height: CGFloat.greatestFiniteMagnitude)
            var layout = Service.reasons.estimatedLayout([reason], boundingSize: boundingSize)
            let position = CGPoint.init(x: 0, y: itemHeight - Double(layout.first?.renderRect.size.height ?? 0))
            layout = Service.reasons.estimatedLayout([reason], position: position, boundingSize: boundingSize)
            item?.layout?.reasons = layout
        }
        
        // 子结点layout计算
        if let subItems =  item?.getSubItems(), subItems.count > 0 {
            for subItem in subItems {
                preCaculateLayout(itemWidth, subItem)
            }
        }
        
        return itemHeight
    }

    func hasSubNodes() -> Bool {
        if shouldHandleSubNodes() == true, let subItems = self.item?.getSubItems() , subItems.count > 0 {
            return true
        }
        return false
    }
    
    func shouldHandleSubNodes() -> Bool {
        let multiItemsSet = ["14001", "14002"]
        if let type = self.item?.itemModel?.type , multiItemsSet.contains(type) {
            return true
        }
        return false
    }
    
    func resumeSliding() {
//        print("fuzhong multiItemContentView startSliding")
        multiItemContentView?.startSliding()
    }
    
    func stopSliding() {
//        print("fuzhong multiItemContentView stopSliding")
        multiItemContentView?.stopSliding()
    }
    
    func viewDidLoad() {
        
    }
    
    func willActivate() {
        
    }
    
    func didActivate() {
        
    }
    
    func willDeactivate() {
        
    }
    
    func didDeactivate() {
        
    }
    
    func pageDealloc() {
        
    }
    
    func appDidBecomeActive() {
        
    }
    
    func appWillResignActive() {
        
    }
    
    func enterDisplayArea(itemView: UIView?) {
        
    }
    
    func exitDisplayArea(itemView: UIView?) {
        
    }
    
}
