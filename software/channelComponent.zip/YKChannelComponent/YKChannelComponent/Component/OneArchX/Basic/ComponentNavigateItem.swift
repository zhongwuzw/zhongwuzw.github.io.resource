//
//  ComponentNavigateItem.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class ComponentNavigateItem: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?

    func itemDidInit() {
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func itemWidth() -> CGFloat {
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return 0.0
        }
        guard let title = itemModel.title else {
            return 0.0
        }
        let size = calcStringSize(title, font: ComponentNavigateItem.titleFont(), size: .zero)
        let size2 = calcStringSize(title, font: ComponentNavigateItem.titleSelFont(), size: .zero)
        return max(size.width, size2.width) + 1
    }

    class func titleFont() -> UIFont {
        return YKNFont.component_tabbar_text()
    }
    
    class func titleSelFont() -> UIFont {
        return YKNFont.posteritem_maintitle_m_weight(.medium)
    }
    
    class func titleHeight() -> CGFloat {
        return YKNFont.height(with: titleFont(), lineNumber: 1) + 5
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return ComponentNavigateItem.titleHeight()
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = ComponentNavigateItemView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? ComponentNavigateItemView else {
            return
        }
        itemView.fillData(self.item)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }

}
