//
//  ReserveButton.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/3.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import YKSCiPhoneService
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout

public protocol ReserveButtonDelegate: NSObjectProtocol {
    //按钮frame出现变化 需要外部重新布局
    func didUpdateReserveButtonFrame()
}

///实心按钮样式
public class ReserveButton: UIView {
    
    weak var delegate: ReserveButtonDelegate?
    
    lazy var imageView: UIImageGIFView = {
        let view = UIImageGIFView(frame: .zero)
        
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_subhead_weight(.medium)
        view.numberOfLines = 1
        return view
    }()
    
    weak var reserveModel: ReserveModel?
    weak var scene: SceneModel?
    
    init() {
        super.init(frame: CGRect.init(x: 0, y: 0, width:ReserveButton.buttonWidth(), height: ReserveButton.buttonHeight()))
        self.layer.cornerRadius = self.height/2.0
        self.clipsToBounds = true
        self.addSubview(titleLabel)
        self.addSubview(imageView)
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddReserveSuccessNotication), name: NSNotification.Name.init("kAddReserveSuccessNotification"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelReserveSuccessNotication), name: NSNotification.Name.init("kCancelReserveSuccessNotification"), object: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public class func buttonWidth() -> CGFloat {
        let base: CGFloat = 60
        if ykrl_isResponsiveLayout() {
            return base * 1.1 // 20221129版本 目标值1.1倍，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        } else {
            return base * YKNSize.yk_icon_size_scale()
        }
    }
    
    public func buttonWidth(_ reserveModel:ReserveModel?) -> CGFloat {
        if let reserveModel = reserveModel {
            let textSize = calcStringSize(titleLabel.text, font: titleLabel.font, size: CGSize(width: 120, height: 30))
            var width = textSize.width + 12 * 2
            var imgSize = CGSize.zero
            if !imageView.isHidden && (imageView.image != nil) {
                imgSize = CGSize.init(width: 14, height: 14)
                width = width + 3.0 + imgSize.width
            }
            return width
        }
        return ReserveButton.buttonWidth()
    }
        
    public class func buttonHeight() -> CGFloat {
        let base: CGFloat = 30
        if ykrl_isResponsiveLayout() {
            return base * 1.1 // 20221129版本 目标值1.1倍，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        } else {
            return base * YKNSize.yk_icon_size_scale()
        }
    }
    
    public func setTitle(_ title:String?) {
        self.titleLabel.text = title
    }
    
    public func setTitleColor(_ titleColor:UIColor?) {
        self.titleLabel.textColor = titleColor
    }
    
    public func setTitleFont(_ font:UIFont?) {
        self.titleLabel.font = font
    }
    
    func refresh(reserveModel:ReserveModel?, scene:SceneModel?) {
        self.reserveModel = reserveModel
        self.scene = scene
        // image
        if let icon = reserveModel?.icon, let url = URL.init(string: icon) {
            self.imageView.sd_setImage(with: url, completed: {[weak self] img, error, type, url in
                self?.imageView.image = self?.imageView.image?.withRenderingMode(.alwaysTemplate)
                self?.imageView.tintColor = .ykn_brandInfo
            })
        }
        
        refreshButtonStatus()
        weak var weakself = self
        self.whenTapped {
            UtilityHelper.doReservation(reserveModel: weakself?.reserveModel)
        }
    }
    
    func refreshButtonFrame() {
        let imgW = 14.0
        let textSize = calcStringSize(titleLabel.text, font: titleLabel.font, size: CGSize(width: 120, height: 30))
        var width = textSize.width + 12 * 2
        var imgSize = CGSize.zero
        var imageIsShow = false
        if !imageView.isHidden , let icon = reserveModel?.icon, icon.count > 0 {
            imgSize = CGSize.init(width: imgW, height: imgW)
            width = width + 3.0 + imgSize.width
            imageIsShow = true
        }
        
        //设置最大最小宽度
        width = max(60.0, width)
        width = min(200, width)
        
        let origin = self.frame.origin
        self.frame = CGRect.init(x: origin.x, y: origin.y, width: width, height: ReserveBorderButton.buttonHeight())
        self.layer.cornerRadius = self.height / 2.0
        
        self.titleLabel.frame = CGRect.init(x: 12.0, y: 0, width: textSize.width, height: self.height)
        if !imageIsShow {
            self.titleLabel.centerX = self.width / 2.0
        } else {
            self.titleLabel.left = 12.0
        }
        
        self.imageView.frame = CGRect.init(x: 0, y: 0, width: imgW, height: imgW)
        self.imageView.left = self.titleLabel.right + 3.0
        self.imageView.centerY = self.height / 2.0
        
        self.delegate?.didUpdateReserveButtonFrame()
    }
    
    func refreshButtonStatus() {
        guard let reserveModel = reserveModel else {
            return
        }
        
        self.imageView.isHidden = true
        let reserved = reserveModel.isReserve
        if !reserved {
            if let sceneThemeColor = scene?.sceneThemeColor() {
                self.titleLabel.textColor = sceneThemeColor
                self.layer.borderColor = sceneThemeColor.withAlphaComponent(0.3).cgColor
                self.layer.borderWidth = 0.5
                self.backgroundColor = .clear
            } else {
                self.titleLabel.textColor = .ykn_brandInfo
                self.layer.borderWidth = 0
                self.backgroundColor = .ykn_border
            }
            //预约有礼下发时使用text，不下发保留以前逻辑
            //展示 text+icon(IMG)
            if let title = reserveModel.text {
                self.titleLabel.text = title
                if let icon = reserveModel.icon, let url = URL.init(string: icon) {
                    self.imageView.isHidden = false
                    self.imageView.tintColor = .ykn_brandInfo
                }
            } else {
                self.titleLabel.text = "预约"
            }
            
            if reserveModel.reservationTip != nil {
                YKNBagdeHelper.showBadge(on: self, image: UIImage.init(named: "ykn_subscribe_gift"), offset: CGPoint.init(x: -3, y: 0))
            } else {
                YKNBagdeHelper.removeBadge(on: self)
            }
        } else {
            if let sceneSubtitleColor = scene?.sceneSubTitleColor() {
                self.titleLabel.textColor = sceneSubtitleColor
                self.layer.borderColor = sceneSubtitleColor.withAlphaComponent(0.3).cgColor
                self.layer.borderWidth = 0.5
                self.backgroundColor = .clear
            } else {
                self.titleLabel.textColor = .ykn_tertiaryInfo
                self.layer.borderWidth = 0
                self.backgroundColor = .ykn_secondaryBackground
            }
            self.titleLabel.text = "已预约"
            YKNBagdeHelper.removeBadge(on: self)
        }
        
        bindStatisticsService()
        refreshButtonFrame()
    }
    
    //MARK: collection
    @objc func handleAddReserveSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, isReserved: true)
    }
    
    @objc func handleCancelReserveSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, isReserved: false)
    }
    
    func handleNotication(notification: Notification, isReserved: Bool) {
       
        guard let reserveId = notification.object as? String else {
            return
        }
        guard let reserveModel = reserveModel, let currentId = reserveModel.rid else {
            return
        }
        guard currentId == reserveId else {
            return
        }

        reserveModel.isReserve = isReserved
        
        // 更新预约人数
        var count = isReserved ? reserveModel.count + 1 : reserveModel.count - 1
        count = max(0, count)
        reserveModel.count = count
        
        refreshButtonStatus()
    }
    
    public func bindStatisticsService() {
        guard let reserveModel = reserveModel else {
            return
        }
        
        if reserveModel.isReserve {
            Service.statistics.bind(reserveModel.cancelReserveReport, self, .OnlyClick)
        } else {
            Service.statistics.bind(reserveModel.addReserveReport, self, .OnlyClick)
        }
    }

    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
    
    public override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
        self.refreshButtonStatus()
    }
}
