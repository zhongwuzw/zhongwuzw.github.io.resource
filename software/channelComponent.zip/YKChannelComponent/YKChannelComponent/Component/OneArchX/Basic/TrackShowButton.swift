//
//  TrackShowButton.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/9/25.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import YKUIComponent
import OneArchSupport4Youku

protocol TrackShowButtonDelegate: NSObjectProtocol {
    //按钮size出现变化 外部调整布局
    func trackShowButtonRenderSizeDidChange(button: TrackShowButton)
}

class TrackShowButton: UIView {

    public override var isAccessibilityElement: Bool {
       get {
           return true
       }
       set {
           
       }
    }
           
    public override var accessibilityLabel: String? {
       get {
           return YKHomeAccessbilityHelperView.accessibilityLabel(with: self) + "，按钮"
       }
       set {
           
       }
    }
    
    /// 常规尺寸，不显示加追人数时固定尺寸
    static let regalarSize: CGSize = CGSize.init(width: 42, height: 30)
    static let zhuiCharSize: CGSize = CGSize.init(width: 16, height: 16)

    public weak var delegate: TrackShowButtonDelegate?
    
    private var isFavor: Bool = false
    private weak var favor: FavorModel?
       
    public var selectTextColor: UIColor = .ykn_tertiaryInfo
    public var selectBgColor: UIColor = .ykn_seconarySeparator
    public var selectBorderWidth: CGFloat = 0.0
    public var selectBorderColor: UIColor = .clear

    public var unselectTextColor: UIColor = .ykn_brandInfo
    public var unselectBgColor: UIColor = .ykn_border
    public var unselectBorderWidth: CGFloat = 1.0
    public var unselectBorderColor: UIColor = .clear
    
    public var canShowGradientLayer: Bool = true
    
    public lazy var gradientLayerView: UIView = {
        let view = UIView.init();
        view.backgroundColor = UIColor.clear
        view.frame = self.bounds
        return view
    }()

    lazy var gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]  //0 30 44 51
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 1.0, y: 0.0)

        self.gradientLayerView.layer.insertSublayer(layer, at: 0)
        layer.colors = [UIColor.ykn_cb_3.cgColor, UIColor.ykn_cb_4.cgColor]
        layer.frame = self.gradientLayerView.bounds
        return layer
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 20, height: 20))
        label.textAlignment = .center
        label.font = YKNIconFont.sharedInstance().font(withSize: 16)
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var countLabel: UILabel = {
        let view = UILabel()
        view.font = YKNFont.button_text_weight(.medium)
        view.numberOfLines = 1
        view.isHidden = true
        return view
    }()
    
    lazy var verticalBar: UIView = {
        let view = UIView()
        view.isHidden = true
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        var preferredSize = frame.size
        if frame.isEmpty {
            preferredSize = TrackShowButton.regalarSize
        }

        layer.masksToBounds = true
        layer.cornerRadius = preferredSize.height / 2
        addSubview(gradientLayerView)
        addSubview(titleLabel)
        addSubview(countLabel)
        addSubview(verticalBar)

        update(isFavor)
        NotificationCenter.default.addObserver(self, selector: #selector(darkModeIsChanged), name: .YKNThemeDidChange, object: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    /// 兼容老接口，仅显示加追、在追状态
    func update(_ state : Bool) {
        isFavor = state
       
        if isFavor {
            titleLabel.text = "\u{e714}"
                       
            layer.borderWidth = selectBorderWidth
            layer.borderColor = selectBorderColor.cgColor
            backgroundColor = selectBgColor
            gradientLayerView.isHidden = true
            gradientLayer.isHidden = true
            titleLabel.textColor = selectTextColor
        } else {
            titleLabel.text = "\u{e712}"

            layer.borderWidth = unselectBorderWidth
            layer.borderColor = unselectBorderColor.cgColor
            backgroundColor = unselectBgColor
            if canShowGradientLayer {
                gradientLayerView.isHidden = false
                gradientLayer.isHidden = false
            } else {
                gradientLayerView.isHidden = true
                gradientLayer.isHidden = true
            }
            titleLabel.textColor = unselectTextColor
        }
        
        self.bounds = CGRect(origin: .zero, size: TrackShowButton.regalarSize)
        self.gradientLayerView.frame = self.bounds
        self.gradientLayer.frame = self.gradientLayerView.bounds
        
        self.titleLabel.frame = self.bounds
        self.delegate?.trackShowButtonRenderSizeDidChange(button: self)
    }
    
    func fillModel(_ model: FavorModel) {
        self.favor = model
        
        self.updateData(model)
        
        if model.needShowCount {
            countLabel.text = model.formatCountText
            countLabel.isHidden = false
            verticalBar.isHidden = false
            
            countLabel.sizeToFit()
            countLabel.left = 15
            countLabel.centerY = self.height / 2
            
            let verticalBarHeight: CGFloat = 12
            let verticalBarWidth: CGFloat = 1
            let verticalBarX: CGFloat = countLabel.frame.maxX + 4
            let verticalBarY: CGFloat = (self.height - verticalBarHeight) / 2
            verticalBar.frame = CGRect.init(x: verticalBarX, y: verticalBarY, width: verticalBarWidth, height: verticalBarHeight)
            
            let titleSize = TrackShowButton.zhuiCharSize
            let titleX: CGFloat = verticalBar.frame.maxX + 4
            let titleY: CGFloat = (self.height - titleSize.height) / 2
            titleLabel.frame = CGRect.init(origin: CGPoint.init(x: titleX, y: titleY), size: titleSize)
            
            let totalWidth: CGFloat = titleLabel.frame.maxX + 15
            self.bounds = CGRect.init(origin: .zero, size: CGSize.init(width: totalWidth, height: TrackShowButton.regalarSize.height))
        } else {
            countLabel.isHidden = true
            verticalBar.isHidden = true
            
            self.bounds = CGRect(origin: .zero, size: TrackShowButton.regalarSize)
            self.gradientLayerView.frame = self.bounds
            self.gradientLayer.frame = self.gradientLayerView.bounds
            
            self.titleLabel.frame = self.bounds
        }
        
        self.delegate?.trackShowButtonRenderSizeDidChange(button: self)
    }
    
    func fillModel(_ model: FavorModel, layoutModel: TrackShowButtonLayoutModel) {
        self.favor = model
        
        self.updateData(model)
        
        if model.needShowCount {
            countLabel.text = model.formatCountText
            countLabel.isHidden = false
            verticalBar.isHidden = false
            
            countLabel.frame = layoutModel.countLabelFrame
            verticalBar.frame = layoutModel.verticalBarFrame
        } else {
            countLabel.isHidden = true
            verticalBar.isHidden = true
        }
        
        titleLabel.frame = layoutModel.titleLabelFrame
        self.bounds = CGRect(origin: .zero, size: layoutModel.totalSize)
        self.gradientLayerView.frame = self.bounds
        self.gradientLayer.frame = self.gradientLayerView.bounds

        self.delegate?.trackShowButtonRenderSizeDidChange(button: self)
    }
    
    private func updateData(_ model: FavorModel) {
        if let isFavor = model.isFavor, isFavor {
            titleLabel.text = "\u{e714}"
                       
            layer.borderWidth = selectBorderWidth
            layer.borderColor = selectBorderColor.cgColor
            backgroundColor = selectBgColor
            gradientLayerView.isHidden = true
            gradientLayer.isHidden = true
            titleLabel.textColor = selectTextColor
            countLabel.textColor = selectTextColor
            verticalBar.backgroundColor = selectTextColor.withAlphaComponent(0.5)
        } else {
            titleLabel.text = "\u{e712}"

            layer.borderWidth = unselectBorderWidth
            layer.borderColor = unselectBorderColor.cgColor
            backgroundColor = unselectBgColor
            if canShowGradientLayer {
                gradientLayerView.isHidden = false
                gradientLayer.isHidden = false
            } else {
                gradientLayerView.isHidden = true
                gradientLayer.isHidden = true
            }
            titleLabel.textColor = UIColor.ykn_cw_1
            countLabel.textColor = titleLabel.textColor
            verticalBar.backgroundColor = titleLabel.textColor.withAlphaComponent(0.5)
        }
    }
    
    static func estimatedLayout(_ model: FavorModel) -> TrackShowButtonLayoutModel {
        var layModel = TrackShowButtonLayoutModel()
        
        if model.needShowCount {
            let boundsHeight = TrackShowButton.regalarSize.height
            
            let countLabelSize = calcStringSize(model.formatCountText, font: YKNFont.button_text_weight(.medium), size: .zero)
            let countLabelX: CGFloat = 15
            let countLabelY: CGFloat = (boundsHeight - countLabelSize.height) / 2
            let countLabelFrame = CGRect.init(x: countLabelX, y: countLabelY, width: countLabelSize.width, height: countLabelSize.height)
            
            let verticalBarHeight: CGFloat = 12
            let verticalBarWidth: CGFloat = 1
            let verticalBarX: CGFloat = countLabelSize.width + countLabelX + 4
            let verticalBarY: CGFloat = (boundsHeight - verticalBarHeight) / 2
            let verticalBarFrame = CGRect.init(x: verticalBarX, y: verticalBarY, width: verticalBarWidth, height: verticalBarHeight)
            
            let titleSize = TrackShowButton.zhuiCharSize
            let titleX: CGFloat = verticalBarFrame.maxX + 4
            let titleY: CGFloat = (boundsHeight - titleSize.height) / 2
            let titleLabelFrame = CGRect.init(origin: CGPoint.init(x: titleX, y: titleY), size: titleSize)
            
            let totalWidth: CGFloat = titleLabelFrame.maxX + 15
            let totalSize = CGSize.init(width: totalWidth, height: boundsHeight)
            
            layModel.countLabelFrame = countLabelFrame
            layModel.verticalBarFrame = verticalBarFrame
            layModel.titleLabelFrame = titleLabelFrame
            layModel.totalSize = totalSize
        } else {
            layModel.titleLabelFrame = CGRect(origin: .zero, size: TrackShowButton.regalarSize)
            layModel.totalSize = TrackShowButton.regalarSize
        }
        
        return layModel
    }

    @objc func darkModeIsChanged() {
        //暗黑模式切换，重刷UI
        if let favor = self.favor {
            fillModel(favor)
        } else {
            update(isFavor)
        }
    }

}

struct TrackShowButtonLayoutModel {
    var countLabelFrame: CGRect = .zero
    var verticalBarFrame: CGRect = .zero
    var titleLabelFrame: CGRect = .zero
    
    var totalSize: CGSize = .zero
}
