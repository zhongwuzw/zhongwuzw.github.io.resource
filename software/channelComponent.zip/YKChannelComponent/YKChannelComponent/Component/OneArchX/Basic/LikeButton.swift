//
//  LikeButton.swift
//  YKChannelComponent
//
//  Created by CC on 2021/11/16.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import Lottie
import YKUIComponent
 
let kImageViewSize = CGSize.init(width: 24, height: 24)
let kAnimationViewSize = CGSize.init(width: 48, height: 48)

public class LikeButton: UIView {
    
    var animationFilePath: String?
    
    let likeImage = UIImage.init(named: "channel_yk11_like")
    let unLikeImage = UIImage.init(named: "channel_yk11_unlike")?.YKChannelComponent_imageWithTintColor(.black)
    
    lazy var displayImageView: UIImageView = {
                
        let view = UIImageView()
        view.image = unLikeImage
        view.isHidden = false
        view.frame = CGRect.init(origin: .zero, size: kImageViewSize)
        
        return view
    }()
    
    lazy var unLikeAnimationView: LOTAnimationView = {
        
        var path = Bundle.main.path(forResource: "DYKResources-cancel-praise-animation", ofType: "json")
        
        let view = LOTAnimationView.init(filePath:path ?? "")
        view.translatesAutoresizingMaskIntoConstraints = true
        view.contentMode = .scaleAspectFit
        view.isHidden = true
        view.frame = CGRect.init(origin: .zero, size: kAnimationViewSize)
        
        return view
    }()
    
    lazy var likeAnimationView: LOTAnimationView = {
        
        var path = Bundle.main.path(forResource: "DYKResources-praise-animation", ofType: "json") ?? ""

        let view = LOTAnimationView.init(filePath:path)
        view.translatesAutoresizingMaskIntoConstraints = true
        view.contentMode = .scaleAspectFit
        view.isHidden = true
        view.frame = CGRect.init(origin: .zero, size: kAnimationViewSize)
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.frame = CGRect.init(x: -7.5, y: 0, width: 50, height: 15)
        view.font = YKNFont.quaternary_auxiliary_text()
        view.textColor = UIColor.ykn_tertiaryInfo
        view.textAlignment = .center
        return view
    }()
    
    lazy var tapGesture: UITapGestureRecognizer = {
       let gesture = UITapGestureRecognizer()
        return gesture
    }()
    
    init() {
        super.init(frame: CGRect.zero)
        self.frame = CGRect.init(x: 0, y: 0, width: 30, height: 38)
        
        self.addSubview(self.displayImageView)

        self.addSubview(self.unLikeAnimationView)
        self.addSubview(self.titleLabel)
        
        self.displayImageView.frame = CGRect.init(origin: .zero, size: kImageViewSize)
        self.displayImageView.centerX = self.width / 2.0
        self.displayImageView.top = 4
        
        unLikeAnimationView.center = displayImageView.center
        likeAnimationView.center = displayImageView.center
        
        titleLabel.top = displayImageView.bottom
        titleLabel.centerX = self.width / 2.0
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func addTarget(_ target: Any, action: Selector) {
        self.tapGesture.addTarget(target, action: action)
        self.addGestureRecognizer(self.tapGesture)
    }
    
    func updateTitle(_ title: String?) {
        self.titleLabel.text = title
        
    }
    
    func startLikeLOTAnimation() {
        if self.likeAnimationView.superview == nil {
            self.addSubview(self.likeAnimationView)
        }
        self.displayImageView.isHidden = true
        self.unLikeAnimationView.isHidden = true
        self.unLikeAnimationView.stop()
        
        self.likeAnimationView.isHidden = false
        self.likeAnimationView.play(){[weak self] (animationFinished: Bool) in
            self?.unLikeAnimationView.isHidden = true
            self?.likeAnimationView.isHidden = true
            self?.displayImageView.isHidden = false
        }
    }
    
    func startUnLikeLOTAnimation() {
        self.displayImageView.isHidden = true
        self.unLikeAnimationView.isHidden = false
        self.likeAnimationView.isHidden = true
        self.unLikeAnimationView.play(){[weak self] (animationFinished: Bool) in
            self?.unLikeAnimationView.isHidden = true
            self?.likeAnimationView.isHidden = true
            self?.displayImageView.isHidden = false
        }
            
    }
    
    //显示点赞动画 - 变成点赞状态
    func updateLikeState(_ isLike: Bool) {
        self.displayImageView.image = isLike ? likeImage : unLikeImage
        self.accessibilityLabel = isLike ? "取消点赞": "点赞"
    }
}

public class FitDarkLikeButton: LikeButton { //适配暗黑按钮
    var isShowLike: Bool = false
    
    var useUnLikeImage:UIImage? {
        get {
            return UIImage.init(named: "channel_yk11_unlike")?.YKChannelComponent_imageWithTintColor(isDark() ? UIColor.white : UIColor.black)
        }
    }
    
    override func updateLikeState(_ isLike: Bool) {
        self.isShowLike = isLike
        self.displayImageView.image = isLike ? likeImage : useUnLikeImage
        self.accessibilityLabel = isLike ? "取消点赞": "点赞"
    }
    
    override public func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        self.displayImageView.image = self.isShowLike ? likeImage : useUnLikeImage
    }
    
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
}
