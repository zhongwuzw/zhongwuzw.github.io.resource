//
//  ReserveCountButton.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/7/18.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import YKSCiPhoneService
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout


class ReserveCountButton : ReserveButton {
    lazy var gradientLayerView: UIView = {
        let view = UIView.init();
        view.backgroundColor = UIColor.clear
        view.frame = self.bounds
        return view
    }()

    lazy var gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]  //0 30 44 51
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 1.0, y: 0.0)

        self.gradientLayerView.layer.insertSublayer(layer, at: 0)
        layer.colors = [UIColor.ykn_cb_3.cgColor, UIColor.ykn_cb_4.cgColor]
        layer.frame = self.gradientLayerView.bounds
        return layer
    }()
    lazy var countLabel: UILabel = {
        let view = UILabel()
        view.font = YKNFont.redpoint_text()
        view.numberOfLines = 1
        return view
    }()
    
    lazy var verticalBar: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var unitLabel: UILabel = {
        let view = UILabel()
        view.font = YKNFont.redpoint_text()
        view.numberOfLines = 1
        return view
    }()
    
    override init() {
        super.init()
        addSubview(gradientLayerView)
        addSubview(countLabel)
        addSubview(verticalBar)
        addSubview(unitLabel)
        
        countLabel.font = YKNFont.qyDigitalThinFont(ofSize: 14)
        titleLabel.font = YKNFont.posteritem_subhead_weight(.semibold)
        unitLabel.font = titleLabel.font
        self.isUserInteractionEnabled = true
        self.sendSubviewToBack(gradientLayerView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func shouldShowCount(reserveModel: ReserveModel?) -> Bool {
        guard let reserveModel = reserveModel else {
            return false
        }
        
        return reserveModel.needShowCount
    }
    
    override func refresh(reserveModel: ReserveModel?, scene: SceneModel?) {
        self.reserveModel = reserveModel
        self.scene = scene
        // 预约有礼icon
        if let icon = reserveModel?.icon, let url = URL.init(string: icon) {
            self.imageView.sd_setImage(with: url, completed: {[weak self] img, error, type, url in
                self?.imageView.image = self?.imageView.image?.withRenderingMode(.alwaysTemplate)
                self?.imageView.tintColor = .white
            })
        }
        
        refreshButtonStatus()
        weak var weakself = self
        self.whenTapped {
            UtilityHelper.doReservation(reserveModel: weakself?.reserveModel)
        }
    }
    
    override func refreshButtonStatus() {
        guard let reserveModel = reserveModel else {
            return
        }
        
        //icon默认隐藏
        self.imageView.isHidden = true
        let reserved = reserveModel.isReserve
        
        //是否显示预约数
        let showCount = shouldShowCount(reserveModel: reserveModel)
        
        if !reserved {
            var title = reserveModel.text ?? "预约"
            if showCount {
                title = "预约"
            }
            self.setTitle(title)
            if let icon = reserveModel.icon, let _ = URL.init(string: icon) {
                self.imageView.isHidden = false
                self.imageView.tintColor = UIColor.white
            }
            let titleColor = UIColor.white
            self.setTitleColor(titleColor)
            countLabel.textColor = titleColor
            verticalBar.backgroundColor = UIColor.ykn_cw_1.withAlphaComponent(0.5)
            self.backgroundColor = UIColor.ykn_brandInfo
            self.gradientLayerView.isHidden = false
        } else {
            let titleColor = UIColor.ykn_secondaryInfo
            self.setTitle("已预约")
            self.setTitleColor(titleColor)
            countLabel.textColor = titleColor
            verticalBar.backgroundColor = UIColor.ykn_outline
            self.backgroundColor = UIColor.ykn_seconarySeparator
            self.gradientLayerView.isHidden = true
        }
        self.titleLabel.font = YKNFont.posteritem_subhead_weight(.medium)
        unitLabel.textColor = titleLabel.textColor
        
        if showCount {
            updateCountLabelStyle()
            countLabel.isHidden = false
            unitLabel.isHidden = false
            verticalBar.isHidden = false
        } else {
            countLabel.text = ""
            countLabel.isHidden = true
            unitLabel.isHidden = true
            verticalBar.isHidden = true
        }
        
        bindStatisticsService()
        refreshButtonFrame()
    }
    
    func updateCountLabelStyle() {
        guard let reserveModel = reserveModel else {
            return
        }
        
        let countStr = reserveModel.formatCount
        let totalStr = reserveModel.formatCountText
        guard totalStr.hasPrefix(countStr), totalStr.count > countStr.count else {
            return
        }
        
        let unitStr = String(totalStr.suffix(from: countStr.endIndex))
        self.countLabel.text = countStr
        
        self.unitLabel.text = unitStr
    }
    
    override func refreshButtonFrame() {
        if countLabel.isHidden == false {
            countLabel.sizeToFit()
            verticalBar.bounds = CGRect.init(x: 0, y: 0, width: 1, height: 14)
            unitLabel.sizeToFit()
        }
        
        titleLabel.sizeToFit()
        
        let countSize = countLabel.bounds.size
        let unitSize = unitLabel.isHidden ? .zero : unitLabel.bounds.size
        let imageSize = CGSize.init(width: 14, height: 14)
        let textSize = titleLabel.bounds.size
        
        //预约按钮起始欢度
        var width = textSize.width + YKNGap.dim_7() * 2
        
        //预约数量（如有）
        var countIsShow = false
        if countLabel.isHidden == false {
            width += countSize.width
            width += unitSize.width
            width += (YKNGap.dim_5() * 2)
            width += verticalBar.bounds.width
            width -= 1
            countIsShow = true
        }
        
        //预约有礼图标（如有）
        var imageIsShow = false
        if !imageView.isHidden, let icon = reserveModel?.icon, !icon.isEmpty {
            width += imageSize.width + YKNGap.dim_4() // +icon 大小
            imageIsShow = true
        }
        
        //设置最大最小宽度
        width = max(ReserveCountButton.buttonWidth(), width)
        width = min(250, width)
        
        let origin = self.frame.origin
        self.frame = CGRect.init(x: origin.x, y: origin.y, width: width, height: ReserveCountButton.buttonHeight())
        self.layer.cornerRadius = self.height / 2.0
        
        self.gradientLayerView.frame = self.bounds
        self.gradientLayer.frame = self.gradientLayerView.bounds
        
        //内部微调
        let halfWidth = self.width / 2.0
        let halfHeight = self.height / 2.0
        let countCenterOffsetY = 1.0
        if countIsShow == false, imageIsShow == false {
            self.titleLabel.centerX = halfWidth
            self.titleLabel.centerY = halfHeight
        } else if countIsShow == true, imageIsShow == false {
            self.countLabel.centerY = halfHeight - countCenterOffsetY
            self.verticalBar.centerY = halfHeight
            self.titleLabel.centerY = halfHeight
            
            self.countLabel.left = YKNGap.dim_7()
            self.unitLabel.left = self.countLabel.right
            self.unitLabel.centerY = halfHeight
            self.verticalBar.left = self.countLabel.right + unitSize.width + YKNGap.dim_5()
            self.titleLabel.right = self.width - YKNGap.dim_7()
        } else if countIsShow == false, imageIsShow == true {
            self.titleLabel.centerY = halfHeight
            self.titleLabel.left = YKNGap.dim_7()
            
            self.imageView.frame = CGRect.init(origin: .zero, size: imageSize)
            self.imageView.right = self.width - YKNGap.dim_7()
            self.imageView.centerY = halfHeight
        } else if countIsShow == true, imageIsShow == true {
            self.countLabel.centerY = halfHeight - countCenterOffsetY
            self.verticalBar.centerY = halfHeight
            self.titleLabel.centerY = halfHeight
            
            self.countLabel.left = YKNGap.dim_7()
            self.unitLabel.left = self.countLabel.right
            self.unitLabel.centerY = halfHeight
            self.verticalBar.left = self.countLabel.right + unitSize.width + YKNGap.dim_5()
            
            self.imageView.frame = CGRect.init(origin: .zero, size: imageSize)
            self.imageView.right = self.width - YKNGap.dim_7()
            self.imageView.centerY = halfHeight
            self.titleLabel.right = self.imageView.left - YKNGap.dim_4()
        }
                
        //通知父容器更新位置
        self.delegate?.didUpdateReserveButtonFrame()
    }
    
    public override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        //暗黑切换无UI变化
    }
}
