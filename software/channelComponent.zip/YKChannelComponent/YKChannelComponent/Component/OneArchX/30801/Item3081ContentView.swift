//
//  Item3081ContentView.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/30.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import SDWebImage
import YKProtocolSDK
import YKHome

class Item3081ContentView: AccessibilityView {

    var itemModel:BaseItemModel?
    
    //MARK: Property
    
    lazy var bgView:UIView = {
        let view = UIView.init(frame:CGRect.init(x: 0, y: 0, width: self.width, height: self.height))
        view.backgroundColor = .black
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.clipsToBounds = true
        view.alpha = 0.3
        return view
    }()
    
    lazy var imageView:UIImageGIFView = {
        let view = UIImageGIFView.init(frame:CGRect.init(x: 0, y: 0, width: self.width, height: self.width * 0.5625))
        view.backgroundColor = .clear
        view.contentMode = .scaleAspectFit
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.clipsToBounds = true
        return view
    }()
    
    lazy var titleLabel:UILabel = {
        let label = UILabel.init(frame:CGRect.init(x: 9, y: 9, width: Int(self.width), height: 27))
        label.backgroundColor = .clear
        label.textAlignment = .left
        label.font = UIFont.systemFont(ofSize: 22, weight: .semibold)
        label.textColor = .white
        label.lineBreakMode = .byTruncatingTail
        return label
    }()

    lazy var subtitleLabel:UILabel = {
        let label = UILabel.init(frame:CGRect.init(x: titleLabel.left, y: titleLabel.bottom + 1, width: titleLabel.width, height: 17))
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = .white
        label.lineBreakMode = .byTruncatingTail
        label.alpha = 0.7
        return label
    }()

    lazy var bottomTitleLabel:UILabel = {
        let label = UILabel.init(frame:CGRect.init(x: 9, y: Int(self.height - 45), width: Int(self.width), height: 18))
        label.backgroundColor = .clear
        label.textAlignment = .left
        label.font = UIFont.systemFont(ofSize: 15, weight: .semibold)
        label.textColor = .white
        label.lineBreakMode = .byTruncatingTail
        return label
    }()

    lazy var bottomSubtitleLabel:UILabel = {
        let label = UILabel.init(frame:CGRect.init(x: titleLabel.left, y: bottomTitleLabel.bottom + 1, width: titleLabel.width, height: 17))
        label.font = UIFont.systemFont(ofSize: 14)
        label.textColor = .white
        label.alpha = 0.7
        label.lineBreakMode = .byTruncatingTail
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.imageView)
        self.addSubview(self.bgView)
        self.addSubview(self.titleLabel)
        self.addSubview(self.subtitleLabel)
        self.addSubview(self.bottomTitleLabel)
        self.addSubview(self.bottomSubtitleLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func fillData(itemModel: BaseItemModel) {
        self.itemModel = itemModel
        self.backgroundColor = .clear
        self.imageView.ykn_setImage(withURLString: itemModel.img, module: "home", imageSize: .zero, parameters: nil, completed: nil)

        self.titleLabel.text = itemModel.reason?.title
        self.subtitleLabel.text = itemModel.summary?.text
        self.bottomTitleLabel.text = itemModel.title
        self.bottomSubtitleLabel.text = itemModel.subtitle
    }
}
