//
//  TopAnimationADUtils.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/11/13.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku

func getTopAnimatioADComponent(_ page:IPage?) -> IComponent? {
    guard let cards = page?.getCards() else {
        return nil
    }
    
    for card in cards {
        if let cardType = card.cardModel?.type, cardType == "15038" {
            if let comp = card.getComponents()?.first as? IComponent {
                if let tag = comp.model?.type, tag == "14325" {
                    return comp
                }
            }
        }
    }
    return nil
}
