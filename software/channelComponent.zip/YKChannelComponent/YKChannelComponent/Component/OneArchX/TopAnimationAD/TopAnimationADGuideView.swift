//
//  TopAnimationADGuideView.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/11/13.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource
import YKChannelPage
import Lottie
import YKHome

public class TopAnimationADGuideView : UIView {
    var guideAnimationView: UIView?
    var textSize:CGSize?
    lazy var themesColorBgView: UIView = {
        let view = UIView.init()
        view.backgroundColor = UIColor.clear
        view.frame = self.bounds
        view.isUserInteractionEnabled = true
        return view
    }()
    lazy var textGradientBGView: UIView = {
        let view = UIView.init()
        view.backgroundColor = UIColor.clear
        view.frame = self.bounds
        view.isUserInteractionEnabled = true
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 7.0
        return view
    }()
    lazy var textGradientLayerView: UIView = {
        let view = UIView.init()
        view.backgroundColor = UIColor.clear
        view.frame = self.bounds
        view.isUserInteractionEnabled = true
        view.layer.masksToBounds = true
//        view.layer.cornerRadius = 7.0
        return view
    }()
    
    lazy var textGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)
        layer.colors = [UIColor.white.withAlphaComponent(0).cgColor,UIColor.white.withAlphaComponent(0.2).cgColor]
        return layer
    }()
    lazy var guideTextLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.ykn_primaryInfo
        view.font = YKNIconFont.sharedInstance().font(withSize: 12.0)
        view.numberOfLines = 0
        view.textAlignment = .center

        return view
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    func initSubviews() {
        self.addSubview(themesColorBgView)
        self.addSubview(textGradientBGView)
        textGradientBGView.addSubview(textGradientLayerView)
//        textGradientLayerView.layer.addSublayer(textGradientLayer)
        textGradientLayerView.addSubview(guideTextLabel)
    }
    func fillData(_ compModel:Comp14325Model?) {
        weak var weakSelf = self
        if compModel?.localGuideLottieUrl == nil || compModel?.localTopBgLottieUrl == nil {
            TopAnimationADGuideView.preloadLottieUrl(compModel)
        }
//        compModel?.guideImg = "https://gw.alipayobjects.com/os/finxbff/lolita/jdqftELxqhzkNaYfha8Jt/lottie-with-images.zip"
        let lottieBlock: (String?, Error?) -> Void  = {[weak self] filePath, error in
            guard let self = self else { return }
            if let filePath = filePath {
                var realView:UIView? = self.guideAnimationView
                let frame = CGRect.init(origin: .zero, size: CGSize.init(width: self.width, height: self.height))
                if realView == nil {
                    realView = YKLottieXManager.createAnimationView(filePath, frame: frame)
                    if let realView = realView {
                        self.guideAnimationView = realView
                        self.addSubview(realView)
                    }
                }
                if let realView = realView {
                    realView.frame = frame
                    YKLottieXManager.play(realView)
                }
            }
        }
        if compModel?.localGuideLottieUrl == nil {
            if let lottiePath = compModel?.guideImg {
                DispatchQueue.global().async {
                    YKLottieXManager.loadLottie(fromURLString: lottiePath) { filePath, urlString, error in
                        DispatchQueue.main.async {
                            compModel?.localGuideLottieUrl = filePath
                            if let localGuideLottieUrl = compModel?.localGuideLottieUrl {
                                lottieBlock(localGuideLottieUrl, nil)
                            }
                        }
                    }
                }
            }
        } else {
            if let filePath = compModel?.localGuideLottieUrl {
                lottieBlock(filePath, nil)
            }
        }
        if let guideText = compModel?.guideText {
            let realText = guideText + " " + "\u{e707}"
            guideTextLabel.text = realText
        } else {
            guideTextLabel.text = ""
        }
        
        textGradientLayerView.backgroundColor = UIColor.ykn_elevatedIconFill.withAlphaComponent(0.08)
        
        
        self.bringSubviewToFront(guideTextLabel)
        relayoutCustomViews()
    }
    
    func relayoutCustomViews() {
        self.themesColorBgView.frame = self.bounds
        var realTextSize = CGSize.zero
        if let textSize = textSize {
            realTextSize = textSize
        } else {
            self.guideTextLabel.sizeToFit()
            realTextSize = self.guideTextLabel.size
        }
        self.guideAnimationView?.frame = CGRect(x: 0, y: 0, width: self.width, height: self.height)
        let layerW = realTextSize.width + 12.0 + 12.0
        let layerH = realTextSize.height + 4.0
        self.textGradientBGView.frame = CGRect(x: 0, y: 0, width: layerW, height: layerH + 8.0)
        self.textGradientBGView.centerX = self.width / 2.0
        self.textGradientBGView.centerY = self.height / 2.0
        self.textGradientBGView.top = self.textGradientBGView.top - 4.0
        self.textGradientLayerView.frame = CGRect(x: 0, y: 8.0, width: layerW, height: layerH)
        self.textGradientLayerView.layer.cornerRadius = layerH * 0.5

        self.textGradientLayer.frame = self.textGradientLayerView.bounds
        self.guideTextLabel.frame = CGRect(origin: CGPoint.init(x: 12.0, y: 0), size: realTextSize)
        self.guideTextLabel.centerY = self.textGradientLayerView.height / 2.0 - 1.0
    }
    
    public class func preloadLottieUrl(_ compModel:Comp14325Model?) {
//        compModel?.guideImg = "https://gw.alipayobjects.com/os/finxbff/lolita/jdqftELxqhzkNaYfha8Jt/lottie-with-images.zip"
//        compModel?.img = "https://gw.alipayobjects.com/os/finxbff/lolita/zN3fa9Lzyyx6Yz3iPG4GL/lottie-with-images.zip"
        DispatchQueue.global().async {
            if let lottiePath = compModel?.guideImg {
                YKLottieXManager.loadLottie(fromURLString: lottiePath) { filePath, urlString, error in
                    compModel?.localGuideLottieUrl = filePath
                }
            }
            if let lottiePath = compModel?.img {
                YKLottieXManager.loadLottie(fromURLString: lottiePath) { filePath, urlString, error in
                    compModel?.localTopBgLottieUrl = filePath
                }
            }
        }
    }
}

