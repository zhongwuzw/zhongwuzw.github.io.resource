//
//  ItemView12074Extension.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/20.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

extension ItemPlugin12074ContentView {
    
    
    func fillData(_ model: BaseItemModel) {
        
        if isSecondFloorComponent {
            self.alpha = self.alphaProgress * self.getNavBackgroundAlpha()
        } else {
            self.alpha = 1.0
        }

        if model.subtitle != nil && !(model.subtitle?.isEmpty ?? true) {
            subTitleLabel.isHidden = false
            titleLabel.numberOfLines = 1
            subTitleLabel.text = model.subtitle
        } else {
            subTitleLabel.isHidden = true
            titleLabel.numberOfLines = 2
        }
        
        relayoutSubviewsV2(model)
        
        if let attributedTitle = model.attributedTitle {
            titleLabel.text = nil
            titleLabel.attributedText = attributedTitle
        } else {
            titleLabel.attributedText = nil
            titleLabel.text = model.title
        }
        let layout = model.layout
        
        videoImageView.frame = self.imageViewFrame()
        videoImageView.ykn_setImage(withURLString: XCDNSTRING(model.img),
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        if let lTopimg = model.lTop?.img, !lTopimg.isEmpty {
            lTopImageView.frame = CGRect.init(x: 3, y: 3, width: 60.0, height: 20.0)
            lTopImageView.ykn_setImage(withURLString: lTopimg,
                                       module: "home",
                                       imageSize: CGSize.zero,
                                       parameters: nil,
                                       completed: nil)
        } else {
            lTopImageView.image = nil
        }

        // 右下角腰封
        Service.summary.attach(model.summary, toView: videoImageView, layout: layout.summary)
        
        // 左下角腰封
        Service.lbTexts.attach(model.lbTexts, toView: videoImageView, layouts: layout.lbTexts)
        
        // uploader or 推荐理由
        if let uploader = model.uploader {
            if let info = uploader.info,
               let infoTitle = info.title, infoTitle.count > 0 {
                uploaderReasonView.textColor = info.titleColor
                uploaderReasonView.backgroundColor = info.backgroundColor
                uploaderReasonView.fill(text: infoTitle)
            }
            
            if let iconURL = uploader.icon {
                uploaderImageView.ykn_setImage(withURLString: iconURL,
                                               module: "home",
                                               imageSize: CGSize.zero,
                                               parameters: nil,
                                               completed: nil)
            }
            
            if let name = uploader.name {
                uploaderNameLabel.text = name
            }
            uploaderNameLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: model.scene?.sceneSubTitleColor()) ?? .ykn_tertiaryInfo

            Service.reasons.detach(fromView: self)
            Service.action.bind(model.uploader?.action, uploaderNameLabel)
        } else if let reasons = model.reasons {
            Service.reasons.attach(reasons, toView: self, layouts: layout.reasons)
        } else {
            Service.reasons.detach(fromView: self)
        }
        
        //color
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: model.scene?.sceneTitleColor())
//        self.backgroundColor = sceneUtil(UIColor.clear, sceneColor: model.scene?.sceneBgColor())
    }

    
    func relayoutSubviewsV2(_ model: OneArchSupport4Youku.BaseItemModel) {
        bgView.frame = self.bounds
        
        let w = self.imageViewFrame().size.width
        
        let maginTypes = ["12144"] //支持找片类型加左右间距、底边距
        let type = model.type ?? ""
        let isMaginType = maginTypes.contains(type)
        
        let leftMagin = isMaginType ? YKNGap.dim_6() : 0
        let bottomMagin = isMaginType ? YKNGap.dim_7() : 0
        
        videoImageView.frame = self.imageViewFrame()
        lTopImageView.frame = CGRect.init(x: 3, y: 3, width: 60.0, height: 20.0)

        let y = CGFloat(videoImageView.frame.maxY) + YKNGap.youku_picture_title_spacing()
        titleLabel.frame = CGRect.init(x: leftMagin, y: y, width: w - leftMagin * 2, height: ceil(38.0 * YKNSize.yk_icon_size_scale()))
        if subTitleLabel.isHidden == true {
            titleLabel.frame = CGRect.init(x: leftMagin, y: y, width: w - leftMagin * 2, height: YKNFont.height(with: titleLabel.font, lineNumber: 2) + 4.0)
        } else {
            titleLabel.frame = CGRect.init(x: leftMagin, y: y, width: w - leftMagin * 2, height: YKNFont.height(with: titleLabel.font, lineNumber: 1))
            subTitleLabel.frame = CGRect.init(x: leftMagin, y: titleLabel.frame.maxY + 3, width: w - leftMagin * 2, height: YKNFont.height(with: subTitleLabel.font, lineNumber: 1))
        }
        
        if let uploader = model.uploader {
            var subviewXCursor = titleLabel.left
            let nameLabelHeight: CGFloat = 18
            let subviewCenterY = self.height - nameLabelHeight - bottomMagin + (nameLabelHeight / 2)
            
            if let info = uploader.info,
               let infoTitle = info.title, infoTitle.count > 0 {
                uploaderReasonView.isHidden = false
                
                let size = uploaderReasonView.estimatedSize(text: infoTitle)
                let position = CGPoint.init(x: subviewXCursor, y: subviewCenterY - size.height / 2)
                uploaderReasonView.frame = CGRect.init(x: position.x,
                                                       y: position.y,
                                                       width: size.width,
                                                       height: size.height)
                
                subviewXCursor += uploaderReasonView.bounds.width + 6
            } else {
                uploaderReasonView.isHidden = true
            }
            
            if let _ = uploader.icon {
                uploaderImageView.isHidden = false
                
                let position = CGPoint.init(x: subviewXCursor, y: self.height - uploaderImageView.bounds.height - bottomMagin)
                uploaderImageView.frame = CGRect.init(x: position.x,
                                                      y: position.y,
                                                      width: uploaderImageView.bounds.width,
                                                      height: uploaderImageView.bounds.height)
                
                subviewXCursor += uploaderImageView.bounds.width + 6
            } else {
                uploaderImageView.isHidden = true
            }
            
            if uploaderImageView.isHidden, !uploaderReasonView.isHidden {
                uploaderSpacingLabel.isHidden = false
                
                let position = CGPoint.init(x: uploaderReasonView.frame.maxX,
                                            y: subviewCenterY - nameLabelHeight / 2)
                
                uploaderSpacingLabel.frame = CGRect.init(x: position.x,
                                                         y: position.y,
                                                         width: uploaderSpacingLabel.bounds.width,
                                                         height: nameLabelHeight)
                
                subviewXCursor = uploaderSpacingLabel.frame.maxX
            } else {
                uploaderSpacingLabel.isHidden = true
            }
            
            if let name = uploader.name {
                uploaderNameLabel.isHidden = false
                
                uploaderNameLabel.text = name
                let position = CGPoint.init(x: subviewXCursor,
                                            y: subviewCenterY - nameLabelHeight / 2)
                
                let fitsize = model.layout.uploader?.boundingSize ?? CGSize.zero
                uploaderNameLabel.frame = CGRect.init(x: position.x,
                                                      y: position.y,
                                                      width: fitsize.width,
                                                      height: nameLabelHeight)
            } else {
                uploaderNameLabel.isHidden = true
            }
        } else {
            uploaderReasonView.isHidden = true
            uploaderImageView.isHidden = true
            uploaderSpacingLabel.isHidden = true
            uploaderNameLabel.isHidden = true
        }
    }
}


              
                                                                                  
