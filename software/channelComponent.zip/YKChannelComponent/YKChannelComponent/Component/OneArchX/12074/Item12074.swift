//
//  Item12074.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/20.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

class Item12074:NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
    
    static func create() -> ItemDelegate {
        return Item12074.init()
    }
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }

    
    func columnCount() -> CGFloat {
        return 2.0
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        if ykrl_isResponsiveLayout() {
            if let components = self.item?.getCard()?.getComponents() {
                for comp in components {
                    if let tag = comp.model?.type, (tag == "14035" || tag == "14196" || tag == "14306") {
                        return 0
                    }
                }
            }
        }
        
        self.receiveEstimatedLayout(Double(itemWidth))
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler(),
                ItemPlayerProgressEventHandler(),
                LongPressPreviewItemEventHandler()]
    }

    /// 渲染复用ID
    func reuseId() -> String? {
        if isPullDrawler() {
            return "15029.12074"
        }
        return "12074"
    }
    
    func isPullDrawler() -> Bool {
        if let card = self.item?.getCard(), let tag = card.model?.type, tag == "15029" {
            return true
        }
        return false
    }
    
    func itemDidInit() {
        if let title = item?.itemModel?.title, title.count > 0 {
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 3.0
            paragraphStyle.lineBreakMode = .byTruncatingTail
            let attributedTitle = NSAttributedString.init(string: title, attributes: [.paragraphStyle: paragraphStyle])
            item?.itemModel?.attributedTitle = attributedTitle
        }
        
        if let reasons = item?.itemModel?.reasons, !reasons.isEmpty {
            //靠下对齐布局，需要统一高度，恢复所有推荐理由的垂直边距
            item?.itemModel?.reasons = reasons.map({
                var newReason = $0
                newReason.isNeedVerticalPaddingAtYK11 = true
                return newReason
            })
        }
        SelectionCardFeedAdUtil.bindAdGrayIdIfNeeded(item)
    }
    
    func getItemHeight(_ itemWidth: Double) -> CGFloat {
        let videoImageHeight = ceil(itemWidth * 9.0/16.0)
        let itemHeight = videoImageHeight + 30 + ceil(38.0 * Double(YKNSize.yk_icon_size_scale()))
        return itemHeight
    }
    
    func receiveEstimatedLayout(_ itemWidth: Double) {

        let itemLayout = item?.itemModel?.layout
        guard let model = item?.itemModel else { return }
        
        let videoImageHeight = ceil(itemWidth * 9.0/16.0)
        let itemHeight = getItemHeight(itemWidth)
        
        itemLayout?.renderRect = CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight)
        
        //预布局

        let videoImageSize = CGSize.init(width: itemWidth, height: videoImageHeight)
        
        if let mark = model.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: videoImageSize)
            itemLayout?.mark = layout
        }
        
        if let summary = model.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize:videoImageSize)
            itemLayout?.summary = layout
        }
        
        if let lbTexts = model.lbTexts {
            let layout = Service.lbTexts.estimatedLayout(lbTexts, toViewSize:videoImageSize)
            itemLayout?.lbTexts = layout
        }
        
        var nameWidthMax: CGFloat = max(0, itemWidth - 16) /* 16 = 负反馈按钮宽度 */
        if let _ = model.uploader?.icon {
            nameWidthMax = max(0, itemWidth - 18 - 6 - 16) /* 18 = icon宽度， 6 = gap，16 = 负反馈按钮宽度 */
        }
        if let infoTitle = model.uploader?.info?.title {
            let infoTitleSize = calcStringSize(infoTitle, font: ReasonView.defaultTextFont(), size: .zero)
            nameWidthMax = max(0, itemWidth - infoTitleSize.width - 14 - 16) /* 14 = gap， 16 = 负反馈按钮宽度*/
        }
        
        if let name = model.uploader?.name {
            let fitsize = calcStringSize(name, font: ReasonView.defaultTextFont(), size: CGSize.init(width: nameWidthMax, height: 18))
            let layout = TextLayoutModel()
            layout.boundingSize = fitsize
            itemLayout?.uploader = layout
        }
        
        if let reasons = model.reasons {
            var boundingwidth: CGFloat = 0.0
            if let oneArchPageScene = self.item?.getPage()?.pageContext?.concurrentDataMap["OneArchPageScene"] as? String, oneArchPageScene == "Detail" {
                if self.item?.itemModel?.feedbackModel != nil {
                    boundingwidth = CGFloat(itemWidth) - 16 - 6
                } else {
                    boundingwidth = CGFloat(itemWidth) //通投到播放页时不下发负反馈按钮则不显示，无需空出负反馈按钮宽度
                }
            } else {
                boundingwidth = CGFloat(itemWidth) - 16 - 6
            }
            let boundingSize = CGSize.init(width: boundingwidth, height: CGFloat.greatestFiniteMagnitude)

            var layout = Service.reasons.estimatedLayout(reasons, boundingSize: boundingSize)
            let position = CGPoint.init(x: 0, y: itemHeight - Double(layout.first?.renderRect.size.height ?? 0))
            layout = Service.reasons.estimatedLayout(reasons, position: position, boundingSize: boundingSize)
            itemLayout?.reasons = layout
        }
    }
    
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = ItemPlugin12074ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        itemView.tag = 10012074
        return itemView
    }

    
    func reuseView(itemView: UIView) {
        self.item?.itemModel?.dataCenterMap["dataIsBinded"] = true
        guard let itemModel = self.item?.itemModel else {
            return
        }
        let itemLayout = itemModel.layout

        if let itemViewNative = itemView as? ItemPlugin12074ContentView {
            //是否是二楼组件
            if let cardType = self.item?.getCard()?.cardModel?.type {
                itemViewNative.isSecondFloorComponent = !disableSecondFloorCompChange() ? ((cardType == "15029") && isSelectionPagePullDrawerMode()) : (cardType == "15029")
                itemViewNative.pageIsThemeMode = isPageInThemeMode(self.item?.getPage())
            } else {
                itemViewNative.isSecondFloorComponent = false
            }
        }
        
        var imageViewFrame = CGRect.zero
        if let itemViewNative = itemView as? ItemPlugin12074ContentView {
            itemViewNative.fillData(itemModel)
            imageViewFrame = itemViewNative.imageViewFrame()
        }
        
        weak var weakItem = self.item
        //跳转
        Service.action.bind(itemModel.action, itemView) {
            print("12074 will action")
        } didAction: {
            print("12074 did action")
            weakItem?.sendEventMessage("yksc.event.item.rec.tap", params: nil)
        }

        //player
        if let itemViewNative = itemView as? ItemPlugin12074ContentView {
            // 角标
            Service.mark.attach(itemModel.mark, toView: itemViewNative.videoImageView, layout: itemLayout.mark)
            Service.player.attach(itemModel.playerModel, toView: itemViewNative.videoImageView, displayFrame: imageViewFrame)
        }
        
        weak var weakComponent = self.item?.getComponent()
        itemModel.feedbackModel?.feedbackFinished = {
            if let component = weakComponent {
                deleteComponentWithAnimation(component)
            }
        }
    }

}
