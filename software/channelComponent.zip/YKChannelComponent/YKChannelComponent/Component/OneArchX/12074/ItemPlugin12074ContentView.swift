//
//  ItemPlugin12074ContentView.swift
//  YKChannelComponent
//
//  Created by better on 2021/4/7.
//  Copyright © 2021 Youku. All rights reserved.
//
   
import UIKit
import YoukuResource
import YKSCBase
import Lottie
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent

class ItemPlugin12074ContentView: ItemBaseAlphaContentView {
    lazy var bgView: UIView = {
        let view = UIView()
//        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
//        view.clipsToBounds = true
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
        
    lazy var lTopImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.backgroundColor = .clear
        return view
    }()
    
    lazy var titleLabel: MarginLabel = {
        let view = MarginLabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.verticalAlignment = .top
        view.numberOfLines = 2
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subTitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.textAlignment = .left
        view.numberOfLines = 1
        view.isHidden = true
        return view
    }()
    
    lazy var uploaderImageView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.bounds = CGRect.init(x: 0, y: 0, width: 18, height: 18)
        view.layer.cornerRadius = 9
        view.layer.borderWidth = 0.5
        view.layer.borderColor = UIColor.ykn_separator.cgColor
        return view
    }()
    
    lazy var uploaderNameLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = ReasonView.defaultTextFont() // 为对齐文案在同一水平线，与推荐理由采用同一字号
        view.numberOfLines = 1
        return view
    }()
    
    lazy var uploaderReasonView: ReasonView = {
        return ReasonView()
    }()
    
    lazy var uploaderSpacingLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = ReasonView.defaultTextFont() // 为对齐文案在同一水平线，与推荐理由采用同一字号
        view.text = " · "
        view.numberOfLines = 1
        view.sizeToFit()
        return view
    }()
    
    lazy var vIconView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.bounds = CGRect.init(x: 0, y: 0, width: 9, height: 9)
        view.layer.cornerRadius = 4
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        backgroundColor = UIColor.clear
        
        addSubview(bgView)
        bgView.addSubview(videoImageView)
        bgView.addSubview(lTopImageView)
        bgView.addSubview(titleLabel)
        bgView.addSubview(subTitleLabel)
        bgView.addSubview(uploaderReasonView)
        bgView.addSubview(uploaderImageView)
        bgView.addSubview(vIconView)
        bgView.addSubview(uploaderSpacingLabel)
        bgView.addSubview(uploaderNameLabel)
    }
    
    // 填充数据函数 见 ItemView12074Extension.swift

    func imageViewFrame() -> CGRect {
        let w = self.frame.size.width
        let h = ceil(w * 9.0/16.0)
        return CGRect.init(x: 0, y: 0, width: w, height: h)
    }
}
