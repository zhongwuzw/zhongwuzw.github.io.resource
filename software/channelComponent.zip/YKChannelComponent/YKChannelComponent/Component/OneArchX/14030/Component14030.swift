//
//  Component14030.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/4.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout
import OneArchSupport4Youku

class Component14030:NSObject, ComponentDelegate {
    
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {
        if let componentModel = self.component?.model as? BaseComponentModel {
            componentModel.extraExtend["aspectRatio"] = 1.78
        }
    }

    func layoutType() -> ComponentLayoutType {
        return .horizontalScroll
    }

    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.headerBottomMargin = 0.0
        config.rowSpacing = 0.0
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        config.horizontalPaddingLeft = YKNGap.youku_margin_left()
        config.horizontalPaddingRight = YKNGap.youku_margin_right()
        config.backgroundLeftMarginOffset = 0
        config.backgroundRightMarginOffset = 0
        config.headerLeftMarginOffset = 0
        config.headerRightMarginOffset = 0
        config.backgroundTopMargin = 0
        return config
    }

    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {

    }
    
    func columnCount() -> CGFloat {
        if ykrl_isResponsiveLayout() {
            return 2
        }
        
        return 2.5
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
