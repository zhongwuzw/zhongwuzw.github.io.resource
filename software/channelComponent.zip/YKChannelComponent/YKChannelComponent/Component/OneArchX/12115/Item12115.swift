//
//  Item12115.swift
//  YKChannelComponent
//
//  Created by better on 2022/10/18.
//  Copyright © 2022 Youku. All rights reserved.
//  广告小卡

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource
import YKAdSDK

class Item12115: Item12113, PlayerStatusCallback {
    var playFinish : Bool = false
    
    var ucAdModel: YKAdResponseModel?
    var isExposed = false

    override func itemDidInit() {
        let feedbackModel = createUCAdFeedbackModel(item?.itemModel) //初始化广告数据
        feedbackModel.isPadStyle = true //标识pad使用样式
        item?.itemModel?.feedbackModel = feedbackModel

        let ucAdModel = feedbackModel.ucAdModel as? YKAdResponseModel
        self.ucAdModel = ucAdModel
        
        var title = item?.itemModel?.title
        if let adtitle = ucAdModel?.firstNativeContent().title, adtitle.count > 0 {
            title = adtitle
        }
        if let title = title, title.count > 0 {
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 3.0
            paragraphStyle.lineBreakMode = .byTruncatingTail
            let attributedTitle = NSAttributedString.init(string: title, attributes: [.paragraphStyle: paragraphStyle])
            item?.itemModel?.attributedTitle = attributedTitle
        }
    }
    
    func afterReuseView(itemView: PadContentView) {
        guard let itemModel = self.item?.itemModel else {
            return
        }
    
        //player
        if let playerModel = itemModel.playerModel {
            Service.player.attach(playerModel, toView: itemView.bgView, displayFrame: itemView.imageView.bounds)

            playerModel.repeatPlay = false
            playerModel.isHideWaterMark = true
            playerModel.playerDelegate = self
            if let config = itemModel.config as? ConfigModel, let forbidAdPlay = config.getBoolValue("forbidAdPlay") as? Bool {
                if forbidAdPlay {
                    playerModel.videoURL = ""
                }
            }
            //adBizInfo
            AdPlayInfoUtil.updatePlayModelExtraWithAd(playerModel: playerModel, ucAdModel: self.ucAdModel)
        }
    }
    
    public func enterDisplayArea() {
        if let ucAdModel = self.ucAdModel {
            if !isExposed {
                isExposed = true
                YKAdReportHandler.reportUCExpose(withAdModel: ucAdModel)
            }
        }
    }
    
    func playHelper() -> YKAdPlayEventHelper? {
        return YKAdPlayEventHelper.shareInstance()
    }
    
    //MARK: PlayerStatusCallback
    func didStartPlayVideoInPlayer(_ player: PlayerView) {
        //adx预播打点-自动播放
        self.playHelper()?.url = self.ucAdModel?.firstNative().videoPlayUrl
        self.playHelper()?.commit(withEid: YKAdEid.playAutoStart.rawValue)
        playFinish = false
    }
    
    func didFinishPositiveVideoInPlayer(_ player: PlayerView) {
        //adx预播打点-完成播放
        self.playHelper()?.commit(withEid:YKAdEid.playComplete.rawValue)
        playFinish = true
    }
    
    func didClickStopPlayer(_ player: PlayerView) {
        //adx预播打点-退出播放
        if !playFinish {
            self.playHelper()?.commit(withEid:YKAdEid.playQuit.rawValue)
        }
    }
    
    func playTimeDidChange(_ player: PlayerView) {
        let duraction = self.ucAdModel?.firstNativeContentVideo().duration ?? 0
        self.playHelper()?.playTimeDidChange(Int(player.playingTime), withDurationTime: duraction)
        playFinish = false
    }
}
