//
//  Item14038.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/14.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item14038: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?

    func itemDidInit() {
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func itemWidth() -> CGFloat {
        return 60.0 * YKNSize.yk_icon_size_scale()
    }

    class func titleFont() -> UIFont {
        return YKNFont.posteritem_maintitle_m()
    }
    
    class func titleSelFont() -> UIFont {
        return YKNFont.posteritem_maintitle_m_weight(.medium)
    }
    
    class func titleHeight() -> CGFloat {
        return YKNFont.height(with: titleFont(), lineNumber: 1) + 5
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let w = 60.0 * YKNSize.yk_icon_size_scale()
        let fontHeight = YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)
        let itemHeight = w - 12 + 9 + fontHeight
        return itemHeight
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14038View(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14038View else {
            return
        }
        itemView.fillData(self.item)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }

}
