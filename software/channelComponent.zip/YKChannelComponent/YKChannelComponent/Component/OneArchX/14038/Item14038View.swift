//
//  Item14038View.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/14.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource
class Item14038View: AccessibilityView {

    lazy var iconImageView: UIImageGIFView = {
        let view = UIImageGIFView(frame: CGRect(x: 0, y: 0, width: self.width - 12, height: self.width - 12))
        view.centerX = self.width / 2.0
        view.contentMode = .scaleAspectFill
        view.layer.cornerRadius = view.height / 2.0
        view.clipsToBounds = true
        view.layer.borderColor = UIColor.ykn_brandInfo.cgColor
        return view
    }()

    lazy var titleLabel: UILabel = {
        let fontHeight = YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)
        let label = UILabel(frame: CGRect(x: 0, y: self.iconImageView.bottom + 4, width: self.width, height: fontHeight))
        label.textAlignment = .center
        label.font = YKNFont.posteritem_subhead()
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(iconImageView)
        self.addSubview(titleLabel)
        NotificationCenter.default.addObserver(self, selector: #selector(refreshFont), name: NSNotification.Name("comp.navigate.index.changed"), object: nil)
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    weak var item:IItem?
    func fillData(_ item:IItem?) {
        self.item = item
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        self.iconImageView.cms_setImage(withURLString: itemModel.img, placeholderImage: UIImage.init(named: "head_default"), module: nil, imageSize: self.iconImageView.bounds.size, parameters: ["fade":true], completed: nil)
        self.titleLabel.text = itemModel.title
        refreshFont()
        //埋点
        Service.statistics.bind(itemModel.action?.report, self, .Defalut)
        //点击
        weak var weakself = self
        self.whenTapped {
            if let item = weakself?.item, let componentModel = item.getComponent()?.model as? BaseComponentModel {
                componentModel.extraExtend["navigate.index"] = item.index
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "comp.navigate.index.changed"), object: nil, userInfo: nil)
                item.getComponent()?.changeMultiTabComponentIndex(item.index)
            }
        }
    }
    
    func isItemSelected() -> Bool {
        guard let item = self.item else {
            return ((self.item?.index) ?? 0) == 0
        }
        if let componentModel = item.getComponent()?.model as? BaseComponentModel {
            if let selIndex = componentModel.extraExtend["navigate.index"] as? Int {
                return (selIndex == item.index)
            }
        }
        return ((self.item?.index) ?? 0) == 0
    }
    
    @objc func refreshFont() {
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        if self.isItemSelected() {
            self.titleLabel.font = YKNFont.posteritem_subhead_weight(YKNFontWeight.semibold)
            self.titleLabel.textColor = sceneUtil(.ykn_brandInfo,
                                                  sceneColor:itemModel.scene?.sceneThemeColor())
            self.iconImageView.layer.borderColor = sceneUtil(.ykn_brandInfo,
                                                             sceneColor:itemModel.scene?.sceneThemeColor())?.cgColor
            self.iconImageView.layer.borderWidth = 1
        } else {
            self.titleLabel.font = YKNFont.posteritem_subhead()
            self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo,
                                           sceneColor:itemModel.scene?.sceneButtonTextColor())
            self.iconImageView.layer.borderWidth = 0
        }
    }
}
