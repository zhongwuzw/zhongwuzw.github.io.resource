//
//  Item14348ContentView.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/8/7.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import YKUIComponent
import YKChannelPage
import YKHome
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item14348ContentView : UIView {
    
    lazy var videoImageView: BaseVideoImageView = {
        return BaseVideoImageView(frame: .zero)
    }()
    
    lazy var titleLabel: MarginLabel = {
        let view = MarginLabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.verticalAlignment = .top
        view.numberOfLines = 2
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var reasonList: ReasonListView = {
        let view = ReasonListView.init()
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(videoImageView)
        self.addSubview(titleLabel)
        self.addSubview(subtitleLabel)
        self.addSubview(reasonList)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(item:IItem?, ratio:CGFloat) {
    
        guard let itemModel = item?.model as? BaseItemModel,
              let compModel = item?.getComponent()?.model as? BaseComponentModel else {
            return
        }
        // image
        self.videoImageView.size = CGSize.init(width: self.width, height: ceil(self.width / ratio))
        self.videoImageView.fillData(item: item)

        //title
        self.titleLabel.frame = item?.layout?.title?.renderRect ?? CGRect.zero
        self.titleLabel.numberOfLines = compModel.enableNewLine ? 2 : 1
        if (compModel.enableNewLine) {
            self.titleLabel.text = nil
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 2.0
            paragraphStyle.lineBreakMode = .byTruncatingTail
            let attributedTitle = NSAttributedString.init(string: itemModel.title ?? "", attributes: [.paragraphStyle: paragraphStyle])
            self.titleLabel.attributedText = attributedTitle
        } else {
            self.titleLabel.attributedText = nil
            self.titleLabel.text = itemModel.title
        }
        
        //subtitle & reasonList
        if let reasonList = itemModel.reasonList, reasonList.count > 0 {
            self.reasonList.fillData(itemModel.reasonList, maxWidth: item?.layout?.subtitle?.renderRect.width ?? 0)
            if self.reasonList.canShow {
                self.reasonList.frame = item?.layout?.subtitle?.renderRect ?? CGRect.zero
                self.reasonList.isHidden = false
                self.subtitleLabel.isHidden = true
            } else {
                self.subtitleLabel.frame = item?.layout?.subtitle?.renderRect ?? .zero
                self.subtitleLabel.text = itemModel.subtitle
                self.reasonList.isHidden = true
                self.subtitleLabel.isHidden = false
            }
        } else {
            self.subtitleLabel.frame = item?.layout?.subtitle?.renderRect ?? .zero
            self.subtitleLabel.text = itemModel.subtitle
            self.reasonList.isHidden = true
            self.subtitleLabel.isHidden = false
        }
        
        //绑定事件
        Service.action.bind(itemModel.action, self)
    }
    
}
