//
//  Item14348.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/8/6.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import YoukuAnalytics
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item14348:NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    lazy var novelHandler:ItemNovelADHandler = {
        let handler = ItemNovelADHandler()
        return handler
    }()
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }

    func loadEventHandlers() -> [ItemEventHandler]? {
        return [novelHandler]
    }
    
    func itemDidInit() {
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        guard let _ = self.item?.model as? BaseItemModel else {
            return 0.0
        }
        return preCaculateLayout(itemWidth, item)
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return Item14348ContentView.init()
    }

    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14348ContentView else {
            return
        }
        itemView.fillData(item:self.item, ratio:0.75)
        //广告通知
        self.item?.getComponent()?.sendEventMessage("item.reuseView", params: ["index":self.item?.index ?? 0])
    }
    
    func preCaculateLayout(_ itemWidth: CGFloat, _ item: IItem?) -> CGFloat {
        guard let tempItemModel = item?.itemModel else {
            return 0
        }
        
        // 封面图
        let imageSize = videoImageSize(itemWidth)
        let coverLayout = ImageLayoutModel.init()
        coverLayout.boundingSize = imageSize
        coverLayout.renderRect = CGRect(origin: .zero, size: imageSize)
        item?.layout?.cover = coverLayout
        
        //cache
        if let mark = tempItemModel.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: imageSize)
            item?.layout?.mark = layout
        }
        
        if let summary = tempItemModel.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize:imageSize)
            item?.layout?.summary = layout
        }
        
        if let lbTexts = tempItemModel.lbTexts {
            let layout = Service.lbTexts.estimatedLayout(lbTexts, toViewSize:imageSize)
            item?.layout?.lbTexts = layout
        }
        
        //主标题
        let titleLayout = TextLayoutModel.init()
        let titleY = imageSize.height + YKNGap.youku_picture_title_spacing()
        titleLayout.renderRect = CGRect.init(x: 0,
                                             y: titleY,
                                             width: imageSize.width,
                                             height: YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1))
        item?.layout?.title = titleLayout
        
        let subtitleWidth:CGFloat = imageSize.width

        //副标题
        let subtitleLayout = TextLayoutModel.init()
        let subtitleY = imageSize.height
            + YKNGap.youku_picture_title_spacing()
            + YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
            + YKNGap.youku_maintitle_subtitle_spacing()
        subtitleLayout.renderRect = CGRect.init(x: 0,
                                                y: subtitleY,
                                                width: subtitleWidth,
                                                height: 18.0)
        item?.layout?.subtitle = subtitleLayout
        
        //item height
        let textAreaH = Double(ceil(titleLayout.renderRect.height + subtitleLayout.renderRect.height + YKNGap.youku_picture_title_spacing() + YKNGap.youku_maintitle_subtitle_spacing()))
        let itemHeight = imageSize.height + textAreaH
        
        return itemHeight
    }
    
    func videoImageSize(_ itemWidth: CGFloat) -> CGSize {
        var ratio = 0.75
        if let componentModel = self.item?.getComponent()?.model as? BaseComponentModel,
           let aspectRatio = componentModel.extraExtend["aspectRatio"] as? Double,
            aspectRatio > 0 {
            ratio = aspectRatio
        }
        return CGSize.init(width: itemWidth, height: ceil(itemWidth / ratio))
    }
    
    
}
