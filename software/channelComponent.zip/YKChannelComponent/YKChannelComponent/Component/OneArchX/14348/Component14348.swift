//
//  Component14348.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/8/6.
//  Copyright © 2024 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku
import YKResponsiveLayout

class Component14348: NSObject, ComponentDelegate {
    
    var componentWrapper: ComponentWrapper?
    
    lazy var novelHandler: ComponentNovelADHandler = {
        let handler = ComponentNovelADHandler()
        return handler
    }()
    
    func componentDidInit() {
        if let componentModel = self.component?.model as? BaseComponentModel {
            componentModel.extraExtend["aspectRatio"] = 0.75
        }
        self.novelHandler.requestNovelData()
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeADComponentModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_comp_margin_bottom()
        if ykrl_isResponsiveLayout() {
            config.rowSpacing = 18 // 20221129版本 目标值18，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        if ykrl_isResponsiveLayout() {
            config.footerTopMargin = -9.0 // 20221129版本 目标值上下距离18，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        config.footerBottomMargin = YKNGap.youku_comp_margin_bottom()
        config.responsiveLayoutMustAligned = false
        if ykrl_isResponsiveLayout() ,
            let superCard = self.component?.getCard()?.getSuperCard(), superCard.model?.type == "15001" { //响应式，多tab抽屉里要对齐
            config.responsiveLayoutMustAligned = true
        }
        return config
    }
    
    func columnCount() -> CGFloat {
        return 3
    }
    
    /// 是否展示组件尾
    func isShowFooter() -> Bool {
        guard let componentModel = self.component?.model as? BaseComponentModel else {
            return false
        }
        if let change = componentModel.change, change.changeOnDrawer == true {
            return false
        }
        if componentModel.enter != nil || componentModel.change != nil {
            return true
        }
        return false
    }

    func footerTag() -> String? {
        return "comp.generic.footer"
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [self.novelHandler]
    }
    
    func getItemJsonExtracter() -> (any ItemJsonExtracter)? {
        let extracter = Item14002JsonExtracter()
        extracter.component = self.component
        return extracter
    }
    
}

