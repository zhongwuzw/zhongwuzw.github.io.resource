//
//  Item13017.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/12/26.
//  Copyright © 2023 Youku. All rights reserved.
//  热播中插播放大卡

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKSCService

class Item13017 : BaseItemDelegate, PlayerStatusCallback {
    
    override func itemDidInit() {
        super.itemDidInit()
        
        // 替换埋点数据
        if let itemModel = item?.itemModel, let action = itemModel.action,
            let previewVid = itemModel.previewModel?.vid, previewVid.count > 0 {
            UtilityHelper.replaceReportModelForPreview(actionModel: action, previewVid: previewVid)
            print("[热播大卡] spm scm调整")
        }
    }
    
    override func forceSingleColumn() -> Bool {
        return true
    }
    
    override func loadEventHandlers() -> [ItemEventHandler]? {
        var handlers = super.loadEventHandlers()
        let toolHandler = PlayerToolsEventHandler()
        
        let addArr = [
            PlayerScrollEndItemEventHandler(),
            ItemPlayerProgressEventHandler(),
        ]
        handlers?.append(contentsOf: addArr)
        return handlers
    }
    
    override func reuseView(itemView: UIView) {
        super.reuseView(itemView: itemView)
        
        guard let itemView = itemView as? BaseItemContentView,
              let itemModel = self.item?.itemModel else {
            return
        }
        
        // 绑定player
        if let playerModel = itemModel.playerModel {
            print("[热播大卡] \(YKCCUtil.objAddress(self)) 绑定player vid:\(String(describing: playerModel.playerId))")
            playerModel.repeatPlay = true
            playerModel.isHideWaterMark = true
            playerModel.playerDelegate = self
            
            let size = itemModel.layout.cover?.boundingSize ?? .zero
            Service.player.attach(playerModel,
                                  toView: itemView.videoImageView,
                                  displayFrame: CGRect.init(origin: CGPoint.zero, size: size))
        }
        
        // 负反馈回调
        Service.feedback.detachFeedbackView()
        weak var weakItem = self.item
        Service.feedback.attach(itemModel.feedbackModel, toView: itemView, morePos: .BottomRight, isSupportUndo: true) {
            guard let _item = weakItem else {
                return
            }
            
            print("[热播大卡] 负反馈移除")
            _item.getComponent()?.getItemManager()?.removeItem(item: _item, animated: true)
        }
    }
    
    // MARK: - PlayerStatusCallback
    func didStartPlayVideoInPlayer(_ player: PlayerView) {
        print("[热播大卡] \(YKCCUtil.objAddress(self)) 视频开始")
        
        self.saveShowNum()
    }
    
    func didFinishPositiveVideoInPlayer(_ player: PlayerView) {
        print("[热播大卡] \(YKCCUtil.objAddress(self)) 视频结束")
    }
    
    func player(_ player: PlayerView, playError errorCode: Int) {
        print("[热播大卡] \(YKCCUtil.objAddress(self)) 视频错误:\(errorCode)")
    }
    
    func playTimeDidChange(_ player: PlayerView) {
        print("[热播大卡] \(YKCCUtil.objAddress(self)) 视频播放中:\(player.playingTime)s")
    }
    
    func saveShowNum() {
        (self.item?.getComponent()?.compModel as? Component14001Model)?.item13017DLService?.saveShowNum()
    }
}
