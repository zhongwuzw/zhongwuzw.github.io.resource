//
//  Item14345.swift
//  YKChannelComponent
//
//  Created by Mingyu on 2024/7/5.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import NovelAdSDK

class Item14345: BaseItemDelegate, ItemLifeCycleEventHandlerDelegate {
    
    let api = NadAPI()
    var adModel: OADModel?
    
    var isVisible: Bool = false
    var isActived: Bool = true
        
    lazy var lifeCycleEventHandler:ItemLifeCycleEventHandler = {
        let handler = ItemLifeCycleEventHandler()
        handler.delegate = self
        return handler
    }()
    
    override func loadEventHandlers() -> [ItemEventHandler]? {
        var handlers = super.loadEventHandlers()
        handlers?.append(lifeCycleEventHandler)
        return handlers
    }
    
    override func disableLongPress() -> Bool {
        return true
    }
    
    override func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }

    override func itemDidInit() {
        parseAd()
    }
    
    override func createView(_ itemSize: CGSize) -> UIView {
        let itemView = OADItemView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView;
    }
    
    override func reuseView(itemView: UIView) {
        guard let itemView = itemView as? OADItemView else {
            return
        }
        guard let adModel = self.adModel else {
            return
        }
        itemView.setup(model: adModel, ratio: getImageAspectRatio(), item: self.item)
        tryExpose()
    }
        
    override func reuseId() -> String? {
        return "Item14345.item.reuseid"
    }

    func tryExpose() {
        if isVisible && isActived {
            adModel?.adExposure()
        }
    }
    
    func parseAd() {
        if let itemModel = self.item?.model as? BaseItemModel, let dataInfo = itemModel.data, let adJson = dataInfo["ad"] as? [String: Any], !adJson.isEmpty {
            self.adModel = self.api.getAd(adJson)
            self.adModel?.setEnableExposureOnce(true)

            //补坑位数据，以获取正确高度
            itemModel.title = self.adModel?.mainTitle
            itemModel.subtitle = self.adModel?.subTitle
        }
    }
    
    override func enterDisplayArea(itemView: UIView?) {
        isVisible = true
        tryExpose()
    }
    
    override func exitDisplayArea(itemView: UIView?) {
        isVisible = false
    }
    
    override func didActivate() {
        isActived = true
    }
    
    override func didDeactivate() {
        isActived = false
    }
    
    override func appWillResignActive() {}
    
}

