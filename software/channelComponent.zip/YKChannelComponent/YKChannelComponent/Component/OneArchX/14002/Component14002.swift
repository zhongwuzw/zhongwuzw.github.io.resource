//
//  Component14002.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/28.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku
import YKResponsiveLayout

class Component14002: NSObject, ComponentDelegate {
   
    var componentWrapper: ComponentWrapper?
    var javisHandler: JarvisRecommendedHandler?
    lazy var novelHandler: ComponentNovelADHandler = {
        let handler = ComponentNovelADHandler()
        return handler
    }()
    
    func componentDidInit() {
        if let componentModel = self.component?.model as? BaseComponentModel {
            componentModel.extraExtend["aspectRatio"] = 0.75
        }
        self.javisHandler = JarvisRecommendedHandler(self)
        self.novelHandler.requestNovelData()
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeADComponentModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        self.javisHandler?.saveUsedDomainDataIfNeeded()
        return .columnAverage
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_comp_margin_bottom()
        if ykrl_isResponsiveLayout() {
            config.rowSpacing = 18 // 20221129版本 目标值18，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        if ykrl_isResponsiveLayout() {
            config.footerTopMargin = -9.0 // 20221129版本 目标值上下距离18，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        config.footerBottomMargin = YKNGap.youku_comp_margin_bottom()
        config.responsiveLayoutMustAligned = false
        if ykrl_isResponsiveLayout() ,
            let superCard = self.component?.getCard()?.getSuperCard(), superCard.model?.type == "15001" { //响应式，多tab抽屉里要对齐
            config.responsiveLayoutMustAligned = true
        }
        return config
    }
    
    func columnCount() -> CGFloat {
        return 3
    }
    
    /// 是否展示组件尾
    func isShowFooter() -> Bool {
        guard let componentModel = self.component?.model as? BaseComponentModel else {
            return false
        }
        if let change = componentModel.change, change.changeOnDrawer == true {
            return false
        }
        if componentModel.enter != nil || componentModel.change != nil {
            return true
        }
        return false
    }

    func footerTag() -> String? {
        return "comp.generic.footer"
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [self.novelHandler]
    }
    
    func getItemJsonExtracter() -> (any ItemJsonExtracter)? {
        let extracter = Item14002JsonExtracter()
        extracter.component = self.component
        return extracter
    }

}

class Item14002JsonExtracter: DefaultItemJsonExtracter {
    weak var component: IComponent?
    
    override func getItemsJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error> {
        guard let itemsJson = componentJson?["nodes"] as? [[String: Any]], itemsJson.count > 0 else {
            return .success([[String : Any]]()) //允许没有坑位列表
        }
        
        var newJson = itemsJson
        if let dataInfo = componentJson?["data"] as? [String: Any],
           let ykAdvertConfig = dataInfo["ykAdvertConfig"] as? [String:Any], ykAdvertConfig.count > 0 {
            if let advertMode = ykAdvertConfig["advertMode"] as? String, advertMode == AdvertMode.replace.rawValue {
                if self.component?.getPage()?.dataState == .network {
                    if let index = YKCCUtil.getIntValue(ykAdvertConfig["index"]), index > 0 && index <= newJson.count { // index从1开始
                        var itemJson = newJson[index-1]
                        itemJson["type"] = 14339 //映射成新类型, 14002 -> 14339
                        newJson[index-1] = itemJson
                    }
                }
            }
        }
        return .success(newJson)
    }
    
}
