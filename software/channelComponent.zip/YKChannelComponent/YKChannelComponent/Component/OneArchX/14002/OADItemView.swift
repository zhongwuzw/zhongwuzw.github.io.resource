//
//  OAdItemView.swift
//  YKChannelComponent
//
//  Created by wustlj on 2024/6/6.
//  Copyright © 2024 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import NovelAdSDK
import OneArch
import OneArchSupport4Youku

class OADArrowMarkView: UIView {
    var showFeedback: Bool = false
    
    lazy var feedbackView: UIImageView = {
        let view = UIImageView.init(frame: CGRectMake(0, 0, 9, 5));
        view.image = UIImage.init(named: "ad_arrow")
        view.isUserInteractionEnabled = true
        return view
    }()
    
    lazy var markView: OADMarkView = {
        let view = OADMarkView.init(frame: CGRect.zero)
        let font = YKNFont.corner_text_weight(.medium)
        view.setFont(font, textColor: UIColor.white, backgroundColor: UIColor.clear, cornerRadius: 0, borderColor: nil, borderWidth: 0)
        view.setPaddingHorizontal(6, paddingVertical: 3, maxWidth: max(150, self.width))
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(markView)
        addSubview(feedbackView)
        
        self.isUserInteractionEnabled = true
        self.backgroundColor = UIColor.init(red: 0, green: 0, blue: 0, alpha: 0.5)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(_ model: OADModel) {
        showFeedback = OADUtil.shouldShowFeedback(model)
        
        markView.fillData(model)
        let markSize = markView.getSize()
        markView.size = markSize
        
        feedbackView.isHidden = !showFeedback
        
        if showFeedback {
            self.width = markSize.width + feedbackView.width + 6
            self.height = max(markSize.height, 15)
            
            feedbackView.right = self.width - 6
            feedbackView.centerY = self.height / 2
            
            markView.right = feedbackView.left
            markView.centerY = self.height / 2
        } else {
            self.width = markSize.width
            self.height = max(markSize.height, 15)
            markView.right = self.width
            markView.centerY = self.height / 2
        }
         
        addRoundingCorners([.bottomLeft, .topRight], radius: YKNCorner.radius_secondary_medium())
    }
    
    func addRoundingCorners(_ corners: UIRectCorner, radius: Double) {
        if radius <= 0 {
            return
        }
        
        let maskPath = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = self.bounds
        maskLayer.path = maskPath.cgPath
        self.layer.mask = maskLayer
    }
}

class OADItemView: BaseItemContentView {
    
    lazy var oadMarkView: OADArrowMarkView = {
        let view = OADArrowMarkView.init(frame: CGRect.zero)
        return view
    }()

    func setup(model:OADModel?, ratio: CGFloat, item: IItem?) {
        guard let model = model else {
            return
        }
                
        var imageRatio = ratio
        if imageRatio == 0 {
            imageRatio = RATIO_9_16
        }
        
        // 封面
        self.videoImageView.frame = CGRectMake(0, 0, self.width, ceil(self.width / imageRatio))
        var imgUrl = ""
        if model.resType == "img" {
            imgUrl = model.resUrl ?? ""
        } else if model.resType == "video" {
            imgUrl = model.thumbnail ?? ""
        }
        self.videoImageView.ykn_setImage(withURLString: imgUrl, module: "", imageSize: .zero, parameters: nil, completed: nil)
        if imgUrl.count == 0 {
            self.videoImageView.backgroundColor = .ykn_primaryFill
        }
        
        self.videoImageView.isUserInteractionEnabled = true
        self.videoImageView.addSubview(oadMarkView)
        oadMarkView.fillData(model)
        oadMarkView.top = 0
        oadMarkView.right = self.videoImageView.width
        
        weak var weakself = self
        oadMarkView.whenTapped {
            if let weakself = weakself {
                OADFeedbackService.sharedInstance().attachFeedback(model,
                                                                   from: weakself.oadMarkView.feedbackView,
                                                                   with: weakself) {
                    
                } didDetach: {
                    
                }
            }
        }
        
        // 子标题
        let subtitleY = self.videoImageView.height
            + YKNGap.youku_picture_title_spacing()
            + YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
            + YKNGap.youku_maintitle_subtitle_spacing()
        let subtitleH = YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)
        self.subtitleLabel.frame = CGRect.init(x: 0, y: subtitleY, width: self.width,
                                                height: subtitleH)
        
        // 标题
        let h = ceil(38.0 * YKNSize.yk_icon_size_scale())
        self.titleLabel.frame = CGRectMake(0, self.videoImageView.height + YKNGap.youku_picture_title_spacing(), self.width, h)
        
        if let subtitle = model.subTitle, subtitle.count > 0 {
            self.titleLabel.numberOfLines = 1
            self.titleLabel.attributedText = nil
            self.titleLabel.text = model.mainTitle
            
            self.subtitleLabel.text = model.subTitle
            self.subtitleLabel.isHidden = false
        } else {
            self.titleLabel.numberOfLines = 0
            self.titleLabel.text = nil
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 2.0
            paragraphStyle.lineBreakMode = .byTruncatingTail
            let attributedTitle = NSAttributedString.init(string: model.mainTitle ?? "广告", attributes: [.paragraphStyle: paragraphStyle])
            self.titleLabel.attributedText = attributedTitle
            
            self.subtitleLabel.isHidden = true
        }
        
        // 氛围
        if let itemModel = item?.model as? BaseItemModel {
            let scene = itemModel.scene
            self.backgroundColor = .clear //sceneUtil(.clear, sceneColor: scene?.sceneBgColor())
            self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: scene?.sceneTitleColor())
        }
                
        // 有效触点监测
        model.adEtpView = self
        
        self.whenTapped {
            model.adClickAction()
        }
        
        model.handleCSJEvent(self, withClickableViews: [self]);
    }
}
