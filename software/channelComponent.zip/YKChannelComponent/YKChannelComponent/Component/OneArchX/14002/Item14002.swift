//
//  Item14002.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/7/9.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import OneArch
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Item14002: BaseItemDelegate {
    lazy var novelHandler:ItemNovelADHandler = {
        let handler = ItemNovelADHandler()
        return handler
    }()
    override func loadEventHandlers() -> [ItemEventHandler]? {
        var handlers = super.loadEventHandlers()
        handlers?.append(novelHandler)
        return handlers
    }
    
    override func reuseView(itemView: UIView) {
        super.reuseView(itemView: itemView)
        self.item?.getComponent()?.sendEventMessage("item.reuseView", params: ["index":self.item?.index ?? 0])
    }
}
