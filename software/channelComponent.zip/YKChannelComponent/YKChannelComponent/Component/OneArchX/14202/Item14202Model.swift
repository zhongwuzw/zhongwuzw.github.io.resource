//
//  Item14202Model.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/8/9.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku

class Item14202Model: BaseItemModel {
    
    var imageMaskColor: UIColor?
    var isBottomRoundCorner: Bool = false
    
    // 第一层tab（更名为catalogue）Model
    var cataloguesModel: [RolePageModel]?
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String: Any] else {
            return
        }
        
        if let tabInfos = dataInfo["tabs"] as? [[String: Any]] {
            var cataloguesModel = [RolePageModel]()
            for tabInfo in tabInfos {
                let aTabPageModel = RolePageModel.init()
                aTabPageModel.setup(tabInfo)
                cataloguesModel.append(aTabPageModel)
            }
            self.cataloguesModel = cataloguesModel
        }
        
        self.isBottomRoundCorner = true
    }
    
}


class RolePageModel: BasePageModel {
    
    var tabFilterItems: [RoleTabFilterItem]?
    
    override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        // 处理tabFilter
        guard let data = cmsInfo?["data"] as? [String: Any],
              let tabFilter = data["tabFilter"] as? [[String: Any]], tabFilter.count > 0 else {
            return
        }
        // 创建
        tabFilterItems = [RoleTabFilterItem]()
        for value in tabFilter {
            let tabFilterItem = RoleTabFilterItem()
            tabFilterItem.setup(value)
            tabFilterItems?.append(tabFilterItem)
        }
    }
}


class RoleTabFilterItem {
    var checked: Bool = false
    var label: String?
    var value: String?
    
    func setup(_ dataInfo: [String : Any]?) {
        checked = (dataInfo?["checked"] as? Bool) ?? false
        label = dataInfo?["label"] as? String
        value = dataInfo?["value"] as? String
    }
    
}
