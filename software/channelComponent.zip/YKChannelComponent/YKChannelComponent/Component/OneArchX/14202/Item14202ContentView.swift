//
//  Item14202ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/8/9.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import SDWebImage
import YoukuResource
import YKUIComponent
import YKChannelPage
import OneArchSupport
import YoukuAnalytics
import YKResponsiveLayout
import OneArchSupport4Youku

class Item14202ImageView: UIImageGIFView {
    var identifier: String = ""
}

class Item14202ContentView: UIView, YKTabMenuDelegate, YKNActionSheetDelegate {

    //MARK: - Property
    weak var item: IItem?
    var itemModel: Item14202Model?
    var tabFilterItem: RoleTabFilterItem?
    
    lazy var imageView: Item14202ImageView = {
        let imageView = Item14202ImageView()
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    lazy var contentView: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var iconImageView: Item14202ImageView = {
        let imageView = Item14202ImageView()
        imageView.contentMode = .scaleAspectFit
        imageView.backgroundColor = .ykn_primaryFill
        imageView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        imageView.layer.masksToBounds = true
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    lazy var menuView: YKTabMenu = {
        let tabMenu = YKTabMenu.init(frame: .zero)
        tabMenu.delegate = self
        return tabMenu
    }()
    
    lazy var filterBtn: UIButton = {
        let btn = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 57.0, height: 40.0))
        btn.setImage(UIImage(named: "role_filter_icon"), for: .normal)
        btn.setTitleColor(UIColor(hexRGB: "#cccccc"), for: .normal)
        btn.titleLabel?.font = YKNFont.carditem_maintitle()
        btn.titleEdgeInsets = UIEdgeInsets(top: 0, left: 1.5, bottom: 0, right: -1.5)
        btn.imageEdgeInsets = UIEdgeInsets(top: 0, left: -1.3, bottom: 0, right: 1.5)
        btn.addTarget(self, action: #selector(filterAction), for: .touchUpInside)
        btn.isHidden = true
        return btn
    }()
    
    lazy var bottomRoundSpacingView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.ykn_primaryBackground
        
        let height: CGFloat = nodePageHeaderCompoenentBottomRoundSpacingHeight()
        let maskFrame = CGRect.init(x: 0, y: 0, width: self.width, height: height * 2)
        let maskPath = UIBezierPath.init(roundedRect: maskFrame,
                                         byRoundingCorners: [.topLeft, .topRight],
                                         cornerRadii: CGSize.init(width: height, height: height))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = maskFrame
        maskLayer.path = maskPath.cgPath
        view.layer.mask = maskLayer
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(imageView)
        addSubview(contentView)
        contentView.addSubview(iconImageView)
        contentView.addSubview(menuView)
        contentView.addSubview(filterBtn)
        contentView.addSubview(bottomRoundSpacingView)
        
        imageView.frame = self.bounds
        
        let statusBarOffset = STATUSBAR_HEIGHT - 20.0
        contentView.frame = CGRect.init(x: 0, y: statusBarOffset, width: self.width, height: self.height - statusBarOffset)
        
        let iconHeight: CGFloat = 26
        let offset: CGFloat = 48 + nodePageHeaderCompoenentBottomRoundSpacingHeight()
        let iconY = contentView.height - iconHeight - offset
        iconImageView.frame = CGRect.init(x: 0, y: iconY, width: contentView.width, height: iconHeight)

        menuView.scrollView.bounces = false
        menuView.showSelectedSlider = false
        
        let itemSpacing = 24.0
        let paddingLeft = YKNGap.youku_margin_left() - itemSpacing / 2
        let paddingRight = YKNGap.youku_margin_right() - itemSpacing / 2
        menuView.padding = .init(top: 0, left: paddingLeft, bottom: 0, right: paddingRight)
        menuView.itemSpacing = itemSpacing
        
        menuView.selectedFont = UIFont.systemFont(ofSize: 18, weight: .medium)
        menuView.unselectedFont = UIFont.systemFont(ofSize: 15, weight: .regular)
        menuView.selectedScale = 1.0
        menuView.tabItemHeight = 40
        menuView.contentMode = .left
        menuView.selectedWhenOneItem = true
        menuView.selectedColor = UIColor.white
        menuView.unselectedColor = UIColor.white.withAlphaComponent(0.6)
    }
    
    func fillData(_ itemModel: Item14202Model) {
        self.itemModel = itemModel
        self.item = itemModel.domainObject as? IItem
        
        // 更新tabMneu
        layoutWithData(itemModel)
        
        // fill image
        var params: [String : Any]?
        let imageURL = itemModel.gifImg ?? itemModel.img
        if imageView.identifier.isEmpty || imageView.identifier != imageURL {
            params = [String : Any]()
            params?["fade"] = true
            //重复图片，无需重复加载，避免闪动一次白色底色。
            imageView.identifier = imageURL ?? ""
            imageView.ykn_setImage(withURLString: imageURL, module: "nodepage", imageSize: .zero, parameters: params, completed: nil)
        }
        
        // fill icon
        let iconURL = itemModel.icon
        if iconImageView.identifier.isEmpty || iconImageView.identifier != iconURL {
            params = [String : Any]()
            params?["fade"] = true
            params?["placeholderColor"] = UIColor.clear
            //重复图片，无需重复加载，避免闪动一次白色底色。
            iconImageView.identifier = iconURL ?? ""
            iconImageView.ykn_setImage(withURLString: iconURL, module: "nodepage", imageSize: .zero, parameters: params, completed: nil)
        }
    }
    
    func layoutWithData(_ itemModel: Item14202Model) {
        let menuViewHeight: CGFloat = 40
        var menuViewY: CGFloat = contentView.height - menuViewHeight
        
        let isBottomRoundCorner = itemModel.isBottomRoundCorner
        if isBottomRoundCorner {
            let w: CGFloat = contentView.width
            let h: CGFloat = nodePageHeaderCompoenentBottomRoundSpacingHeight()
            let x: CGFloat = 0
            let y: CGFloat = contentView.height - h
            bottomRoundSpacingView.frame = CGRect.init(x: x, y: y, width: w, height: h)
            bottomRoundSpacingView.isHidden = false
            
            menuViewY -= h
        } else {
            bottomRoundSpacingView.isHidden = true
        }
        
        filterBtn.top = menuViewY
        filterBtn.left = contentView.width - (57.0 + YKNGap.youku_margin_right() - 10)
        
        // 处理menuView
        if let tabs = itemModel.cataloguesModel, tabs.count > 0 {
            var tabMenuItems = [YKTabMenuItem]()
            var selectedIndex = 0
            var tabItemModel: RolePageModel?
            for (i, aCataloguesModel) in tabs.enumerated() {
                let item = YKTabMenuItem()
                item.title = aCataloguesModel.title
                if aCataloguesModel.checked {
                    tabItemModel = aCataloguesModel
                    selectedIndex = i
                }
                tabMenuItems.append(item)
            }
            menuView.setMenuItems(tabMenuItems, selectedIndex: selectedIndex)
            
            // 更新filterBtn的size
            var menuWidth = contentView.bounds.width
            if let tabFilterItems = tabItemModel?.tabFilterItems, tabFilterItems.count > 0 {
                menuWidth = filterBtn.left - 10.0
                updateFilterBtn(tabFilterItems)
                filterBtn.isHidden = false
            }
            
            // 更新menuView的size
            menuView.frame = CGRect.init(x: 0, y: menuViewY, width: menuWidth, height: menuViewHeight)
            if menuView.scrollView.contentSize.width > contentView.bounds.width {
                menuView.scrollView.bounces = true
            } else {
                menuView.scrollView.bounces = false
            }
        }
        
    }
    
    
    func layoutMenuAndFilter() {
        guard let itemModel = self.itemModel, let cataloguesModel = itemModel.cataloguesModel else {
            return
        }
        
        let cataIndex = menuView.selectedIndex
        guard cataIndex < cataloguesModel.count else {
            return
        }
        
        // 更新filterBtn
        var menuWidth = contentView.bounds.width
        let currentCatalogueModel = cataloguesModel[cataIndex]
        if let tabFilterItems = currentCatalogueModel.tabFilterItems, tabFilterItems.count > 0 {
            menuWidth = contentView.bounds.width - (10 + filterBtn.left)
            updateFilterBtn(tabFilterItems)
            filterBtn.isHidden = false
        } else {
            filterBtn.isHidden = true
        }
        
        // 更新menuView的size
        menuView.width = menuWidth
        if menuView.scrollView.contentSize.width > contentView.bounds.width {
            menuView.scrollView.bounces = true
        } else {
            menuView.scrollView.bounces = false
        }
        
    }
    
    func updateFilterBtn(_ tabFilterItems:[RoleTabFilterItem]) {
        var item: RoleTabFilterItem?
        //遍历选中item
        for filterItem in tabFilterItems {
            if filterItem.checked {
                item = filterItem
           }
        }
        // 兜底
        if item == nil {
            item = tabFilterItems[0]
        }
        // 更新标题
        tabFilterItem = item
        filterBtn.setTitle(item?.label, for: .normal)
        p_exposeFilter("change")
    }
    
    
    // MARK: YKTabMenuDelegate
    
    func ykTabMenu(_ tabMenu: YKTabMenu?, didSelect menuItem: YKTabMenuItem?, at index: Int) {
        guard let page = self.item?.getPage() as? IMultiPage,
              let pageModel = page.pageModel as? NodePageYKVBangRootModel,
              pageModel.cataloguesSelectedIndex != index
        else {
            return
        }
        
        pageModel.tabpagesInitFlag = false
        pageModel.cataloguesSelectedIndex = index
        
        //更新tabMenu尺寸
        layoutMenuAndFilter()
        
        // 发起请求
        var option = RequestOptions.init()
        option.source = "selectCatalogues"
        page.triggerFirstPageRequest(option)
    }
    
    func ykTabMenu(_ tabMenu: YKTabMenu?, exposureWithItemViews itemViews: [UIView]?) {
        if let itemModel = self.item?.itemModel as? Item14202Model {
            if let tabInfos = itemModel.cataloguesModel, let itemViews = itemViews, tabInfos.count == itemViews.count {
                for (index, itemView) in itemViews.enumerated() {
                    if index < tabInfos.count {
                        let tabPageModel = tabInfos[index]
                        let report = tabPageModel.action?.report
                        Service.statistics.bind(report, itemView, .Defalut)
                    }
                }
            }
        }
    }
    
    
    // MARK: filter
    @objc func filterAction() {
        // 展示筛选
        guard let itemModel = self.itemModel, let cataloguesModel = itemModel.cataloguesModel else {
            return
        }
        
        let cataIndex = menuView.selectedIndex
        guard cataIndex < cataloguesModel.count else {
            return
        }
        
        let actionSheet = YKNActionSheet.init()
        actionSheet.maxHeight = YKRLScreenHeight() - 100
        actionSheet.showsCancelButton = true
        actionSheet.delegate = self
        
        // 处理数据
        var items = [YKNActionItem]()
        let currentCatalogueModel = cataloguesModel[cataIndex]
        if let filterItems = currentCatalogueModel.tabFilterItems, !filterItems.isEmpty {
            for filterItem in filterItems {
                if let actionSheetItem = YKNActionItem.init(title: filterItem.label) {
                    actionSheetItem.showAttentionColor = filterItem.checked
                    actionSheetItem.attentionColor = UIColor.ykn_brandInfo
                    actionSheetItem.style = .default
                    items.append(actionSheetItem)
                    if filterItem.checked {
                        tabFilterItem = filterItem
                    }
                }
            }
        }
        actionSheet.items = items
        actionSheet.show()
        
        // 点击埋点
        p_clickFilter("change")
        // 弹窗曝光埋点
        p_exposeFilter("select")
    }

    // objc方法必须写在主类
    @objc func actionSheet(_ actionSheet: YKNActionSheet!, didSelectItemAt index: Int) {
        p_actionSheet(actionSheet, didSelectItemAt: index)
    }
    
    
    // MARK: bizContext
    fileprivate func updateBizContext() {
        if let requestModel = getRequestModel() {
            if let dic = requestModel.bizContext as? [String: Any] {
                var tmpDic = dic
                tmpDic["tabFilter"] = tabFilterItem?.value
                requestModel.bizContext = tmpDic
            } else if let value = requestModel.bizContext as? String, !value.isEmpty, let dic = stringValueToDic(value) {
                var tmpDic = dic
                tmpDic["tabFilter"] = tabFilterItem?.value
                requestModel.bizContext = dicValueToString(tmpDic)
            }
        }
    }
    
    private func getRequestModel() -> RequestModel? {
        guard let multiPage = item?.getPage() as? IMultiPage,
              let pageModel = multiPage.pageModel as? NodePageYKVBangRootModel else {
            return nil
        }
        
        let selectedIndex = pageModel.cataloguesSelectedIndex
        let requestModels = pageModel.cataloguesRequestModel
        if selectedIndex < requestModels.count {
            return requestModels[selectedIndex]
        } else {
            return nil
        }
    }
    
}


extension Item14202ContentView {
    
    func p_actionSheet(_ actionSheet: YKNActionSheet, didSelectItemAt index: Int) {
        guard let itemModel = self.itemModel, let cataloguesModel = itemModel.cataloguesModel else {
            return
        }
        
        //获取选中当前tab
        let cataIndex = menuView.selectedIndex
        guard cataIndex < cataloguesModel.count else {
            return
        }
        let currentCatalogueModel = cataloguesModel[cataIndex]
        
        // 获取筛选项
        guard let tabFilterItems = currentCatalogueModel.tabFilterItems, tabFilterItems.count > 0 else {
            return
        }
        
        for (i, filterItem) in tabFilterItems.enumerated() {
            filterItem.checked = (i == index)
            if filterItem.checked {
                tabFilterItem = filterItem
            }
        }
        
        // 刷新UI，更新按钮
        filterBtn.setTitle(tabFilterItem?.label, for: .normal)
        // 点击埋点
        p_clickFilter("select")
        
        // 重新请求数据
        if let page = self.item?.getPage() as? IMultiPage, let pageModel = page.pageModel as? NodePageYKVBangRootModel {
            // 更新bizContext
            updateBizContext()
            //重置标识
            pageModel.tabpagesInitFlag = false
            // 触发请求
            var option = RequestOptions.init()
            option.source = "selectCatalogues"
            option.useCacheStrategy = .none
            item?.getPage()?.triggerFirstPageRequest(option)
        }
    }
    
    
    func p_exposeFilter(_ spmD: String) {
        guard let itemModel = self.itemModel, let cataloguesModel = itemModel.cataloguesModel else {
            return
        }
        //获取选中当前tab
        let cataIndex = max(menuView.selectedIndex, 0)
        guard cataIndex < cataloguesModel.count else {
            return
        }
        let currentCatalogueModel = cataloguesModel[cataIndex]
        //手动发一次曝光
        if let report = currentCatalogueModel.action?.report, let tmpReport = report.replaceSpmD(spmd: spmD) {
            tmpReport.spmC = "filter"
            tmpReport.spm = (report.spmAB ?? "") + "." + (tmpReport.spmC ?? "") + "." + spmD
            tmpReport.args?["spm"] = tmpReport.spm
            tmpReport.trackInfoDic?["label"] = tabFilterItem?.label
            if let trackInfoInfo = tmpReport.trackInfoDic {
                tmpReport.args?["track_info"] = dicValueToString(trackInfoInfo)
            }
            YoukuAnalytics.sharedInstance()?.collectALiCustomEvent(withEventID: "2201",
                                                                   pageName: tmpReport.pageName,
                                                                   arg1: nil,
                                                                   arg2: nil,
                                                                   args:tmpReport.args)
        }
        
    }
    
    func p_clickFilter(_ spmD: String) {
        guard let itemModel = self.itemModel, let cataloguesModel = itemModel.cataloguesModel else {
            return
        }
        //获取选中当前tab
        let cataIndex = menuView.selectedIndex
        guard cataIndex < cataloguesModel.count else {
            return
        }
        let currentCatalogueModel = cataloguesModel[cataIndex]
        //点击
        if let report = currentCatalogueModel.action?.report, let tmpReport = report.replaceSpmD(spmd: spmD) {
            tmpReport.spmC = "filter"
            tmpReport.spm = (report.spmAB ?? "") + "." + (tmpReport.spmC ?? "") + "." + spmD
            tmpReport.args?["spm"] = tmpReport.spm
            tmpReport.trackInfoDic?["label"] = tabFilterItem?.label
            if let trackInfoInfo = tmpReport.trackInfoDic {
                tmpReport.args?["track_info"] = dicValueToString(trackInfoInfo)
            }
            YoukuAnalytics.sharedInstance().collectSPMPageClick(withPage: tmpReport.pageName,
                                                                controlName: tmpReport.controlName,
                                                                spm: tmpReport.spm,
                                                                extend: tmpReport.args)
        }
        
    }
    
}
