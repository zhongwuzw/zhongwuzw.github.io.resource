//
//  Item14202.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/8/9.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource
import YKChannelPage
import YKResponsiveLayout

class Item14202: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    weak var contentView: Item14202ContentView? //弱持有视图
    
    func getModelClass<T: NodeModel>() -> T.Type? {
        return Item14202Model.self as? T.Type
    }
    
    func itemDidInit() {
        
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return backgroundImageSize().height
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14202ContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14202ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? Item14202Model else {
            return
        }

        itemView.fillData(itemModel)
        self.contentView = itemView
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [
            ItemImmersionBackgroundAdapterPlugin()
        ]
    }
    
    func backgroundImageSize() -> CGSize {
        var itemHeight: CGFloat = 150 //兜底值，正常case不适用
        
        if let page = self.item?.getPage() as? IMultiPage,
           let pageProxy = page.getPageDelegate() as? YKMultiPageProxy {
            itemHeight = pageProxy.navigationBarHeight()
        }
        
        return .init(width: YKRLScreenWidth(), height: itemHeight)
    }
    
}


