//
//  RoleRankGaiaXModel.swift
//  YKChannelComponent
//
//  Created by zhangjc on 2023/11/27.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import YKResponsiveLayout
import GaiaXCore
import OneArch
import GaiaX


class RoleRankGaiaXModel: NodeModel {
    /// 组件/坑位高度
    var itemWidth = 0.0
    var itemHeight = 0.0
        
    /// 模板Config信息
    var config: [String: Any]?
    var configData: [String: Any]?
    
    /// 数据源
    var sourceData: [String: Any]?
    
    /// 模板信息 & 数据
    var templateItem = GaiaXTemplateItem()
    var templateData = GaiaXTemplateData()
    
    /// 排行编号
    public var rankIndex: Int = 0
    /// 是否展示排行
    public var rankInvolved: Bool = false
    
        
    /// setup方法
    override func setup(_ cmsInfo: [String: Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        // 统一处理数据
        process(cmsInfo, source: source)
    }
    
    /// update方法
    override func update(_ cmsInfo: [String: Any]?, source: String = "") {
        super.update(cmsInfo, source: source)
        // 统一处理数据
        process(cmsInfo, source: source)
    }
    
    /// 统一处理数据
    private func process(_ cmsInfo: [String: Any]?, source: String = "") {
        sourceData = cmsInfo
        
        if let dataInfo = cmsInfo?["data"] as? [String:Any] {
            self.data = dataInfo
            //设置rank逻辑
            if let rankInvolved = dataInfo["rankInvolved"] as? Int, rankInvolved == 1 {
                self.rankInvolved = true
            }
        }

        // 获取type & level
        if let type = cmsInfo?["type"] as? String {
            self.type = type
        } else if let type = cmsInfo?["type"] as? Int {
            self.type = String(type)
        }
        
        // 模板数据
        var dataDict: [String: Any]?
        if let cmsInfo = cmsInfo {
            // 处理业务数据
            dataDict = cmsInfo
            //增加氛围
            if let sceneDict = processScene() {
                dataDict?["gaiaxscene"] = GaiaXTools.transformSceneInfo(sceneDict)
            }
        }
                
        //模板数据
        templateData.data = dataDict
        
        // 处理templateItem & config
        processTemplateItem()
        processConfig(templateItem)
        
        // 重置高度
        itemHeight = 0.0
        itemWidth = 0.0
    }
    
    
    // MARK: - 处理模板信息
    func processTemplateItem(){
        //子类重载
    }
    
    // MARK: - 读取氛围信息
    func processScene() -> [String: Any]?{
        //子类重载
        return nil
    }

    
    // MARK: - 读取config信息，处理layout信息
    func processConfig(_ templateItem: GaiaXTemplateItem){
        //读取config信息
        if let tmpConfig = GaiaXTemplateContext.shared().loadTemplateContent(with: templateItem) as? [String: Any] {
            config = tmpConfig
        }
        
        //读取configData信息
        if let data = templateData.data, let tmpConfigData = GaiaXTemplateContext.shared().loadConfig(with: templateItem, originData: data) as? [String: Any] {
            configData = tmpConfigData;
        }
    }
    
}



class RoleRankGaiaXItemModel: RoleRankGaiaXModel {

    override func processTemplateItem() {

        var templateId: String = ""
        
        if let aType = self.type {
            switch aType {
            case "14327": templateId = "yk-role-rank-item2" //角色榜2
            case "14328": templateId = "yk-role-rank-item1" //角色榜1
            case "14329": templateId = "yk-cp-rank-item2" //CP榜2
            case "14330": templateId = "yk-cp-rank-item1" //CP榜1
            case "14331": templateId = "yk-role-info-item" //角色信息
            case "14332": templateId = "yk-role-story-item" //角色故事
            default: templateId = ""
            }
        }
        
        templateItem.bizId = "yk-homepage"
        templateItem.templateId = templateId
    }
    
    func updateGaiaXData(_ index: Int) {
        if rankInvolved {
            if var tData = templateData.data, var data = tData["data"] as? [String: Any]{
                data["rank"] = index
                var rankColor = "primaryInfo"
                var topBgColor: String?
                var bottomBgColor: String?
                switch index {
                case 1:
                    rankColor = "#ff4a50"
                    topBgColor = "linear-gradient(to right, #ff4a5014, #ff4a5000)"
                    bottomBgColor = "linear-gradient(to right, #ff4a5026, #ff4a5000)"
                case 2:
                    rankColor = "#ff5810"
                    topBgColor = "linear-gradient(to right, #ff581014, #ff581000)"
                    bottomBgColor = "linear-gradient(to right, #ff581026, #ff581000)"
                case 3:
                    rankColor = "#ff9b00"
                    topBgColor = "linear-gradient(to right, #ff9b0014, #ff9b0000)"
                    bottomBgColor = "linear-gradient(to right, #ff9b0026, #ff9b0000)"
                default:
                    rankColor = "primaryInfo"
                }
                data["bottomBgColor"] = bottomBgColor
                data["topBgColor"] = topBgColor
                data["rankColor"] = rankColor
                tData["data"] = data
                templateData.data = tData
            }
        }
    }
    
    /// 处理氛围
    override func processScene() -> [String: Any]?{
        //获取page的style
       return self.superModel?.superModel?.superModel?.style
    }
    
    // TODO: 处理templateInfo，读取config信息，处理layout信息
    override func processConfig(_ templateItem: GaiaXTemplateItem){
        super.processConfig(templateItem)
        
        guard let configInfo = configData ?? config else {
            return
        }
        
        //读取layout信息
        if let layout = configInfo["layout"] as? [String: Any] {
            //读取witdth
            if let width = layout["itemWith"] as? Double  {
                itemWidth = width
            }
        }
    }
    
//    private func isValidType() -> Bool {
//        if let type = self.type, (type == "14327" || type == "14328" || type == "14329" || type == "14330" ) {
//            return true
//        }
//        return false
//    }
    
}

