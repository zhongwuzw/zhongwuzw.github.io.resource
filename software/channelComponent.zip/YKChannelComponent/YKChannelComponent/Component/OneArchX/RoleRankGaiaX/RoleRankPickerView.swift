//
//  RoleRankPickerView.swift
//  YKChannelComponent
//
//  Created by zhangjc on 2023/11/28.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YKNodePage
import YoukuResource
import YKUIComponent
import DYKIOSCategory

protocol RoleRankPickerViewDelegate: NSObjectProtocol {
    func didSelectItemInfo(_ itemInfo: [String: Any])
}

class RoleRankPickerView: UIView, UICollectionViewDelegate, UICollectionViewDataSource {
    
    let padding = 40.0
    
    lazy var contentWidth: CGFloat = {
        let w = min(500, YKRLScreenWidth())
        return w
    }()
    
    lazy var bgView: UIView = {
        let view = UIView.init(frame: self.bounds)
        view.backgroundColor = UIColor(white: 0, alpha: 0.65)
        view.whenTapped { [weak self] in
            self?.closeAction()
        }
        return view
    }()
    
    lazy var contentView: UIView = {
        let cHeight = 310.0 + 61.0 + YKHomeIndicatorHeight()
        let originY = self.height// self.height - cHeight
        let originX = (self.width - contentWidth) / 2.0
        let content = UIView.init(frame: CGRect.init(x: originX, y: originY, width: contentWidth, height: cHeight))
        content.backgroundColor = .ykn_primaryBackground
        //mask
        let radius: CGFloat = 14
        let maskPath = UIBezierPath(roundedRect: content.bounds,
                                    byRoundingCorners:[.topLeft, .topRight],
                                    cornerRadii: CGSize(width: radius, height: radius))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = content.bounds
        maskLayer.path = maskPath.cgPath
        content.layer.mask = maskLayer
        //return
        return content
    }()
    
    lazy var titleLabel: UILabel = {
        let tWidth = contentWidth - 20.0 - (34.0 + YKNGap.dim_8() * 2)
        let label = UILabel(frame: CGRect(x: 20, y: 0, width: tWidth, height: 65.0))
        label.font = YKNFont.top_navbar_text_weight(.semibold)
        label.textColor = UIColor.ykn_primaryInfo
        label.text = "请选择想要统计的周期"
        return label
    }()
            
    lazy var closeBtn: UILabel = {
        let originX = contentWidth - (34.0 + YKNGap.dim_8())
        let label = UILabel(frame: CGRect(x: originX, y: 12.0, width: 34.0, height: 34.0))
        label.layer.cornerRadius = 17.0
        label.layer.masksToBounds = true
        label.backgroundColor = UIColor.yk_color(forLightHex: "#ffffff", darkHex: "#1affffff")
        label.textColor = UIColor.createColorWithHexRGB(colorStr: "#040404")
        label.font = YKNIconFont.sharedInstance().font(withSize: 18)
        label.font = YKNIconFont.sharedInstance().font(withSize: 18)
        label.text = "\u{e70c}"
        label.whenTapped { [weak self] in
            self?.closeAction()
        }
        label.textAlignment = .center
        return label
    }()
    
    lazy var centerView: UIView = {
        let originY = titleLabel.bottom + 7.0// self.height - cHeight
        let cHeight = self.contentView.height - originY - 61.0 - YKHomeIndicatorHeight()
        let content = UIView.init(frame: CGRect.init(x: 0, y: originY, width: contentWidth, height: cHeight))
        content.backgroundColor = .ykn_primaryBackground
        return content
    }()
    
    lazy var collectionView: UICollectionView = {
        let cWidth = (contentWidth - YKNGap.dim_8() * 2) / 2.0 + padding
        let x = contentWidth - cWidth - YKNGap.dim_8()
        var frame = CGRect(x: x, y: 0, width: cWidth, height: centerView.height)
        let collectionView = UICollectionView.init(frame: frame, collectionViewLayout: self.collectionViewLayout)
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.isScrollEnabled = true
        collectionView.showsVerticalScrollIndicator = false
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.backgroundColor = .ykn_primaryBackground
        collectionView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        collectionView.register(RoleRankPickerViewCell.self, forCellWithReuseIdentifier: "RoleRankPickerViewCell")
        return collectionView
    }()
    
    lazy var collectionViewLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = .vertical
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
        let itemWdith = (contentWidth - YKNGap.dim_8() * 2) / 2.0 + padding
        layout.itemSize = CGSize(width: itemWdith, height: 36.0)
        return layout
    }()
    
    lazy var confirmBtn: UILabel = {
        let label = UILabel(frame: CGRect(x: 0, y: centerView.bottom, width: contentWidth, height: 52.0))
        label.font = UIFont.systemFont(ofSize: 15.0, weight: .medium)
        label.textColor = .ykn_brandInfo
        label.textAlignment = .center
        label.text = "确定"
        label.whenTapped { [weak self] in
            self?.confirmAction()
        }
        
        let layer = CALayer()
        layer.frame = CGRect(x: 0, y: 0, width: contentWidth, height: 0.5)
        layer.backgroundColor = UIColor.ykn_separator.cgColor
        label.layer.addSublayer(layer)
        
        return label
    }()
    
    lazy var coverView: UIView = {
        let x = YKNGap.dim_8()
        let cWidth = contentWidth - YKNGap.dim_8() * 2
        let view = UIView.init(frame: CGRect(x: x, y: 0.0, width: cWidth, height: 36.0))
        view.backgroundColor = UIColor.ykn_border
        view.layer.cornerRadius = YKNCorner.radius_small()
        view.isUserInteractionEnabled = false
        return view
    }()
    
    lazy var gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer()
        let cWidth = (contentWidth - YKNGap.dim_8() * 2) / 2.0
        let x = YKNGap.dim_8() + cWidth
        layer.frame = CGRect.init(x: x, y: collectionView.bottom - 36, width: cWidth, height: 36)
        layer.startPoint = CGPoint(x: 0, y: 0)
        layer.endPoint = CGPoint(x: 0, y: 1)
        layer.locations = [0.0, 1.0]
        return layer
    }()
    
    // props
    var itemViews = [UILabel]()
    var selectedLItemView: UILabel?
    var selectedRItemCell: RoleRankPickerViewCell?
    
    // 数据源
    var isClick = false
    var leftItems: [HomeDateModel]?
    var rightItems: [HomeDateItemModel]?

    // bizContext的参数
    var dimension: String? // day
    var date: HomeDateItemModel? //2023-1-1
    weak var delegate: RoleRankPickerViewDelegate?

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    init(frame: CGRect, dates:[HomeDateModel]) {
        super.init(frame: frame)
        addSubview(bgView)
        addSubview(contentView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(closeBtn)
        contentView.addSubview(centerView)
        contentView.addSubview(confirmBtn)
        centerView.addSubview(collectionView)

        //增加渐变
        centerView.layer.addSublayer(gradientLayer)
        setupGradientColors()

        //创建筛选数据
        self.leftItems = dates
        creatLeftItems()

        // 响应式
        if (ykrl_isResponsiveLayout()) {
            NotificationCenter.default.addObserver(self, selector: #selector(responseLayoutDidChanged), name: Notification.Name(rawValue: "YKRLLayoutStatusDidChangeNotification"), object: nil)
        }
    }
    
    
    // MARK: - UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return rightItems?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "RoleRankPickerViewCell", for: indexPath)
        if let cell = cell as? RoleRankPickerViewCell {
            let itemIndex = indexPath.item
            cell.titleLabel.text = rightItems?[itemIndex].label
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        //支持选中逻辑
        if isClick == false {
            isClick = true
            updateRightSelectItem(indexPath)
        }
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        selectedRItemCell?.titleLabel.textColor = .ykn_primaryInfo
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        if (!decelerate) {
            handleRightSelectItem()
        }
    }

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        handleRightSelectItem()
    }

    func scrollViewDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        handleRightSelectItem()
    }
    

    // MARK: - private
    
    private func creatLeftItems() {
        guard let items = self.leftItems, items.count > 0 else {
            return
        }
        
        let x = YKNGap.dim_8() + padding
        var y = 0.0
        let cWidth = (contentWidth - YKNGap.dim_8() * 2) / 2.0 - padding * 2
        // 子视图移除父视图
        itemViews.forEach { $0.removeFromSuperview()}
        // 添加子视图
        for i in 0..<items.count {
            var itemView: UILabel
            if i < itemViews.count {
                itemView = itemViews[i]
            } else {
                itemView = UILabel.init(frame: CGRect(x: x, y: 0, width: cWidth, height: 36.0))
                itemView.font = YKNFont.posteritem_maintitle_weight(.medium)
                itemView.textColor = .ykn_primaryInfo
                itemView.textAlignment = .center
                itemView.whenTapped { [weak self] in
                    self?.selectLeftItem(itemView)
                }
                itemViews.append(itemView)
            }
            itemView.top = y
            y = itemView.bottom
            itemView.tag = 1000 + i
            itemView.text = items[i].label
            centerView.addSubview(itemView)
        }
        
        if let view = contentView.viewWithTag(1000) as? UILabel {
            selectLeftItem(view)
        }
    }
    
    private func selectLeftItem(_ view: UILabel) {
        // 更新左边筛选区域
        updateSelectedLeftView(view)
        // 更新右边内容区域
        updateSelectedRightView(view)
    }
    
    private func updateSelectedLeftView(_ view: UILabel) {
        // 更新选中浮层
        coverView.top = view.top
        centerView.addSubview(coverView)
        
        // 重置选中leftItem
        selectedLItemView?.textColor = .ykn_primaryInfo
        
        // 更新选中leftItem
        view.textColor = .ykn_brandInfo
        selectedLItemView = view
        
        // 获取最终参数
        dimension = nil
        rightItems = nil
        let index = view.tag - 1000
        if let items = leftItems, index < items.count {
            dimension = items[index].key
            rightItems = items[index].items
        }
    }
    
    private func updateSelectedRightView(_ view: UILabel) {
        // 重置内容位置
        let top = view.top
        let bottom = centerView.height - view.bottom
        collectionView.contentOffset = CGPoint(x: 0, y: -top)
        collectionView.contentInset = UIEdgeInsets(top: top, left: 0, bottom: bottom, right: 0)
        // 刷新数据
        collectionView.reloadData()
        // 获取右边选中逻辑
        DispatchQueue.main.async {
            DispatchQueue.main.async {
                self.handleRightSelectItem()
            }
        }
    }
    
    
    // MARK: - 处理右边的item
    
    private func handleRightSelectItem() {
        guard !isClick else { //如果是点击触发，不执行下面逻辑
            return
        }
        
        //重置历史选中
        date = nil
        selectedRItemCell?.titleLabel.textColor = .ykn_primaryInfo
        //获取最新选中
        let visibleFrame = centerView.convert(coverView.frame, to: collectionView)
        let point = CGPoint(x: 0.0, y: visibleFrame.origin.y + visibleFrame.size.height / 2.0)
        if let indexPath = collectionView.indexPathForItem(at: point) {
            //滑动选中位置
            collectionView.decelerationRate = UIScrollView.DecelerationRate(rawValue: 0.75)
            collectionView.scrollToItem(at: indexPath, at: .centeredVertically, animated: true)
            
            //更新最新选中
            let cell = collectionView.cellForItem(at: indexPath) as? RoleRankPickerViewCell
            cell?.titleLabel.textColor = .ykn_brandInfo
            selectedRItemCell = cell
            
            //参数
            date = rightItems?[indexPath.item]
        }
    }
    
    private func updateRightSelectItem(_ indexPath: IndexPath) {
        //重置历史选中
        date = nil
        selectedRItemCell?.titleLabel.textColor = .ykn_primaryInfo
        
        //获取最新选中
        collectionView.decelerationRate = UIScrollView.DecelerationRate(rawValue: 0.75)
        collectionView.scrollToItem(at: indexPath, at: .centeredVertically, animated: true)
        
        //更新最新选中
        let cell = collectionView.cellForItem(at: indexPath) as? RoleRankPickerViewCell
        cell?.titleLabel.textColor = .ykn_brandInfo
        selectedRItemCell = cell
        
        //参数
        date = rightItems?[indexPath.item]
        
        //重置isClick
        isClick = false
    }
        
    
    // MARK: - action
    
    func showInView(_ view: UIView) {
        if !self.isDescendant(of: view) {
            view.addSubview(self)
        }
        
        self.alpha = 1
        self.bgView.alpha = 0
        self.contentView.top = self.height
        UIView.animate(withDuration: 0.25) {
            self.bgView.alpha = 1
            self.contentView.top = self.height - self.contentView.height
        }
    }

    private func closeAction() {
        UIView.animate(withDuration: 0.25) {
            self.bgView.alpha = 0
            self.contentView.top = self.height
        } completion: { isFinished in
            if isFinished {
                self.alpha = 0
            }
        }
    }
    
    private func confirmAction() {
        if let dimension = self.dimension, let date = self.date {
            let itemInfo: [String: Any] = ["date": date, "dimension": dimension]
            closeAction()
            delegate?.didSelectItemInfo(itemInfo)
        } else {
            MessageBox.sharedInstance()?.showMessage("请选择想统计的周期")
        }
    }
    
    
    // MARK: - 响应式
    @objc func responseLayoutDidChanged() {
        self.removeFromSuperview()
        
        let screenWidth = YKRLScreenWidth()
        let screenHeight = YKRLScreenHeight()
        
        self.height = screenHeight
        self.width = screenWidth
        
        self.bgView.alpha = 0
        bgView.width = screenWidth
        bgView.height = screenHeight
        
        contentView.top = screenHeight
        contentView.centerX = screenWidth / 2.0
    }
    
    
    // MARK: - 暗黑
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) { [weak self] in
            self?.setupGradientColors()
        }
    }
    
    private func setupGradientColors() {
        let currentThemeIdentifier = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        if currentThemeIdentifier == YKNThemeIdentifierDark {
            let color = UIColor.createColorWithHexRGB(colorStr: "#161616")
            self.gradientLayer.colors = [
                color.withAlphaComponent(0).cgColor as Any,
                color.withAlphaComponent(1).cgColor as Any,
            ]
        } else {
            let color = UIColor.createColorWithHexRGB(colorStr: "#ffffff")
            self.gradientLayer.colors = [
                color.withAlphaComponent(0).cgColor as Any,
                color.withAlphaComponent(1).cgColor as Any,
            ]
        }
    }

}




class RoleRankPickerViewCell: UICollectionViewCell {
    
    lazy var titleLabel: UILabel = {
        let label = UILabel(frame: self.bounds)
        label.font = YKNFont.posteritem_maintitle()
        label.textColor = .ykn_primaryInfo
        label.textAlignment = .center
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .ykn_primaryBackground
        contentView.addSubview(titleLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
