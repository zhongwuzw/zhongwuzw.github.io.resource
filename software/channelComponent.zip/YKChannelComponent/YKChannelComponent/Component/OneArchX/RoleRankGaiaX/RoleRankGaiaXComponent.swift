//
//  RoleRankGaiaXComponent.swift
//  YKChannelComponent
//
//  Created by zhangjc on 2023/11/27.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import YoukuResource
import OneArchSupport
import YKResponsiveLayout
import OneArchSupport4Youku

class RoleRankGaiaXComponent: NSObject, ComponentDelegate {
    
     var componentWrapper: ComponentWrapper?

     func componentDidInit() {

     }
     
     func layoutType() -> ComponentLayoutType {
         if isValidType() {
             return .custom //响应式适配改多列均分（多行一列）为自定义布局。
         } else {
             return .columnAverage
         }
     }
     
     func layoutConfig() -> ComponentLayoutConfig {
         var config = ComponentLayoutConfig()
         let bottom = getBottom()
         let left = is14331() ? 0 : YKNGap.youku_margin_left()
         let right = is14331() ? 0 : YKNGap.youku_margin_right()
         config.padding = UIEdgeInsets.init(top: 0, left: left, bottom: bottom, right: right)
         config.columnSpacing = YKNGap.youku_column_spacing()
         config.preferredCardSpacingTop = YKNGap.dim_6()
//         config.rowSpacing = YKNGap.youku_line_spacing()
//         config.footerBottomMargin = YKNGap.youku_comp_margin_bottom()
         if isValidType() {
             config.responsiveAdjustableMinColumnCount = 1
             config.responsiveMinColumnCount = 2
             config.responsiveMaxColumnCount = 2
         }
         return config
     }

     func columnCount() -> CGFloat {
         return 1
     }
     
     func loadEventHandlers() -> [ComponentEventHandler]? {
         return nil
     }
     
     // MARK: 响应式适配，组件级的UI回调转发到坑位级
     /// 渲染复用ID
     func reuseId() -> String? {
         guard let item = self.component?.getItems()?.first,
               let itemDelegate = item.getItemDelegate()
         else {
             return nil
         }
         
         return itemDelegate.reuseId()
     }

     /// item高度
     func itemHeight(itemWidth: CGFloat) -> CGFloat {
         guard let item = self.component?.getItems()?.first,
               let itemDelegate = item.getItemDelegate()
         else {
             return 0
         }
         
         return itemDelegate.itemHeight(itemWidth: itemWidth)
     }
     
     /// 初始化item view
     func createView(_ itemSize: CGSize) -> UIView {
         guard let item = self.component?.getItems()?.first,
               let itemDelegate = item.getItemDelegate()
         else {
             return UIView.init()
         }
         
         return itemDelegate.createView(itemSize)
     }

     /// 复用
     func reuseView(itemView: UIView) {
         guard let item = self.component?.getItems()?.first,
               let itemDelegate = item.getItemDelegate()
         else {
             return
         }
         
         return itemDelegate.reuseView(itemView: itemView)
     }

    
    // 角色榜 / CP榜 - 非前3组件
    private func isValidType() -> Bool {
        guard ykrl_isResponsiveLayout() else {
            return false
        }
        
        guard let type = component?.compModel?.type, (type == "14327" || type == "14329")  else {
            return false
        }
        
        //响应式下，这两个组件支持双列
        return true
    }
    
    // 角色榜 / CP榜 - 4个组件
    private func getBottom() -> CGFloat {
        if let type = component?.compModel?.type, ["14327", "14328", "14329", "14330"].contains(type) {
            if ykrl_isResponsiveLayout() {
                return 18
            } else {
                return 15
            }
        }
        
        return YKNGap.youku_comp_margin_bottom()
    }
    
    // 角色主页组件
    private func is14331() -> Bool {
        guard let type = component?.compModel?.type, type == "14331" else {
            return false
        }
        
        return true
    }
    
}

