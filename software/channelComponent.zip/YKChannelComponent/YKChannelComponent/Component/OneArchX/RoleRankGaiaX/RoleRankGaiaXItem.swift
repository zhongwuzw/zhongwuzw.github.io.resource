//
//  RoleRankGaiaXItem.swift
//  YKChannelComponent
//
//  Created by zhangjc on 2023/11/27.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import YKUIComponent
import GaiaXCore
import OneArch
import GaiaX
import UIKit

class RoleRankGaiaXItem: NSObject, ItemDelegate, GaiaEventHandlerProtocol, GaiaDataTransformProtocol {
    
    var itemWrapper: ItemWrapper?
    
    // model属性
    lazy var model: RoleRankGaiaXItemModel = {
        guard let value = item?.model as? RoleRankGaiaXItemModel else {
            return RoleRankGaiaXItemModel()
        }
        
        if isValidType() {
            let index = (item?.getComponent()?.index ?? 0) + 1
            value.updateGaiaXData(index)
        }
        
        return value
    }()
    
    open func itemDidInit() {
        // print("GaiaXItem init")
    }
    
    open func reuseId() -> String? {
        return model.templateItem.templateId
    }
    
    open func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return handleItemHeight(itemWidth: itemWidth)
    }
    
    open func createView(_ itemSize: CGSize) -> UIView {
        // 创建视图
        guard let view = GaiaXTemplateContext.shared().renderView(by: model.templateItem, measure: itemSize ) else {
            return UIView()
        }
        return view
    }
    
    open func reuseView(itemView: UIView) {
        // 绑定数据
        guard let itemView = itemView as? GaiaRootViewProtocal & UIView else {
            return
        }
        itemView.autoRouter = true
        itemView.autoTrack = true

        // 设置data
        let templateData = model.templateData
        templateData.eventListener = self
        templateData.dataListener = self
        
        // 设置size
        let size = CGSize(width: model.itemWidth, height: model.itemHeight)
        GaiaXTemplateContext.shared().bindData(templateData, measure: size, onRootView: itemView)
    }
    
    open func getModelClass<T>() -> T.Type? where T: NodeModel {
        return RoleRankGaiaXItemModel.self as? T.Type
    }
    
    open func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    
    // MARK: - private
    
    private func isValidType() -> Bool {
        if let type = item?.model?.type, (type == "14327" || type == "14328" || type == "14329" || type == "14330" ) {
            return true
        }
        return false
    }
    
    private func handleItemHeight(itemWidth: CGFloat) -> CGFloat{
        var height = model.itemHeight
        
        //部分情况读取缓存
        if isValidType() {
            if model.itemWidth == itemWidth, height != 0 {
                return height
            }
        }
        
        //计算 & 更新model
        height = caculateItemSize(estimationWidth: itemWidth)
        model.itemHeight = height
        model.itemWidth = itemWidth
        return height
    }
    
    private func caculateItemSize(estimationWidth: CGFloat) -> CGFloat {
        // 计算Size
        guard model.templateItem.isAvailable(), model.templateData.isAvailable() else {
            return 0
        }
        
        let measureSize = CGSize(width: estimationWidth, height: CGFloat(Float.nan))
        return GaiaXTemplateContext.shared().size(with: model.templateItem, measure: measureSize, data: model.templateData).height;
    }

    
    // MARK: - GaiaEventHandlerProtocol & GaiaDataTransformProtocol
    
    public func onScroll(_ event: GaiaEvent) {

    }
    
    public func onScrollEnd(_ event: GaiaEvent) {

    }
    
    open func didReceivedGaiaEvent(_ event: GaiaEvent) {
        // 事件处理
        if event.eventId == "heart-view",
             let toast = event.eventDict?["guideText"] as? String {
            MessageBox.sharedInstance()?.showMessage(toast)
        }
    }
    
    public func didReceivedGaiaJSEvent(_ event: [AnyHashable: Any]) {

    }
    
    public func gx_animationDidFinished(_ animationInfo: [AnyHashable: Any]) {
        
    }
    
    public func onBindTrack(_ event: GaiaEvent) {

    }
    
    public func onBindData(_ data: GaiaXData) -> Any? {
        return nil
    }
    
    public func gx_(onManualClickTrackEvent track: GaiaEvent) {

    }
    
    public func gx_(onManualExposureTrackEvent track: GaiaEvent) {

    }
    
}
