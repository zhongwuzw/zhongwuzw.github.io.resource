//
//  Comp14301SlierView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/5/9.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
 
class Comp14301SlierView: UISlider {
    
    var sliderHeight: CGFloat = 2.0
    
    override func minimumValueImageRect(forBounds bounds: CGRect) -> CGRect {
        return self.bounds
    }
    
    override func maximumValueImageRect(forBounds bounds: CGRect) -> CGRect {
        return self.bounds
    }
    
    // 控制slider的宽和高，这个方法才是真正的改变slider滑道的高的
    override func trackRect(forBounds bounds: CGRect) -> CGRect {
        let rect = super.trackRect(forBounds: bounds)
        layer.cornerRadius = sliderHeight/2
        return CGRect.init(x: rect.origin.x, y: (bounds.size.height-sliderHeight)/2, width: bounds.size.width, height: sliderHeight)
    }
    
    // 改变滑块的触摸范围
    override func thumbRect(forBounds bounds: CGRect, trackRect rect: CGRect, value: Float) -> CGRect {
        let rect = super.thumbRect(forBounds: bounds, trackRect: rect, value: value)
        var newRect = rect
        if rect.maxX > bounds.maxX {
            newRect = CGRect.init(x: bounds.width - rect.width, y: rect.minY, width: rect.width, height: rect.height)
        } else if rect.minX < 0 {
            newRect = CGRect.init(x: 0, y: rect.minY, width: rect.width, height: rect.height)
        }
        return newRect
    }

    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
        let margin: CGFloat = (40 > self.width) ? (40 - self.width) / 2 : 0
        let area = self.bounds.insetBy(dx: -margin, dy: -margin)
        print("[immersive] ext slider a:\(area) f:\(area.contains(point))")
        return area.contains(point)
    }
}
