//
//  Comp14301PlayFinishView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/5/9.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent
import YKChannelPage
import YKProtocolSDK

class Comp14301PlayFinishView: UIView {
    
    lazy var contentView: UIView = {
        let height = 36 * 2 + YKNGap.dim_6()
        let view = UIView.init(frame: CGRect.init(x: (self.width - 91) / 2, y: (self.height - height) / 2, width: 91, height: height))
        return view
    }()
    
    // 重播
    
    lazy var rpLabel: UILabel = {
        let img = UIImage(named: "immersive_refresh")
        let attachment = NSTextAttachment()
        attachment.image = img
        attachment.bounds = CGRect(x: 0, y: -2, width: 16, height: 16)
        let attrImage = NSAttributedString(attachment: attachment)
        let attrMub = NSMutableAttributedString()
        attrMub.append(attrImage)
        
        let font = YKNIconFont.sharedInstance().font(withSize: 14)
        let attrStr = NSAttributedString(string: "  重播", attributes: [NSAttributedString.Key.font : font, NSAttributedString.Key.foregroundColor: UIColor.white])
        attrMub.append(attrStr)
        
        let label = UILabel.init(frame: CGRect.init(origin: CGPointMake((contentView.width - 74) / 2, 36 + YKNGap.dim_6()), size: CGSize(width: 74, height: 36)))
        label.attributedText =  attrMub
        label.textAlignment = .center
        label.isUserInteractionEnabled = true
        
        weak var weakSelf = self
        label.whenTapped {
            weakSelf?.replayCallback?()
        }
        return label
    } ()
    
    weak var item: IItem?
    var replayCallback: (() -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.tag = 9955770
        self.backgroundColor = UIColor.init(white: 0, alpha: 0.6)
        
        addSubview(contentView)
        contentView.addSubview(rpLabel)

    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        
    }
    
    
    func fill(_ item: IItem?) {
        self.item = item
        
        rpLabel.top = (contentView.height - 36) / 2
        
        Service.statistics.bind(self.item?.itemModel?.preview?["report_replay"] as? ReportModel, rpLabel, .Defalut)
    }
}
