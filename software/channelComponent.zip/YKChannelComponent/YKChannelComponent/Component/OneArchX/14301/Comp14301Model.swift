//
//  Item14301Model.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/3/15.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item14301IconModel: NSObject {
    var url: String?
    var width: CGFloat = 0
    var height: CGFloat = 0
    
    func setup(_ info: [String : Any]?) {
        if let value = info?["url"] as? String {
            url = value
        }
        
        if let value = info?["width"] as? CGFloat {
            width = value
        }
        
        if let value = info?["height"] as? CGFloat {
            height = value
        }
    }
}

class Item14301Model: BaseItemModel {
    var iconModel: Item14301IconModel?
    var buttonType: Int = 0 //播放结束按钮类型
    
    var exposeLogIgnored: Bool = false // 标记曝光埋点被忽略
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)

        if let dataInfo = cmsInfo?["data"] as? [String:Any] {
            if let value = dataInfo["titleIcon"] as? [String:Any], value.count > 0 {
                self.iconModel = Item14301IconModel.init()
                self.iconModel?.setup(value)
                self.extend["model.titleIcon.url"] = self.iconModel?.url
                self.extend["model.titleIcon.text"] = self.title
            }
            
            if let preview = dataInfo["preview"] as? [String:Any] {
                self.preview = preview
                
                //report model
                if var actionInfo = dataInfo["action"] as? [String:Any] {
                    if var reportInfo = actionInfo["report"] as? [String:Any] {
                        //reserve
                        reportInfo["spmD"] = "play_volumeon"
                        actionInfo["report"] = reportInfo
                        var tmpAction = buildActionModel(actionInfo, model: self)
                        self.preview?["report_volumeon"] = tmpAction?.report
                        //cancel
                        reportInfo["spmD"] = "play_volumeoff"
                        actionInfo["report"] = reportInfo
                        tmpAction = buildActionModel(actionInfo, model: self)
                        self.preview?["report_volumeoff"] = tmpAction?.report
                        
                        //暂停
                        reportInfo["spmD"] = "show_pause"
                        actionInfo["report"] = reportInfo
                        tmpAction = buildActionModel(actionInfo, model: self)
                        self.preview?["report_pause"] = tmpAction?.report
                        
                        reportInfo["spmD"] = "show_play"
                        actionInfo["report"] = reportInfo
                        tmpAction = buildActionModel(actionInfo, model: self)
                        self.preview?["report_play"] = tmpAction?.report
                        
                        //看正片
                        reportInfo["spmD"] = "endshow"
                        actionInfo["report"] = reportInfo
                        tmpAction = buildActionModel(actionInfo, model: self)
                        tmpAction?.routeParams["mode"] = "full_horizontal"
                        tmpAction?.routeParams["forceFSBF"] = 1
                        self.preview?["report_see"] = tmpAction
                        
                        //重播
                        reportInfo["spmD"] = "endreplay"
                        actionInfo["report"] = reportInfo
                        tmpAction = buildActionModel(actionInfo, model: self)
                        self.preview?["report_replay"] = tmpAction?.report
                        
                        //reserve
                        reportInfo["spmD"] = "endreserve"
                        actionInfo["report"] = reportInfo
                        tmpAction = buildActionModel(actionInfo, model: self)
                        self.reserveModel?.addReserveReport = tmpAction?.report
                        
                        //cancel
                        reportInfo["spmD"] = "endcancelreserve"
                        actionInfo["report"] = reportInfo
                        tmpAction = buildActionModel(actionInfo, model: self)
                        self.reserveModel?.cancelReserveReport = tmpAction?.report
                        
                        //showFullScreen
                        reportInfo["spmD"] = "show_fullscreen"
                        actionInfo["report"] = reportInfo
                        tmpAction = buildActionModel(actionInfo, model: self)
                        tmpAction?.routeParams["mode"] = "full_horizontal"
                        tmpAction?.routeParams["forceFSBF"] = 1
                        self.extraExtend["model.action"] = tmpAction
                    }
                    
                }
                self.previewModel = PreviewModel.init(preview, itemModel: self)
            }
            
            if let _buttonType = dataInfo["buttonType"] as? Int {
                self.buttonType = _buttonType
            }
        }
        
        let actionModel = self.action
        actionModel?.routeParams["mode"] = "full_horizontal"
        actionModel?.routeParams["forceFSBF"] = 1
        
    }
    
}

class Comp14301Model: BaseComponentModel {
    
}
