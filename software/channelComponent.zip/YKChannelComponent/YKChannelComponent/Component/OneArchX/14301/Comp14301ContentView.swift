//
//  Comp14301ContentView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/3/15.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent
import YKCMSComponent
import YKChannelPage
import DYKIOSCategory
import YKProtocolSDK
import GodViewTracker
import YoukuAnalytics

let KComp14301ContentViewTopMagin : CGFloat = 198
let KComp14301ContentViewRatio : CGFloat = 8 / 7.0

class Comp14301ContentView: UIView, PlayingProgress, ImmersivePlayerDelegate {
    weak var component:IComponent?
    
    static var isMute = true
    
    var _visable = false
    
    // MARK: - 播放器区
    
    lazy var coverImageView: UIImageGIFView = { //封面图
        let view = UIImageGIFView.init(frame:self.playerViewFrame)
        view.isUserInteractionEnabled = false
        view.tag = 998866
        view.isHidden = true
        view.contentMode = .scaleAspectFill
        return view
    }()
    
    lazy var contentSuperView: Content14301ContentPlaceHolderView = {
        let view = Content14301ContentPlaceHolderView.init(frame: CGRect.zero)
        view.backgroundColor = .clear
        view.tag = 997755
        view.isHidden = true
        return view
    }()
    
    lazy var leftImgView: UIImageView = { //封面图
        let view = UIImageView.init(frame:CGRect.init(x: 0, y: 0, width: 18, height: 12))
        view.isUserInteractionEnabled = false
        view.image = UIImage.init(named: "immersive_l")
//        view.backgroundColor = .red
        return view
    }()
    
    lazy var rightImgView: UIImageView = { //封面图
        let view = UIImageView.init(frame:CGRect.init(x: 0, y: 0, width: 18, height: 12))
        view.isUserInteractionEnabled = false
        view.image = UIImage.init(named: "immersive_r")
//        view.backgroundColor = .red
        return view
    }()
    
    lazy var logoContainerView: ImmersiveOneLogoView = { //名称logo
        let buildframe = CGRect.init(x: (self.width - 200) / 2, y: CGRectGetMaxY(self.playerViewFrame) - 15, width: 200, height: 90)
        let view = ImmersiveOneLogoView.init(frame: buildframe)
        view.backgroundColor = .clear
        
        weak var weakSelf = self
        weak var weakLogoView = view
        view.setImageFinishedBlock = {
            guard let weakLogoView = weakLogoView else {
                return
            }
            
            let bottom = weakLogoView.useView.bottom
            let usedBottom = bottom + weakLogoView.top
            weakSelf?.titleLabel.top = usedBottom + 12
            weakSelf?.subTitleLabel.top = (weakSelf?.titleLabel.bottom  ?? 0) + 4
            
            weakSelf?.leftImgView.centerY = weakSelf?.titleLabel.centerY ?? 0
            weakSelf?.leftImgView.right = (weakSelf?.titleLabel.left  ?? 0) - 9
            
            weakSelf?.rightImgView.centerY = weakSelf?.titleLabel.centerY ?? 0
            weakSelf?.rightImgView.left = (weakSelf?.titleLabel.right ?? 0) + 9
            
            weakSelf?.seeLabel.top = (weakSelf?.seeLabelTop() ?? 0)
            weakSelf?.sbLabel.top = (weakSelf?.seeLabelTop() ?? 0)
            
            weakSelf?.subTitleLabel.isHidden = weakSelf?.shouldHideSubtitle() ?? false
        }
        return view
    }()
    
    // MARK: - 播控区
    
    lazy var playControlView: Comp14301PlayerControlView = {
        let view = Comp14301PlayerControlView.init(frame: CGRect.init(x: 0, y: self.playerViewFrame.maxY - 25 - 20, width: self.width, height: 25))
        return view
    }()
    
    lazy var playBtn: UIButton = {
        let button = Comp14301ExtendedUIButton.init(type: .custom)
        button.frame = CGRect.init(x: 18, y: (playControlView.height - 25) / 2, width: 25, height: 25)
        button.setImage(UIImage.init(named: "st_player_plugin_icon_pause"), for: .normal)
        button.setImage(UIImage.init(named: "lunbo_q_play"), for: .selected)
        button.addTarget(self, action: #selector(playBtnTap), for: UIControl.Event.touchUpInside)
        return button
    }()
    
    lazy var slider: UISlider = {
        let leftM = playBtn.right + 15
        let right = muteButton.left  - 15
        let slider = Comp14301SlierView.init(frame: CGRect.init(x: playBtn.right + 15, y: (self.playControlView.height - 25) / 2, width: right - leftM, height: 25))
        slider.minimumValue = 0
        slider.value = 0
        slider.maximumValue = 100
        slider.thumbTintColor = .white
        slider.minimumTrackTintColor = .white
        slider.maximumTrackTintColor = .white.withAlphaComponent(0.3)
        slider.layer.cornerRadius = 4
        slider.clipsToBounds = true
        let image = imageWithColor()
        slider.setThumbImage(image, for: .normal)
        slider.setThumbImage(image, for: .highlighted)
        slider.isContinuous = false
        
        slider.addTarget(self, action: #selector(sliderValueChanged(_:)), for: .valueChanged)
        
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(sliderTapped(_:)))
        slider.addGestureRecognizer(tapGesture)
        return slider
    } ()
    
    lazy var muteButton:UIButton = {
        let button = Comp14301ExtendedUIButton.init(type: .custom)
        button.setImage(UIImage.init(named: "st_player_plugin_icon_silent_off"), for: .normal)
        button.setImage(UIImage.init(named: "st_player_plugin_icon_silent_on"), for: .selected)
        button.frame = CGRect.init(x: fullScreenBtn.left - 16 - 24, y: (playControlView.height - 24) / 2, width: 24, height: 24)
        button.addTarget(self, action: #selector(muteBtnTap), for: UIControl.Event.touchUpInside)
        button.isSelected = !ImmersivePlayerView.isMute
        return button
    }()
    
    lazy var muteButton2:UIButton = {
        let button = Comp14301ExtendedUIButton.init(type: .custom)
        button.setImage(UIImage.init(named: "st_player_plugin_icon_silent_off"), for: .normal)
        button.setImage(UIImage.init(named: "st_player_plugin_icon_silent_on"), for: .selected)
        button.frame = CGRect.init(x: self.width - 24 - YKNGap.dim_9(), y: self.playerViewFrame.maxY - 24 - YKNGap.dim_9(), width: 24, height: 24)
        button.addTarget(self, action: #selector(muteBtnTap2), for: UIControl.Event.touchUpInside)
        button.isSelected = !ImmersivePlayerView.isMute
        button.isHidden = true
        button.tag = 990876
        return button
    }()
    
    lazy var fullScreenBtn: UIView = {
        let btn = Comp14301ExtendedUIButton.init(type: .custom)
        btn.frame = CGRect.init(x: self.width - 25 - 18, y: 0, width: 25, height: 25)
        let imgView = UIImageView.init(frame: btn.bounds)
        let img = UIImage(named: "st_player_plugin_icon_full_screen")
        imgView.image = img
        btn.addSubview(imgView)
        
        return btn
    } ()
    
    weak var playerView: ImmersivePlayerView? {
        return ImmersivePageManager.shared.playerView
    }
    
    private func imageWithColor() -> UIImage? {
        let size = CGSize(width: 8, height: 8)
        let cornerRadius: CGFloat = 4.0
        UIGraphicsBeginImageContextWithOptions(size, false, 0)
        let context = UIGraphicsGetCurrentContext()!
        let path = UIBezierPath(roundedRect: CGRect(origin: .zero, size: size), cornerRadius: cornerRadius)
        UIColor.white.setFill()
        path.fill()
        context.addPath(path.cgPath)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
    
    // MARK: - 文本区
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init(frame: CGRect.init(x: 0, y: CGRectGetMaxY(self.playerViewFrame) + 9, width: self.width, height: YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)))
        view.textColor = UIColor.white
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1 //最大16个字
        view.lineBreakMode = .byTruncatingTail
        view.textAlignment = .center
        return view
    }()
    
    lazy var subTitleLabel: UILabel = {
        let view = UILabel.init(frame: CGRect.init(x: 0, y: titleLabel.bottom + 4, width: self.width, height: YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)))
        view.textColor = UIColor.init(white: 1, alpha: 0.7)
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1  //最大16个字
        view.lineBreakMode = .byTruncatingTail
        view.textAlignment = .center
        return view
    }()
    
    lazy var bgImageView: UIImageGIFView = { //封面图
        let vW = ceil(self.height * 16 / 9)
        let view = UIImageGIFView.init(frame:CGRect.init(x: (self.width - vW) / 2, y: 0, width: vW, height: self.height))
        view.isUserInteractionEnabled = false
//        view.contentMode = .scaleAspectFill
        view.backgroundColor = .black
        view.tag = 998855
            
        view.addSubview(topBlurView)
        topBlurView.frame = view.bounds
        
        let layer = CAGradientLayer.init()
        layer.frame = view.bounds
        layer.locations = [NSNumber.init(value: 0.0),
                           NSNumber.init(value: 198.0/self.height),
                           NSNumber.init(value: (198.0 + 75)/self.height),
                           NSNumber.init(value: (self.playerViewFrame.maxY - 75)/self.height),
                           NSNumber.init(value: (self.playerViewFrame.maxY )/self.height),
                           NSNumber.init(value: 1.0)]
        
        layer.startPoint = CGPoint.init(x: 0, y: 0)
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)
        let clr1 = UIColor.white.withAlphaComponent(0).cgColor
        let clr2 = UIColor.white.withAlphaComponent(1).cgColor
        layer.colors = [clr2, clr2, clr1, clr1, clr2, clr2]

        view.layer.mask = layer
        return view
    }()
    
    lazy var topBlurView: UIVisualEffectView = {
        let blurEffect = UIBlurEffect(style: .dark)
        let effectView = UIVisualEffectView(effect: blurEffect)
        effectView.frame = CGRect.init(x: 0, y: 0, width: self.width, height: self.height)
        effectView.isUserInteractionEnabled = false
        return effectView
    }()
    
    lazy var topGradientView: UIView = {
        let view = UIView.init(frame: CGRect.init(x: 0, y: 0, width: self.width, height: 120))
        view.backgroundColor = UIColor.clear
        view.layer.addSublayer(self.topGradientLayer)
        self.topGradientLayer.frame = view.bounds
        view.isUserInteractionEnabled = false
        return view
    }()
    
    lazy var topGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init(x: 0, y: 0)
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)

        let clr1 = UIColor.black.withAlphaComponent(0).cgColor
        let clr2 = UIColor.black.withAlphaComponent(1).cgColor
        layer.colors = [clr2, clr1]
        return layer
    } ()
    
    lazy var bottomGradientView: UIView = {
        let view = UIView.init(frame: CGRect.init(x: 0, y: self.height - 120, width: self.width, height: 120))
        view.backgroundColor = UIColor.clear
        view.layer.addSublayer(self.bottomGradientLayer)
        view.isUserInteractionEnabled = false
        self.bottomGradientLayer.frame = view.bounds
        return view
    }()
    
    lazy var bottomGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init(x: 0, y: 0)
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)

        let clr1 = UIColor.black.withAlphaComponent(0).cgColor
        let clr2 = UIColor.black.withAlphaComponent(1).cgColor
        layer.colors = [clr1 , clr2]
        return layer
    } ()
    
//    lazy var bottomMaskView: UIView = {
//        let view = UIView.init(frame: CGRect.init(x: 0, y: self.height - 120, width: self.width, height: 120))
//        view.backgroundColor = UIColor.black
//        view.isUserInteractionEnabled = false
//        return view
//    }()
    
    lazy var finishView: Comp14301PlayFinishView = {
        let view = Comp14301PlayFinishView.init(frame: self.playerViewFrame)
        view.isHidden = true
        
        weak var weakSelf = self
        view.replayCallback = {
            weakSelf?.finishView.isHidden = true
            weakSelf?.playerView?.replayPlayer()
            weakSelf?.seekToTime(0)
//            weakSelf?.showWithDelayHide()
        }
        return view
    } ()
    
    lazy var hotActionView: UIView = {
        let hasStack = self.playerViewFrame.origin.y == KComp14301ContentViewTopMagin
        let top = YKStatusBarHeight() + 46 + YKNGap.dim_5() //从tabMenu下方开始
        let view = UIView.init(frame: CGRect.init(x: 0, y: top, width: self.width, height: self.height - (hasStack ? 70 : 0) - top))
        view.backgroundColor = .clear
        
        weak var weakSelf = self
        view.whenTapped {
            weakSelf?.showWithDelayHide(true)
        }
        return view
    } ()
    
    lazy var bottomActionView: UIView = {
        let view = UIView.init(frame: CGRect.init(x: 15, y: self.height - 70, width: self.width - 30, height: 70))
        view.backgroundColor = .clear
        
        weak var weakSelf = self
        
        if self.playerViewFrame.origin.y == KComp14301ContentViewTopMagin {
            view.whenTapped {
                if let page = weakSelf?.component?.getPage() {
                    let userInfo = ["page" : page]
                    NotificationCenter.default.post(name: Notification.Name(rawValue: "immersive.bottom.clicked"), object: nil, userInfo: userInfo)
                }
                
            }
        }
        return view
    } ()
    
    // MARK: - 结束区
    
    // 看正片
    lazy var seeLabel: UIView = {
        let view = UIView.init(frame: CGRect.zero)
        view.layer.cornerRadius = 18
        view.clipsToBounds = true
        view.backgroundColor = .white
        
        let label = UILabel.init(frame: CGRect.zero)
        label.text = "\u{e678}"
        label.font = YKNIconFont.sharedInstance().font(withSize: 16) //图标大一些
        label.textColor = UIColor.ykn_brandInfo
        label.sizeToFit()
        view.addSubview(label)
        
        let seelabel = UILabel.init(frame: CGRect.zero)
        seelabel.text = "看正片"
        seelabel.font = YKNIconFont.sharedInstance().font(withSize: 14)
        seelabel.textColor = UIColor.ykn_brandInfo
        seelabel.sizeToFit()
        view.addSubview(seelabel)
        
        let width = 12 + label.width + 8 + seelabel.width + 15
        view.frame = CGRect.init(x: (self.width - width) / 2, y: seeLabelTop(), width: width, height: 36)
        
        label.left = 12
        label.top = (36 - label.height) / 2
        
        seelabel.right = width -  15
        seelabel.top = (36 - seelabel.height) / 2
        
        view.isHidden = true
        return view
    } ()
    
    // 预约
    lazy var sbLabel: UIView = {
        let view = UIView.init(frame: CGRect.zero)
        view.layer.cornerRadius = 18
        view.clipsToBounds = true
        view.backgroundColor = .white
        
        let label = UILabel.init(frame: CGRect.zero)
        label.text = "\u{e67e}"
        label.font = YKNIconFont.sharedInstance().font(withSize: 16) //图标大一些
        label.textColor = UIColor.ykn_brandInfo
        label.sizeToFit()
        label.tag = 808080
        view.addSubview(label)
        
        let seelabel = UILabel.init(frame: CGRect.zero)
        seelabel.font = YKNIconFont.sharedInstance().font(withSize: 14)
        seelabel.textColor = UIColor.ykn_brandInfo
        seelabel.tag = 808081
        view.addSubview(seelabel)
        
        weak var weakSelf = self
        view.whenTapped {
            weakSelf?.reserveAction()
        }
        view.isHidden = true
        return view
    } ()
    
    weak var reserveModel:ReserveModel?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.tag = 998877
        self.addSubview(self.bottomActionView)
        self.addSubview(self.hotActionView)
        self.addSubview(self.coverImageView)
        self.addSubview(self.bgImageView)
        
        if !YKUIConfig.sharedInstance().isLowDevice() {
            self.addSubview(self.topGradientView)
            self.addSubview(self.bottomGradientView)
//            self.addSubview(self.bottomMaskView)
        }
        self.addSubview(self.contentSuperView)
        self.addSubview(self.logoContainerView)
        self.addSubview(self.titleLabel)
        self.addSubview(self.subTitleLabel)
        
        self.addSubview(self.leftImgView)
        self.addSubview(self.rightImgView)
        
        self.addSubview(self.seeLabel)
        self.addSubview(self.sbLabel)
        
        self.addSubview(self.playControlView)
        self.playControlView.addSubview(self.playBtn)
        self.playControlView.addSubview(self.slider)
        self.playControlView.addSubview(self.muteButton)
        self.playControlView.addSubview(self.fullScreenBtn)
        self.addSubview(self.finishView)
        self.addSubview(self.muteButton2)
        
        contentSuperView.view1 = logoContainerView
        contentSuperView.view2 = titleLabel
        contentSuperView.view3 = subTitleLabel
//        contentSuperView.view4 = playControlView
        contentSuperView.view5 = leftImgView
        contentSuperView.view6 = rightImgView
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        if ImmersivePageManager.shared.pageVcDataIsReady == false &&
            self.component?.getPage()?.pageModel?.dataState == .network {
            
            ImmersivePageManager.shared.pageVcDataIsReady = true
            NSLog("[Immersive] layoutSubviews set pageVcDataIsReady")
        }
    }
    
    // MARK: - update data
    weak var comp: IComponent?
    weak var item: IItem?
    
    func fill(_ comp: IComponent?) {
        guard let comp = comp, let item = comp.getItems()?.first , let itemModel = item.itemModel as? Item14301Model else {
            return
        }
        
        self.component = comp
        self.item = item
        
        print("[immersive] hidden fillData \(self)")
        leftImgView.isHidden = true
        rightImgView.isHidden = true
        if var title = itemModel.subtitle, title.isEmpty == false {
            if title.count > 16 {
                title = title.prefix(16) + "..."
            }
            titleLabel.text = title
            
            titleLabel.sizeToFit()
            titleLabel.centerX = self.width / 2
            
            leftImgView.isHidden = false
            rightImgView.isHidden = false
            leftImgView.centerY = titleLabel.centerY
            leftImgView.right = titleLabel.left - 9
            
            rightImgView.centerY = titleLabel.centerY
            rightImgView.left = titleLabel.right + 9
        } else {
            titleLabel.text = ""
        }
        
        if var title = itemModel.desc, title.isEmpty == false {
            if title.count > 16 {
                title = title.prefix(16) + "..."
            }
            subTitleLabel.text = title
        } else {
            subTitleLabel.text = ""
        }

        coverImageView.isHidden = true
        if let img = itemModel.previewModel?.coverImg, let imgUrl = URL.init(string: img) {
//            bgImageView.sd_setImage(with: imgUrl)
            weak var weakbgImageView = bgImageView
            
            coverImageView.isHidden = false
            coverImageView.sd_setImage(with: imgUrl, module: "home", placeholderImage: nil, progress: nil) { image, err, cacheType, url in
                if let image = image {
                    let newSize = CGSize.init(width: image.size.width / 4, height: image.size.height / 4)
                    let newImg = resize(image, newSize, 1)
                    weakbgImageView?.image = newImg ?? image
                }
            }
            resetBgViewPosition()
        } else {
            bgImageView.image = nil
            coverImageView.image = nil
        }
        
        logoContainerView.fillData(itemModel)
        
        itemModel.action?.playingProgress = self
        
        if let actionModel = itemModel.extraExtend["model.action"] as? ActionModel {
            actionModel.playingProgress = self
            Service.action.bind(actionModel, fullScreenBtn, .OnlyClick)
        }
        
        Service.statistics.bind(itemModel.action?.report, self, .OnlyExposure)
        
        bindPauseReport(true)
        syncMuteBtn()
        
        self.playControlView.muteBtn = self.muteButton2
        self.playControlView.isHidden = true
        self.muteButton2.isHidden = true
        
        self.finishView.fill(item)
        self.finishView.isHidden = true
        
        self.reserveModel = itemModel.reserveModel
        print("[immersive] type: \(2) reserve: \(self.reserveModel) item:\(item)")
//        itemModel.buttonType = 2
        refreshReserveSubViews(itemModel.buttonType)
        
        self.subTitleLabel.isHidden = shouldHideSubtitle()
        
        if !ImmersivePageManager.shared.isEnterPage { //防止过早发曝光
            print("[immersive] 未进入页面")
            setIgnoreExpose()
        } else {
            print("[immersive] 已进入页面")
            sendItemExposed()
        }
    }
    
    func setIgnoreExpose(_ ignore: Bool = true) {
        guard let itemModel = getItemModel() as? Item14301Model, itemModel.exposeLogIgnored != ignore else {
            return
        }
        
        itemModel.exposeLogIgnored = ignore
        
        if ignore {
            print("[immersive] hidden setIgnoreExpose")
            GTrackerManager.sharedInstance().setIgnoreTagForExposureView(self)
            GTrackerManager.sharedInstance().setIgnoreTagForExposureView(seeLabel)
            
            registExposeObserver()
        } else {
            print("[immersive] hidden setClearIgnoreExpose")
            GTrackerManager.sharedInstance().clearTrackerTagView(self)
            GTrackerManager.sharedInstance().clearTrackerTagView(seeLabel)
        }
    }
    
    func registExposeObserver() {
        NotificationCenter.default.addObserver(self, selector: #selector(receiveFirstItemExposeNotification(_:)), name: Notification.Name(rawValue: "YKChannelpage.immersive.enterPage"), object: nil)
    }
    
    func removeExposeObserver() {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func receiveFirstItemExposeNotification(_ notif: Notification?) {
        guard ImmersivePageManager.shared.isEnterPage  else {
            return
        }
        
        print("[immersive] hidden receive enter")
        setIgnoreExpose(false)
        removeExposeObserver()
        sendItemExposed()
    }

    // MARK: - layout
    
    lazy var playerViewFrame: CGRect =  {
        let width = self.width
        let height: CGFloat = ceil(width / KComp14301ContentViewRatio)
        return CGRect(x: 0, y: ImmersivePageManager.shared.playerTopMagin, width: width, height: height)
    } ()
    
    // MARK: - life
    
    func didActivate() {
//        NSLog("[Immersive] didActivate")
//        if _visable {
//            startPlayer()
//        }
    }
    
    func didDeactivate() {
//        NSLog("[Immersive] didDeactivate")
//        stopPlayer()
    }
    
    func enterDisplay() {
//        NSLog("[Immersive] enterDisplay")
//        _visable = true
    }
    
    func exitDisplay() {
//        NSLog("[Immersive] exitDisplay")
//        _visable = false
    }
    
    // MARK: - ChannelSliderPlayerDelegate
    
    /// 开始播放
    func didStartPlayVideo(in player: ChannelSliderPlayer) {
        NSLog("[Immersive] conentView didStartPlayVideo")
        self.finishView.isHidden = true
        self.insertSubview(self.finishView, belowSubview: self.bgImageView)
        player.embedPlayerView().isHidden = false
        updatePlayBtnStatus(true)
        syncMuteBtn()
//        self.cancelDelayHidePlayerControl()
//        self.hidePlayerControl()
        if self.playControlView.isHidden {
            self.muteButton2.isHidden = !ImmersivePlayerView.isMute
        }
    }

    /// 播放错误
    func player(_ player: ChannelSliderPlayer, playError errorCode: Int32) {
        NSLog("[Immersive] conentView playError :\(errorCode)")
    }
    
    /// 播放完成
    func didFinishPositiveVideo(in player: ChannelSliderPlayer) {
        NSLog("[Immersive] conentView didFinishPositiveVideo")
        
//        self.finishView.fill(item)
        player.embedPlayerView().isHidden = true
        coverImageView.isHidden = false
        self.finishView.isHidden = false
        self.cancelDelayHidePlayerControl()
        self.hidePlayerControl()
        self.muteButton2.isHidden = true
    }
    
    func didTouch(_ player: ChannelSliderPlayer!) {
        NSLog("[Immersive] contentview didTouch")
        
        showWithDelayHide(true)
    }
    
    func playingProgress(_ progress: Int, totalTime time: Int) {
//        NSLog("[Immersive] contentview \(self) playingProgress progress:\(progress) totalTime:\(time) ")
        playerView?.userPaused = false
        finishView.isHidden = true
        
        self.slider.value = Float(progress)
        if self.slider.maximumValue == 0 || Int(self.slider.maximumValue) != time {
            self.slider.maximumValue = Float(time)
        }
        
        if ImmersivePageManager.shared.curScrollProgress < 1 { //滑动过程中不处理
            return
        }
        
        updateBgOrigin(progress)
    }
    
    func immersiveStartPlayer() {
        resetBgViewPosition()
    }
    
    func immersivePausePlayer() {
        
    }
    
    func immersiveResumePlayer() {
        
    }
    func immersiveStopPlayer() { //重置位置
        resetBgViewPosition()
    }
    
    func resetBgViewPosition() {
        self.bgImageView.left = (self.width - self.bgImageView.width) / 2
        isToRight = true
    }
    
    var isToRight: Bool = true
    var isReplay: Bool = false
    var hasPlayed: Bool = false
    
    // 平移动画
    func updateBgOrigin(_ progress: Int) {
        let totalX = ceil((self.bgImageView.width - self.width) / 2)
        
        let curMoveX = ceil(totalX * (1.0 / 15))
        var useX: CGFloat = 0
        
        if isToRight {
            useX = self.bgImageView.left - curMoveX
            
            if abs(useX - (self.width - self.bgImageView.width)) <= curMoveX { //最右侧
                isToRight = false
            }
        } else {
            useX = self.bgImageView.left + curMoveX
            
            if abs(useX) <= curMoveX { //最左侧
                isToRight = true
            }
        }
        
        // 从中心开始
        
        UIView.animate(withDuration: 0.95, delay: 0, options:.curveLinear, animations: {
            self.bgImageView.left = useX
        }, completion: { _ in
            self.bgImageView.left = useX
        })
        
//        NSLog("[Immersive] contentview \(self) move 播放时间:\(progress)s 总位移:\(totalX) 之前位置:\(beforeLeft) 计算位移:\(curMoveX) 之后位置:\(useX) 向右:\(isToRight)")
    }

    
    // MARK: - PlayingProgress
    
    public func getPlayedSeconds() -> Int {
        var playerProgress: CGFloat = 0
        if let playerId = getPreviewId(), let seekTime = ImmersivePageManager.shared.seekTimeMap[playerId] {
            playerProgress = seekTime * 1000
        }
        
        let isPreview = (getItemModel() as? Item14301Model)?.buttonType != 0 //预览视频加进度
        if isPreview, let hotPoint = highlightPoint() {
            playerProgress = CGFloat(hotPoint) + playerProgress
        }
        let usePoint = Int(playerProgress)
        NSLog("[Immersive] 跳转播放器 进度：\(usePoint)s")
        return usePoint
    }
    
    public func isHotPointVideo() -> Bool {
        if let hotPoint = self.item?.itemModel?.preview?["hotPoint"] as? NSNumber, hotPoint.intValue > 0 {
            return true
        }
        return false
    }
    public func highlightPoint() -> Int? {
        if let hotPoint = self.item?.itemModel?.preview?["hotPoint"] as? NSNumber, hotPoint.intValue > 0 {
            return hotPoint.intValue
        }
        return nil
    }
        
    func getPreviewId() -> String? {
        guard let itemModel = getItemModel() else {
            return nil
        }
        
        let preview = itemModel.preview
        var previewVid:String?
        if let vid = preview?["vid"] as? NSNumber {
            previewVid = vid.stringValue
        } else if let vid = preview?["vid"] as? String {
            previewVid = vid
        }
        return previewVid
    }
    
    // MARK: - 播控
    
    func resumePlayer() {
        playerView?.resumePlayer()
    }
    
    func pausePlayer() {
        playerView?.pausePlayer()
    }
    
    // MARK: - action
    
    @objc func muteBtnTap() {
        muteBtnTap2()
//        showWithDelayHide()
    }
    
    @objc func muteBtnTap2() {
        ImmersivePlayerView.isMute = !ImmersivePlayerView.isMute
        self.playerView?.player?.isSlientMode = ImmersivePlayerView.isMute
        self.muteButton.isSelected = ImmersivePlayerView.isMute
        self.muteButton2.isSelected = self.muteButton.isSelected
        bindMuteButtonReport()
        showWithDelayHide()
    }
    
    @objc func playBtnTap() {
        let isPlay = !(playerView?.isPlayerPlaying ?? false)
        updatePlayBtnStatus(isPlay)
        if isPlay {
            resumePlayer()
        } else {
            pausePlayer()
        }
    }
    
    func updatePlayBtnStatus(_ isPlay: Bool) {
        if isPlay {
            self.playBtn.isSelected = false
            playerView?.userPaused = false
            bindPauseReport(true)
            delayHidePlayControl()
        } else {
            self.playBtn.isSelected = true
            playerView?.userPaused = true
            bindPauseReport(false)
            showPlayerControl()
        }
    }
    
    @objc func hidePlayBtn() {
        self.playBtn.isHidden = true
    }
    
    @objc func sliderValueChanged(_ sender: UISlider) {
        let newValue = sender.value
        seekToTime(Double(newValue))
        delayHidePlayControl()
    }

    @objc func sliderTapped(_ gesture: UITapGestureRecognizer) {
        guard let view = gesture.view else {
            return
        }
        
        let pointTapped: CGPoint = gesture.location(in: view)
        let widthOfSlider: CGFloat = slider.frame.size.width
        let progress = Float(pointTapped.x + 2) / Float(widthOfSlider)
//        print("当前进度：\(progress)")
        
        let value = slider.maximumValue * progress
        slider.setValue(value, animated: true)
                        
        seekToTime(Double(value))
        delayHidePlayControl()
    }
    
    func syncMuteBtn() {
        self.muteButton.isSelected = ImmersivePlayerView.isMute
        self.muteButton2.isSelected = self.muteButton.isSelected
        
        bindMuteButtonReport()
    }

    private func seekToTime(_ time: Double) {
        self.playerView?.player?.seek(toTime: TimeInterval(time))
    }
    
    private func getItemModel() -> BaseItemModel? {
        return self.item?.itemModel
    }
    
    func bindMuteButtonReport() {
        guard let itemModel = getItemModel() else {
            return
        }
        if ImmersivePlayerView.isMute {
            Service.statistics.bind(itemModel.preview?["report_volumeon"] as? ReportModel, muteButton, .OnlyClick)
            Service.statistics.bind(itemModel.preview?["report_volumeon"] as? ReportModel, muteButton2, .OnlyClick)
        } else {
            Service.statistics.bind(itemModel.preview?["report_volumeoff"] as? ReportModel, muteButton, .OnlyClick)
            Service.statistics.bind(itemModel.preview?["report_volumeoff"] as? ReportModel, muteButton2, .OnlyClick)
        }
    }
    
    func bindPauseReport(_ isPause: Bool) {
        guard let itemModel = getItemModel() else {
            return
        }
        
        Service.statistics.bind(isPause ? itemModel.preview?["report_pause"] as? ReportModel : itemModel.preview?["report_play"] as? ReportModel, playBtn, .OnlyClick)
    }
    
    func delayHidePlayControl() {
        cancelDelayHidePlayerControl()
        self.perform(#selector(hidePlayerControl), with: nil, afterDelay: 3)
    }
    
    func cancelDelayHidePlayerControl() {
        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(hidePlayerControl), object: nil)
    }
    
    @objc func hidePlayerControl() {
        _hidePlayerControl(true)
    }
    
    func _hidePlayerControl(_ isHiden: Bool) {
        UIView.animate(withDuration: 0.25, delay: 0, options:.curveEaseInOut, animations: {
            self.playControlView.isHidden = isHiden
        }, completion: { _ in
            
        })
    }
    
    func showPlayerControl() {
        cancelDelayHidePlayerControl()
        _hidePlayerControl(false)
    }
    
    func showWithDelayHide(_ orHide: Bool = false) {
        if self.playControlView.isHidden {
            showPlayerControl()
            
            if (playerView?.userPaused ?? false) == false {
                delayHidePlayControl()
            }
        } else {
            if orHide {
                hidePlayerControl()
            } else {
                if (playerView?.isPlayerPlaying ?? false) {
                    delayHidePlayControl()
                }
            }
        }
    }
    
    // MARK: - 结束区view
    
    func refreshReserveSubViews(_ buttonType: Int) {
        if buttonType == 2 { //预约
            showSubscribeLabel()
        } else {
            showSeeLabel()
        }
    }
    
    func showSeeLabel() {
        seeLabel.isHidden = false
        sbLabel.isHidden = true
        
        self.seeLabel.top = seeLabelTop()
        
        if let actionModel = self.item?.itemModel?.preview?["report_see"] as? ActionModel {
            actionModel.playingProgress = self
            Service.action.bind(actionModel, seeLabel, .Defalut) //点击去正片
        }
    }
    
    func showSubscribeLabel() {
        guard let _ = reserveModel else {
            sbLabel.isHidden = true
            seeLabel.isHidden = true
            return
        }

        sbLabel.isHidden = false
        seeLabel.isHidden = true
        
        refreshSubscrib()
        bindStatisticsService()
        addObserver()
    }
    
    func onlyShowReplay() {
        sbLabel.isHidden = true
        seeLabel.isHidden = true
    }
    
    // MARK: - action
    
    @objc func reserveAction() {
        guard let reserveModel = item?.itemModel?.reserveModel else {
            return
        }
        guard let dingyueSDK = DYKServiceManager.sharedInstance().service(forProtocolName: "YKDingYueProtocol") as? YKDingYueProtocol else {
            return
        }
        
        var params = [String:Any]()
        params["bizId"] = reserveModel.bizId
        params["reservationId"] = reserveModel.rid
        params["reservationType"] = reserveModel.reservationType
        params["deviceType"] = "IPHONE"
        let report = reserveModel.isReserve ? reserveModel.cancelReserveReport : reserveModel.addReserveReport
        params["src"] = report?.spm
        if reserveModel.isReserve {
            dingyueSDK.help_cancelReservation?(params) { _, _, _ in
                
            }
        } else {
            dingyueSDK.help_addReservation?(params) { _, _, _ in

            }
        }
    }
    
    // MARK: - 预约
    
    func addObserver() {
        guard let _ = reserveModel else {
            return
        }
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddReserveSuccessNotication), name: NSNotification.Name.init("kAddReserveSuccessNotification"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelReserveSuccessNotication), name: NSNotification.Name.init("kCancelReserveSuccessNotification"), object: nil)
    }
    
    @objc func handleAddReserveSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, isReserved: true)
    }
    
    @objc func handleCancelReserveSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, isReserved: false)
    }
    
    func handleNotication(notification: Notification, isReserved: Bool) {
        
        guard let reserveId = notification.object as? String else {
            return
        }
        guard let reserveModel = reserveModel, let currentId = reserveModel.rid else {
            return
        }
        guard currentId == reserveId else {
            return
        }

        reserveModel.isReserve = isReserved
        
        refreshSubscrib()
        bindStatisticsService()
    }
    
    func refreshSubscrib() {
        guard let reserveModel = reserveModel else {
            return
        }
        
        guard let label = sbLabel.viewWithTag(808080), let seelabel =  sbLabel.viewWithTag(808081) as? UILabel else {
            return
        }
        
        if !reserveModel.isReserve {
            label.isHidden = false
            seelabel.isHidden = false
            
            seelabel.text = "预约"
            seelabel.textColor = UIColor.ykn_brandInfo
            seelabel.sizeToFit()
            
            let width = 12 + label.width + 6 + seelabel.width + 15
            sbLabel.frame = CGRect.init(x: (self.width - width) / 2, y: seeLabelTop(), width: width, height: 36)
            sbLabel.backgroundColor = .white

            label.left = 12
            label.top = (36 - label.height) / 2
            
            seelabel.right = width -  15
            seelabel.top = (36 - seelabel.height) / 2
        } else {
            label.isHidden = true
            seelabel.isHidden = false
            seelabel.text = "已预约"
            seelabel.textColor = UIColor.white
            seelabel.sizeToFit()
            
            sbLabel.frame = CGRect.init(origin: CGPointMake((self.width - 72) / 2, seeLabelTop()), size: CGSize(width: 72, height: 36))
            sbLabel.backgroundColor = .ykn_co_2

            seelabel.left = (72 - seelabel.width) / 2
            seelabel.top = (36 - seelabel.height) / 2
        }
    }
    
    public func bindStatisticsService() {
        guard let reserveModel = reserveModel else {
            return
        }
        if reserveModel.isReserve {
            Service.statistics.bind(reserveModel.cancelReserveReport, sbLabel, .OnlyClick)
        } else {
            Service.statistics.bind(reserveModel.addReserveReport, sbLabel, .OnlyClick)
        }
    }
    
    func isSmallDevice() -> Bool {
        return self.playerViewFrame.origin.y != KComp14301ContentViewTopMagin
    }
    
    func seeLabelTop() -> CGFloat {
        return shouldHideSubtitle() ? (self.titleLabel.bottom + 12) : (self.subTitleLabel.bottom + 12)
    }
    
    func shouldHideSubtitle() -> Bool {
        let showImg = self.logoContainerView.useView.isKind(of: UIImageView.self)
        let flag = (isSmallDevice() && showImg)
        return flag
    }
    
    // MARK: - 自定义埋点
    
    func sendItemExposed() {
        guard let model = self.getItemModel() as? Item14301Model, let reportModel = model.action?.report else {
            return
        }
        
        var params = [String : Any]()
        params["spm"] = reportModel.spm
        params["scm"] = reportModel.scm
        params["vid"] = model.previewModel?.vid
        params["isNodePage"] = ImmersivePageManager.shared.isNodePage
        print("[immersiveLog] sendItemExposed param:\(params)")
        YoukuAnalytics.sharedInstance().collectALiCustomEvent(withEventID: "19999", pageName: "immersiveCustomLog", arg1: "itemExpose", arg2: nil, arg3: nil, args: params)
    }
}

class Content14301ContentPlaceHolderView: UIView {
    weak var view1: UIView?
    weak var view2: UIView?
    weak var view3: UIView?
    weak var view4: UIView?
    weak var view5: UIView?
    weak var view6: UIView?
    
    override var alpha: CGFloat {
        didSet {
            view1?.alpha = alpha
            view2?.alpha = alpha
            view4?.alpha = alpha
            view3?.alpha = alpha
            view5?.alpha = alpha
            view6?.alpha = alpha
        }
    }
}

class Comp14301PlayerControlView: UIView {
    weak var muteBtn: UIButton?
    
    override var isHidden: Bool {
        didSet {
            if isHidden == true {
                muteBtn?.isHidden = true
                if (muteBtn?.isSelected ?? false) == true {
                    muteBtn?.isHidden = false
                }
            } else {
                muteBtn?.isHidden = true
            }
        }
    }
}

class Comp14301ExtendedUIButton: UIButton {
    override func point(inside point: CGPoint, with event: UIEvent?) -> Bool {
        let margin: CGFloat = (40 > self.width) ? (40 - self.width) / 2 : 0
        let area = self.bounds.insetBy(dx: -margin, dy: -margin)
        print("[immersive] ext button a:\(area) f:\(area.contains(point))")
        return area.contains(point)
    }
}
