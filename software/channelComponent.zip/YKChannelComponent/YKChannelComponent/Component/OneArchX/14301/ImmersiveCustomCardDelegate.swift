//
//  ImmersiveCustomCardDelegate.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/3/15.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku

class ImmersiveCustomCardDelegate: BaseCardDelegate {
    override func isShowHeader() -> Bool {
        return false
    }
}
