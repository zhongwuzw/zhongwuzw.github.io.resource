//
//  Component14301.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/3/15.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import YKChannelPage

class Component14301: NSObject, ComponentDelegate, ComponentLifeCycleDelegate {
   
    var componentWrapper: ComponentWrapper?
    weak var contentView: Comp14301ContentView?
    
    func componentDidInit() {}
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    func isShowBackground() -> Bool {
        return false
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        return config
    }

    func columnCount() -> CGFloat {
        return 1
    }

    /// 是否展示组件尾
    func isShowFooter() -> Bool {
        return false
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        let eventHandler = ComponentLifeCycleEventHandler.init()
        eventHandler.delegate = self
        return [eventHandler]
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Comp14301Model.self as? T.Type
    }

    func createView(_ itemSize: CGSize) -> UIView {
        let view = Comp14301ContentView.init(frame: CGRect.init(origin: CGPoint(x: 0, y: 0), size: itemSize))
        NSLog("[Immersive] 14301 createView \(view)")
        return view
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Comp14301ContentView else {
            return
        }
        NSLog("[Immersive] 14301 reuseView \(itemView)")
        contentView = itemView
        itemView.fill(self.component)
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return self.component?.getPage()?.pageContext?.getContainerView()?.height ?? UIScreen.main.bounds.height
    }
    
    // MARK: - ComponentLifeCycleDelegate
    func enterDisplayArea(itemView: UIView?) {
        contentView?.enterDisplay()
    }
    
    func exitDisplayArea(itemView: UIView?) {
        contentView?.exitDisplay()
    }
    
    func didActivate() {
        contentView?.didActivate()
    }
    
    func didDeactivate() {
        contentView?.didDeactivate()
    }
}

class Item14301 : NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {}
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14301Model.self as? T.Type
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView.init(frame: CGRect.zero)
    }
    
    func reuseView(itemView: UIView) {
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
}
