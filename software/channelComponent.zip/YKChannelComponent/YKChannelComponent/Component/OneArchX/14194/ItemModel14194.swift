//
//  ItemModel14194.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/4/8.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku
import YKChannel

class ItemModel14194: BaseItemModel {
    
    var listActionInfo: [String: Any]?
    
    var attachTitle: String?
    
    var attachTitleIcon: String?
    
    var attachImg: String?
    
    var attachPlayVideoId: String?
    
    var attachYear: String?
    
    var attachMonth: String?
    
    var attachDay: String?
    
    var attachDateString: String?
    
    var attachMovieTitle: String?
    
    var attachSubtitle: String?
    
    var attachDesc: String?
    
    var attachPlayActionInfo: [String: Any]?
    
    var attachModel: YKSCCalendarHeaderAttachmentModel?
    
    override func setup(_ cmsInfo: [String: Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        // 解析属性
        if let listActionInfo = cmsInfo?["action"] as? [String: Any] {
            self.listActionInfo = listActionInfo
        }
        
        guard let dataInfo = cmsInfo?["data"] as? [String: Any] else {
            return
        }
        
        if let attachTitle = dataInfo["title"] as? String {
            self.attachTitle = attachTitle
        }
        
        if let attachTitleIcon = dataInfo["titleIcon"] as? String {
            self.attachTitleIcon = attachTitleIcon
        }
        
        if let attachImg = dataInfo["imgV2"] as? String {
            self.attachImg = attachImg
        }
        
        if let playVideoId = dataInfo["playVideoId"] as? NSNumber {
            self.attachPlayVideoId = playVideoId.stringValue
        } else if let playVideoId = dataInfo["playVideoId"] as? String {
            self.attachPlayVideoId = playVideoId
        }
        
        if let extraExtend = dataInfo["extraExtend"] as? [String: Any] {
            if let attachYear = extraExtend["year"] as? String {
                self.attachYear = attachYear
            }
            
            if let attachMonth = extraExtend["month"] as? String {
                self.attachMonth = attachMonth
            }
            
            if let attachDay = extraExtend["day"] as? String {
                self.attachDay = attachDay
            }
            
            if let attachDateString = extraExtend["returnVal"] as? String {
                self.attachDateString = attachDateString
            }
            
            if let attachMovieTitle = extraExtend["title"] as? String {
                self.attachMovieTitle = attachMovieTitle
            }
            
            if let attachSubtitle = extraExtend["anniversary"] as? String {
                self.attachSubtitle = attachSubtitle
            }
            
            if let attachDesc = extraExtend["desc"] as? String {
                self.attachDesc = attachDesc
            }
        }
        
        if let attachPlayActionInfo = dataInfo["action"] as? [String: Any] {
            self.attachPlayActionInfo = attachPlayActionInfo
        }
        
        self.attachModel = self.parseCalendarData(self)
    }
    
    func parseCalendarData(_ itemModel: ItemModel14194) -> YKSCCalendarHeaderAttachmentModel? {

        // 初始化YKSCCalendarHeaderAttachmentModel实例
        let attachModel = YKSCCalendarHeaderAttachmentModel()

        if let listActionInfo = itemModel.listActionInfo, !listActionInfo.isEmpty {
            attachModel.listActionInfo = listActionInfo
        }

        if let title = itemModel.attachTitle, !title.isEmpty {
            attachModel.title = title
        }

        if let titleIcon = itemModel.attachTitleIcon, !titleIcon.isEmpty {
            attachModel.titleIcon = titleIcon
        }

        if let img = itemModel.attachImg, !img.isEmpty {
            attachModel.img = img
        }

        if let playVideoId = itemModel.attachPlayVideoId, !playVideoId.isEmpty {
            attachModel.playVideoId = playVideoId
        }

        if let year = itemModel.attachYear, !year.isEmpty {
            attachModel.year = year
        }

        if let month = itemModel.attachMonth, !month.isEmpty {
            attachModel.month = month
        }

        if let day = itemModel.attachDay, !day.isEmpty {
            attachModel.day = day
        }

        if let dateString = itemModel.attachDateString, !dateString.isEmpty {
            attachModel.dateString = dateString
        }

        if let movieTitle = itemModel.attachMovieTitle, !movieTitle.isEmpty {
            attachModel.movieTitle = movieTitle
        }

        if let subtitle = itemModel.attachSubtitle, !subtitle.isEmpty {
            attachModel.subtitle = subtitle
        }

        if let desc = itemModel.attachDesc, !desc.isEmpty {
            attachModel.desc = desc
        }

        if let playActionInfo = itemModel.attachPlayActionInfo, !playActionInfo.isEmpty {
            attachModel.playActionInfo = playActionInfo
        }

        return attachModel
    }

}
