//
//  Item14194.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/4/6.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YKChannel
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Item14194: NSObject, ItemDelegate {

    var itemWrapper: ItemWrapper?
    var itemModel: BaseItemModel?

    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14194ConentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }

    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14194ConentView else {
            return
        }
        guard let itemModel = self.item?.model as? ItemModel14194 else {
            return
        }

        self.itemModel = itemModel
        
        itemView.fillData(self.item, layout: itemModel.layout)
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let aspectRatio: CGFloat = 16.0 / 9.0
        let itemHeight: CGFloat = itemWidth * aspectRatio
        let itemSize = CGSize(width: itemWidth, height: itemHeight)
        self.estimatedLayout(itemSize)
        return itemHeight
    }

    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return ItemModel14194.self as? T.Type
    }

    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }

    func itemDidInit() {

    }

    func isPageInPreload() -> Bool {
        guard let pageModel = self.item?.getPage()?.pageModel else {
            return false
        }
        if pageModel.dataState == .cache || pageModel.dataState == .default {
            return true
        }
        return false
    }

    func estimatedLayout(_ itemSize: CGSize) {
        guard let itemModel = self.item?.model as? ItemModel14194 else {
            return
        }
        
        guard let layoutModel = self.item?.layout else {
            return
        }
        
        if layoutModel.boundingSize == itemSize {
            return
        }
        
        let extraExtend = itemModel.extraExtend
        
        layoutModel.boundingSize = itemSize
        layoutModel.renderRect = CGRect.init(origin: .zero, size: itemSize)
        
        var extendExtra = [String: Any]()

        let itemHeight = itemSize.height
        var textYCursor: CGFloat = max(itemHeight - 9.0 - 30.0 - 5.0, 0) // formula = 坑位总高 - bottompadding - 播放按钮高度 - gap
        let textLeft: CGFloat = 12
        let textWidthMax = max(itemSize.width - textLeft * 2, 0)

        if let t3Text = extraExtend["title"] as? String, !t3Text.isEmpty {
            let layout = TextLayoutModel.init()
            let font = Item14194ConentView.t3LabelFont()
            let singleLineHeight = font.lineHeight

            textYCursor = textYCursor - singleLineHeight
            layout.renderRect = CGRect.init(x: textLeft, y: textYCursor, width: textWidthMax, height: singleLineHeight)

            extendExtra["t3"] = layout

            textYCursor = textYCursor - 6.0
        }

        if let t2Text = extraExtend["desc"] as? String, !t2Text.isEmpty {
            let layout = TextLayoutModel.init()
            let font = Item14194ConentView.t2LabelFont()
            let singleLineHeight = font.lineHeight
            let textHeightMax = singleLineHeight * 3.5 // 最多3行，小数点为行间距约数。
            let textFitHeight = calcStringHeight(t2Text, font: font, limitSize: CGSize.init(width: textWidthMax, height: textHeightMax))//(t2Text, font: font, size: CGSize.init(width: textWidthMax, height: textHeightMax))

            textYCursor = textYCursor - textFitHeight
            layout.renderRect = CGRect.init(x: textLeft, y: textYCursor, width: textWidthMax, height: textFitHeight)

            extendExtra["t2"] = layout

            textYCursor = textYCursor - 9.0
        }

        if let t1Text = extraExtend["anniversary"] as? String, !t1Text.isEmpty {
            let layout = TextLayoutModel.init()
            let font = Item14194ConentView.t1LabelFont()
            let singleLineHeight = font.lineHeight

            textYCursor = textYCursor - singleLineHeight
            layout.renderRect = CGRect.init(x: textLeft, y: textYCursor, width: textWidthMax, height: singleLineHeight)

            extendExtra["t1"] = layout
        }
        
//        DispatchQueue.main.async {
            layoutModel.extendExtra = extendExtra
//        }
    }
}
