//
//  Item14194ConentView.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/4/6.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import SDWebImage
import YoukuResource
import YKChannel
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item14194ConentView: AccessibilityView {
    
    let monthArray = ["JAN", "FEB", "MAR", "APR", "MAY", "JUNE", "JULY", "AUG", "SEPT", "OCT", "NOV", "DEC"]
    weak var item: IItem?
    var model:ItemModel14194? {
        return self.item?.itemModel as? ItemModel14194
    }
    
    lazy var dayLabel: UILabel = {
        let view = UILabel()
        view.textColor = .white
        view.font = YKNFont.akrobatExtraBoldFont(ofSize: 29)
        return view
    }()
    
    lazy var monthLabel: UILabel = {
        let view = UILabel()
        view.textColor = .white.withAlphaComponent(0.7)
        view.font = YKNFont.akrobatExtraBoldFont(ofSize: 11)
        return view
    }()
    
    lazy var t1Label: UILabel = {
        let view = UILabel()
        view.textColor = .white.withAlphaComponent(0.7)
        view.font = Item14194ConentView.t1LabelFont()
        return view
    }()
    
    lazy var t2Label: UILabel = {
        let view = UILabel()
        view.textColor = .white
        view.font = Item14194ConentView.t2LabelFont()
        view.numberOfLines = 3
        return view
    }()
    
    lazy var t3Label: UILabel = {
        let view = UILabel()
        view.textColor = .white.withAlphaComponent(0.7)
        view.font = Item14194ConentView.t3LabelFont()
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.isUserInteractionEnabled = true
        return view
    }()
    
    lazy var playImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.image = UIImage.init(named: "movie_poster_play")
        view.isUserInteractionEnabled = true
        return view
    }()
    
    //MARK:
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        self.backgroundColor = UIColor.ykn_primaryBackground
        self.addSubview(self.videoImageView)
        self.addSubview(self.dayLabel)
        self.addSubview(self.monthLabel)
        self.addSubview(self.t1Label)
        self.addSubview(self.t2Label)
        self.addSubview(self.t3Label)
        self.addSubview(self.playImageView)
    }
    
    func fillData(_ item: IItem?, layout: OneArchSupport4Youku.LayoutModel) {
        guard let itemModel = item?.itemModel as? ItemModel14194 else {
            return
        }
        self.item = item
        
        let extraExtend = itemModel.extraExtend
        
        if let img = extraExtend["harmonyImg"], let url = URL.init(string: img as? String ?? "") {
            self.videoImageView.sd_setImage(with: url)
            var w = Double(self.frame.width);
            var h = ceil(w * 16.0/9.0)
            videoImageView.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
        }
            
        dayLabel.text = extraExtend["day"] as? String
        if let m = extraExtend["month"] as? String,
           let month = ((Int(m) ?? 0) - 1) as? Int,
           month < monthArray.count,
           month >= 0,
           let year = extraExtend["year"] as? String {
            monthLabel.text = monthArray[month] + " \(year)"
        }
            
        t1Label.text = extraExtend["anniversary"] as? String
        t2Label.text = extraExtend["desc"] as? String
        t3Label.text = extraExtend["title"] as? String
        
        Service.action.bind(itemModel.action, playImageView, .Defalut)
        
        weak var weakSelf =  self
        videoImageView.whenTapped  {
            weakSelf?.showCalendarWindow()
        }
        
        self.relayoutSubviews(layout)
    }
    
    func relayoutSubviews(_ layout: OneArchSupport4Youku.LayoutModel) {
        videoImageView.frame = self.bounds
        
        dayLabel.frame = CGRect.init(x: 12, y: 12, width: 40, height: 29)
        monthLabel.frame = CGRect.init(x: 12, y: dayLabel.bottom, width: 60, height: 13)
        
        if let t1Layout = layout.extendExtra?["t1"] as? TextLayoutModel {
            t1Label.frame = t1Layout.renderRect
        } else {
            t1Label.frame = .zero
        }
        
        if let t2Layout = layout.extendExtra?["t2"] as? TextLayoutModel {
            t2Label.frame = t2Layout.renderRect
        } else {
            t2Label.frame = .zero
        }
        
        if let t3Layout = layout.extendExtra?["t3"] as? TextLayoutModel {
            t3Label.frame = t3Layout.renderRect
        } else {
            t3Label.frame = .zero
        }
        
        playImageView.frame = CGRect.init(x: 0, y: 0, width: 30, height: 30)
        playImageView.right = self.width - 9
        playImageView.bottom = self.height - 9
    }
    
    func showCalendarWindow() {
        guard let attachModel = self.model?.attachModel else {
            return
        }
        
        let calVc = YKCCalCardViewController()
        calVc.attachmentModel = attachModel
        calVc.superViewController = self.item?.getPage()?.pageContext?.getViewController()
        calVc.animSize = CGSize.zero
        calVc.hideHistoryBtn = true
        
        let screenSize = UIScreen.main.bounds.size
        calVc.animCenter = CGPoint.init(x: screenSize.width/2.0, y: screenSize.height/2.0)

        calVc.show()
        
        bindStastics(calVc)
    }
    
    func bindStastics(_ calVc: YKCCalCardViewController) {
        guard let playInfo = model?.attachPlayActionInfo else {
            return
        }
        
        let action = ActionModel.init(playInfo,controller: calVc,compTag: self.item?.getComponent()?.model?.type, moduleId: nil, jumpExtra: nil, model: self.model)
        
        let closeReport = action.report?.replaceSpmD(spmd: "close")
        Service.statistics.bind(closeReport, calVc.getCloseButton(), .Defalut)
        
        let shareReport = action.report?.replaceSpmD(spmd: "share")
        Service.statistics.bind(shareReport, calVc.getShareButton(), .Defalut)
        
        let downloadReport = action.report?.replaceSpmD(spmd: "download")
        Service.statistics.bind(downloadReport, calVc.getDownloadButton(), .Defalut)
        
        let playReport = action.report?.replaceSpmD(spmd: "play")
        action.report = playReport
        Service.action.bind(action, calVc.getPlayView(), .Defalut, willAction: nil) {
            calVc.hide(true)
        }
    }
    
    static func t1LabelFont() -> UIFont {
        return YKNFont.posteritem_auxiliary_text()
    }
    
    static func t2LabelFont() -> UIFont {
        return YKNFont.content_text()
    }
    
    static func t3LabelFont() -> UIFont {
        return t1LabelFont()
    }
    
}
