//
//  Component14194.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/4/6.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Component14194: NSObject, ComponentDelegate {
    
    var componentWrapper: ComponentWrapper?
    
    func componentDidInit() {
        
    }

    func layoutType() -> ComponentLayoutType {
        
        return .columnAverage
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.dim_6()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: 0, right: YKNGap.youku_margin_right())
        return config
    }
    
    func columnCount() -> CGFloat {
        return 2.0
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
