//
//  Item14007.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/4/3.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item14007: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    func itemDidInit() {
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func itemWidth() -> CGFloat {
        return Item14007.calItemWidth(self.item)
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let imageWidth: CGFloat = 60
        let titleSpacing = YKNGap.youku_picture_title_spacing()
        let titleHeight = YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
        let subtitleSpacing = YKNGap.youku_maintitle_subtitle_spacing()
        let subtitleHeight = YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)

        let itemHeight = imageWidth + titleSpacing + titleHeight + subtitleSpacing + subtitleHeight
        return itemHeight
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14007ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14007ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        itemView.fillData(itemModel: itemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    static func calItemWidth(_ item: IItem?) -> CGFloat {
        let scale:CGFloat = 1.0 // YKNSize.yk_icon_size_scale()
        var width = 10 + ceil(60 * scale)
        let font = YKNFont.posteritem_maintitle()
        if let title = item?.itemModel?.title, title.isEmpty == false {
            let labelWidth = calcStringSize(title, font: font, size: .zero).width
            if labelWidth > width {
                if labelWidth >= width * 2 {
                    width = width * 2
                } else {
                    width = labelWidth
                }
            }
        }
        return width
    }

}
