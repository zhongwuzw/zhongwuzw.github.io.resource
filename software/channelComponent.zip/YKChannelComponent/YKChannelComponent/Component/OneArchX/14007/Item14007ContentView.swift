//
//  Item14007ContentView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/4/3.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Item14007ContentView: AccessibilityView {

    //MARK: Property
    lazy var imageView:UIImageGIFView = {
        let view = UIImageGIFView()
        view.backgroundColor = .clear
        view.contentMode = .scaleAspectFit
        view.layer.cornerRadius = YKNCorner.radius_medium()
        view.clipsToBounds = true
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = YKNFont.posteritem_maintitle()
        label.textColor = UIColor.ykn_primaryInfo
        return label
    }()
    
    lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = YKNFont.posteritem_subhead()
        label.textColor = UIColor.ykn_tertiaryInfo
        return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.imageView)
        self.addSubview(self.titleLabel)
        self.addSubview(self.subtitleLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(itemModel: BaseItemModel) {
        self.backgroundColor = .clear

        self.titleLabel.text = itemModel.title
        self.subtitleLabel.text = itemModel.subtitle
        
        var icon = itemModel.gifImg
        if icon == nil {
            icon = itemModel.img
        }

        self.imageView.ykn_setImage(withURLString: icon, module: "home", imageSize: .zero, parameters: nil, completed: nil)
        
        layoutUI(itemModel)

        titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor:itemModel.scene?.sceneTitleColor())
        subtitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor:itemModel.scene?.sceneSubTitleColor())
        
        Service.action.bind(itemModel.action, self)
    }
    
    func layoutUI(_ itemModel: BaseItemModel) {
        self.imageView.frame = CGRect(x: (self.width - 60) / 2, y: 0, width: 60, height: 60)
        
        let titleHeight = YKNFont.height(with: self.titleLabel.font, lineNumber: 1)
        self.titleLabel.frame = CGRect.init(x: 0, y: self.imageView.bottom + YKNGap.youku_picture_title_spacing(), width: self.width, height: titleHeight)
        
        let subtitleHeight = YKNFont.height(with: self.subtitleLabel.font, lineNumber: 1)
        self.subtitleLabel.frame = CGRect.init(x: 0, y: self.titleLabel.bottom + YKNGap.youku_maintitle_subtitle_spacing(), width: self.width, height: subtitleHeight)
    }
}
