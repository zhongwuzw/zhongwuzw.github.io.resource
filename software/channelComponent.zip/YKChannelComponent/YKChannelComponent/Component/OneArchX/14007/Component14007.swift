//
//  Component14007.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/4/3.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout

class Component14007: NSObject, ComponentDelegate {
    
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeComponentModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .horizontalScroll
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        config.preferredCardSpacingTop = YKNGap.youku_module_margin_top()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.horizontalPaddingLeft = YKNGap.youku_margin_left()
        config.horizontalPaddingRight = YKNGap.youku_margin_right()
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        if let collectionView = itemView.subviews.first as? UICollectionView {
            collectionView.contentOffset = CGPoint.init(x: -collectionView.contentInset.left, y: 0)
        }
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
