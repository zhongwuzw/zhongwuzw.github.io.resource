//
//  Component14322ContentView.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/10/11.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent
import YKResponsiveLayout
import YoukuAnalytics

class Component14322ContentView: AccessibilityView,HorizontalScrollViewDelegate {
    
    weak var component: IComponent?
    weak var model: BaseComponentModel?
    var centerIndex:Int = 0
    var lastContentOffset:CGFloat = 0
    lazy var itemModels: [SportItemModel14322] = {
        let models = [SportItemModel14322]()
        return models
    }()
    
    //MARK: - Property
    lazy var horizontalScrollView: HorizontalScrollView = {
        let view = HorizontalScrollView.init(frame: CGRect.zero)
        view.delegate = self
        self.addSubview(view)
        return view
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(horizontalScrollView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
    }
    
    func fill(_ model: BaseComponentModel) {
        self.model = model
        self.component = model.domainObject as? IComponent

    }
    
    func fillItems(_ itemModels: [SportItemModel14322], scrollToTop:Bool) {
        self.itemModels.removeAll()
        self.itemModels.append(contentsOf: itemModels)
        
        var index = 0
        var firstLiveIndex = -1
        var firstReserveIndex = -1
        var isTop = false
        for itemModel in itemModels {
            if let sport = itemModel.sportsCompetition,
               sport.isTop {
                self.centerIndex = index
                isTop = true
                break
            }
            if firstLiveIndex < 0, let sport = itemModel.sportsCompetition,sport.matchStatus == "1" {
                firstLiveIndex = index
            }
            if firstReserveIndex < 0, let sport = itemModel.sportsCompetition,sport.matchStatus == "0" {
                firstReserveIndex = index
            }
            index += 1
        }
        if !isTop {
            if firstLiveIndex >= 0 {
                self.centerIndex = firstLiveIndex
            } else if firstReserveIndex >= 0 {
                self.centerIndex = firstReserveIndex
            }
        }
        
        let scrollHeight =  Component14322ContentView.itemSize14322(self.width).height
        horizontalScrollView.frame = CGRect.init(x: 0.0, y: 0, width: self.width, height: scrollHeight)
        horizontalScrollView.collectionView.backgroundColor = .clear
        horizontalScrollView.reload(delegate: self, datas: itemDatas())
        horizontalScrollView.collectionView.contentOffset = CGPoint.init(x: 0, y: 0)
        if scrollToTop {
            if !isTop , firstLiveIndex < 0, firstReserveIndex < 0 {
                horizontalScrollView.collectionView.scrollToItem(at: IndexPath(row: itemDatas().count - 1, section: 0), at: .right, animated: true)
            } else {
                horizontalScrollView.collectionView.scrollToItem(at: IndexPath(row: centerIndex, section: 0), at: .left, animated: true)
                var offset = horizontalScrollView.collectionView.contentOffset
                offset.x -= 18
                horizontalScrollView.collectionView.contentOffset = offset
            }
        } else {
            if lastContentOffset <= horizontalScrollView.collectionView.contentSize.width - horizontalScrollView.collectionView.width {
                var offset = horizontalScrollView.collectionView.contentOffset
                offset.x = lastContentOffset
                horizontalScrollView.collectionView.contentOffset = offset
            } else {
                horizontalScrollView.collectionView.scrollToItem(at: IndexPath(row: centerIndex, section: 0), at: .left, animated: true)
                var offset = horizontalScrollView.collectionView.contentOffset
                offset.x -= 18
                horizontalScrollView.collectionView.contentOffset = offset
            }
        }
        self.layoutCustomViews()
    }
    
    func layoutCustomViews() {
        
        let scrollHeight =  Component14322ContentView.itemSize14322(self.width).height
        horizontalScrollView.frame = CGRect.init(x: 0.0, y: 0, width: self.width, height: scrollHeight)
    }
    
    func itemDatas() -> [Any] {
        return self.itemModels
    }
    
    func getItem(_ index:Int) -> SportItemModel14322? {
        let itemDatas = itemDatas()
        if index < itemDatas.count {
            let item = itemDatas[index] as? SportItemModel14322
            return item
        }
        return nil
    }
    
    //MARK: HorizontalScrollViewDelegate
    func itemSpacing() -> CGFloat {
        return YKNGap.youku_column_spacing()
    }
    
    func leftMargin() -> CGFloat {
        return YKNGap.youku_margin_left()
    }
    
    func rightMargin() -> CGFloat {
        return YKNGap.youku_margin_right()
    }
    
    func topMargin() -> CGFloat {
        return 0
    }
    
    func bottomMargin() -> CGFloat {
        return 0
    }

    func itemIdentifier(index: Int) -> String {
        var reuseId = "horizontal_scroll_identifier"
        if !hasMoreItem() {
            reuseId = reuseId + "_" + "14322"
        } else {
            if index < self.itemModels.count - 1 {
                reuseId = reuseId + "_" + "14322"
            } else {
                reuseId = reuseId + "_" + "more"
            }
        }
        return reuseId
    }

    func itemSize(index: Int) -> CGSize {
        if !hasMoreItem() {
            return Component14322ContentView.itemSize14322(self.width)
        }
        if index < self.itemModels.count - 1 {
            return Component14322ContentView.itemSize14322(self.width)
        } else {
            return Component14322ContentView.itemSizeMoreItem(self.width)
        }
    }

    public class func responsiveColumn() -> CGFloat {
        let defaultColumn = 2.1
        var responsiveColumn =  YKRLCompLayoutManager.sharedInstance().columnCount(forOriginalCount: defaultColumn)
        if responsiveColumn < defaultColumn {
            responsiveColumn = defaultColumn
        }
        return responsiveColumn
    }
    public class func itemSize14322(_ itemWidth: CGFloat) -> CGSize {
        let width = ceil((itemWidth - YKNGap.youku_margin_left() - YKNGap.youku_margin_right()) / responsiveColumn())
        let height = ceil(width * 112.0 / 165.0)
        return CGSize.init(width: width, height: height)
    }
    public class func itemSizeMoreItem(_ itemWidth: CGFloat) -> CGSize {
        let width = ceil((itemWidth - YKNGap.youku_margin_left() - YKNGap.youku_margin_right()) / responsiveColumn())
        let height = ceil(width * 112.0 / 165.0)
        return CGSize.init(width: 60, height: height)
    }
    
    func createItemView(index: Int, itemSize: CGSize) -> UIView {
        if hasMoreItem() && self.itemModels.count > 0 {
            if index < self.itemModels.count - 1 {
                return Item14322ContentView.init(frame: CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            } else {
                return Item13016ContentView.init(frame: CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            }
        } else {
            return Item14322ContentView.init(frame: CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        }
    }

    func reuseItemView(index: Int, itemView: UIView) {
        if let itemModel = getItem(index) as? SportItemModel14322 {
            if let itemView = itemView as? Item14322ContentView {
                itemView.index = index
                itemView.component = self.component
                itemView.componentView = self
                itemView.fillData(itemModel: itemModel)
            } else if let itemView = itemView as? Item13016ContentView {
                itemView.fillData(itemModel)
                //无需播放 复用此字段
                itemModel.playerModel?.itemView = itemView
            }
        }
        self.component?.setData(false, forKey: "personal.moreItem.display")
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if let view = moreItem()?.playerModel?.itemView as? Item13016ContentView {
            if !canJumpToMorePage(view)  {
                view.updateTitle(false)
                self.component?.setData(false, forKey: "personal.moreItem.display")
            } else {
                view.updateTitle(true)
                self.component?.setData(true, forKey: "personal.moreItem.display")
            }
            
        }
    }
    
    func horizontalScrollWillDisplayItem(_ index: NSInteger) {
        if let view = moreItem()?.playerModel?.itemView {
            if !isViewFullVisible(view)  {
                self.component?.setData(false, forKey: "personal.moreItem.display")
            } else {
                self.component?.setData(true, forKey: "personal.moreItem.display")
            }
        }
    }
    
    func horizontalScrollEndDisplayItem(_ index: NSInteger) {
        if let view = moreItem()?.playerModel?.itemView {
            if !isViewFullVisible(view)  {
                self.component?.setData(false, forKey: "personal.moreItem.display")
            } else {
                self.component?.setData(true, forKey: "personal.moreItem.display")
            }
        }
    }
    
    func horizontalScrollDidEndScroll(_ indexPaths: [IndexPath]?, collectionView:UICollectionView) {
        lastContentOffset = collectionView.contentOffset.x
    }
    
    func horizontalScrollViewWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: CGPoint) {
//        let indexPaths = self.horizontalScrollView.collectionView.indexPathsForVisibleItems
//        let count = self.itemModels.count
//        if indexPaths.contains(IndexPath(row: count - 1, section: 0)) == false {
//            return
//        }
//        let isSlidLeft = velocity.x > 0
//        if isSlidLeft {
//            naviToMorePage()
//        } else {
//            let isOverScroll = scrollView.contentOffset.x > targetContentOffset.x
//            if velocity.x == 0 && isOverScroll {
//                naviToMorePage()
//            }
//        }
    }
    
    private func naviToMorePage() {
        DispatchQueue.main.asyncAfter(deadline: .now() + .milliseconds(60)) { [self] in
            if let moreItem = self.moreItem(), let model = moreItem.action {
                Service.action.doAction(model, extendRouteParams:nil, willAction: nil, didAction: nil)
                Service.statistics.updateNextPageParamsWhenClicked(model.report)
            }
        }
    }
    
    func isViewVisible(_ view: UIView?) -> Bool {

        guard let view = view else {
            return false
        }

        if !isViewFullVisible(view) {
            return false
        } else {
            return true
        }
        let min = 0.0
        let max = self.width
        let containerView = self.horizontalScrollView.collectionView
        let width = CGFloat(containerView.width)
        let height = CGFloat(containerView.height)
        let frame = view.superview?.convert(view.frame, to: self.horizontalScrollView.collectionView) ?? CGRect()
        let minX = CGFloat(frame.minX)
        let maxX = CGFloat(frame.maxX)

//        if maxX <= min || minX >= max {
//            return false
//        }

        //交集-横向宽度
//        print("ccplayer contentOffsetX:\(containerView.contentOffset.x), minX:\(minX),width:\(view.width * 0.8)")
        let playWidth = view.width
        let playLine = containerView.contentOffset.x + 70
        if playLine > minX && playLine < maxX {
            return true
        }
        return false

    }
    
    func isScroll() -> Bool {
        let containerView = self.horizontalScrollView.collectionView
        if containerView.isDragging || containerView.isDecelerating {
            return true
        }
    
        return false
    }
    
    func isViewFullVisible(_ view: UIView?) -> Bool {
        guard let view = view else {
            return false
        }

        let min = 0.0
        let max = self.width
        let containerView = self.horizontalScrollView.collectionView
        let width = CGFloat(containerView.width)
        let height = CGFloat(containerView.height)
        let frame = view.superview?.convert(view.frame, to: self.horizontalScrollView.collectionView) ?? CGRect()
        let minX = CGFloat(frame.minX)
        let maxX = CGFloat(frame.maxX)
        
        if minX >= containerView.contentOffset.x && maxX < containerView.contentOffset.x + containerView.width {
            return true
        }
        return false

    }
    
    func canJumpToMorePage(_ view: UIView?) -> Bool {
        guard let view = view else {
            return false
        }

        let min = 0.0
        let max = self.width
        let containerView = self.horizontalScrollView.collectionView
        let width = CGFloat(containerView.width)
        let height = CGFloat(containerView.height)
        let frame = view.superview?.convert(view.frame, to: self.horizontalScrollView.collectionView) ?? CGRect()
        let minX = CGFloat(frame.minX)
        let maxX = CGFloat(frame.maxX)
        
        if minX >= containerView.contentOffset.x && maxX < containerView.contentOffset.x + containerView.width - 50 {
            return true
        }
        return false

    }

    private func sendMoreItemClickAnalytics(_ report:ReportModel?) {
        guard let report = report else {
            return
        }
        var arg1 = ""
        if let pageName = report.pageName, let spmC = report.spmC {
            arg1 = pageName + "_" + spmC
        }
        if let pageName = report.pageName, let args = report.args {
            YoukuAnalytics.sharedInstance().collectALiCustomEvent(withEventID: "2101", pageName: pageName, arg1: arg1, arg2: "", args: args)
        }
    }
    
    func hasMoreItem() -> Bool {
        if moreItem() != nil {
            return true
        }
        return false
    }
    func moreItem() -> SportItemModel14322? {
        if let items = self.component?.getItems() {
            for item in items {
                if let type = item.itemModel?.type, type == "13016" {
                    return item.itemModel as? SportItemModel14322
                }
            }
        }
        return nil
    }
    
//    ///MARK:SportsMatchStatusView14322Delegate
//    func needUpdateStatusView(_ statusView:SportsMatchStatusView14322) {
//        guard let targetItem = statusView.itemModel else {return}
//
//        sportsCompetition?.matchStatus = statusView.sportModel?.matchStatus
//    }
}
