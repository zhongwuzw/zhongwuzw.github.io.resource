//
//  Item14322.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/10/11.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import YoukuResource
import YKHome
import YKSCService
import YKResponsiveLayout
import OneArchSupport4Youku
import DYKNetwork_YK

open class Component14322Delegate: NSObject, ComponentDelegate,ComponentLifeCycleDelegate {
    public var componentWrapper: ComponentWrapper?
    var isDisplay:Bool = false

    lazy var lifeCycleEventHandler:ComponentLifeCycleEventHandler = {
        let handler = ComponentLifeCycleEventHandler()
        handler.delegate = self
        return handler
    }()
    
    public func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom() + 9, right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = 0.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        return config
    }
    
    public func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    public func columnCount() -> CGFloat {
        return 1
    }
    
    public func getModelClass<T>() -> T.Type? where T : NodeModel {
        return SportsComponentModel.self as? T.Type
    }
    
    // MARK: - event
    public func loadEventHandlers() -> [ComponentEventHandler]? {
        return [self.lifeCycleEventHandler]
    }
    
    public func componentDidInit() {

    }
    
    public func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let itemHeight:CGFloat = 259.0
        return itemHeight
    }
    
    public func createView(_ itemSize: CGSize) -> UIView {
        let itemWidth = Double(itemSize.width)
        let itemHeight = Double(itemSize.height)
        let itemView = Component14203ContentView.init(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        return itemView
    }
    
    public func reuseView(itemView: UIView) {
        
    }
    
    public func enterDisplayArea(itemView: UIView?) {
        isDisplay = true
    }
    public func exitDisplayArea(itemView: UIView?) {
        isDisplay = false
    }
    public func didActivate() {
       
    }
    public func didDeactivate() {

    }


    func isPageInActive() -> Bool {
        if let page = self.component?.getPage() {
            if let state = page.activeState, state == true {
                return true
            }
        }
        return false
    }
}
