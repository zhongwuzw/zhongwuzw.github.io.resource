//
//  SportItemModel14322.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/10/13.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout

open class SportItemModel14322: BaseItemModel {
    var isMoreItem = false
    /**
      * 体育赛事
      */
    public var sportsCompetition: SportsCompetitionModel?
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        if let cmsInfo = cmsInfo {
            self.sportsCompetition = SportsCompetitionModel.init(cmsInfo)
        }
    }
}
