//
//  Item14322ContentView.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/10/12.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import OneArch
import YKUIComponent

class Item14322ContentView: AccessibilityView, SportsMatchStatusView14322Delegate {
    
    var index:Int = 0
    weak var component: IComponent?
    weak var componentView: Component14322ContentView?
    weak var delegate:SportsMatchStatusView14322Delegate?
    weak var itemModel:SportItemModel14322?
    var sportsCompetition:SportsCompetitionModel?

    lazy var backgroundGradientView:GradientBorderView = {
        let view = GradientBorderView.init(frame: CGRect.init(x: 0.0, y: 0.0, width: 0, height: 100))
        view.backgroundColor = UIColor.clear
        return view
    }()
    
    lazy var backgroundWhiteView:UIView = backgroundGradientView.backgroundWhiteView
    
    lazy var topView:UIView = {
        let view = UIView.init(frame: CGRect.init(x: 0.0, y: 0.0, width: 0, height: 100))
        view.backgroundColor = UIColor.clear
        return view
    }()
    
    lazy var topGradientLayer: CAGradientLayer = {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.createColorWithHexRGB(colorStr: "#87CDF1").withAlphaComponent(0.2).cgColor, UIColor.createColorWithHexRGB(colorStr: "#C1CBCD").withAlphaComponent(0.2).cgColor, UIColor.createColorWithHexRGB(colorStr: "#FFB694").withAlphaComponent(0.2).cgColor]
        gradientLayer.locations = [NSNumber.init(value: 0), NSNumber.init(value: 0.5), NSNumber.init(value: 1.0)]
        gradientLayer.startPoint = CGPoint(x: 0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 0)
        
        return gradientLayer
    }()
    lazy var bottomDarkView:UIView = {
        let view = UIView.init(frame: CGRect.init(x: 0.0, y: 0.0, width: 0, height: 100))
        view.backgroundColor = UIColor.clear
        return view
    }()
    
    lazy var bottomDarkGradientLayer: CAGradientLayer = {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.createColorWithHexRGB(colorStr: "#87CDF1").withAlphaComponent(0.05).cgColor, UIColor.createColorWithHexRGB(colorStr: "#C1CBCD").withAlphaComponent(0.05).cgColor, UIColor.createColorWithHexRGB(colorStr: "#FFB694").withAlphaComponent(0.05).cgColor]
        gradientLayer.locations = [NSNumber.init(value: 0), NSNumber.init(value: 0.5), NSNumber.init(value: 1.0)]
        gradientLayer.startPoint = CGPoint(x: 0.0, y: 0)
        gradientLayer.endPoint = CGPoint(x: 1, y: 1)
        
        return gradientLayer
    }()
    
    lazy var topTitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.tertiary_auxiliary_text_weight(.medium)
        view.textAlignment = .left
        view.numberOfLines = 1
        return view
    }()
    
    lazy var timeLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.quaternary_auxiliary_text()
        view.textAlignment = .left
        view.numberOfLines = 1
        return view
    }()
    
    lazy var laterLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.createColorWithHexRGB(colorStr: "#F65200")
        view.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#F65200").withAlphaComponent(0.1)
        view.font = YKNFont.quaternary_auxiliary_text()
        view.textAlignment = .center
        view.numberOfLines = 1
        view.layer.cornerRadius = 2.0
        view.layer.masksToBounds = true
        return view
    }()
    
    lazy var matchStatusView: SportsMatchStatusView14322 = {
        let view = SportsMatchStatusView14322()
        view.delegate = self
        return view
    }()
    
    //非对阵比赛 只展示标题
    lazy var matchNameLabel: MarginLabel = {
        let view = MarginLabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_subhead_weight(.medium)
        view.textAlignment = .left
        view.verticalAlignment = .top
        view.numberOfLines = 2
        return view
    }()
    
    lazy var homeBodyView: SportMatchAgainstItemView = {
        let view = SportMatchAgainstItemView()
        return view
    }()
    
    lazy var guestBodyView: SportMatchAgainstItemView = {
        let view = SportMatchAgainstItemView()
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(backgroundGradientView)
        
        backgroundWhiteView.addSubview(bottomDarkView)
        bottomDarkView.layer.addSublayer(bottomDarkGradientLayer)
        
        backgroundWhiteView.addSubview(topView)
        topView.layer.addSublayer(topGradientLayer)
        topView.addSubview(topTitleLabel)
      
        backgroundWhiteView.addSubview(timeLabel)
        backgroundWhiteView.addSubview(laterLabel)
        backgroundWhiteView.addSubview(matchStatusView)
        backgroundWhiteView.addSubview(matchNameLabel)
        backgroundWhiteView.addSubview(homeBodyView)
        backgroundWhiteView.addSubview(guestBodyView)
        
        layer.cornerRadius = 7.0
        layer.masksToBounds = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(itemModel: SportItemModel14322) {
        
        self.itemModel = itemModel
        self.sportsCompetition = itemModel.sportsCompetition
        
        guard let sportsCompetition = sportsCompetition else {return}
        
        Service.action.bind(itemModel.action, self)
        
        topTitleLabel.text = sportsCompetition.displayTitle
        timeLabel.text = sportsCompetition.startTime
        if sportsCompetition.isDelay {
            laterLabel.text = sportsCompetition.delayName ?? "延迟"
            laterLabel.isHidden = false
        } else {
            laterLabel.isHidden = true
        }
        matchStatusView.fillData(sportsCompetition)
        matchStatusView.itemModel = self.itemModel
        
        if sportsCompetition.isAgainst {
            homeBodyView.isHidden = false
            guestBodyView.isHidden = false
            
            matchNameLabel.isHidden = true
            
            homeBodyView.frame = CGRect.init(x: 0.0, y: 0.0, width: self.width, height: 20.0)
            guestBodyView.frame = CGRect.init(x: 0.0, y: homeBodyView.bottom + 8.0, width: self.width, height: 20.0)
            homeBodyView.fillData(sportsCompetition.homeBodyName, badge: sportsCompetition.homeBodyBadge, score: sportsCompetition.homeBodyScore, isShowRoundBadge: !sportsCompetition.homeIsFlag, sportModel: sportsCompetition)
            guestBodyView.fillData(sportsCompetition.guestBodyName, badge: sportsCompetition.guestBodyBadge, score: sportsCompetition.guestBodyScore, isShowRoundBadge: !sportsCompetition.guestIsFlag, sportModel: sportsCompetition)
        } else {
            homeBodyView.isHidden = true
            guestBodyView.isHidden = true
            
            matchNameLabel.isHidden = false
            matchNameLabel.text = sportsCompetition.matchName
        }
        
        backgroundGradientView.fillData([UIColor.createColorWithHexRGB(colorStr: "#87CDF1").withAlphaComponent(0.25).cgColor, UIColor.createColorWithHexRGB(colorStr: "#C1CBCD").withAlphaComponent(0.25).cgColor, UIColor.createColorWithHexRGB(colorStr: "#FFB694").withAlphaComponent(0.25).cgColor], borderWidth: 0.5, cornerRadius: 7.0, viewFrame: self.bounds)
        
        updateDarkUI()
        
        layoutCustomViews(itemModel)
    }
    
    
    func layoutCustomViews(_ itemModel: BaseItemModel) {
        
        self.topView.frame = CGRect.init(x: 0.0, y: 0.0, width: self.width, height: 24.0)
        self.topGradientLayer.frame = self.topView.bounds
        
        self.bottomDarkView.frame = CGRect.init(x: 0.0, y: self.topView.bottom, width: self.width, height: self.height - self.topView.bottom)
        self.bottomDarkGradientLayer.frame = self.bottomDarkView.bounds
        self.topTitleLabel.frame = self.topView.bounds
        self.topTitleLabel.width = self.topView.width - 20.0
        self.topTitleLabel.left = 10.0
        
        self.timeLabel.sizeToFit()
        self.timeLabel.left = 10.0
        self.timeLabel.top = self.topView.bottom + 6
        
        self.laterLabel.sizeToFit()
        self.laterLabel.width += 10.0
        self.laterLabel.left = self.timeLabel.right + 1
        self.laterLabel.centerY = self.timeLabel.centerY
        
        self.matchStatusView.size = SportsMatchStatusView14322.getSize(sportsCompetition)
        self.matchStatusView.right = self.width - 12.0
        self.matchStatusView.centerY = self.timeLabel.centerY
        
        self.timeLabel.centerY = self.matchStatusView.centerY
        
        let matchTop = timeLabel.bottom + 14.0
        self.matchNameLabel.width = self.width - 10.0 - 32.0
        self.matchNameLabel.height = self.height - matchTop - 10
        self.matchNameLabel.left = 10.0
        self.matchNameLabel.top = matchTop
        
        let bottomH = self.height - timeLabel.bottom
        
        let homeBodyTop = timeLabel.bottom + (bottomH - 6.0) / 2.0 - 20.0
        
        homeBodyView.frame = CGRect.init(x: 0.0, y: homeBodyTop, width: self.width, height: 20.0)
        guestBodyView.frame = CGRect.init(x: 0.0, y: homeBodyView.bottom + 6.0, width: self.width, height: 20.0)
        
        //
        self.matchNameLabel.top = homeBodyView.top
    }
    
    ///MARK:SportsMatchStatusView14322Delegate
    func needUpdateStatusView(_ statusView:SportsMatchStatusView14322) {
        sportsCompetition?.matchStatus = statusView.sportModel?.matchStatus
        itemModel?.sportsCompetition?.matchStatus = statusView.sportModel?.matchStatus
        if let compDelegate = component?.getComponentDelegate() as? Component14322, let itemModels = compDelegate.itemView?.itemModels {
            var newItemModels = [SportItemModel14322]()
            for model in itemModels {
                if let videIdStr = model.sportsCompetition?.liveId, let curLiveId = itemModel?.sportsCompetition?.liveId, videIdStr == curLiveId {
                    model.sportsCompetition?.matchStatusName = statusView.sportModel?.matchStatusName
                }
                newItemModels.append(model)
            }
            compDelegate.itemView?.itemModels = newItemModels
        }

        
        self.matchStatusView.size = SportsMatchStatusView14322.getSize(sportsCompetition)
        self.matchStatusView.right = self.width - 6.0
        self.matchStatusView.top = self.topView.bottom + 7.0
    }
    
    func updateDarkUI() {
        if isDark() {
            self.bottomDarkView.isHidden = false
        } else {
            self.bottomDarkView.isHidden = true
        }
    }
    
    /// 暗黑变化回调
    public override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
        self.updateDarkUI()
    }
    public override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        self.updateDarkUI()
    }
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
}
