//
//  Component14322.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/10/11.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout
import YKDowngradeSDK

class Component14322: NSObject, ComponentDelegate, ComponentLifeCycleDelegate {
    
    weak var itemView: Component14322ContentView?
    var itemModels:[SportItemModel14322]?
    ///定时刷新
    var requestTimer: Timer?
    var timeInterval:Double = 60.0
    ///组件状态
    var isDisplay:Bool = false
    var lastRefreshTime:CGFloat = 0
    
    var isPageInActive: Bool {
        if let page = self.component?.getPage() {
            if let state = page.activeState, state == true {
                return true
            }
        }
        return false
    }
    
    lazy var lifeCycleEventHandler:ComponentLifeCycleEventHandler = {
        let handler = ComponentLifeCycleEventHandler()
        handler.delegate = self
        return handler
    }()
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return SportsComponentModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = 18
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: 18, right: 0)
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 9.0
        config.preferredRowHeight = 0.0
        
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [lifeCycleEventHandler]
    }
    
    var componentWrapper: ComponentWrapper?
    
    /// item高度（custom布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        
        if !isLowDevice() {
            if let itemModels = itemModels, itemModels.count > 0 {
                let itemSize = Component14322ContentView.itemSize14322(itemWidth)
                let itemHeight = itemSize.height
                return itemHeight
            }
            return 0
        } else {
            let itemSize = Component14322ContentView.itemSize14322(itemWidth)
            let itemHeight = itemSize.height
            return itemHeight
        }
    }
    
    /// 初始化item view（custom布局使用）
    func createView(_ itemSize: CGSize) -> UIView {
        let itemWidth = itemSize.width
        let itemHeight = itemSize.height
        
        let itemView = Component14322ContentView.init(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        return itemView
    }
    
    func reuseId() -> String? {
        let reuseId = "Component14322"
        return reuseId
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Component14322ContentView else {
            return
        }
        guard let compModel = self.component?.compModel as? SportsComponentModel else {
            return
        }
        self.itemView = itemView
        itemView.fill(compModel)
        if let itemModels = itemModels {
            itemView.fillItems(itemModels, scrollToTop: true)
        }
        timeInterval = Double(compModel.refreshTime)
        initRequestTimer(interval: timeInterval)
    }
    
    func componentDidInit() {
        //        forceRefreshComponentData()
    }
    
    /// data
    @objc public func refreshComponentData() {
        print("14322 refreshComponentData pre")
        if !isDisplay {
            return
        }
        if !isPageInActive {
            return
        }
        print("14322 refreshComponentData end")
        self.forceRefreshComponentData()
    }
    
    @objc public func forceRefreshComponentData() {
        lastRefreshTime = NSDate().timeIntervalSince1970
        weak var weakSelf = self
        Component14322RequestUtil.loadPageData { data in
            guard let weakSelf = weakSelf else { return }
            if var itemModels = Component14322RequestUtil.createItemModels(data) {
                if weakSelf.hasMoreItem(), itemModels.count > 0 {
                    if let moreItem = weakSelf.moreItem() {
                        moreItem.isMoreItem = true
                        itemModels.append(moreItem)
                    }
                }
                if let originItems = self.itemModels, originItems.count > 0 {
                    weakSelf.itemModels = itemModels
                    weakSelf.itemView?.fillItems(itemModels, scrollToTop: false)
                } else {
                    weakSelf.itemModels = itemModels
                    if !weakSelf.isLowDevice() {
                        weakSelf.component?.refresh(true)
                    } else {
                        weakSelf.itemView?.fillItems(itemModels, scrollToTop: false)
                    }
                }
            }
        } failure: { error in
            
        }
    }
    
    func isLowDevice() -> Bool {
        if YKDowngradeManager.evaluationForDeviceLevel().rawValue
            < YKDeviceEvaluationLevel.LOW_END_DEVICE.rawValue {
            return false
        }
        return true
    }
    
    ///MARK:Timer
    func initRequestTimer(interval: Double) {
        if self.requestTimer != nil {
            self.requestTimer?.invalidate()
            self.requestTimer = nil
        }
        if interval > 0 {
            weak var weakSelf = self
            let timer = Timer.scheduledTimer(timeInterval: interval, target: self, selector: #selector(refreshComponentData), userInfo: nil, repeats: true)
            RunLoop.main.add(timer, forMode: RunLoop.Mode.common)
            self.requestTimer = timer
            pauseTimer()
        }
    }
    
    func resumeTimer() {
        print("14322 refreshComponentData resume time")
        if let timer = self.requestTimer, timer.isValid {
            timer.fireDate = Date.init(timeIntervalSinceNow: timeInterval)
        } else {
            initRequestTimer(interval: self.timeInterval)
            requestTimer?.fireDate = Date.init(timeIntervalSinceNow: timeInterval)
        }
    }

    func pauseTimer() {
        print("14322 refreshComponentData pause time")
        guard let timer = self.requestTimer else {
            return
        }
        if timer.isValid {
            timer.fireDate = NSDate.distantFuture
        }
    }
    
    func clearTimer() {
        self.requestTimer?.invalidate()
        self.requestTimer = nil
    }
    
    ///MARK:MORE ITEM
    func hasMoreItem() -> Bool {
        if moreItem() != nil {
            return true
        }
        return false
    }
    func moreItem() -> SportItemModel14322? {
        if let items = self.component?.getItems() {
            for item in items {
                if let type = item.itemModel?.type, type == "13016" {
                    return item.itemModel as? SportItemModel14322
                }
            }
        }
        return nil
    }
    
    ///MARK: ComponentLifeCycleDelegate
    public func enterDisplayArea(itemView: UIView?) {
        print("14322 refreshComponentData enterDisplayArea start")
        isDisplay = true
        if isPageInActive {
            print("14322 refreshComponentData enterDisplayArea end")
            let currentTime = NSDate().timeIntervalSince1970
            if currentTime - lastRefreshTime >= timeInterval, let dataState = self.component?.getPage()?.pageModel?.dataState, dataState == .network {                refreshComponentData()
            }
            resumeTimer()
        }
    }
    public func exitDisplayArea(itemView: UIView?) {
        print("14322 refreshComponentData exitDisplayArea")
        isDisplay = false
        pauseTimer()
    }
    public func didActivate() {
        print("14322 refreshComponentData didActivate start")
        if isDisplay {
            print("14322 refreshComponentData didActivate end")
            let currentTime = NSDate().timeIntervalSince1970
            if currentTime - lastRefreshTime >= timeInterval {
                refreshComponentData()
            }
            resumeTimer()
        }
    }
    public func didDeactivate() {
        print("14322 refreshComponentData didDeactivate")
        pauseTimer()
    }
    public func appDidBecomeActive() {
        if isDisplay, isPageInActive {
            print("14322 refreshComponentData appDidBecomeActive end")
            let currentTime = NSDate().timeIntervalSince1970
            if currentTime - lastRefreshTime >= timeInterval {
                refreshComponentData()
            }
            resumeTimer()
        }
    }
    public func appWillResignActive() {
        pauseTimer()

    }
}
