//
//  Item14151Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/8/16.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item14151Delegate: NSObject, ItemDelegate {
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView()
    }
    
    func reuseView(itemView: UIView) {
        
    }
    
    var itemWrapper: ItemWrapper?
    
    static func create() -> ItemDelegate {
        return Item14151Delegate.init()
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func itemDidInit() {

    }
    
    required override init() {
        
    }

}
