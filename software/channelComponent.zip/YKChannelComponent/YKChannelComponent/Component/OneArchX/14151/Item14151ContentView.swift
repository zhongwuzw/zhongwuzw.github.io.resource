//
//  Item14151ContentView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/8/16.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import YKAdSDK
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import SDWebImage
import YoukuResource

class CustomUILabel: UILabel {
    override var frame: CGRect {
        didSet {
            NSLog("frame change:\(frame)")
        }
    }
}
@objcMembers
class Item14151ContentView: AccessibilityView {
    private var _timeInterval: TimeInterval?
    private var _imageRatio: CGFloat?
    private var _renderTimer: Timer?
    private var currentIndex: CInt = 0
    private var _hasSceneBgColor: Bool = false
    private var _arrowImageView: UIImageView?
    private var _nextArrowImageView: UIImageView?
    
    lazy var bgImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.backgroundColor = UIColor.clear
        view.contentMode = .topLeft
        return view
    }()
    
    lazy var leftImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        return view
    }()
    
    lazy var titleLabel: CustomUILabel = {
        let view = CustomUILabel()
        view.font = YKNFont.posteritem_subhead()
        view.textColor = .ykn_secondaryInfo
        view.backgroundColor = .clear
        view.isOpaque = true
        view.clipsToBounds = true
        return view
    }()
    
    lazy var nextTitleLabel: CustomUILabel = {
        let view = CustomUILabel()
        view.font = YKNFont.posteritem_subhead()
        view.textColor = .ykn_secondaryInfo
        view.backgroundColor = .clear
        view.isOpaque = true
        view.clipsToBounds = true
        return view
    }()

    lazy var arrowImageView: UIImageView = {
        let view = UIImageView(image: UIImage(named: "text_link_arrow")?.withRenderingMode(.alwaysTemplate))
        view.tintColor = .ykn_tertiaryInfo
        view.width = 12
        view.height = 12
        return view
    }()
    
    lazy var nextArrowImageView: UIImageView = {
        let view = UIImageView(image: UIImage(named: "text_link_arrow")?.withRenderingMode(.alwaysTemplate))
        view.tintColor = .ykn_tertiaryInfo
        view.width = 12
        view.height = 12
        return view
    }()
    
    weak var component: IComponent?

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        layer.cornerRadius = YKNCorner.radius_secondary_medium()
//        layer.borderWidth = 0.5
//        layer.borderColor = UIColor.ykn_hideAbleSeparator.cgColor
        layer.masksToBounds = true

        backgroundColor = UIColor.ykn_secondaryBackground
        addSubview(bgImageView)
        addSubview(leftImageView)
        addSubview(titleLabel)
        addSubview(nextTitleLabel)
//        addSubview(arrowImageView)
//        addSubview(nextArrowImageView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        _renderTimer?.invalidate()
        _renderTimer = nil
    }

    func fillModel(_ compModel: BaseComponentModel?, timerInterval: Double, imageRatio: CGFloat, imgPath: String?) {
//    func fillComponentContexts(_ componentContext: YKSCComponentContext, timerInterval: Double, imageRatio: String, imgPath: String) {
        component = compModel?.domainObject as? IComponent
        let compModel = compModel as? HomeComponentModel
        
        _timeInterval = timerInterval
        _imageRatio = imageRatio

        let ratio = _imageRatio ?? 1.8

        _hasSceneBgColor = compModel?.scene?.sceneBgColor() != nil

        if let iconImg = compModel?.iconImg, !iconImg.isEmpty {
            leftImageView.isHidden = false
            var width = 12.0
            let height = 12.0
            if let iconHeight = compModel?.iconImgHeight, let iconWidth = compModel?.iconImgWidth, iconWidth >= 1, iconHeight >= 1 {
                width = (iconWidth / iconHeight) * height
            }
            leftImageView.frame = CGRect(x: 15.0, y: 0, width: width, height: height)
            leftImageView.sd_setImage(with: URL(string: iconImg))
            leftImageView.centerY = self.height / 2.0
        } else {
            leftImageView.isHidden = true
        }
        do {
            if let bgImg = compModel?.bgImg, !bgImg.isEmpty {
                bgImageView.isHidden = false
                bgImageView.contentMode = .scaleAspectFill
                
                var width = self.width
                let height = self.height
                bgImageView.frame = CGRect(x: 0.0, y: 0, width: width, height: height)
                bgImageView.centerY = self.height / 2.0

                weak var weakself = self
                SDWebImageManager.shared()?.downloadImage(with: URL(string: bgImg), viewSize: .zero, completed: { image, error, cacheType, finish, url in
                    if let image = image, image.size.height > 0, let weakself = weakself {
                        var frame = weakself.bgImageView.frame
                        if ykrl_isResponsiveLayout() {
                            frame.size.width = frame.size.height * image.size.width / image.size.height
                        }
                        weakself.bgImageView.frame = frame
                        weakself.bgImageView.image = image
                        weakself.bgImageView.centerY = self.height / 2.0
                    }
                })
            } else {
                bgImageView.isHidden = true
            }
        }
//        arrowImageView.frame = CGRect(x: self.width - 12 - 9, y: (self.height - 12) / 2, width: 12, height: 12)
//        nextArrowImageView.frame = CGRect(x: self.width - 12 - 9, y: self.height + (self.height - 12) / 2, width: 12, height: 12)

        //title区
        var titleX = 15.0
        if !leftImageView.isHidden {
            titleX = leftImageView.right + 9
        }
        let titleWidth = self.width - 9 - leftImageView.right - 9

        guard let items = component?.getItems(), items.count > 0 else {
            return
        }
        
        if items.count == 1 {
            if _renderTimer != nil {
                _renderTimer?.invalidate()
                _renderTimer = nil
            }
            NSLog("14151 1 titleX:\(titleX)")
            titleLabel.frame = CGRect(x: titleX, y: 0, width: titleWidth, height: self.height)
            let item = items[0] as? IItem
            bindTitleLabel(titleLabel, withItem: item)
            nextTitleLabel.isHidden = true
        }

        if items.count > 1 {
            titleLabel.isHidden = false
            nextTitleLabel.isHidden = false

            //timer
            if _renderTimer != nil {
                _renderTimer?.invalidate()
                _renderTimer = nil
            }

            currentIndex = 0

            //初始配置第一次数据
            resetTitleLabelFrame()

            let item = items[0] as? IItem
            bindTitleLabel(titleLabel, withItem: item)
            
            _renderTimer = Timer.scheduledTimer(timeInterval: _timeInterval ?? 2, target: self, selector: #selector(handleTimer), userInfo: nil, repeats: true)
        }

        updateShader()
        
        let sceneCardFooterBgColor = compModel?.scene?.sceneCardFooterBgColor()
        let sceneTitleColor = compModel?.scene?.sceneTitleColor()
        let sceneSeparatorColor = compModel?.scene?.sceneSeparatorColor()
        let sceneCardHeaderArrowColor = compModel?.scene?.sceneCardHeaderArrowColor()
        
        if let sceneCardFooterBgColor = sceneCardFooterBgColor, let sceneTitleColor = sceneTitleColor {
            backgroundColor = sceneCardFooterBgColor
//            layer.borderWidth = 0.5
//            layer.borderColor = sceneSeparatorColor?.cgColor
            titleLabel.textColor = sceneTitleColor
            nextTitleLabel.textColor = sceneTitleColor
//            if let sceneCardHeaderArrowColor = sceneCardHeaderArrowColor {
//                arrowImageView.tintColor = sceneCardHeaderArrowColor
//                nextArrowImageView.tintColor = sceneCardHeaderArrowColor
//            }
        } else {
            backgroundColor = .ykn_secondaryBackground
//            layer.borderWidth = 0.5
//            layer.borderColor = UIColor.ykn_hideAbleSeparator.cgColor
            titleLabel.textColor = .ykn_secondaryInfo
//            arrowImageView.tintColor = .ykn_tertiaryInfo
            nextTitleLabel.textColor = .ykn_secondaryInfo
//            nextArrowImageView.tintColor = .ykn_tertiaryInfo
        }
        if let textColor = compModel?.textColor {
            titleLabel.textColor = textColor
            nextTitleLabel.textColor = textColor
//            leftImageView.tintColor = textColor
        } else {
//            leftImageView.tintColor = UIColor.clear
        }
        if let bgColorStr = compModel?.bgColorStr, !bgColorStr.isEmpty,let bgColor = compModel?.bgColor {
            self.backgroundColor = bgColor
        }
    }
    
    @objc
    func handleTimer() {
        guard let items = component?.getItems(), items.count > 1 else {
            return
        }
        
        var nextIndex:Int = Int(currentIndex + 1)

        if currentIndex + 1 >= items.count {
            nextIndex = 0
        }

        var nextItem:IItem? = nil
        if nextIndex < items.count {
            nextItem = items[nextIndex]
        }
        bindTitleLabel(nextTitleLabel, withItem: nextItem)
        
        UIView.animate(withDuration: 0.3, animations: {
            self.titleLabel.center = CGPoint(x: self.titleLabel.centerX, y: -self.height * 0.5)

            self.nextTitleLabel.center = CGPoint(x: self.nextTitleLabel.centerX, y: self.height * 0.5)

            self.arrowImageView.center = CGPoint(x: self.arrowImageView.centerX, y: -self.height * 0.5)

            self.nextArrowImageView.center = CGPoint(x: self.nextArrowImageView.centerX, y: self.height * 0.5)
        }, completion: { (finished: Bool) -> Void in
            let tempLabel = self.titleLabel

            //动画完成交换上下label
            self.titleLabel = self.nextTitleLabel
            self.nextTitleLabel = tempLabel

            let tempImageView = self.arrowImageView

            self.arrowImageView = self.nextArrowImageView

            self.nextArrowImageView = tempImageView

            self.resetTitleLabelFrame()

            //重置上下label的frame
            self.currentIndex += 1

            if self.currentIndex >= items.count {
                self.currentIndex = 0
            }
        })
    }
    
    func resetTitleLabelFrame() {
        var titleX = 15.0
        if !leftImageView.isHidden {
            titleX = leftImageView.right + 9
        }
        NSLog("14151 0 titleX:\(titleX)")
        let titleWidth = self.width - 9 - leftImageView.right - 9

        titleLabel.frame = CGRect(x: titleX, y: 0, width: titleWidth, height: self.height)

        nextTitleLabel.frame = CGRect(x: titleX, y: self.height, width: titleWidth, height: self.height)

        arrowImageView.frame = CGRect(x: self.width - 12 - 9, y: (self.height - 12) / 2, width: 12, height: 12)

        nextArrowImageView.frame = CGRect(x: self.width - 12 - 9, y: self.height + (self.height - 12) / 2, width: 12, height: 12)
    }
    
    func bindTitleLabel(_ titleLabel: UILabel?, withItem item: IItem?) {
//        if titleLabel?.superview != nil {
//            let params = ["view": titleLabel?.superview, "tag": "root", "action": "tap"]
//
//            itemContext?.scFireEvent(YKSCItemEventBindItemView, params: params)
//        }
        
        Service.action.bind(item?.itemModel?.action, self)

        titleLabel?.text = item?.itemModel?.title
    }

    
    
    /// 暗黑变化回调
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
        
        let theme = identifier as? String
        if theme == YKNThemeIdentifierDark {
            yknpcs_shadowLayer.shadowOpacity = 0
        } else {
            yknpcs_shadowLayer.shadowOpacity = 1
        }
        
        if _hasSceneBgColor {
            yknpcs_shadowLayer.shadowOpacity = 0
        }
    }
    
    func updateShader() {
        if isDark() {
            yknpcs_shadowLayer.shadowOpacity = 0
        } else {
            yknpcs_shadowLayer.shadowOpacity = 1
        }

        if _hasSceneBgColor {
            yknpcs_shadowLayer.shadowOpacity = 0
        }
    }
    
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
}
