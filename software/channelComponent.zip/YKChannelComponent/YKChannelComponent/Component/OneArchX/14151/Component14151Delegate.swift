//
//  Component14151Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/8/16.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import YKAdSDK
import OneArchSupport4Youku

class Component14151Delegate:NSObject, ComponentDelegate,ComponentLifeCycleDelegate {
    private var _visible: Bool = false
    
    var exposeCount:Int = 0
    var interval: Double = 2
    var ratio = CGFloat(1.8)
    var imgPath: String? = nil
    weak var itemView: Item14151ContentView?

    var itemModel: BaseItemModel? {
        get {
            return self.component?.getItems()?.first?.itemModel
        }
    }
    lazy var lifeCycleEventHandler:ComponentLifeCycleEventHandler = {
        let handler = ComponentLifeCycleEventHandler()
        handler.delegate = self
        return handler
    }()
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeComponentModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        
//        var lastCard:ICard?
//        var nextCard:ICard?
//        if let curCard = self.component?.getCard(), let cards = self.component?.getPage()?.getCards() {
//            let curCardIndex = curCard.index
//            let lastCardIndex = curCardIndex - 1
//            let nextCardIndex = curCardIndex + 1
//            if lastCardIndex >= 0, lastCardIndex < cards.count {
//                lastCard = cards[lastCardIndex]
//            }
//            if nextCardIndex >= 0, nextCardIndex < cards.count {
//                nextCard = cards[nextCardIndex]
//            }
//        }
//
//        if let lastCard = lastCard, let components = lastCard.getComponents() {
//            for component in components {
//                if let type = component.compModel?.type, type == ""
//            }
//        }
        config.padding = UIEdgeInsets.init(top: -9.0, left: YKNGap.youku_margin_left(), bottom: 6.0, right: YKNGap.youku_margin_right())
        if ykrl_isResponsiveLayout() {
            config.padding = UIEdgeInsets.init(top: -9.0, left: YKNGap.youku_margin_left(), bottom: 9.0, right: YKNGap.youku_margin_right())
        }
        config.preferredCardSpacingTop = 0.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [self.lifeCycleEventHandler]
    }
    
    func componentDidInit() {
        let compModel = self.component?.compModel as? HomeComponentModel
        _visible = false
        interval = Double(compModel?.scrollInterval ?? Int(2))
        
        if let imgRatio = compModel?.imgRatio {
            ratio = imgRatio
        }
            
        imgPath = compModel?.img
    }
    
    var componentWrapper: ComponentWrapper?
    
    /// item高度（custom布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        if canShowViewByTimeLimit() {
            return 30 * YKNSize.yk_icon_size_scale()
        } else {
            return 0
        }
    }

    /// 初始化item view（custom布局使用）
    func createView(_ itemSize: CGSize) -> UIView {
        let itemWidth = itemSize.width
        let itemHeight = itemSize.height

        let itemView = Item14151ContentView.init(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        return itemView
    }
    
    func reuseId() -> String? {
        var reuseId = "YKChannelComponent.Item14151ContentView"
        if let tag = self.component?.compModel?.type {
            reuseId += tag
        }
        if canShowViewByTimeLimit() {
            reuseId = reuseId + ".1"
        } else {
            reuseId = reuseId + ".0"
        }
        return reuseId
    }

    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14151ContentView else {
            return
        }
        if itemView.height < 1 {
            return
        }
        guard let itemModel = self.itemModel else {
            return
        }
 
        itemView.fillModel(component?.compModel, timerInterval: interval, imageRatio: ratio, imgPath: imgPath)
        
        itemView.superview?.clipsToBounds = false

        let sceneCardFooterBgColor = self.itemModel?.scene?.sceneCardFooterBgColor()

//        if itemView.yknpcs_shadowLayer == nil && sceneCardFooterBgColor == nil {
//            itemView.yknp_addCorners(.allCorners, rRadii: 7) { (shadowLayer: CALayer) in
//                let themeIdentifier = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
//                let isDark = themeIdentifier == YKNThemeIdentifierDark
//                
//                shadowLayer.shadowColor = UIColor.createColorWithHexRGB(colorStr: "#EAEAEA").cgColor
//                shadowLayer.shadowRadius = 3
//                shadowLayer.shadowOffset = CGSize(width: 0, height: 2)
//                shadowLayer.shadowOpacity = isDark ? 0 : 1
//            }
//        }
        self.itemView = itemView

    }

    ///MARK:Item14151ContentViewDelegate
    
    public func enterDisplayArea(itemView: UIView?) {
        _visible = true
        let isPageActive = self.component?.pageContext?.isPageActive() ?? false
        let dataState = self.component?.getPage()?.dataState ?? .invalid
        if isPageActive, dataState == .network {
            markShowFlag()
        }
    }
    public func exitDisplayArea(itemView: UIView?) {
        _visible = false
    }
    public func didActivate() {
        self.itemView?.updateShader()
    }
    public func didDeactivate() {
        
    }
}

extension Component14151Delegate {
    ///标记Flag：每一天展示一次
    func canShowViewByTimeLimit() -> Bool {
        guard let result = getSaveResult() else {
            return true
        }
    
        let interval = result.0
        let exposeCount = result.1
        let compModel = self.component?.compModel as? HomeComponentModel
        let exposeMaxCount = compModel?.exposeCount ?? 1
        if interval > 0 {
            let date = Date(timeIntervalSinceReferenceDate: interval)
            let timeKey = timeIntervalChangeToTimeStr(timeInterval: interval)
            print("[14151] canshow time:\(timeKey), exposeCount:\(exposeCount), maxCount:\(exposeMaxCount)")
            // 存在记录的日期，校验是否为当天
            if Calendar.current.isDateInToday(date) {
                if exposeCount < exposeMaxCount {
                    return true
                } else {
                    return false
                }
            } else {
                //非当天，执行展示
                return true
            }
        }
        //从没有展示过
        return true
    }
    
    func markShowFlag() {
        updateExposeFromUserDefaults()
        //刷新日期
        exposeCount += 1
        let count = exposeCount
        let timeKey = timeIntervalChangeToTimeStr(timeInterval: Date.timeIntervalSinceReferenceDate)
        print("[14151] mark time:\(timeKey)")
        
        UserDefaults.standard.setValue(timeKey, forKey: showDateKey())
        UserDefaults.standard.setValue(count, forKey: showDateExposeCountKey())
        UserDefaults.standard.synchronize()
    }
    
    func showDateKey() -> String {
        let suffix = "yk.component.14151.show.date"
        return suffix
    }
    
    func showDateExposeCountKey() -> String {
        let suffix = "yk.component.14151.exposeCount.show.date"
        return suffix
    }
    
    func updateExposeFromUserDefaults() {
        guard let result = getSaveResult() else {
            return
        }
        let interval = result.0
        let exposeCount = result.1
        
        let date = Date(timeIntervalSinceReferenceDate: interval)
        // 存在记录的日期，校验是否为当天
        if Calendar.current.isDateInToday(date) {
            self.exposeCount = exposeCount
        } else {
            self.exposeCount = 0
        }
    }
    
    func getSaveResult() -> (TimeInterval, Int)? {
        guard let dateKey = UserDefaults.standard.object(forKey: showDateKey()) as? String else {
            return (0, 0)
        }
        guard let exposeCount = UserDefaults.standard.object(forKey: showDateExposeCountKey()) as? Int else {
            return (0, 0)
        }
        let date = timeStrChangeTotimeInterval(dateKey)
        return (date, exposeCount)
    }

    //时间戳转成字符串
    func timeIntervalChangeToTimeStr(timeInterval:TimeInterval) -> String {
        let date:Date = Date.init(timeIntervalSinceReferenceDate: timeInterval)
        let formatter = DateFormatter.init()
        formatter.dateFormat = "yyyy-MM-dd"

        return formatter.string(from: date)
    }
    
    //MARK:- 字符串转时间戳
    func timeStrChangeTotimeInterval(_ timeString:String) -> TimeInterval {
        if timeString.isEmpty {
            return -1
        }
        let format = DateFormatter.init()
        format.dateStyle = .medium
        format.timeStyle = .short
        format.dateFormat = "yyyy-MM-dd"

        if let date = format.date(from: timeString) {
            return date.timeIntervalSinceReferenceDate
        }
        return -1
    }
}
