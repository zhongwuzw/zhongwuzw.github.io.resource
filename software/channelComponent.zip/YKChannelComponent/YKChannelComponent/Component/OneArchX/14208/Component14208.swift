//
//  Component14208.swift
//  YKChannelComponent
//
//  Created by better on 2022/12/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout
import OneArchSupport4Youku

class Component14208:NSObject, ComponentDelegate {
    
    var componentWrapper: ComponentWrapper?
    var currentFocusIndex: Int  = 0

    func componentDidInit() {
    }

    func layoutType() -> ComponentLayoutType {
        return .horizontalScroll
    }

    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
         config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.headerBottomMargin = 0.0
        config.rowSpacing = 0.0
        config.columnSpacing = YKNGap.dim_9() //YKNGap.youku_column_spacing()
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        config.horizontalPaddingLeft = YKNGap.youku_margin_left()
        config.horizontalPaddingRight = YKNGap.youku_margin_right()
        config.backgroundLeftMarginOffset = 0
        config.backgroundRightMarginOffset = 0
        config.headerLeftMarginOffset = 0
        config.headerRightMarginOffset = 0
        config.backgroundTopMargin = 0
        config.responsiveAdjustableMinColumnCount = 1.0
        return config
    }
    
    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        if let collectionView = itemView.subviews.first as? UICollectionView {
            if self.component?.compModel?.extraExtend["currentIndex"] == nil { //有值不重置
                collectionView.contentOffset = CGPoint.init(x: -YKNGap.youku_margin_left(), y: 0)
            }
        }
    }
    
    func columnCount() -> CGFloat {
        if ykrl_isResponsiveLayout() {
            return 1.0
        }
        return 1.3
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [Comp14208EventHandler()]
    }

    /// 是否开启自动聚焦能力 (横滑布局使用)
    func autoFocusMode() -> AutoFocusMode {
        return .left
    }
    
    /// 自动聚焦item变更 (横滑布局使用)
    func autoFocusItemChanged(_ index:Int) {
        print("[14208] indexchanged \(index)")
    
        currentFocusIndex = index
        self.component?.compModel?.extraExtend["currentIndex"] = index
    }

    /// 定位item位置（自定义布局使用）
    func scrollToItem(at index: Int, at scrollPosition: DomainScrollPosition, animated: Bool) {
        
    }
}

class Comp14208EventHandler: ComponentEventHandler, IComponentLifeCycleEventHandler {
    
    func enterDisplayArea(itemView: UIView?) {
        
    }
    
    func exitDisplayArea(itemView: UIView?) {
        
    }
    
    func visibleViewDidScroll(itemView: UIView?) {
        
        guard let compDelegate = self.component?.getComponentDelegate() as? Component14208 , let items = self.component?.getItems() , items.count > compDelegate.currentFocusIndex else {
            return
        }
        
        guard let itemDelegate = items[compDelegate.currentFocusIndex].getItemDelegate() as? Item14208 else {
            return
        }
        itemDelegate.eventHandler?.visibleViewDidScroll(itemView: itemView)
    }
    
    func visibleViewDidEndScroll(itemView: UIView?) {
        
    }
    
    func visibleViewsDidEndScroll() {
   
        guard let compDelegate = self.component?.getComponentDelegate() as? Component14208,
                let items = self.component?.getItems() , items.count > compDelegate.currentFocusIndex else {
            return
        }
        
        guard let itemDelegate = items[compDelegate.currentFocusIndex].getItemDelegate() as? Item14208 else {
            return
        }
        itemDelegate.eventHandler?.visibleViewDidEndScroll(itemView: itemDelegate.eventHandler?.backgroundView)
    }
}
