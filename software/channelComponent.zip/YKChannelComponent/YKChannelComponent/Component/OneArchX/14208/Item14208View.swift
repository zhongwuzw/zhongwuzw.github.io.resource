//
//  Item14208View.swift
//  YKChannelComponent
//
//  Created by better on 2022/12/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import SDWebImage
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent
import YKChannelPage
import YKHome
import YKResponsiveLayout
import YKChannel
import YKModeConfigFramework
import YoukuAnalytics
import DYKURLRouter
import YKProtocolSDK
import AliReachability
import OneTransition
import OneTransitionCore

class Item14208View: AccessibilityView, ChannelSliderPlayerDelegate {
    
    weak var model:Item14208Model?

    weak var component:IComponent?
    weak var item: IItem?
    
    var isFavor: Bool = false
    var isReserve: Bool = false
    
    var _visable = false
    var _disableVV = false

    var delayPlayTimer:Timer?

    var transitionAutoPlayAdaptor = TransitionAutoPlayAdaptorV2()

    //MARK: Property
    
    lazy var topTitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var rightArrow: UIImageView = {
        let view = UIImageView.init(frame:CGRect.init(x: 0, y: 0, width: 12, height: 12))
        view.image = UIImage.init(named: "ykn_more_btn")?.withRenderingMode(.alwaysTemplate)
        view.tintColor = .ykn_tertiaryInfo
        return view
    }()

    lazy var rightTitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.module_headline_linktext()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var videoImageViewBg1: UIView = {
        let view = UIView(frame: .zero)
        view.backgroundColor = UIColor.ykn_primaryInfo
        view.alpha = 0.2
        return view
    }()
    
    lazy var videoImageViewBg2: UIView = {
        let view = UIView(frame: .zero)
        view.backgroundColor = UIColor.ykn_primaryInfo
        view.alpha = 0.2
        return view
    }()
    
    lazy var videoImageView: BaseVideoImageView = {
        let view = BaseVideoImageView(frame: .zero)
        view.isUserInteractionEnabled = true
        return view
    }()
    
    lazy var playingBgView: UIView = {
        let view = UIView.init()
        view.backgroundColor = .clear
        return view
    }()
    
    lazy var shadowview: UIView = {
        let shadowview = UIView()
        shadowview.layer.masksToBounds = true
        shadowview.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return shadowview
    }()

    lazy var bottomShadow: CAGradientLayer = {
        let bottomShadow = CAGradientLayer.init()
        bottomShadow.colors = [UIColor(red: 0, green: 0, blue: 0, alpha: 0.5).cgColor, UIColor(red: 0, green: 0, blue: 0, alpha: 0.0).cgColor]
        bottomShadow.locations = [0.0, 1.0]
        bottomShadow.startPoint = CGPoint(x: 0, y: 1)
        bottomShadow.endPoint = CGPoint(x: 0, y: 0)
        return bottomShadow
    }()
    
    lazy var progressBar: UIView = {
        let view = UIView.init()
        view.backgroundColor = UIColor.ykn_brandInfo
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var followContentView: UserFollowViewV2 = {
        let view = UserFollowViewV2()
        return view
    }()
    
    lazy var uploaderLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    //player
    lazy var player:ChannelSliderPlayer? = {
        let vc = self.component?.pageContext?.getViewController()
        let player = ChannelSliderPlayer.init(controller: vc)
        player?.delegate = self
        player?.isSlientMode = true
        player?.videoScreenMode = 1
        player?.isHideWaterMark = true
        player?.embedPlayerView().clipsToBounds = true
        player?.embedPlayerView().layer.cornerRadius = YKNCorner.radius_secondary_medium()
        let pWidth = self.videoImageView.width
        let pHeight = self.videoImageView.height
        player?.setupFrame(CGRect.init(x: 0, y: 0, width: pWidth, height: pHeight))
        //添加起播互斥插件
        player?.registerPlugin(withPluginID: "startPlayMutex", params: mutextParams())
        return player
    }()

    //底部区阴影
    lazy var silentButton: UIButton = {
        let silentButton = UIButton()
        silentButton.isExclusiveTouch = true
        silentButton.setImage(UIImage(named: "st_player_plugin_icon_silent_on"), for: UIControl.State.normal)
        silentButton.setImage(UIImage(named: "st_player_plugin_icon_silent_on"), for: UIControl.State.highlighted)
        silentButton.addTarget(self, action: #selector(didClickSilentButton), for: UIControl.Event.touchUpInside)
        return silentButton
    }()
    
   func mutextParams() -> [String:Any] {
       return ["name":"YKCStartPlayMutexPlugin",
               "initlevel":10,
               "enabled":true,
               "classname":"YKCStartPlayMutexPlugin",
               "layers":["layerid":"ad", "level":1000]
       ]
   }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(topTitleLabel)
        self.addSubview(rightTitleLabel)
        self.addSubview(rightArrow)
        self.addSubview(videoImageViewBg2)
        self.addSubview(videoImageViewBg1)
        self.addSubview(videoImageView)
        self.addSubview(titleLabel)
        self.addSubview(followContentView)
        self.addSubview(uploaderLabel)
        self.videoImageView.addSubview(playingBgView)
        
        self.playingBgView.addSubview(self.shadowview)
        self.shadowview.layer.addSublayer(self.bottomShadow)
        self.shadowview.addSubview(self.silentButton)
        self.shadowview.addSubview(self.progressBar)
        self.shadowview.isHidden = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        
    }
        
    func fillData(_ item: IItem?) {
        self.item = item
    
        guard let itemModel = item?.itemModel as? Item14208Model else {
            return
        }
        model = itemModel
        
        var y: CGFloat = 0.0
        self.topTitleLabel.isHidden = isStringEmpty(itemModel.seriesModel?.title)
        if self.topTitleLabel.isHidden == false, let seriesModel = itemModel.seriesModel {

            self.rightArrow.isHidden = (seriesModel.action == nil)
            self.rightTitleLabel.isHidden = self.rightArrow.isHidden
            self.rightTitleLabel.text = seriesModel.showDesc
            self.rightTitleLabel.height = seriesModel.moreSize.height
            self.rightTitleLabel.width = seriesModel.moreSize.width
            self.rightTitleLabel.right = self.width - YKNGap.dim_7()
            self.rightArrow.right = self.width

            self.topTitleLabel.font = seriesModel.titleFont
            self.topTitleLabel.text = seriesModel.title
            self.topTitleLabel.frame = CGRect.init(x: 0, y: 0, width: self.width - seriesModel.moreSize.width - 6, height: YKNFont.height(with: seriesModel.titleFont, lineNumber: 1))
            if self.rightArrow.isHidden {
                self.topTitleLabel.width = self.width
            } else {
                self.topTitleLabel.width = self.width - seriesModel.moreSize.width - YKNGap.dim_7()
            }
            self.rightTitleLabel.height = self.topTitleLabel.height
            self.rightTitleLabel.centerY = self.topTitleLabel.centerY
            self.rightArrow.centerY = self.topTitleLabel.centerY

            y = self.topTitleLabel.bottom + 9

            //action
            Service.action.bind(seriesModel.action, topTitleLabel)
            Service.action.bind(seriesModel.action, rightTitleLabel)
        }
        
        // 封面
        let w = Double(self.frame.width);
       // let h = ceil(w * 9.0/16.0);
        videoImageView.frame = CGRect.init(x: 0, y: y, width: itemModel.imageWidth, height: itemModel.imageHeight)
        videoImageView.ykn_setImage(withURLString: XCDNSTRING(itemModel.img ?? ""),
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        videoImageViewBg1.frame = CGRect.init(x: 0, y: 0, width: 234, height: 131)
        videoImageViewBg1.right = videoImageView.right + YKNGap.dim_5()
        videoImageViewBg1.centerY = videoImageView.centerY
        videoImageViewBg2.frame = CGRect.init(x: 0, y: 0, width: 212, height: 119)
        videoImageViewBg2.right = videoImageViewBg1.right + YKNGap.dim_5()
        videoImageViewBg2.centerY = videoImageView.centerY
        videoImageViewBg1.layer.cornerRadius = videoImageView.layer.cornerRadius
        videoImageViewBg2.layer.cornerRadius = videoImageView.layer.cornerRadius

        //play
        playingBgView.frame = videoImageView.bounds
        shadowview.frame = CGRect(x: 0, y: playingBgView.height - 40, width: playingBgView.width, height: 40)
        bottomShadow.frame = self.shadowview.bounds
        silentButton.frame = CGRect(x: playingBgView.width - 44 + 6, y: shadowview.height - 38 + 5, width: 44, height: 38)
        progressBar.frame = CGRect.init(x: 0, y: shadowview.height - 2, width: 0, height: 2)

        // 关注
        followContentView.shouldShowFollowView = true
        followContentView.fill(itemModel)
        followContentView.width = 36
        followContentView.height = 46
        followContentView.left = videoImageView.left
        followContentView.top = videoImageView.bottom + 6

        // 标题
        titleLabel.font = itemModel.titleFont
        titleLabel.text = itemModel.title
        titleLabel.numberOfLines = itemModel.titleLineCoune
        titleLabel.width = itemModel.titleWidth
        titleLabel.height = itemModel.titleHeight
        titleLabel.left = followContentView.right + YKNGap.dim_5()
        titleLabel.top = followContentView.top

        // 上传者
        self.uploaderLabel.font = itemModel.nameFont
        self.uploaderLabel.text = itemModel.uploader?.name
        self.uploaderLabel.width = self.titleLabel.width
        self.uploaderLabel.height = itemModel.nameHeight
        self.uploaderLabel.left = self.titleLabel.left
        self.uploaderLabel.top = titleLabel.bottom + YKNGap.dim_2()
        
        Service.action.bind(itemModel.uploader?.action, uploaderLabel)

        // 角标
        Service.mark.attach(itemModel.mark, toView: videoImageView, layout: nil)
        
        // 右下角腰封
        Service.summary.attach(itemModel.summary, toView: videoImageView, layout: nil)
        
        // 左下角腰封
        Service.lbTexts.attach(itemModel.lbTexts, toView: videoImageView, layouts: nil)
        
        Service.lTop.attach(itemModel.lTop, toView: videoImageView)
        
        //Service.action.bind(itemModel.action, self)
        
        refreshScene()
        
        //reset headicon
        if titleLabel.numberOfLines == 1 {
            self.followContentView.top = videoImageView.bottom + 6 + (self.uploaderLabel.bottom - self.titleLabel.top) / 2.0 - 18
        } else {
            self.followContentView.top = videoImageView.bottom + 6
        }
        
        //action
        Service.action.bind(itemModel.action, self)
    }
    
    private func enableTransitionToSv() -> Bool {
        let data = self.model?.data as? [String : Any]
        let dataExtraExtend = data?["extraExtend"] as? [String : Any]
        let enableTransition = dataExtraExtend?.yk_bool("enableSvPageTransition") ?? false
        return enableTransition
    }
    
    private func enableTransitionBack() -> Bool {
        let data = self.model?.data as? [String : Any]
        let dataExtraExtend = data?["extraExtend"] as? [String : Any]
        let enableTransition = dataExtraExtend?.yk_bool("enableSvPageTransitionBack") ?? false
        return enableTransition
    }
    
    func addTransitionItem(itemModel: BaseItemModel) -> String? {
        guard let playId = itemModel.playerModel?.playerId,
              let itemView = itemModel.playerModel?.itemView
        else { return nil }
        
        let item = OTTransitionItem()
        item.playId = playId
        item.viewContainer = itemView
        let imgView = UIImageView(frame: self.videoImageView.frame)
        imgView.contentMode = .scaleAspectFill
        imgView.ykn_setImage(withURLString: itemModel.img ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        item.originRect = self.videoImageView.convert(self.videoImageView.frame, to: nil)
        item.videoCover = imgView
        item.transitionType = .player
        
        if enableTransitionBack() {
            item.needTransitionBack = true
            item.transitionBackDelegate = self.transitionAutoPlayAdaptor
        }
        
        let videoSize = self.videoImageView.frame.size
        self.addVideoInfo(to: item, videoSize: videoSize)
        let transitionId = OTTransitionMonitor.sharedInstance.addTransitionItem(item: item)
        return transitionId
    }
    
    private func addVideoInfo(to transitionItem: OTTransitionItem, videoSize: CGSize) {
        var extraData = transitionItem.extraData
        if videoSize != CGSize.zero {
            let sWidth = "\(videoSize.width)"
            let sHeight = "\(videoSize.height)"
            extraData["videoWidth"] = sWidth
            extraData["videoHeight"] = sHeight
        }
        transitionItem.extraData = extraData
    }
    
    func refreshScene() {
        self.backgroundColor = .clear
        titleLabel.textColor = sceneUtil(UIColor.ykn_primaryInfo, sceneColor: model?.scene?.sceneTitleColor())
        uploaderLabel.textColor = sceneUtil(UIColor.ykn_tertiaryInfo, sceneColor: model?.scene?.sceneSubTitleColor())
        topTitleLabel.textColor = sceneUtil(UIColor.ykn_primaryInfo, sceneColor: model?.scene?.sceneTitleColor())
        rightTitleLabel.textColor =  sceneUtil(UIColor.ykn_tertiaryInfo, sceneColor: model?.scene?.sceneSubTitleColor())
        rightArrow.tintColor = sceneUtil(UIColor.ykn_tertiaryInfo, sceneColor:  model?.scene?.sceneSubTitleColor())
        videoImageViewBg1.backgroundColor = sceneUtil(UIColor.ykn_primaryInfo, sceneColor: model?.scene?.sceneSubTitleColor())
        videoImageViewBg2.backgroundColor = sceneUtil(UIColor.ykn_primaryInfo, sceneColor: model?.scene?.sceneSubTitleColor())
    }

    @objc func didClickSilentButton() {
        let isSlient = isSilentMode()
        self.player?.isSlientMode = !isSlient
        self.asyncSlientBtnState()
        
        saveSilentMode(!isSlient)
    }
    
    func asyncSlientBtnState() {
        let isSlientMode: Bool = self.player?.isSlientMode ?? true
        if isSlientMode {
            silentButton.setImage(UIImage(named: "st_player_plugin_icon_silent_on"), for: UIControl.State.normal)
        } else {
            silentButton.setImage(UIImage(named: "st_player_plugin_icon_silent_off"), for: UIControl.State.normal)
        }
        silentButton.isHidden = false
    }
    
    // MARK: play action
    func startPlayer() {
        if !self.isWifi {
            let mobileConfig = PlayerControlConfig.mobileScrollAutoPlay(self.item)
            if mobileConfig != "1" {
                return
            } else {
                self.player?.enable4GPlay()
            }
        }
                
        guard let model = self.model else {
            return
        }
        
        guard isPageInActive(), let previewId = getPreviewId(), let vc = self.component?.pageContext?.getViewController() else {
            return
        }
        
        guard let player = self.player else {
            return
        }
        if player.isPlaying {
            print("[14208] already play")
            return
        }
        
        print("[14208] play \(previewId)")
        
        var params = [String : Any]()
        params["play_style"] = "1"
        params["from"] = model.progress
        
        if let playTrigger = self.model?.extraExtend["playTrigger"] as? Int, playTrigger == 2 {
            params["playtrigger"] = "2"
            params["disableVV"] = false
        } else {
            params["playtrigger"] = "1"
            params["disableVV"] = true
        }
        
        //report
        if let report = self.model?.action?.report {
            params["pageName"] = report.pageName
            params["controlName"] = report.controlName
            if let spm = report.spm {
                params["spm"] = "\(spm)_preview"
            }
            params["scm"] = report.scm
            params["trackInfo"] = report.trackInfo
            params["utparam"] = report.utparam
        }

        self.player?.playVideo(withVid: previewId, params: params, controller: vc)
    }
    
    func stopPlayer() {
        player?.stopVideo()
        player?.embedPlayerView().removeFromSuperview()
        print("[14208] stop play")
        self.shadowview.isHidden = true
    }
    
    // MARK: ChannelSliderPlayerDelegate
    
    /// 开始播放
    func didStartPlayVideo(in player: ChannelSliderPlayer) {
        let previewVid = getPreviewId()
        self.model?.playingVid = player.playingVid
        print("[14208] didStartPlayVideo \(previewVid)")
        
        if _visable, isPageInActive() {
            player.embedPlayerView().isHidden = false
            self.shadowview.isHidden = false
            
            self.player?.isSlientMode = isSilentMode()
            self.asyncSlientBtnState()
            
            if let embedPlayerView = player.embedPlayerView(), embedPlayerView.superview != self {
                playingBgView.addSubview(embedPlayerView)
                playingBgView.sendSubviewToBack(embedPlayerView)
                playingBgView.bringSubviewToFront(silentButton)
            }
        } else {
            stopPlayer()
        }
    }

    /// 播放错误
    func player(_ player: ChannelSliderPlayer, playError errorCode: Int32) {
        stopPlayer()
    }
    
    /// 播放完成
    func didFinishPositiveVideo(in player: ChannelSliderPlayer) {
        stopPlayer()
        
        guard let compModel = self.component?.compModel, let items = self.component?.getItems() else {
            return
        }
        
        var currentIndex : Int = 0
        if let tempIndex = compModel.extraExtend["currentIndex"] as? Int {
            currentIndex = tempIndex
        }
        
        if currentIndex < (items.count - 1) {
            let newItem = items[currentIndex + 1]
            newItem.scrollTo(at: .center, animated: true)
        }
    }

    func playingProgress(_ progress: Int, totalTime time: Int) {
        guard time > 0 else {
            return
        }
        self.model?.progress = progress
        self.model?.totalTime = time
        progressBar.width = self.shadowview.width * CGFloat(progress) * 1.0 / CGFloat(time)
        print("[14208] playing \(progress) \(time)")
    }
    
    func getPreviewId() -> String? {
        guard let preview = self.item?.itemModel?.preview else {
            return nil
        }
        if let vid = preview["vid"] as? String {
            return vid
        } else if let vid = preview["vid"] as? Int {
            return "\(vid)"
        }
        return nil
    }
    
    //MARK: - state
    
    var isWifi: Bool {
        return NWReachabilityManager.shareInstance()?.currentNetworkStatus() == NetworkStatus.ReachableViaWiFi
    }
    
    func isPageInActive() -> Bool {
        return self.component?.pageContext?.isPageActive() ?? false
    }
    
    func isSilentMode() -> Bool {
        guard let num = self.component?.compModel?.extraExtend["14208.isMute"] as? NSNumber else {
            return true
        }
        return num.boolValue
    }
    
    func saveSilentMode(_ isSilent: Bool) {
        self.component?.compModel?.extraExtend["14208.isMute"] = isSilent
    }
    
    func didActivate() {
        if _visable {
            if UtilityHelper.isPlayerInValidArea(playerView: videoImageView) {
                startPlayer()
            }
        }
    }

    func didDeactivate() {
        stopPlayer()
    }

    func enterDisplay() {
        _visable = true
        if UtilityHelper.isPlayerInValidArea(playerView: videoImageView) {
            startPlayer()
        }
    }

    func exitDisplay() {
        _visable = false
        
        stopPlayer()
    }
    
    func judgeStartOrStopPlayerForScroll(_ canStart: Bool) {
        if UtilityHelper.isPlayerInValidArea(playerView: videoImageView) {
            if canStart {
                enterDisplay()
            }
        } else {
            exitDisplay()
        }
    }

}
