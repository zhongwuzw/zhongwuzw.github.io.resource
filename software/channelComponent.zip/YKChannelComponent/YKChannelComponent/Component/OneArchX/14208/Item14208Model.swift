//
//  Item14208Model.swift
//  YKChannelComponent
//
//  Created by better on 2022/12/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout

public class SeriesModel {
    
    let titleFont = YKNFont.module_headline_weight(.medium)
   
    let moreFont = YKNFont.module_headline_linktext()
    var moreSize: CGSize = .zero
    
    /// 文本
    public var title: String?
    
    /// 右侧文本
    public var showDesc: String?
    
    /// 跳转
    public var action: ActionModel?
    
    public init() {
        
    }
    
    public init(_ json: [String: Any], itemModel: BaseItemModel) {
        title = json["title"] as? String
        showDesc = json["showDesc"] as? String
        if let actionInfo = json["action"] as? [String: Any] {
            action = buildActionModel(actionInfo, model: itemModel)
        }
        moreSize = calcStringSize(showDesc, font: moreFont, size: .zero)
    }
}

class Item14208Model: HomeItemModel {
    
    var seriesModel: SeriesModel?

    var imageWidth: CGFloat = 0.0
    var imageHeight: CGFloat = 0.0
    
    let titleFont = YKNFont.posteritem_maintitle()
    var titleWidth: CGFloat = 0.0
    var titleLineCoune = 1
    var titleHeight: CGFloat = 0.0

    let nameFont = YKNFont.module_headline_linktext()
    let nameHeight = YKNFont.height(with: YKNFont.module_headline_linktext(), lineNumber: 1)
    
    var progress = 0
    var totalTime = 0
    var playingVid: String?

    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        if let cmsInfo = cmsInfo, let data = cmsInfo["data"] as? [String : Any] {
            if let json = data["series"] as? [String:Any] {
                self.seriesModel = SeriesModel.init(json, itemModel: self)
            }
        }
        titleWidth = calcStringSize(title, font: titleFont, size: .zero).width
    }
}
