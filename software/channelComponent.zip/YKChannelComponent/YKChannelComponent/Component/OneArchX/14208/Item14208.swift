//
//  Item14208.swift
//  YKChannelComponent
//
//  Created by better on 2022/12/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout

class Item14208: NSObject, ItemDelegate, PlayingProgress {
    var itemWrapper: ItemWrapper?
    weak var eventHandler: Item14208BackgroundEventHandler?
    var displayingItemView: Item14208View?

    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14208Model.self as? T.Type
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        guard let itemModel = self.item?.model as? Item14208Model else {
            return 0.0
        }
        
        var titleHeight:CGFloat = 0.0
        if let seriesModel = itemModel.seriesModel, !isStringEmpty(seriesModel.title) {
            titleHeight = YKNFont.height(with: seriesModel.titleFont, lineNumber: 1)
            titleHeight += 9.0
        }
        
        let imageWidth = itemWidth - YKNGap.dim_7()
        let imageHeight = imageWidth * 143.0 / 255.0
        itemModel.imageWidth = imageWidth
        itemModel.imageHeight = imageHeight
        
        var totalHeight = titleHeight + imageHeight
        
        if itemModel.uploader != nil {
            totalHeight += 6.0
            
            let headIconHeight:CGFloat = 42
            
            let titleMaxWidth = imageWidth - 36 - YKNGap.dim_5()
            var titleWidth = calcStringSize(itemModel.title, font: itemModel.titleFont, size: .zero).width
            var titleHeight = 0.0
            if titleWidth > titleMaxWidth {
                titleHeight = YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 2)
                itemModel.titleLineCoune = 2
            } else {
                titleHeight = YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
                itemModel.titleLineCoune = 1
            }
            itemModel.titleHeight = titleHeight
            itemModel.titleWidth = titleMaxWidth
            
            let titleAreaHeight = titleHeight + YKNGap.dim_2() + itemModel.nameHeight
            if titleAreaHeight > headIconHeight {
                totalHeight += titleAreaHeight
            } else {
                totalHeight += headIconHeight
            }
        }
        return totalHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        let handler = Item14208BackgroundEventHandler()
        self.eventHandler = handler
        return [handler]
    }
    
    func itemDidInit() {
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14208View(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14208View else {
            return
        }
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        guard let item = self.item else {
            return
        }
        itemModel.action?.playingProgress = self

        self.eventHandler?.backgroundView = itemView
        self.displayingItemView = itemView
        
        itemView.component = self.item?.getComponent()
        itemView.fillData(item)
    }
    
    public func getPlayedSeconds() -> Int {
        guard let itemModel = self.item?.model as? Item14208Model else {
            return 0
        }
        return itemModel.progress *  1000
    }
    public func isHotPointVideo() -> Bool {
        if let hotPoint = self.item?.itemModel?.preview?["hotPoint"] as? NSNumber, hotPoint.intValue > 0 {
            return true
        }
        return false
    }
    public func highlightPoint() -> Int? {
        if let hotPoint = self.item?.itemModel?.preview?["hotPoint"] as? NSNumber, hotPoint.intValue > 0 {
            return hotPoint.intValue
        }
        return nil
    }
}

class Item14208BackgroundEventHandler: ItemEventHandler, IPageLifeCycleEventHandler, IItemLifeCycleEventHandler {
    
    weak var backgroundView: Item14208View?
        
    /// 页面视图初始化
    func viewDidLoad() {
        
    }

    /// 页面将激活
    func willActivate() {
        
    }

    /// 页面已激活
    func didActivate() {
        
        if isCurrentBgInReuse() {
            self.backgroundView?.didActivate()
        }
    }

    /// 页面将失活
    func willDeactivate() {

    }

    /// 页面已失活
    func didDeactivate() {
        
        if isCurrentBgInReuse() {
            self.backgroundView?.didDeactivate()
        }
    }

    /// 页面销毁
    func pageDealloc() {
        
    }
    
    /// 应用进入激活状态
    func appDidBecomeActive() {
        
        if isCurrentBgInReuse() {
            self.backgroundView?.didActivate()
        }
    }
    
    /// 应用即将进入失活状态
    func appWillResignActive() {
        
        if isCurrentBgInReuse() {
            self.backgroundView?.didDeactivate()
        }
    }
    
    // MARK: IItemLifeCycleEventHandler
    func enterDisplayArea(itemView: UIView?) {
        
    }
    
    func exitDisplayArea(itemView: UIView?) {
        
        if isCurrentBgInReuse() {
            self.backgroundView?.exitDisplay()
        }
    }
    
    func visibleViewDidScroll(itemView: UIView?) {
        
        if isCurrentBgInReuse() {
            self.backgroundView?.judgeStartOrStopPlayerForScroll(false)
        }
    }
    
    func visibleViewDidEndScroll(itemView: UIView?) {
        
        if isCurrentBgInReuse() {
            self.backgroundView?.judgeStartOrStopPlayerForScroll(true)
        }
    }
    
    /// 自动聚焦到ItemView。在设置了autoFocusMode的横滑组件中有用。
    func autoFocusItemView(_ itemView: UIView?) {
        
        if isCurrentBgInReuse() {
            self.backgroundView?.enterDisplay()
        }
    }
    
    /// 取消聚焦ItemView。在设置了autoFocusMode的横滑组件中有用。
    func cancelFocusItemView(_ itemView: UIView?) {
        
        if isCurrentBgInReuse() {
            self.backgroundView?.exitDisplay()
        }
    }

    func isCurrentBgInReuse() -> Bool {
        guard let viewComp = self.backgroundView?.component else {
            return false
        }
        guard let component = self.item?.getComponent() else {
            return false
        }
        let ptr1 = Unmanaged<AnyObject>.passUnretained(viewComp).toOpaque()
        let ptr2 = Unmanaged<AnyObject>.passUnretained(component).toOpaque()
        if ptr1 == ptr2 {
            return true
        }
        return false
    }
}
