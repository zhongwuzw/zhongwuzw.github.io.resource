//
//  Component14193ContentView.swift
//  YKChannelComponent
//
//  Created by better on 2022/2/23.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchBridge
import YoukuResource
import OneArchSupport4Youku
import SDWebImage

class Component14193ContentView: AccessibilityView, UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout, WeakTimerActionProtocol {
    
    //是否是平铺模式
    var isTileMode = false
    var hasTopImage = false

    //大的背景View

    lazy var sceneBackgroundView: UIView = {
        let view = UIView.init(frame:CGRect.init(x: 0, y: self.hasTopImage ? 22 : 0.0, width: self.width, height: self.hasTopImage ? (self.height - 22) : self.height))
        view.backgroundColor = .clear
        return view
    }()
    
    //剧场logo图
    lazy var logoImageView: UIImageGIFView = {
        let view = createVideoImageView()
        view.frame = CGRect.init(x: YKNGap.dim_8(), y: (self.hasTopImage ? 22 : 0.0) +  13, width: 150, height: 56)
        return view
    }()
    
    lazy var topBackgroundView: UIView = {
        let view = UIView.init(frame:CGRect.init(x: 0, y: 0, width: self.width, height: Comp14193Util.topImageHeight(self.hasTopImage)))
        view.backgroundColor = .clear
        return view
    }()
    
    lazy var topSceneLogoImageView: UIImageGIFView = {
        let view = createVideoImageView()
        view.frame = CGRect.init(x: 0, y: 0, width: 345, height: 22)
        return view
    }()
    
    lazy var bottomSceneLogoImageView: UIImageGIFView = {
        let view = createVideoImageView()
        view.frame = CGRect.init(x: 0, y: 0, width: 345, height: 82)
        return view
    }()

    lazy var tabScrollView: UIScrollView = {
        var view = UIScrollView.init(frame: CGRect.init(x: 0, y: 104, width: self.width, height: tabHeight()))
        view.contentInset = UIEdgeInsets.init(top: 0, left: YKNGap.dim_7(), bottom: 0, right: YKNGap.dim_7())
        view.showsHorizontalScrollIndicator = false
        view.backgroundColor = .clear
        return view
    }()
    
    lazy var tabItemViews: [UILabel] = {
        var result = [UILabel]()
        for i in 0..<10 {
            result.append(createItemLabel())
        }
        return result
    }()
    
    lazy var collectionView: UICollectionView = {
        let layout = UICollectionViewFlowLayout.init()
        layout.scrollDirection = UICollectionView.ScrollDirection.horizontal
        layout.minimumLineSpacing = YKNGap.youku_column_spacing()
        layout.minimumInteritemSpacing = 0
        let view = UICollectionView.init(frame:CGRect.init(x: 0, y: Comp14193Util.tabMenuHeight() + Comp14193Util.topImageHeight(self.hasTopImage) + YKNGap.dim_6(), width: self.width, height: itemHeight()), collectionViewLayout:layout)
        view.contentInset = UIEdgeInsets.init(top: 0, left: YKNGap.dim_7(), bottom: 0, right: YKNGap.dim_7())
        view.showsHorizontalScrollIndicator = false
        view.backgroundColor = .clear
        view.dataSource = self
        view.delegate = self
        return view
    }()
        
    lazy var tileBackgroundView: TileBackgroundView = {
        let itemHeight = itemHeight() * 2 + 18
        let view = TileBackgroundView.init(frame:CGRect.init(x: 0, y: Comp14193Util.tabMenuHeight() + Comp14193Util.topImageHeight(self.hasTopImage) + YKNGap.dim_6(), width: self.width, height: itemHeight))
        return view
    }()
    
    lazy var bottomLogoImageView: UIImageGIFView = {
        let view = createVideoImageView()
        view.frame = CGRect.init(x: 12, y: 0, width: 150, height: 24)
        view.bottom = self.height - YKNGap.dim_9()
        return view
    }()
    
    lazy var actionView: YKRoundActionView = {
        let view = YKRoundActionView.init(frame: CGRect.init(x: self.width - 15 - 84, y: 48, width: 84, height: 30))
        return view
    }()
    
    lazy var bottomArrowView: UIImageView = {
        let view = UIImageView.init(frame:CGRect.init(x: 0, y: 0, width: 12 * YKNSize.yk_icon_size_scale(), height: 12 * YKNSize.yk_icon_size_scale()))
        view.image = UIImage.init(named: "ykn_more_btn")?.withRenderingMode(.alwaysTemplate)
        view.tintColor = .white
        view.centerY = self.bottomLogoImageView.centerY
        view.right = self.width - YKNGap.dim_7()
        return view
    }()
    
    lazy var bottomMoreLabel: UILabel = {
        let view = UILabel.init(frame:CGRect.init(x: 0, y: 0, width:100, height: 30))
        view.font = YKNFont.button_text()
        view.textColor = .white
        view.centerY = self.bottomLogoImageView.centerY
        view.right = self.bottomArrowView.left - YKNGap.dim_1()
        view.textAlignment = .right
        return view
    }()

    func itemHeight() -> CGFloat {
        return Comp14193Util.videoImageViewHeight(self.width) + Comp14193Util.textAreaHeight()
    }
    
    func itemWidth() -> CGFloat {
        return Comp14193Util.videoImageViewWidth(self.width)
    }
    
    func createItemLabel() -> UILabel {
        let label = UILabel.init()
        label.textColor = .ykn_primaryInfo
        label.font = YKNFont.top_tabbar_text()
        self.tabScrollView.addSubview(label)
        return label
    }
    
    func tabHeight() -> CGFloat {
        return YKNFont.height(with: YKNFont.top_tabbar_textbold(), lineNumber: 1)
    }
    
    init(frame: CGRect, hasTopImage:Bool) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        self.hasTopImage = hasTopImage

        self.sceneBackgroundView.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#040000")
//        self.sceneBackgroundView.layer.cornerRadius = YKNCorner.radius_large()
//        self.sceneBackgroundView.clipsToBounds = true
//        self.clipsToBounds = false
//        self.superview?.clipsToBounds = false

        
        ///整体氛围背景view
        addSubview(self.sceneBackgroundView)
        ///氛围图下半部分
        sceneBackgroundView.addSubview(self.bottomSceneLogoImageView)
        
        ///氛围图 上半部分
        addSubview(self.topSceneLogoImageView)
        
        /// 左上logo
        addSubview(self.logoImageView)
        ///右上按钮
        addSubview(self.actionView)
        ///点击区域 空白view
        addSubview(self.topBackgroundView)
        
        addSubview(self.tabScrollView)
        addSubview(self.collectionView)
        addSubview(self.tileBackgroundView)
        addSubview(self.bottomLogoImageView)
        addSubview(self.bottomArrowView)
        addSubview(self.bottomMoreLabel)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    var selIndex = 0
    var itemsSize = [CGFloat]()
    weak var component:IComponent?
    var scrollInterval = 3
    
    func fillData(component: IComponent, itemsSize:[CGFloat]) {
        guard let components = component.getCard()?.getComponents(), components.count > 0, components.count == itemsSize.count else {
            return
        }
        guard let compModel = component.compModel else {
            return
        }

        self.selIndex = compModel.extend["selectIndex"] as? Int ?? 0
        self.component = component
        self.itemsSize = itemsSize
        if compModel.scrollInterval > 0 {
            self.scrollInterval = compModel.scrollInterval
        }

        //cache不够时增加label
        if itemsSize.count > self.tabItemViews.count {
            for _ in self.tabItemViews.count..<itemsSize.count {
                self.tabItemViews.append(createItemLabel())
            }
        }

        self.tabScrollView.isHidden = itemsSize.count <= 1
        if !self.tabScrollView.isHidden {
            self.tabScrollView.width = self.width
            var x:CGFloat = 0.0
            for i in 0..<self.tabItemViews.count {
                let tabItemView = self.tabItemViews[i]
                tabItemView.isHidden = i >= itemsSize.count
                if !tabItemView.isHidden {
                    if let model = components[i].model as? BaseComponentModel {
                        tabItemView.text = model.title
                        tabItemView.frame = CGRect.init(x: x, y: 0, width: itemsSize[i], height: tabHeight())
                        x = tabItemView.right + YKNGap.youku_horz_spacing_l()
                        Service.statistics.bind(model.action?.report, tabItemView, .Defalut)
                        weak var weakself = self
                        tabItemView.whenTapped {
                            weakself?.stopAnimation()
                            weakself?.refresh(i)
                            weakself?.startAnimation()
                        }
                    }
                }
            }
            self.tabScrollView.contentSize = CGSize.init(width: x - YKNGap.youku_horz_spacing_l(), height: 10.0)
        }
        self.topSceneLogoImageView.isHidden = self.hasTopImage ? false : true
        self.addBgViewBorderAndShadow()
        
        refresh(selIndex)
    
        startAnimation()
    }
    
    func refresh(_ selIndex: Int) {
        self.selIndex = selIndex
        
        guard let compModel = getCurrentComponent()?.model as? BaseComponentModel else {
            return
        }
        guard let firstCompModel = self.component?.compModel else {
            return
        }
        firstCompModel.extend["selectIndex"] = self.selIndex
        
        guard selIndex < self.tabItemViews.count, selIndex < self.itemsSize.count else {
            return
        }
        
        //adjust tab scroll
        let tabItemView = self.tabItemViews[selIndex]
        if self.tabScrollView.contentOffset.x + YKNGap.dim_7() > tabItemView.left {
            self.tabScrollView.setContentOffset(CGPoint.init(x: tabItemView.left - YKNGap.dim_7(), y: 0), animated: true)
            print("[jbp] scroll 1")
        } else if selIndex == self.itemsSize.count - 1 {
            if self.tabScrollView.contentOffset.x - YKNGap.dim_7() + self.tabScrollView.width < tabItemView.right {
                self.tabScrollView.setContentOffset(CGPoint.init(x: tabItemView.right - (-YKNGap.dim_7() + self.tabScrollView.width), y: 0), animated: true)
                print("[jbp] scroll 2")
            }
        } else if self.tabScrollView.contentOffset.x - (YKNGap.youku_horz_spacing_l() + 12) + self.tabScrollView.width < tabItemView.right {
            self.tabScrollView.setContentOffset(CGPoint.init(x: tabItemView.right - (-12 - YKNGap.youku_horz_spacing_l() + self.tabScrollView.width), y: 0), animated: true)
            print("[jbp] scroll 3")
        }

        self.logoImageView.image = nil
        if let url = compModel.titleImg {
            weak var weakself = self
            SDWebImageManager.shared()?.downloadImage(with: URL.init(string: url), progress: nil) { (image, error, type, finished, url) in
                if let image = image, image.size.height > 0, let weakself = weakself {
                    var frame = weakself.logoImageView.frame
                    frame.size.width = frame.height * image.size.width / image.size.height
                    weakself.logoImageView.frame = frame
                    weakself.logoImageView.image = image
                }
            }
        }
        
        let homeCompModel = getCurrentComponent()?.homeCompModel
        
        let topImagePath = homeCompModel?.bgTopImg
        self.topSceneLogoImageView.image = nil
        let logoImageW = CGFloat(345)
        self.topSceneLogoImageView.frame = CGRect.init(x: self.width - logoImageW, y: 1, width: logoImageW, height: 22)
        self.topSceneLogoImageView.ykn_setImage(withURLString: topImagePath,
                            module: "channel",
                            imageSize: CGSize.zero,
                            parameters: ["placeholderColor": UIColor.clear]) { (image: UIImage?, _: Error?, _: [AnyHashable : Any]?) in
        }
        
        let bottomImagePath = homeCompModel?.bgBottomImg
        self.bottomSceneLogoImageView.image = nil
        self.bottomSceneLogoImageView.frame = CGRect.init(x: self.sceneBackgroundView.width - logoImageW, y: 0, width: logoImageW, height: 82)
        self.bottomSceneLogoImageView.layer.cornerRadius = YKNCorner.radius_large()
        self.bottomSceneLogoImageView.clipsToBounds = true
       
        self.bottomSceneLogoImageView.ykn_setImage(withURLString: bottomImagePath,
                            module: "channel",
                            imageSize: CGSize.zero,
                            parameters: ["placeholderColor": UIColor.clear]) { (image: UIImage?, _: Error?, _: [AnyHashable : Any]?) in
        }
            
        self.bottomLogoImageView.image = nil
        if let url = compModel.iconModel?.icon {
            weak var weakself = self
            SDWebImageManager.shared()?.downloadImage(with: URL.init(string: url), progress: nil) { (image, error, type, finished, url) in
                if let image = image, image.size.height > 0, let weakself = weakself {
                    var frame = weakself.bottomLogoImageView.frame
                    frame.size.width = frame.height * image.size.width / image.size.height
                    if frame.size.width > 240 {
                        frame.size.width = 240
                    }
                    weakself.bottomLogoImageView.frame = frame
                    weakself.bottomLogoImageView.image = image
                }
            }
        }
        Service.action.bind(compModel.iconModel?.action, self.bottomLogoImageView)

        if let entry = compModel.detailEntry {
            //不展示广告，进入剧场按钮移动到左上方
            if !Component14193ContentView.isShowAdIcon(getCurrentComponent()) {
                self.bottomMoreLabel.isHidden = true
                self.bottomArrowView.isHidden = true
                self.actionView.isHidden = false
                
                if let text = entry.text, !text.isEmpty {
                    self.actionView.text = text
                    self.actionView.isHidden = false
                } else {
                    self.actionView.isHidden = true
                }

                Service.action.bind(entry.action, self.actionView, .Defalut)
                Service.action.bind(entry.action, self.topBackgroundView, .Defalut)
                
                //Scene Color
                self.actionView.unselectTextColor = sceneUtil(.white, sceneColor: compModel.scene?.sceneButtonTextColor()) ?? .white
                self.actionView.unselectBorderColor = sceneUtil(.white, sceneColor: compModel.scene?.sceneButtonTextColor()?.withAlphaComponent(0.3)) ?? .white
                self.actionView.unselectBgColor = sceneUtil(.white, sceneColor: compModel.scene?.sceneButtonSelectBgColor()) ?? .white
                self.actionView.refresh()
            } else {
                self.bottomMoreLabel.isHidden = false
                self.bottomArrowView.isHidden = false
                self.actionView.isHidden = true
                
                self.bottomMoreLabel.text = entry.text
                Service.action.bind(entry.action, self.bottomMoreLabel, .Defalut)
                Service.action.bind(entry.action, self.topBackgroundView, .Defalut)
            }

        } else {
            self.actionView.isHidden = true
            self.bottomMoreLabel.isHidden = true
            self.bottomArrowView.isHidden = true
        }

        //actionview
        self.layoutActionView()
        
        self.collectionView.isHidden = isTileMode
        self.tileBackgroundView.isHidden = !isTileMode
        
        if isTileMode {
            //layout
            if self.tabScrollView.isHidden {
                self.tileBackgroundView.top = Comp14193Util.topImageHeight(self.hasTopImage)
            } else {
                self.tileBackgroundView.top = self.tabScrollView.bottom + YKNGap.dim_6()
            }
            //reload
            self.tileBackgroundView.fillData(self.getItems())
        } else {
            //layout
            if self.tabScrollView.isHidden {
                self.collectionView.top = Comp14193Util.topImageHeight(self.hasTopImage)
            } else {
                self.collectionView.top = self.tabScrollView.bottom + YKNGap.dim_6()
            }
            //reload
            self.collectionView.setContentOffset(CGPoint.init(x: -self.collectionView.contentInset.left, y: 0), animated: false)
            self.collectionView.reloadData()
        }

        self.bottomLogoImageView.bottom = self.height - YKNGap.dim_9()
        self.bottomMoreLabel.centerY = self.bottomLogoImageView.centerY
        self.bottomArrowView.centerY = self.bottomLogoImageView.centerY
       
    
        //scene
        let scene = compModel.scene
        self.sceneBackgroundView.backgroundColor = sceneUtil(UIColor.createColorWithHexRGB(colorStr: "#040000"), sceneColor: scene?.sceneBgColor())
        
        self.bottomMoreLabel.textColor = scene?.sceneTitleColor()
        self.bottomArrowView.tintColor = scene?.sceneTitleColor() ?? UIColor.white
        for i in 0..<self.tabItemViews.count {
            let tabItemView = self.tabItemViews[i]
            let select = (i == self.selIndex)
            tabItemView.font = select ? YKNFont.top_tabbar_textbold() : YKNFont.top_tabbar_text()
            tabItemView.textColor = select ? scene?.sceneThemeColor() : scene?.sceneSubTitleColor()
        }
    }
    
    func layoutActionView() {
        //actionview

        let size = calcStringSize(self.actionView.text, font: self.actionView.titleLabel.font, size: CGSize.init(width: 200, height: 100))
        let actionW = size.width + 24
        self.actionView.frame = CGRect.init(x: self.width - 15 - actionW, y: 48, width: actionW, height: 30)
        self.actionView.refresh()
    }
    
    func addBgViewBorderAndShadow() {
        let bgView = self.sceneBackgroundView
        bgView.clipsToBounds = false
        bgView.layer.cornerRadius = YKNCorner.radius_large()

        bgView.layer.shadowColor = UIColor.wvColor(withHex: 0xEAEAEA).cgColor
        bgView.layer.shadowOffset = CGSize.init(width: 0, height: 4)
        bgView.layer.shadowRadius = YKNCorner.radius_large()
        bgView.layer.shadowPath = UIBezierPath.init(rect: bgView.bounds).cgPath

        self.clipsToBounds = false
        self.superview?.clipsToBounds = false
        
        refreshShadowStatus()
    }
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
    
    func showBackgroundShadow() -> Bool {
        if isDark() {
            return false
        }
        if let _ = self.component?.getPage()?.pageModel?.scene?.sceneBgColor() {
            return false
        }
        return true
    }

    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
        refreshShadowStatus()
    }
    
    func refreshShadowStatus() {
        let bgView = self.sceneBackgroundView
        bgView.layer.borderWidth = showBackgroundShadow() ? 0.5 : 0.0
        bgView.layer.shadowOpacity = showBackgroundShadow() ? 1.0 : 0.0
        bgView.layer.borderColor = UIColor.ykn_separator.cgColor
    }
    
    // MARK: collection delegate
    public func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        guard let items = getItems() else {
            return 0
        }
        return items.count
    }

    public func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let itemSize = CGSize.init(width: Comp14193Util.videoImageViewWidth(self.width), height: Comp14193Util.itemHeight(self.width))
        return itemSize
    }

    public func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
    }

    public func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let identifier = "custom.14193.itemview"
        collectionView.register(Component14193ItemView.self, forCellWithReuseIdentifier: identifier)
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath)
        if let items = getItems(), indexPath.row < items.count {
            if let itemview = cell as? Component14193ItemView {
                itemview.fillData(items[indexPath.row])
            }
        }
        return cell
    }
    
    // MARK: - UIScrollViewDelegate

    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        stopAnimation()
    }
    
    func scrollViewDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        startAnimation()
    }
    
    //MARK: current items
    private func getItems() -> [IItem]? {
        let curComponent = getCurrentComponent()
        guard let items = curComponent?.getItems() else {
            return nil
        }
        return items
    }
    
    private func getCurrentComponent() -> IComponent? {
        guard let components = self.component?.getCard()?.getComponents(), self.selIndex < components.count else {
            return nil
        }
        let curComponent = components[self.selIndex]
        return curComponent
    }
    
    public class func isShowAdIcon(_ component: IComponent?) -> Bool {
        guard let components = component?.getCard()?.getComponents()else {
            return false
        }
        for component in components {
            if let icon = component.compModel?.iconModel?.icon, !icon.isEmpty {
                return true
            }
        }
        return false
    }
    //MARK: animation
    private var timer: Timer?
    private weak var weakAction: WeakTimerAction?
    func startAnimation() {
        if self.itemsSize.count <= 1 {
            return
        }
        
        print("[jbp] startAnimation \(self.selIndex) \(self.itemsSize.count) \(self.tabItemViews.count)")
        if timer != nil {
            timer?.invalidate()
            timer = nil;
            
            weakAction?.delegate = nil
            weakAction = nil
        }
//        if self.selIndex >= self.itemsSize.count - 1 || self.selIndex >= self.tabItemViews.count - 1 {
//            return
//        }
        print("[jbp] schedule timer")
        let action = WeakTimerAction.init()
        weakAction = action
        weakAction?.delegate = self
        timer = Timer.scheduledTimer(timeInterval: TimeInterval(self.scrollInterval), target: action, selector: #selector(timerAction), userInfo: nil, repeats: true)
    }
    
    func stopAnimation() {
        print("[jbp] stopAnimation")
        timer?.invalidate()
        timer = nil
    }
    
    func didWeakTimerAction() {
        timerAction()
    }

    @objc func timerAction() {
        self.selIndex = self.selIndex + 1
        print("[jbp] time action \(self.selIndex) \(self.itemsSize.count)")
        if (self.selIndex >= self.itemsSize.count) {
            self.selIndex = 0;
        }
        if self.selIndex >= self.itemsSize.count || self.selIndex >= self.tabItemViews.count {
            stopAnimation()
            return
        }
        self.refresh(self.selIndex)
    }

}
