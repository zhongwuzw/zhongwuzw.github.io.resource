//
//  Comp14193Util.swift
//  YKChannelComponent
//
//  Created by better on 2022/2/24.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchBridge
import YoukuResource
import OneArchSupport4Youku

class Comp14193Util {
    static func videoImageViewWidth(_ containerWidth:CGFloat) -> CGFloat {
        var columnCount = 3.0
        if isiPad() {
            if containerWidth >= 1300 - 80 {
                columnCount = 6.0
            } else if containerWidth >= 1024 - 80 {
                columnCount = 5.0
            } else if containerWidth >= 694 - 80 {
                columnCount = 4.0
            }
        }
        return (containerWidth - YKNGap.dim_7()*(columnCount - 1) - 2 * YKNGap.youku_column_spacing()) / columnCount
    }
    
    static func videoImageViewHeight(_ containerWidth:CGFloat) -> CGFloat {
        return videoImageViewWidth(containerWidth) * 1.33
    }
    
    static func titleHeight() -> CGFloat {
        return YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
    }
    
    static func subtitleHeight() -> CGFloat {
        return YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)
    }
    
    static func textAreaHeight() -> CGFloat {
        return YKNGap.dim_4() + titleHeight() + YKNGap.dim_2() + subtitleHeight()
    }
    
    static func itemHeight(_ containerWidth: CGFloat) -> CGFloat {
        return videoImageViewHeight(containerWidth) + textAreaHeight()
    }
    
    static func tabMenuHeight() -> CGFloat {
        return YKNFont.height(with: YKNFont.top_tabbar_textbold(), lineNumber: 1)
    }
    
    static func topImageHeight(_ hasTopImage: Bool) -> CGFloat {
        return hasTopImage ? 104 : (104 - 22)
    }
    
    static func totalHeight(_ containerWidth:CGFloat, tabItemCount: Int, hasAdIcon: Bool, hasTopImage: Bool) -> CGFloat {
        let tabHeight = tabItemCount > 1 ? (Comp14193Util.tabMenuHeight() + YKNGap.dim_6()) : 0
        var bottomHeight = YKNGap.dim_10() + 24 * YKNSize.yk_icon_size_scale() + YKNGap.dim_9()
        if !hasAdIcon {
            bottomHeight = 15
        }
        return topImageHeight(hasTopImage)
            + tabHeight
            + Comp14193Util.videoImageViewHeight(containerWidth)
            + Comp14193Util.textAreaHeight()
            + bottomHeight
    }
    
    static func totalHeightForTileMode(_ containerWidth:CGFloat, tabItemCount: Int, hasAdIcon: Bool, hasTopImage: Bool) -> CGFloat {
        let tabHeight = tabItemCount > 1 ? (Comp14193Util.tabMenuHeight() + YKNGap.dim_6()) : 0
        let itemHeight = Comp14193Util.videoImageViewHeight(containerWidth) + Comp14193Util.textAreaHeight()
        var bottomHeight = YKNGap.dim_10() + 24 * YKNSize.yk_icon_size_scale() + YKNGap.dim_9()
        if !hasAdIcon {
            bottomHeight = 15
        }
        return topImageHeight(hasTopImage)
            + tabHeight
            + (itemHeight * 2 + YKNGap.dim_9())
            + bottomHeight
    }
    
    
}

