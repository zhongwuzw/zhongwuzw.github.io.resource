//
//  TileBackgroundView.swift
//  YKChannelComponent
//
//  Created by better on 2022/5/11.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch

class TileBackgroundView: UIView {

    lazy var itemViews:[Component14193ItemView] = {
        var items = [Component14193ItemView]()
        let itemWidth = Comp14193Util.videoImageViewWidth(self.width)
        let itemHeight = Comp14193Util.itemHeight(self.width)
        for i in 0..<6 {
            let x:CGFloat = 12 + (itemWidth + 6) * CGFloat(i%3)
            let y:CGFloat = i >= 3 ? (itemHeight + 18) : 0.0
            let view = Component14193ItemView.init(frame: CGRect.init(x: x, y: y, width: itemWidth, height: itemHeight))
            self.addSubview(view)
            items.append(view)
        }
        return items
    }()
    
    func fillData(_ items:[IItem]?) {
        guard let items = items else {
            return
        }
        for i in 0..<itemViews.count {
            let itemView = itemViews[i]
            itemView.isHidden = i >= items.count
            if i < items.count {
                itemView.fillData(items[i])
            }
        }
    }

}
