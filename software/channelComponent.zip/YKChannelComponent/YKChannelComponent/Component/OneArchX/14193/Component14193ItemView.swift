//
//  Component14193ItemView.swift
//  YKChannelComponent
//
//  Created by better on 2022/2/23.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchBridge
import YoukuResource
import OneArchSupport4Youku

class Component14193ItemView: UICollectionViewCell {
    
    //MARK: Property
    lazy var videoImageView: BaseVideoImageView = {
        return BaseVideoImageView(frame: .zero)
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(videoImageView)
        self.addSubview(titleLabel)
        self.addSubview(subtitleLabel)
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
    }
    
    func fillData(_ item:IItem?) {
        guard let itemModel = item?.model as? BaseItemModel else {
            return
        }
        // image
        self.videoImageView.size = CGSize.init(width: self.width, height: self.width * 1.33)
        self.videoImageView.fillData(item: item)

        //title
        self.titleLabel.frame = CGRect.init(x: 0, y: self.videoImageView.bottom + YKNGap.dim_4(), width: self.width, height: Comp14193Util.titleHeight())
        self.titleLabel.text = itemModel.title
        //subtitle
        self.subtitleLabel.text = itemModel.subtitle
        self.subtitleLabel.frame = CGRect.init(x: 0, y: self.titleLabel.bottom + YKNGap.dim_2(), width: self.width, height: Comp14193Util.subtitleHeight())
    
        //氛围
        let scene = itemModel.scene
        self.backgroundColor = .clear //sceneUtil(.clear, sceneColor: scene?.sceneBgColor())
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: scene?.sceneTitleColor())
        self.subtitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: scene?.sceneSubTitleColor())
        
        //绑定事件
        Service.action.bind(itemModel.action, self)
    }
}
