//
//  Component14193.swift
//  YKChannelComponent
//
//  Created by better on 2022/2/23.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku
import OneArch
import YoukuResource
import YKResponsiveLayout
import OneArchSupport4Youku

class Component14193EventHandler: ComponentEventHandler, IPageLifeCycleEventHandler, IComponentLifeCycleEventHandler {
    
    var compVisible = false
    weak var itemView: Component14193ContentView?
    
    func viewDidLoad() {
        
    }
    
    func willActivate() {
        
    }
    
    func didActivate() {
        startAnimation()
    }
    
    func willDeactivate() {
    }
    
    func didDeactivate() {
        stopAnimation()
    }
    
    func pageDealloc() {
        
    }
    
    func appDidBecomeActive() {
        startAnimation()
    }
    
    func appWillResignActive() {
        stopAnimation()
    }
    
    func enterDisplayArea(itemView: UIView?) {
        compVisible = true
        startAnimation()
    }
    
    func exitDisplayArea(itemView: UIView?) {
        compVisible = false
        stopAnimation()
    }
    
    func visibleViewDidScroll(itemView: UIView?) {
        
    }
    
    func visibleViewDidEndScroll(itemView: UIView?) {
        
    }
    
    func visibleViewsDidEndScroll() {
        
    }

    //MARK: private
    func startAnimation() {
        guard let pageContext = self.component?.pageContext else {
            return
        }
        if pageContext.isPageActive(), compVisible {
            self.itemView?.startAnimation()
        }
    }

    func stopAnimation() {
        self.itemView?.stopAnimation()
    }

}

class Component14193:NSObject, ComponentDelegate {
    var componentWrapper: ComponentWrapper?
    
    var tabItemsSizeCache = [CGFloat]()
    
    weak var eventHandler: Component14193EventHandler?
    
    func componentDidInit() {
    }
    
    deinit {
        self.eventHandler?.itemView?.stopAnimation()
        print("[jbp] Component14193 deinit")
    }

    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = 9.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        
        if let cardModel = self.component?.getCard()?.model as? BaseCardModel {
            if cardModel.noModuleTitle {
                // remark: ’-18‘魔法数 是基于默认上一个组件paddingBottom = 18,本抽屉preferredCardSpacingTop = 9.0作前提条件下，期望与上一个组件距离9px，综合计算而来。
                config.padding =  UIEdgeInsets.init(top: -18, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
            }
        }
        
        return config
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeComponentModel.self as? T.Type
    }
    
    func columnCount() -> CGFloat {
        return 1
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        let handler = Component14193EventHandler.init()
        self.eventHandler = handler
        return [handler]
    }

    /// item高度（custom布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        tabItemsSizeCache.removeAll()
        if let components = self.component?.getCard()?.getComponents() {
            for i in 0..<components.count {
                let comp = components[i]
                var width:CGFloat = 0.0
                if let model = comp.model as? BaseComponentModel {
                    let size = calcStringSize(model.title, font: YKNFont.top_tabbar_textbold(), size: .zero)
                    width = size.width
                }
                tabItemsSizeCache.append(width)
            }
        }
        if !isValidComponent() {
            return 0
        }
        let isShowAdIcon = Component14193ContentView.isShowAdIcon(self.component)

        if isTileMode() {
            return Comp14193Util.totalHeightForTileMode(itemWidth, tabItemCount: tabItemsSizeCache.count, hasAdIcon: isShowAdIcon, hasTopImage:hasTopSceneImage())
        } else {
            return Comp14193Util.totalHeight(itemWidth, tabItemCount: tabItemsSizeCache.count, hasAdIcon: isShowAdIcon, hasTopImage:hasTopSceneImage())
        }
    }
    
    private func hasTopSceneImage() -> Bool {
        guard let components = self.component?.getCard()?.getComponents(), components.count > 0 else {
            return false
        }
        guard let firstComp = components.first else {
            return false
        }
        
        if let topImg = firstComp.homeCompModel?.bgTopImg, topImg.count > 0 {
            return true
        }
    
        return false
    }
    
    func isTileMode() -> Bool {
        guard let config = self.component?.getCard()?.cardModel?.config else {
            return false
        }
        let value = config.getIntValue("isTileMode")
        var tileMode = (value == 1)
        if isiPad() {
            tileMode = false
        }
        return tileMode
    }

    /// 初始化item view（custom布局使用）
    func createView(_ itemSize: CGSize) -> UIView {
        if (!isValidComponent()) {
            let itemWidth = itemSize.width
            let itemHeight = itemSize.height
            let itemView = UIView.init(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
            itemView.backgroundColor = .red
            return itemView
        }
        let itemWidth = itemSize.width
        let itemHeight = itemSize.height
        let itemView = Component14193ContentView.init(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight), hasTopImage:hasTopSceneImage())
        return itemView
    }

    func reuseId() -> String? {
        var reuseId = "component.14193" + (isValidComponent() ? "valid" : "empty")
        if isTileMode() {
            reuseId += ".tileMode"
        }
        if hasTopSceneImage() {
            reuseId += ".topSceneImg"
        }
        return reuseId
    }

    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Component14193ContentView else {
            return
        }
        self.eventHandler?.itemView = itemView
        if let component = self.component {
            itemView.isTileMode = isTileMode()
            itemView.fillData(component: component, itemsSize:self.tabItemsSizeCache)
        }
    }
    
    private func isValidComponent() -> Bool {
        guard let component = self.component else {
            return false
        }
        return component.index == 0
    }
}
