//
//  Card15022.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/9/8.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YKNodePage

class Card15022ComponentJsonExtracter: DefaultComponentJsonExtracter {

    override public init() {
        super.init()
    }

    // MARK: - 原始数据加工

    override public func getComponentsJson(cardJson: [String : Any]?, card: ICard?) -> Result<[[String : Any]], Error> {
        guard let subComponents = cardJson?["nodes"] as? [[String: Any]] else {
            return .success([[String : Any]]()) //允许没有组件列表
        }
        
        guard var historyComponent = subComponents.first else {
            return .success([[String : Any]]())
        }
        
        guard let historyItems = historyComponent["nodes"]as? [[String: Any]],
              let templateNode = historyItems.first
        else {
            return .success([[String : Any]]())
        }
        
        // 修改组件类型
        historyComponent["type"] = "14168-History"
        historyComponent["nodes"] = self.makeHistoryWordItemNodes(templateNode: templateNode)
        
        return .success([historyComponent])
    }
    
    private func makeHistoryWordItemNodes(templateNode: [String: Any]) -> [[String: Any]] {
        var itemNodes = [[String: Any]]()
        
        let historyWordDictionaries = YKNPRCSSearchHistoryUtil.sharedInstance().allHistoryWordDictionaries()
        for (i, aWord) in historyWordDictionaries.enumerated() {
            guard let title = aWord["title"] as? String, let actionURLString = aWord["actionURLString"] as? String else {
                break
            }
            
            var aItem = templateNode
            if var data = aItem["data"] as? [String: Any] {
                data["title"] = title
                
                if var action = data["action"] as? [String: Any] {
                    action["value"] = actionURLString
                    
                    if var report = action["report"] as? [String: Any] {
                        report["spmC"] = "History"
                        report["spmD"] = "\(title)_\(i+1)"
                        
                        if let oriScmAB = report["scmAB"] as? String {
                            var newScmAB = oriScmAB
                            if oriScmAB.count > 0 {
                                if let oriScmA = oriScmAB.components(separatedBy: ".").first, oriScmA.count > 0 {
                                    newScmAB = "\(oriScmA).function"
                                }
                            }
                            report["scmAB"] = newScmAB
                        }
                        report["scmD"] = "keyword_\(title)"
                        
                        action["report"] = report
                    }
                    
                    data["action"] = action
                }
                
                aItem["contentId"] = "client_history_word_index_\(title)"
                
                aItem["data"] = data
            }
            
            itemNodes.append(aItem)
        }
        
        return itemNodes
    }
}

class Card15022Model: BaseCardModel {
        
    public override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        if let cmsInfo = cmsInfo {
            self.extraExtend["rawJSON"] = cmsInfo
        }
    }
    
}

class Card15022: BaseCardDelegate {
    
    override func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Card15022Model.self as? T.Type
    }

    override func getComponentJsonExtracter() -> ComponentJsonExtracter? {
        return Card15022ComponentJsonExtracter.init()
    }
    
    override func isShowHeader() -> Bool {
        guard let cardModel = self.card?.model as? BaseCardModel else {
            return false
        }
        
        if cardModel.noModuleTitle {
            return false
        }
        
        if cardModel.title != nil || cardModel.titleImg != nil {
            let allHistoryWords = YKNPRCSSearchHistoryUtil.sharedInstance().allHistoryWordDictionaries()
            
            if !allHistoryWords.isEmpty {
                return true
            } else {
                return false
            }
        }
        
        return false
    }
    
}
