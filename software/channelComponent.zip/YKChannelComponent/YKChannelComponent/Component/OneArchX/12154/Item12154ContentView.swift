//
//  Item12154ContentView.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/7/10.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item12154ContentView : Item12153ContentView {
    
    lazy var lineView: UIView = {
        let view = UILabel.init(frame: .zero)
        view.textAlignment = .center
        view.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#999999").withAlphaComponent(0.3)
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var descLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.textColor = .ykn_tertiaryInfo
        view.numberOfLines = 1
        view.textAlignment = .left
        view.lineBreakMode = .byTruncatingTail
        view.font = YKNFont.tertiary_auxiliary_text()
        return view
    }()
    
    lazy var newGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init(x: 0.5, y: 0)
        layer.endPoint = CGPoint.init(x: 0.5, y: 1.0)
        let clr1 = UIColor.createColorWithHexRGB(colorStr: "#FFE385").withAlphaComponent(0.2).cgColor
        let clr2 = UIColor.createColorWithHexRGB(colorStr: "#FFE385").withAlphaComponent(0).cgColor
        layer.colors = [clr1, clr2]
        self.layer.insertSublayer(layer, at: 0)
        return layer
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.topGradientLayer.removeFromSuperlayer()
        self.titleLeftLabel.isHidden = true
        self.titleRightLabel.isHidden = true
        self.titleLabel.numberOfLines = 2
        self.addSubview(descLabel)
        self.addSubview(lineView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func setUpLayout(_ comp: IComponent?) {
        super.setUpLayout(comp)
        titleLabel.textColor = .ykn_primaryInfo
        subtitleLabel.textColor = .ykn_tertiaryInfo
        titleLabel.textAlignment = .left
        subtitleLabel.textAlignment = .left
        
        guard let comp = comp, let compModel = comp.model as? Component12142Model else {
            return
        }
        
        titleLabel.frame = compModel.layout.title?.renderRect ?? .zero
        //titleLabel.sizeToFit()
        newGradientLayer.frame = CGRect(x: 0, y: 0, width: width, height: width * 100 / 170)
        if let layout = compModel.layout.extendExtra {
            if let lineLayout = layout["line"] as? TextLayoutModel {
                lineView.frame = lineLayout.renderRect
            }
            if let descLayout = layout["desc"] as? TextLayoutModel {
                descLabel.frame = descLayout.renderRect
            }
        }
        
    }
 
    override func fillData(_ comp: IComponent?) {
        super.fillData(comp)
        
        guard let comp = comp, let compModel = comp.model as? Component12142Model else {
            return
        }
        
        if let title = compModel.title, !title.isEmpty {
            titleLabel.text = title
        }
        
        if let moreText = compModel.moreText, !moreText.isEmpty {
            bottomLabel.text = moreText
        } else {
            bottomLabel.text = "查看更多"
        }

        if let desc = compModel.desc, !desc.isEmpty {
            descLabel.text = desc
            lineView.isHidden = false
        } else {
            //没有后面的文案不显示分割线
            lineView.isHidden = true
        }
        
        let compIndex = comp.index
        self.addNewGradientLayer(compIndex)
    }
    
    func addNewGradientLayer(_ showTimes: Int) {
        let showTimes = showTimes % 4
        
        switch showTimes {
        case 1:
            let clr1 = UIColor.createColorWithHexRGB(colorStr: "#FF8D8D").withAlphaComponent(0.2).cgColor
            let clr2 = UIColor.createColorWithHexRGB(colorStr: "#FF8D8D").withAlphaComponent(0).cgColor
            newGradientLayer.colors = [clr1, clr2]
        case 2:
            let clr1 = UIColor.createColorWithHexRGB(colorStr: "#8AC2FF").withAlphaComponent(0.2).cgColor
            let clr2 = UIColor.createColorWithHexRGB(colorStr: "#8AC2FF").withAlphaComponent(0).cgColor
            newGradientLayer.colors = [clr1, clr2]
        case 3:
            let clr1 = UIColor.createColorWithHexRGB(colorStr: "#D4FF8A").withAlphaComponent(0.2).cgColor
            let clr2 = UIColor.createColorWithHexRGB(colorStr: "#D4FF8A").withAlphaComponent(0).cgColor
            newGradientLayer.colors = [clr1, clr2]
        default:
            let clr1 = UIColor.createColorWithHexRGB(colorStr: "#FFE385").withAlphaComponent(0.2).cgColor
            let clr2 = UIColor.createColorWithHexRGB(colorStr: "#FFE385").withAlphaComponent(0).cgColor
            newGradientLayer.colors = [clr1, clr2]
        }
    }
    
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        weak var weakSelf = self
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            guard let weakSelf = weakSelf else {return}
            weakSelf.updateLabelColor()
        }
    }
    
    override func updateLabelColor() {
        if isDark() {
            self.backgroundColor = .ykn_cg_11
            self.bottomLabel.backgroundColor = .ykn_co_2
        } else {
            self.backgroundColor = .ykn_primaryBackground
            self.bottomLabel.backgroundColor = .ykn_secondaryBackground
        }
    }
}

class Item12164ContentView: Item12154ContentView {
    override func updateLabelColor() {
        self.backgroundColor = .ykn_tertiaryFill
        self.bottomLabel.backgroundColor = .ykn_elevatedButtonFill
        self.bottomLabel.layer.cornerRadius = 7.0
        self.bottomLabel.font = YKNFont.button_text_weight(.medium)
    }
}
 
