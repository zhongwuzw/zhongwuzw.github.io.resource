//
//  Component12154.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/7/9.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout

class Component12154: NSObject, ComponentDelegate {
    
    func componentDidInit() {
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Component12142Model.self as? T.Type
    }

    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.dim_6()
        let margin = YKNGap.youku_margin_left()
        let bottom = YKNGap.youku_column_spacing()
        
        if ykrl_isResponsiveLayout() {
            config.padding = UIEdgeInsets.init(top: 0, left: margin, bottom: bottom, right: margin)
        } else {
            config.padding = UIEdgeInsets.init(top: 0, left: margin, bottom: bottom, right: margin)
        }
        return config
    }
    
    func columnCount() -> CGFloat {
        return 2
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
    
    var componentWrapper: ComponentWrapper?
    
    func createView(_ itemSize: CGSize) -> UIView {
        return Item12154ContentView.init()
    }

    func reuseView(itemView: UIView) {
        guard let contentView = itemView as? Item12154ContentView else {
            return
        }
        let forceTheme = self.component?.getCard()?.cardModel?.dataCenterMap["forceTheme"] as? String ?? ""
        contentView.forceTheme = forceTheme
        contentView.fillData(self.component)
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.estimatedLayout(itemWidth)
        
        guard let componentModel = self.component?.compModel else {
            return 0
        }

        if let layout = componentModel.layout.extendExtra {
            if let moreTextLayout = layout["moreText"] as? TextLayoutModel {
                return moreTextLayout.renderRect.maxY + YKNGap.dim_7()
            }
        }
        return 0
    }
    
    func estimatedLayout(_ itemWidth: Double) {
        guard let componentModel = self.component?.compModel else {
            return
        }
        guard let items = component?.getItems(), items.count > 0 else {
            return
        }
        
        let compLayout = componentModel.layout
        compLayout.extendExtra = [String: Any]()
        
        var titleMaxY: CGFloat = 0
        var subtitleMaxY: CGFloat = 0
        var itemsMaxY: CGFloat = 0
        var subtitleMaxX: CGFloat = 0
        var lineMaxX: CGFloat = 0
        
        //片单标题文案
        if let titleText = componentModel.title, !titleText.isEmpty {
            let titleLayout = TextLayoutModel()
            titleLayout.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.discuss_content_text().pointSize)
            let titleWidth: CGFloat = CGFloat(itemWidth) - YKNGap.dim_6() * 2
            let fitSize = CGSize.init(width: titleWidth, height: CGFloat.greatestFiniteMagnitude)
            let titleHeight: CGFloat = calcStringHeight(titleText, font: YKNFont.discuss_content_text_weight(.medium), limitSize: fitSize)
            titleLayout.renderRect = CGRect.init(x: YKNGap.dim_6(), y: YKNGap.dim_7(), width: titleWidth, height: ceil(titleHeight))
            titleMaxY = titleLayout.renderRect.maxY
            compLayout.title = titleLayout
        }
        
        // 片单副标题文案
        if let subtitleText = componentModel.subtitle, !subtitleText.isEmpty {
            let subtitleLayout = TextLayoutModel()
            subtitleLayout.font = YKNFont.tertiary_auxiliary_text()
            if let compModel = self.component?.compModel as? Component12142Model, let subtitle = compModel.subtitle {
                let subtitleSize = calcStringSize(subtitle, font: YKNFont.tertiary_auxiliary_text(), size: .zero)
                subtitleLayout.renderRect = CGRect.init(x: YKNGap.dim_6(), y: titleMaxY + 4.0, width: subtitleSize.width, height: subtitleSize.height)
                subtitleMaxY = subtitleLayout.renderRect.maxY
                subtitleMaxX = subtitleLayout.renderRect.maxX
                compLayout.subtitle = subtitleLayout
            }
        }
        
        // 分割线
        if let descText = componentModel.desc, !descText.isEmpty {
            let lineLayout = TextLayoutModel()
            lineLayout.renderRect = CGRect.init(x: subtitleMaxX + YKNGap.dim_5(), y: titleMaxY + 8.0, width: 1.0, height: 7.0)
            lineMaxX = lineLayout.renderRect.maxX
            compLayout.extendExtra?["line"] = lineLayout
        }
        
        // 片单副标题描述文案
        if let descText = componentModel.desc, !descText.isEmpty {
            let descLayout = TextLayoutModel()
            descLayout.font = YKNFont.tertiary_auxiliary_text()
            let subtitleWidth: CGFloat = CGFloat(itemWidth) - YKNGap.dim_6() - lineMaxX
            let subtitleHeight: CGFloat = YKNFont.height(with: descLayout.font, lineNumber: 1)
            descLayout.renderRect = CGRect.init(x: lineMaxX + YKNGap.dim_5(), y: titleMaxY + 4.0, width: subtitleWidth, height: subtitleHeight)
            compLayout.extendExtra?["desc"] = descLayout
        }
        
        // 坑位
        let itemsLayout = LayoutModel()
        let itemsWidth: CGFloat = CGFloat(itemWidth) - YKNGap.dim_6() * 2
        let itemsHeight: CGFloat = (51.0 * YKNSize.yk_icon_size_scale() + YKNGap.dim_6()) * CGFloat(items.count)
        itemsLayout.renderRect = CGRect.init(x: YKNGap.dim_6(), y: subtitleMaxY + YKNGap.dim_7(), width: itemsWidth, height: itemsHeight)
        itemsMaxY = itemsLayout.renderRect.maxY
        compLayout.extendExtra?["items"] = itemsLayout
        
        // 灰色点击按钮
        let moreLayout = TextLayoutModel()
        let moreWidth: CGFloat = CGFloat(itemWidth) - YKNGap.dim_6() * 2
        let moreHeight: CGFloat = 31.0
        moreLayout.renderRect = CGRect.init(x: YKNGap.dim_6(), y: itemsMaxY, width: moreWidth, height: moreHeight)
        compLayout.extendExtra?["moreText"] = moreLayout
    }

}


class Component12164: Component12154 {
    
    override func createView(_ itemSize: CGSize) -> UIView {
        return Item12164ContentView.init()
    }
    
    override func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.dim_6()
        let margin = YKNGap.youku_margin_left()
        let bottom = YKNGap.youku_line_spacing()
        
        if ykrl_isResponsiveLayout() {
            config.padding = UIEdgeInsets.init(top: 0, left: margin, bottom: bottom, right: margin)
        } else {
            config.padding = UIEdgeInsets.init(top: 0, left: margin, bottom: bottom, right: margin)
        }
        return config
    }
    
}
