//
//  Item12154Model.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/7/9.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item12154Model: BaseItemModel {
    
    //用推荐理由的结构 下发在reason字段里
    var newReason: LabelModel?
    
    override func setup(_ cmsInfo: [String: Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        guard let dataInfo = cmsInfo?["data"] as? [String: Any] else {
            return
        }
        if let reason = dataInfo["reason"] as? [String: Any] {
            var reasons: [[String: Any]] = []
            reasons.append(reason)
            let reasonList = LabelModel.newModels(reasons)
            self.newReason = reasonList?.first
        }
    }
}
