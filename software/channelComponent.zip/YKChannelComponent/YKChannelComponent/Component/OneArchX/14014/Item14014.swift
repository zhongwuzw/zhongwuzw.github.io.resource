//
//  Item14014.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/24.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKProtocolSDK
import OneArchSupport4Youku

class Item14014: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    weak var eventHandler: Item14014PlayerHandler?
    
    var displayingItemView: Item14014ContentView?
    
    func itemDidInit() {
        
    }
    
    func getModelClass<T: NodeModel>() -> T.Type? {
        return Item14014Model.self as? T.Type
    }
    
    func itemWidth() -> CGFloat {
        let value = Component14014Util.itemWidth()
        return value
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let value = Component14014Util.itemHeight()
        return value
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14014ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14014ContentView else {
            return
        }
        
        guard let itemModel = self.item?.itemModel as? Item14014Model else {
            return
        }
        
        self.eventHandler?.contentView = itemView
        self.displayingItemView = itemView
        
        itemView.item = self.item
        itemView.fillData(itemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        let handler = Item14014PlayerHandler()
        self.eventHandler = handler
        return [handler]
    }
    
}


class Item14014PlayerHandler: ItemEventHandler, IPageLifeCycleEventHandler, IItemLifeCycleEventHandler {
    
    weak var contentView: Item14014ContentView?
        
    /// 页面视图初始化
    func viewDidLoad() {
        
    }

    /// 页面将激活
    func willActivate() {
        
    }

    /// 页面已激活
    func didActivate() {
        if isCurrentBgInReuse() {
            self.contentView?.didActivate()
        }
    }

    /// 页面将失活
    func willDeactivate() {

    }

    /// 页面已失活
    func didDeactivate() {
        if isCurrentBgInReuse() {
            self.contentView?.didDeactivate()
        }
    }

    /// 页面销毁
    func pageDealloc() {
        
    }
    
    /// 应用进入激活状态
    func appDidBecomeActive() {
        if isCurrentBgInReuse() {
            self.contentView?.didActivate()
        }
    }
    
    /// 应用即将进入失活状态
    func appWillResignActive() {
        if isCurrentBgInReuse() {
            self.contentView?.didDeactivate()
        }
    }
    
    // MARK: IItemLifeCycleEventHandler
    func enterDisplayArea(itemView: UIView?) {
        
    }
    
    func exitDisplayArea(itemView: UIView?) {
        if isCurrentBgInReuse() {
            self.contentView?.exitDisplay()
        }
    }
    
    func visibleViewDidScroll(itemView: UIView?) {
        if isCurrentBgInReuse() {
            self.contentView?.judgeStartOrStopPlayerForScroll(false)
        }
    }
    
    func visibleViewDidEndScroll(itemView: UIView?) {
        if isCurrentBgInReuse() {
            self.contentView?.judgeStartOrStopPlayerForScroll(true)
        }
    }
    
    /// 自动聚焦到ItemView。在设置了autoFocusMode的横滑组件中有用。
    func autoFocusItemView(_ itemView: UIView?) {
        if isCurrentBgInReuse() {
            self.contentView?.enterDisplay()
        }
    }
    
    /// 取消聚焦ItemView。在设置了autoFocusMode的横滑组件中有用。
    func cancelFocusItemView(_ itemView: UIView?) {
        if isCurrentBgInReuse() {
            self.contentView?.exitDisplay()
        }
    }

    func isCurrentBgInReuse() -> Bool {
        guard let viewItem = self.contentView?.item else {
            return false
        }
        guard let item = self.item else {
            return false
        }
        let ptr1 = Unmanaged<AnyObject>.passUnretained(viewItem).toOpaque()
        let ptr2 = Unmanaged<AnyObject>.passUnretained(item).toOpaque()
        if ptr1 == ptr2 {
            return true
        }
        return false
    }
}
