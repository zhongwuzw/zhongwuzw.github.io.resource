//
//  Item14014ContentView.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/24.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import YKResponsiveLayout
import YKUIComponent
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKChannel

class Item14014ContentView: AccessibilityView, ChannelSliderPlayerDelegate {
    
    weak var item: IItem?
    
    var _visable = false

    //MARK: - Property
    lazy var imageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    lazy var imageAverageColorLayer: CALayer = {
        let layer = CALayer()
        return layer
    }()
    
    lazy var contentView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var titleLabel: MarginLabel = {
        let label = MarginLabel()
        let font: UIFont = YKNFont.mediumfont_size_big2()
        
        label.font = font
        label.textAlignment = .left
        label.textColor = YKNColor.cw_1()
        label.numberOfLines = 2
        label.lineBreakMode = .byTruncatingTail
        label.isUserInteractionEnabled = true
        label.verticalAlignment = .top
        return label
    }()
    
    lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.font = YKNFont.posteritem_subhead()
        label.textAlignment = .left
        label.textColor = .white.withAlphaComponent(0.8)
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var descLabel: UILabel = {
        let label = UILabel()
        label.font = YKNFont.font_size_small1()
        label.textAlignment = .center
        label.textColor = YKNColor.cw_1()
        label.numberOfLines = 1
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var descBackgroundView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.black.withAlphaComponent(0.3)
        return view
    }()
    
    lazy var reasonLabel: UILabel = {
        let label = UILabel()
        label.font = YKNFont.posteritem_subhead_weight(.medium)
        label.textAlignment = .center
        label.textColor = YKNColor.cw_1()
        label.backgroundColor = YKNColor.cy_1()
        return label
    }()
    
    lazy var playerContainer: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var player: ChannelSliderPlayer? = {
        let vc = self.item?.pageContext?.getViewController()
        let player = ChannelSliderPlayer.init(controller: vc)
        player?.delegate = self
        player?.isSlientMode = true
        player?.videoScreenMode = 1
        player?.isHideWaterMark = true
        let pWidth = self.playerContainer.bounds.width
        let pHeight = self.playerContainer.bounds.height
        player?.setupFrame(CGRect.init(x: 0, y: 0, width: pWidth, height: pHeight))
        //添加起播互斥插件
        player?.registerPlugin(withPluginID: "startPlayMutex", params: mutextParams())
        return player
    }()
     
   func mutextParams() -> [String:Any] {
       return ["name":"YKCStartPlayMutexPlugin",
               "initlevel":10,
               "enabled":true,
               "classname":"YKCStartPlayMutexPlugin",
               "layers":["layerid":"ad", "level":1000]
       ]
   }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(contentView)
        contentView.frame = self.bounds
        
        contentView.clipsToBounds = true
        contentView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        
        contentView.addSubview(imageView)
        contentView.layer.addSublayer(self.imageAverageColorLayer)
        
        contentView.addSubview(playerContainer)
        
        contentView.addSubview(titleLabel)
        contentView.addSubview(subtitleLabel)
        contentView.addSubview(reasonLabel)
        
        contentView.addSubview(descBackgroundView)
        contentView.addSubview(descLabel)
        
        let padding: CGFloat = YKNGap.dim_7()
        
        imageView.frame = CGRect.init(x: 0, y: 0, width: Component14014Util.itemWidth(), height: Component14014Util.imageHeight())
        playerContainer.frame = imageView.frame
        
        let imageAverageColorHeight: CGFloat = Component14014Util.descAreaHeight()
        self.imageAverageColorLayer.frame = CGRect.init(x: 0,
                                                        y: self.height - imageAverageColorHeight,
                                                        width: self.width,
                                                        height: imageAverageColorHeight)
        
        titleLabel.frame = CGRect.init(x: padding, y: 0, width: self.width - padding * 2, height: 48)
        subtitleLabel.frame = CGRect.init(x: padding, y: 0, width: self.width - padding * 2, height: 17)
        reasonLabel.frame = CGRect.init(x: padding, y: 0, width: 100, height: 16)
        
        subtitleLabel.bottom = self.height - padding
        titleLabel.top = subtitleLabel.top - YKNGap.dim_4() - 24
        reasonLabel.centerY = imageAverageColorLayer.frame.origin.y
        
        let descPadding: CGFloat = YKNGap.dim_5()
        let descBackgroundViewHeight: CGFloat = 26
        let descBackgroundViewCornerRadius = descBackgroundViewHeight / 2
        descBackgroundView.frame = CGRect.init(x: -descBackgroundViewCornerRadius,
                                               y: descPadding,
                                               width: 100,
                                               height: descBackgroundViewHeight)
        descBackgroundView.layer.cornerRadius = descBackgroundViewCornerRadius
        descBackgroundView.isHidden = true
        descLabel.frame = CGRect.init(x: descPadding, y: descPadding, width: 100, height: descBackgroundViewHeight)
    }
    
    func fillData(_ itemModel: Item14014Model) {
        
        // fill image
        var params = [String : Any]()
        params["fade"] = true
        let imageURL = itemModel.gifImg ?? itemModel.img
        imageView.ykn_setImage(withURLString: imageURL, module: "nodepage", imageSize: .zero, parameters: params, completed: nil)
        
        // fill texts
        
        descLabel.text = itemModel.desc
        
        if let color = itemModel.shadowColor {
            imageAverageColorLayer.isHidden = false
            imageAverageColorLayer.backgroundColor = color.cgColor
        }
            
        titleLabel.attributedText = itemModel.titleAttributedString
        subtitleLabel.attributedText = itemModel.subtitleAttributedString
        
        //标题2行，子标题需要隐藏不予显示
        let titleDisplayLines: CGFloat = titleLabel.sizeThatFits(titleLabel.size).height / 30
        if titleDisplayLines > 1 {
            subtitleLabel.isHidden = true
        } else {
            subtitleLabel.isHidden = false
        }
        
        if let reason = itemModel.reason, let title = reason.title, !title.isEmpty {
            reasonLabel.text = title
            reasonLabel.isHidden = false
            reasonLabel.sizeToFit()
            reasonLabel.height = 16
            reasonLabel.width += (7*2)
            
            var textColor = YKNColor.cw_1()
            if let str = reason.titleColorStr, !str.isEmpty {
                textColor = reason.titleColor
            }
            
            var bgColor = YKNColor.cy_1()
            if let str = reason.backgroundColorStr, !str.isEmpty {
                bgColor = reason.backgroundColor
            }
            
            reasonLabel.textColor = textColor
            reasonLabel.backgroundColor = bgColor
        } else {
            reasonLabel.isHidden = true
        }
        
        if let desc = itemModel.desc, !desc.isEmpty {
            descLabel.isHidden = false
            descLabel.text = desc
            descBackgroundView.isHidden = false
            
            descLabel.sizeToFit()
            descLabel.height = descBackgroundView.height
            descBackgroundView.width = descLabel.width + 18 + 10; //文字宽度 + 左侧相对距离 + 右侧相对距离
        } else {
            descLabel.isHidden = true
            descBackgroundView.isHidden = true
        }
        
        // 绑定跳转
        Service.action.bind(itemModel.action, self.contentView)
    }
    
    func startPlayer() {
        guard isPageInActive(), let previewId = getPreviewId(), let vc = self.item?.pageContext?.getViewController() else {
            return
        }
        
        if ykrl_isResponsiveLayout() {
            return //响应式不播放
        }
        
        var params = [String : Any]()
        params["play_style"] = "1"
        params["playtrigger"] = "1"
        params["disableVV"] = true
        
        self.player?.playVideo(withVid: previewId, params: params, controller: vc)
    }
    
    func stopPlayer() {
        player?.stopVideo()
        player?.embedPlayerView().removeFromSuperview()
    }
    
    // MARK: ChannelSliderPlayerDelegate
    
    /// 开始播放
    func didStartPlayVideo(in player: ChannelSliderPlayer) {
        let previewVid = getPreviewId()
        if (!isStringEmpty(player.playingSid) || !isStringEmpty(player.playingVid)),
           let playingVid = player.playingVid, let previewVid = previewVid,
           previewVid != playingVid {
            stopPlayer()
            return
        }
        
        if _visable, isPageInActive() {
            player.embedPlayerView().isHidden = false
            
            self.player?.isSlientMode = true
            
            if let embedPlayerView = player.embedPlayerView(), embedPlayerView.superview != self {
                self.playerContainer.addSubview(embedPlayerView)
            }
        } else {
            stopPlayer()
        }
    }

    /// 播放错误
    func player(_ player: ChannelSliderPlayer, playError errorCode: Int32) {
        stopPlayer()
    }
    
    /// 播放完成
    func didFinishPositiveVideo(in player: ChannelSliderPlayer) {
        stopPlayer()
    }
    
    func getPreviewId() -> String? {
        return self.item?.itemModel?.previewModel?.vid
    }
        
    func isPageInActive() -> Bool {
        return self.item?.pageContext?.isPageActive() ?? false
    }
    
    func didActivate() {
        if _visable {
            startPlayer()
        }
    }

    func didDeactivate() {
        stopPlayer()
    }

    func enterDisplay() {
        _visable = true
        
        startPlayer()
    }

    func exitDisplay() {
        _visable = false
        
        stopPlayer()
    }
    
    func judgeStartOrStopPlayerForScroll(_ canStart: Bool) {
        if UtilityHelper.isPlayerInValidArea(playerView: playerContainer) {
            if canStart {
                enterDisplay()
            }
        } else {
            exitDisplay()
        }
    }
}

