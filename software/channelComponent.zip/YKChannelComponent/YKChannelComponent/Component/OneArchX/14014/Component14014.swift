//
//  Component14014.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/24.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Component14014Util {
    
    static func itemWidth() -> CGFloat {
        return ceil(268.0 * YKNSize.yk_icon_size_scale())
    }
    
    static func itemHeight() -> CGFloat {
        let screenWidth: CGFloat = UIScreen.main.portraitBounds().width
        if (screenWidth == 320) {
            return 217;
        } else if (screenWidth == 414) {
            return 264;
        } else {
            return ceil(244 * YKNSize.yk_icon_size_scale())
        }
    }
    
    static func imageHeight() -> CGFloat {
        return self.itemHeight() - self.descAreaHeight()
    }
    
    static func descAreaHeight() -> CGFloat {
        return 68.0
    }
    
    static func backgroundImageSize(_ componentModel: BaseComponentModel) -> CGSize {
        let screenWidth: CGFloat = UIScreen.main.portraitBounds().width
        var itemHeight: CGFloat = self.itemHeight()
        
        var bottom: CGFloat = YKNGap.dim_6()
        if ykrl_isResponsiveLayout() {
            bottom = 12 // 20221129版本 目标值上下距离12，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        
        if (self.isDisplayInChannel(componentModel)) {
            itemHeight += bottom //底部距离
        } else {
            itemHeight += 20 //导航距离
            itemHeight += 64 //导航高度
            let statusBarOffset = YKStatusBarHeight() - 20
            itemHeight += statusBarOffset //刘海屏适配
            itemHeight += bottom //底部距离
        }
        
        return CGSize.init(width: screenWidth, height: itemHeight)
    }
    
    static func isDisplayInChannel(_ componentModel: BaseComponentModel) -> Bool {
        if let isDisplayInChannel = componentModel.extraExtend["displayInChannel"] as? Bool {
            return isDisplayInChannel
        } else {
            return false
        }
    }
}

class Component14014: NSObject, ComponentDelegate {

    var componentWrapper: ComponentWrapper?
    
    var currentFocusIndex: Int  = 0
    
    func componentWillInit() {
        guard let componentModel = component?.compModel as? BaseComponentModel else {
            return
        }
        
        if let card = component?.getCard(), let cardModel = card.cardModel {
            if let isDisplayInChannel = cardModel.extraExtend["displayInChannel"] as? Bool {
                componentModel.extraExtend["displayInChannel"] = isDisplayInChannel
            }
        }
    }
    
    func componentDidInit() {
        
    }
    
    func layoutType() -> ComponentLayoutType {
        return .horizontalScroll
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        
        var bottom: CGFloat = YKNGap.dim_6()
        if ykrl_isResponsiveLayout() {
            bottom = 12 // 20221129版本 目标值上下距离12，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        
        let top: CGFloat = Item14014Background.height(self.component) - Component14014Util.itemHeight() - bottom
        
        config.padding = UIEdgeInsets.init(top: top, left: 0, bottom: bottom, right: 0)
        config.preferredCardSpacingTop = 0
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_comp_margin_bottom()
        config.horizontalPaddingLeft = YKNGap.youku_margin_left()
        config.horizontalPaddingRight = YKNGap.youku_margin_right()
        config.footerBottomMargin = YKNGap.youku_comp_margin_bottom()
        config.backgroundLeftMarginOffset = -YKNGap.youku_margin_left()
        config.backgroundRightMarginOffset =  -YKNGap.youku_margin_right()
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [Comp14014EventHandler()]
    }
    
    func isShowBackground() -> Bool {
        return true
    }
    
    /// 是否开启自动聚焦能力 (横滑布局使用)
    func autoFocusMode() -> AutoFocusMode {
        if ykrl_isResponsiveLayout() {
            return .none
        }
        
        return .left
    }
    
    /// 自动聚焦item变更 (横滑布局使用)
    func autoFocusItemChanged(_ index:Int) {
        currentFocusIndex = index
        self.component?.compModel?.extraExtend["currentIndex"] = index
    }
}

class Comp14014EventHandler: ComponentEventHandler, IComponentLifeCycleEventHandler {
    
    func enterDisplayArea(itemView: UIView?) {
        
    }
    
    func exitDisplayArea(itemView: UIView?) {
        
    }
    
    func visibleViewDidScroll(itemView: UIView?) {
        guard let compDelegate = self.component?.getComponentDelegate() as? Component14014 , let items = self.component?.getItems() , items.count > compDelegate.currentFocusIndex else {
            return
        }
        
        guard let itemDelegate = items[compDelegate.currentFocusIndex].getItemDelegate() as? Item14014 else {
            return
        }
        
        itemDelegate.eventHandler?.visibleViewDidScroll(itemView: itemView)
    }
    
    func visibleViewDidEndScroll(itemView: UIView?) {
        
    }
    
    func visibleViewsDidEndScroll() {
        guard let compDelegate = self.component?.getComponentDelegate() as? Component14014,
                let items = self.component?.getItems() , items.count > compDelegate.currentFocusIndex else {
            return
        }
        
        guard let itemDelegate = items[compDelegate.currentFocusIndex].getItemDelegate() as? Item14014 else {
            return
        }
        
        itemDelegate.eventHandler?.visibleViewDidEndScroll(itemView: itemDelegate.eventHandler?.contentView)
    }
}
