//
//  Item14014BackgroundView.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/29.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YKUIComponent

class Item14014GradientView: UIView {

    override class var layerClass: AnyClass {
        return CAGradientLayer.self
    }

    override var layer: CAGradientLayer {
        return super.layer as! CAGradientLayer
    }
    
}

class Item14014BackgroundView: AccessibilityView, ItemImmersionBackgroundViewContainer {
    
    var _visable = false
    
    //MARK: - Property
    lazy var imageView: UIView = {
        let imageView = Item14014GradientView()
        imageView.contentMode = .scaleAspectFill
        imageView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        imageView.layer.startPoint = CGPoint.init(x: 0, y: 0)
        imageView.layer.endPoint = CGPoint.init(x: 0, y: 1)

        let topColor = UIColor.init(white: 0, alpha: 0.6).cgColor
        let bottomColor = UIColor.init(white: 0, alpha: 0).cgColor
        imageView.layer.colors = [topColor, bottomColor]

        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(imageView)
        imageView.frame = self.bounds
    }
    
    // MARK: ItemImmersionBackgroundViewContainer
    func immersionBackgroundView() -> UIView {
        return imageView
    }

}
