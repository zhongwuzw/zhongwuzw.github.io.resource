//
//  Item14014Model.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/24.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku

class Item14014Model: BaseItemModel {
    
    var shadowColor: UIColor?
    var titleAttributedString: NSAttributedString?
    var subtitleAttributedString: NSAttributedString?
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        self.shadowColor = UIColor.createColorWithHexRGB(colorStr: "#1C2029")
        if let shadowColorString = extraExtend["shadowColor"] as? String, shadowColorString.count > 0 {
            self.shadowColor = UIColor.createColorWithHexRGB(colorStr: shadowColorString)
        }
        
        if let title = title, title.isEmpty == false {
            let color = UIColor.white
            
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.minimumLineHeight = 24.0
            paragraphStyle.maximumLineHeight = 24.0
            paragraphStyle.lineBreakMode = .byTruncatingTail
            
            self.titleAttributedString = NSAttributedString.init(string: title, attributes: [.paragraphStyle: paragraphStyle,
                                                                                             .foregroundColor: color,
                                                                                            ])
        }
        
        if let subtitle = subtitle, subtitle.isEmpty == false {
            let color = UIColor.white.withAlphaComponent(0.8)
            self.subtitleAttributedString = NSAttributedString.init(string: subtitle, attributes: [.foregroundColor: color,
                                                                                                  ])
        }
        
    }
    
}
