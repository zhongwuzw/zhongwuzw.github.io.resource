//
//  Item14014Background.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/25.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

class Item14014Background: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {

    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }

    static func height(_ component: IComponent?) -> CGFloat {
        var itemHeight: CGFloat = 0
        if let component = component, let model = component.model as? BaseComponentModel {
            itemHeight = Component14014Util.backgroundImageSize(model).height
        }
        return itemHeight
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return Item14014Background.height(self.item?.getComponent())
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return Item14014BackgroundView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
    }

    func reuseView(itemView: UIView) {
        
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [
            ItemImmersionBackgroundAdapterPlugin()
        ]
    }
}
