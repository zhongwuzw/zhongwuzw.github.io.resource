//
//  Item12114.swift
//  YKChannelComponent
//
//  Created by better on 2022/10/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item12114: Item12113 {

}
