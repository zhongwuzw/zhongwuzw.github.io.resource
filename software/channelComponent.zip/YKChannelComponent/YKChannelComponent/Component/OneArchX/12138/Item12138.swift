//
//  Item12138.swift
//  YKChannelComponent
//
//  Created by wustlj on 2023/11/27.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKChannel
import NovelAdSDK
import YKAdSDK

class Item12138:NSObject, ItemDelegate, ItemLifeCycleEventHandlerDelegate, PlayerStatusCallback, OADFeedbackProtocol{
    
    var playFinish : Bool = false
    
    var itemWrapper: ItemWrapper?
    
    let nadApi = NadAPI()
    var adModel: OADModel? = nil
    var isExposed = false
    var contentViewLeftMagin : CGFloat = 0
    var contentBottomMagin: CGFloat = 0
    
    lazy var lifeCycleEventHandler:ItemLifeCycleEventHandler = {
        let handler = ItemLifeCycleEventHandler()
        handler.delegate = self
        return handler
    }()
    
    
    static func create() -> ItemDelegate {
        return Item12138.init()
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }

    
    func columnCount() -> CGFloat {
        return 2.0
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.receiveEstimatedLayout(Double(itemWidth))
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler(),
                ItemPlayerProgressEventHandler(),
                self.lifeCycleEventHandler]
    }

    
    func itemDidInit() {
        guard let itemModel = self.item?.itemModel else {
            return
        }
        if let unifyAd = itemModel.extraExtend["unifyAd"] as? [String : Any] {
            createNovelAdFeedbackModel(itemModel, nadApi: nadApi, unifyAdData: unifyAd)
            
            if let adModel = adModel {
                nadApi.adFill(adModel)
            }
        }
                
        if self.adModel?.resType == "video" {
            itemModel.playerModel?.videoURL = self.adModel?.resUrl;
            itemModel.playerModel?.repeatPlay = true
        }

        let title = self.adModel?.mainTitle
        if let title = title, title.count > 0 {
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 3.0
            paragraphStyle.lineBreakMode = .byTruncatingTail
            let attributedTitle = NSAttributedString.init(string: title, attributes: [.paragraphStyle: paragraphStyle])
            item?.itemModel?.attributedTitle = attributedTitle
        }
    }
    
    func receiveEstimatedLayout(_ itemWidth: Double) {

        let itemHeight = ceil(itemWidth * RATIO_9_16) + 30 + ceil(38.0 * Double(YKNSize.yk_icon_size_scale())) + self.contentBottomMagin
        
        item?.itemModel?.layout.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)
    }
    
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = ItemPlugin12077ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))

        return itemView
    }

    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? ItemPlugin12077ContentView else {
            return
        }
        guard let itemModel = self.item?.itemModel else {
            return
        }
        let itemLayout = itemModel.layout
        
        itemView.feedbackDelegate = self
        
        //填充数据
        itemView.fillOADData(model: adModel, titleLayout: itemLayout.title, item: item, leftMagin: self.contentViewLeftMagin, bottomMagin: self.contentBottomMagin)
        
        //跳转
        weak var weakself = self
        itemView.whenTapped {
            if let weakself = weakself, let adModel = weakself.adModel {
                weakself.nadApi.adClickAction(adModel, extraParams: nil)
            }
        }

//        //负反馈
//        if let oneArchPageScene = self.item?.getPage()?.pageContext?.concurrentDataMap["OneArchPageScene"] as? String, oneArchPageScene == "Detail" {
//            //通投到播放页场景是，不展示负反馈按钮
//        } else {
//            Service.feedback.attach(itemModel.feedbackModel, toView: itemView, morePos: .BottomRight, isSupportUndo: true, feedbackSuccess: nil)
//            if let feedbackBtn = itemView.viewWithTag(999998) {
//                itemView.superview?.accessibilityElements = [itemView, feedbackBtn]
//            }
//        }
        
        //player
        if let playerModel = itemModel.playerModel {
            Service.player.attach(playerModel, toView: itemView.videoImageView, displayFrame: itemView.imageViewFrame())

            playerModel.repeatPlay = false
            playerModel.isHideWaterMark = true
            playerModel.playerDelegate = self
            if let config = itemModel.config as? ConfigModel, let forbidAdPlay = config.getBoolValue("forbidAdPlay") as? Bool {
                if forbidAdPlay {
                    playerModel.videoURL = ""
                }
            }
            //adBizInfo
            AdPlayInfoUtil.updatePlayModelExtraWithAd(playerModel: playerModel, oadModel: self.adModel)
        }
        
//        adModel?.handleCSJEvent(itemView, withClickableViews: [itemView]);
        
        //埋点（240123，补发内容埋点）
        Service.statistics.bind(itemModel.action?.report, itemView, .Defalut)
//        NSLog("[feed ad] 12138 report spm:\(itemModel.action?.report?.spm) scm:\(itemModel.action?.report?.scm)")
    }
    
    public func enterDisplayArea(itemView: UIView?) {
        print("[12138] enterDisplayArea")
        if let itemView = itemView as? ItemPlugin12077ContentView {
            if let adModel = adModel {
                
                adModel.handleCSJEvent(itemView, withClickableViews: [itemView]);
                
                if !isExposed {
                    isExposed = true
                    self.nadApi.adExposure(adModel)
                }
            }
        }
    }
    public func exitDisplayArea(itemView: UIView?) {
        print("[12138] exitDisplayArea")
        adModel?.setAdEtpInterruptShow(true)
        if let itemView = itemView {
            adModel?.unregistClient(itemView, withClickableViews: [itemView])
        }
    }
    public func didActivate() {
        
    }
    public func didDeactivate() {
        adModel?.setAdEtpInterruptShow(true)
    }
    public func appWillResignActive() {
        adModel?.setAdEtpInterruptShow(true)
    }
    public func feedback() {
        adModel?.setAdEtpInterruptShow(true)
    }
 
//    func playHelper() -> YKAdPlayEventHelper? {
//        return YKAdPlayEventHelper.shareInstance()
//    }
//
    //MARK: PlayerStatusCallback
    func didStartPlayVideoInPlayer(_ player: PlayerView) {
        print("[12138] play start")

        playFinish = false
        
        if let adModel = adModel {
            adModel.adPlayStart()
            adModel.adExposureEtp(OAD_ETP_PLAY_START, time: -1);
        }
    }

    func didFinishPositiveVideoInPlayer(_ player: PlayerView) {
        print("[12138] play end")
        
        playFinish = true
        
        if let adModel = adModel {
            adModel.adPlayEnd()
            adModel.adExposureEtp(OAD_ETP_PLAY_END, time: -1);
        }
    }

    func didClickStopPlayer(_ player: PlayerView) {
        print("[12138] play stop")
                
        if !playFinish, let adModel = adModel {
            adModel.adPlayEnd()
        }
    }

    func playTimeDidChange(_ player: PlayerView) {
//        print("[12138] play time = \(player.playingTime)")
        
        playFinish = false
        
        if let adModel = adModel {
            adModel.adPlay(atTime: NSInteger(player.playingTime))
            adModel.adExposureEtp(OAD_ETP_PLAY_EFFECT, time: NSInteger(player.playingTime));
        }
    }
    
    //MARK: ad
    
    func createNovelAdFeedbackModel(_ itemModel: BaseItemModel, nadApi: NadAPI, unifyAdData: [String: Any]) {
        let feedbackModel: FeedbackModel = FeedbackModel()
        
        let defalutTitle = "就是不感兴趣"
        feedbackModel.reasons = [FeedbackItemModel.init(["title":defalutTitle, "reason":"I"])]
        feedbackModel.report = itemModel.action?.report
        feedbackModel.scene = itemModel.scene
        
        self.adModel = nadApi.getAd(unifyAdData)
                
        itemModel.feedbackModel = feedbackModel
    }
    
    
    // MARK: OADFeedbackProtocol
    func didAttachAdFeedback() {
        
    }
    
    func didDetachAdFeedback() {
        
    }
    
    func didSuccessAdFeedback() {
        if let component = item?.getComponent(),let tag = item?.itemModel?.type, tag == "12140" {
            deleteComponentWithAnimation(component)
            feedback()
        }
    }

}

