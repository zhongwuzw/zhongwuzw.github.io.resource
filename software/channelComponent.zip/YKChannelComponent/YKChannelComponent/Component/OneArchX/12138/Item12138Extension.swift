//
//  Item12138Extension.swift
//  YKChannelComponent
//
//  Created by wustlj on 2023/11/27.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArchSupport
import OneArchSupport4Youku
import OneArch
import NovelAdSDK
import YoukuResource
 
extension ItemPlugin12077ContentView {
    
    func fillOADData(model: OADModel?, titleLayout: TextLayoutModel?, item: IItem?, leftMagin: CGFloat, bottomMagin: CGFloat) {
        guard let model = model else { return }
        
        let itemModel = item?.itemModel
        
        curModel = model
        
        bgView.frame = self.bounds
        //imageview
        videoImageView.frame = self.imageViewFrame()
        var imgUrl = ""
        if model.resType == "img" {
            imgUrl = model.resUrl ?? ""
        } else if model.resType == "video" {
            imgUrl = model.thumbnail ?? ""
        }
        videoImageView.ykn_setImage(withURLString: imgUrl,
                                    module: "",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        if let attributedTitle = itemModel?.attributedTitle {
            titleLabel.attributedText = attributedTitle
        } else {
            titleLabel.text = model.mainTitle ?? "广告"
        }
        titleLabel.frame = CGRect.init(x: leftMagin,
                                       y: videoImageView.bottom + YKNGap.youku_picture_title_spacing(),
                                       width: width - leftMagin * 2,
                                       height: ceil(38.0 * YKNSize.yk_icon_size_scale()));

        if model.isShowOADMark() {
            //adMarkView
            adLabel.isHidden = true
            oadMarkView.isHidden = false
            
            oadMarkView.fillData(withDspName: model.dspDisplayName ?? "", subName: model.subDspName ?? "", logoUrl: model.dspLogo ?? "")
            oadMarkView.setPaddingHorizontal(0, paddingVertical: 2.5, maxWidth: self.width - leftMagin * 2 - 24)
            let adMarkSize = oadMarkView.getSize()
            oadMarkView.frame = CGRect(x: leftMagin, y: self.height - 18 - bottomMagin, width: adMarkSize.width, height: 18)
        } else {
            //ad corner
            oadMarkView.isHidden = true
            adLabel.isHidden = false
            
            if let vendorName = model.vendorName, vendorName.count > 0 {
                adLabel.text =  vendorName
            } else {
                adLabel.text = "广告"
            }
            let adLabelH : CGFloat = 18
            let adLabelW = adLabel.sizeThatFits(CGSize.init(width: self.width - leftMagin * 2, height: adLabelH)).width
            adLabel.frame = CGRect.init(x: leftMagin, y: self.height - adLabelH - bottomMagin, width: adLabelW, height: adLabelH)
        }
        var reasonX: CGFloat = 0
        if !oadMarkView.isHidden {
            reasonX = oadMarkView.frame.maxX + 3
            reasonLabel.centerY = oadMarkView.centerY
        } else {
            reasonX = adLabel.frame.maxX + 3
            reasonLabel.centerY = adLabel.centerY
        }
        var textRight: CGFloat = self.width - leftMagin
        if let _ = item?.itemModel?.feedbackModel {
            textRight = textRight - 25 - YKNGap.dim_3()
        }
        reasonLabel.width = textRight - reasonX
        
        //reason
        reasonLabel.text = model.isDownload() ? "· 立即下载" : "· 了解详情"
        reasonLabel.origin.x = reasonX
        
        //color
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: itemModel?.scene?.sceneTitleColor())
        self.reasonLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: itemModel?.scene?.sceneSubTitleColor())
//        self.backgroundColor = sceneUtil(UIColor.clear, sceneColor: itemModel?.scene?.sceneBgColor())
        
        feedbackView.addTarget(self, action: #selector(showFeedback), for: .touchUpInside)
        if let tag = itemModel?.type {
            if tag == "12138" {
                feedbackView.frame = CGRect.init(x: self.width - 30, y: self.height - 30 + 7, width: 30, height: 30)
            } else if tag == "12140" {
                feedbackView.frame = CGRect.init(x: self.width - 30, y: self.height - 30 - 5, width: 30, height: 30)
            }
        }
    }
    
    // MARK: Feedback
    @objc func showFeedback() {
        guard let curModel = curModel else {
            return
        }
        if feedbackView.isHidden {
            return
        }
        weak var weakself = self
        OADFeedbackService.sharedInstance().attachFeedback(curModel, from: feedbackView) {
            
        } didDetach: {
            
        } successBlock: {
            weakself?.didSuccessAdFeedback()
        }
    }
    
    func didSuccessAdFeedback() {
        feedbackDelegate?.didSuccessAdFeedback()
    }
    
    override func hitTest(_ point: CGPoint, with event: UIEvent?) -> UIView? {
        let hitView = super.hitTest(point, with: event)
        if hitView == feedbackView {
            guard let curModel = curModel else {
                return hitView
            }
            if hitTestIsMisClick {
                hitTestIsMisClick = false
                return self
            }
            if OADFeedbackService.sharedInstance().isMisClick(curModel) {
                hitTestIsMisClick = true
                return self
            }
        }
        return hitView
    }
}

