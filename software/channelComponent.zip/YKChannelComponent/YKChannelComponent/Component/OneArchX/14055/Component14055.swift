//
//  Component14055.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/4/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import YoukuResource
import YKResponsiveLayout
import OneArchSupport4Youku

class Component14055: NSObject, ComponentDelegate {
    
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {
        
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        var bottom: CGFloat = 0
        if ykrl_isResponsiveLayout() {
            config.preferredCardSpacingTop = -9 // 20221129版本 目标值上下距离18，标注见 https://work.aone.alibaba-inc.com/issue/46241807
            bottom = YKNGap.youku_comp_margin_bottom() // 20221129版本 目标值上下距离36
        } else {
            config.preferredCardSpacingTop = YKNGap.youku_column_spacing()
            bottom = 9
        }
        
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: bottom, right: YKNGap.youku_margin_right())
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }

    /// item高度
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        guard let model = component?.model as? BaseComponentModel, let items = component?.getItems(), items.count > 0 else {
            return 0
        }
        
        let enterItem = items[0]
        let changeItem = items.count == 2 ? items[1] : nil
        let enterModel: BaseItemModel? = enterItem.itemModel
        let changeModel: BaseItemModel? = changeItem?.itemModel
        
        let hasEnter = enterModel != nil && ((enterModel?.title?.isEmpty ?? true) == false)
        let hasChange = changeModel != nil && ((changeModel?.title?.isEmpty ?? true) == false)
        
        if hasEnter || hasChange {
            return 36
        }
        
        return 0
    }

    /// 初始化item view
    func createView(_ itemSize: CGSize) -> UIView {
        return Component14055ContentView.init(frame: CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
    }

    /// 复用
    func reuseView(itemView: UIView) {
        if let itemView = itemView as? Component14055ContentView {
            itemView.fillData(self.component)
        }
    }
    
    func reuseId() -> String? {
        return "Component14055"
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
