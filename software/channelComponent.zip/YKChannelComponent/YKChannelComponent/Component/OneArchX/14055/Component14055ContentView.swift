//
//  Component14055ContentView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/4/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Component14055ContentView: AccessibilityView {

    lazy var enterItemView:UIButton = {
        return createItemView()
    }()

    lazy var changeItemView:UIButton = {
        return createItemView()
    }()
    
    func createItemView() -> UIButton {
        let view = UIButton.init()
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.backgroundColor = .ykn_secondaryBackground
        view.titleLabel?.font = YKNFont.button_text()
        return view
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(enterItemView)
        addSubview(changeItemView)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func fillData(_ component:IComponent?) {
        guard let model = component?.model as? BaseComponentModel, let items = component?.getItems(), items.count > 0 else {
            return
        }
        self.backgroundColor = .clear
        
        let enterItem = items[0]
        let changeItem = items.count == 2 ? items[1] : nil
        let enterModel: BaseItemModel? = enterItem.itemModel
        let changeModel: BaseItemModel? = changeItem?.itemModel
        
        let hasEnter = enterModel != nil && ((enterModel?.title?.isEmpty ?? true) == false)
        let hasChange = changeModel != nil && ((changeModel?.title?.isEmpty ?? true) == false)
        let itemWidth = (hasEnter && hasChange) ? (self.width - YKNGap.youku_column_spacing())/2.0 : self.width
        
        self.changeItemView.size = CGSize.init(width: itemWidth, height: self.height)
        self.enterItemView.size = CGSize.init(width: itemWidth, height: self.height)
        self.changeItemView.setTitle(changeModel?.title, for: .normal)
        self.enterItemView.setTitle(enterModel?.title, for: .normal)
        self.changeItemView.isHidden = !hasChange
        self.enterItemView.isHidden = !hasEnter

        self.changeItemView.left = self.enterItemView.isHidden ? 0 : (self.enterItemView.right + YKNGap.youku_column_spacing())

        //action
        Service.action.bind(enterModel?.action, self.enterItemView)
        if changeModel != nil {
            Service.action.bind(changeModel?.action, self.changeItemView)
        }

        //氛围
        let bgColor = sceneUtil(.ykn_secondaryBackground, sceneColor: model.scene?.sceneCardFooterBgColor())
        let textColor = sceneUtil(.ykn_secondaryInfo, sceneColor: model.scene?.sceneCardHeaderTitleColor())
        self.changeItemView.backgroundColor = bgColor
        self.enterItemView.backgroundColor = bgColor
        self.changeItemView.setTitleColor(textColor, for: .normal)
        self.enterItemView.setTitleColor(textColor, for: .normal)
    }

}
