//
//  Item14097ContentView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/5/30.
//  Copyright © 2022 Youku. All rights reserved.
//

import SDWebImage
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import UIKit

class Item14097ContentView: AccessibilityView {
    lazy var bgImage: UIImageGIFView = {
        let _bgImage = UIImageGIFView()
        _bgImage.backgroundColor = UIColor.createColorWithHexRGB(colorStr:"#E4E4E4")
        _bgImage.contentMode = UIView.ContentMode.scaleAspectFill
        _bgImage.layer.cornerRadius = 9
        _bgImage.layer.masksToBounds = true
        return _bgImage
    }()
    
    lazy var contentView: UIView = {
        let _contentView = UIView()
        _contentView.layer.cornerRadius = 9
        _contentView.layer.masksToBounds = true
        return _contentView
    }()
    
    var contentLayer: CAGradientLayer =  {
        let _contentLayer = CAGradientLayer.init()
        _contentLayer.locations = [0.0, 1.0]
        _contentLayer.startPoint = CGPoint(x: 0, y: 0)
        _contentLayer.endPoint = CGPoint(x: 0, y: 1)
        return _contentLayer
    }()
    
    lazy var icon: UIImageGIFView = {
        return  UIImageGIFView()
    }()
    
    lazy var title: UILabel = {
        let _title = UILabel()
        _title.font = YKNFont.corner_text() //[UIFont systemFontOfSize:9];
        _title.textAlignment = NSTextAlignment.center
        _title.lineBreakMode = NSLineBreakMode.byWordWrapping
        return _title
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setupSubviews() {
        self.addSubview(bgImage)
        self.addSubview(contentView)
        self.contentView.layer.addSublayer(self.contentLayer)
        self.contentView.addSubview(icon)
        self.contentView.addSubview(title)
    }
    
    func fillData(_ item: IItem?) {
        guard let item = item, let model = item.itemModel as? HomeItemModel else {
            return
        }

        let bgHeight = Item14097ContentView.bgHeight(self.width)
        self.bgImage.size = CGSize.init(width: self.width, height: bgHeight)
        self.bgImage.ykn_setImage(withURLString: model.img, module: nil, imageSize: CGSize.zero, parameters: nil, completed: nil)
        
        let fromColor = getValueFromDict("titleBgFromColor", model.extraExtend, "#F5F5F5")
        let toColor = getValueFromDict("titleBgToColor", model.extraExtend, "#F5F5F5")
        self.contentLayer.colors = [UIColor.createColorWithHexRGB(colorStr: fromColor).cgColor,UIColor.createColorWithHexRGB(colorStr: toColor).cgColor]
        
        self.title.text = model.subtitle
        let textColor = getValueFromDict("textColor", model.extraExtend, "#999999")
        self.title.textColor = UIColor.createColorWithHexRGB(colorStr: textColor)
        
        self.icon.size = CGSize.init(width: 63, height: 18)
        if let icon = model.extraExtend["icon"] as? String, icon.isEmpty == false {
            self.icon.cms_setImage(withURLString: icon, placeholderImage: UIImage.init(named: "youku_default"), module: nil, imageSize: .zero, parameters: nil, completed: nil)
        }
        
        relayoutSubViews()
        
        Service.action.bind(model.action, self)
    }
    
    func relayoutSubViews() {
        let bgHeight = self.width * 82.0 / 109.0
        var contentWidth = self.width - 28

        if contentWidth < 81 {
            contentWidth = 81
        }

        let contentHeight: CGFloat = 37
        self.bgImage.frame = CGRect(x: 0, y: 0, width: self.width, height: bgHeight)

        self.contentView.frame = CGRect(x: 0, y: self.height - contentHeight, width: contentWidth, height: contentHeight)
        self.contentView.centerX = self.width / 2.0

        self.contentLayer.frame = self.contentView.bounds

        self.icon.frame = CGRect(x: (contentWidth - 63) / 2, y: 3, width: 63, height: 18)

        self.title.frame = CGRect(x: 3, y: self.icon.bottom + 1, width: contentWidth - 6, height: 13)
    }
    
    static func viewHeight(_ width: CGFloat) -> CGFloat {
        return bgHeight(width) + 12
    }
    
    static func bgHeight(_ width: CGFloat) -> CGFloat {
        return width * 79 / 105.0
    }
    
    // private
    
    private func getValueFromDict(_ key: String, _ dict: [String: Any], _ defaultValue: String) -> String {
        if let value = dict[key] as? String, value.isEmpty == false {
            return value
        }
        return defaultValue
    }
}

