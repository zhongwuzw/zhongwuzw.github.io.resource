//
//  Item14097.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/5/30.
//  Copyright © 2022 Youku. All rights reserved.
//

import OneArch
import YoukuResource
import YKProtocolSDK
import OneArchSupport4Youku

class Item14097: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    weak var displayingItemView: Item14097ContentView?
    
    func itemDidInit() {
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeItemModel.self as? T.Type
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return Item14097ContentView.viewHeight(itemWidth)
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14097ContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14097ContentView else {
            return
        }

        itemView.fillData(self.item)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
}

