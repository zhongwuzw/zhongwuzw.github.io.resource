//
//  Item12153ContentView.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/7/9.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import SDWebImage
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKUIComponent

class Item12153BillboardView : UIView {
    
    lazy var coverImage: UIImageView = {
        let width :CGFloat = ceil(38 * YKNSize.yk_icon_size_scale())
        let height :CGFloat = ceil(51 * YKNSize.yk_icon_size_scale())
        let view = UIImageView.init(frame: CGRect(x: 0, y: 0, width: width, height: height))
        view.layer.cornerRadius = YKNCorner.radius_small()
        view.clipsToBounds = true
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.textColor = .ykn_primaryInfo
        view.numberOfLines = 1
        view.textAlignment = .left
        view.lineBreakMode = .byTruncatingTail
        view.font = YKNFont.posteritem_maintitle_weight(.medium)
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.textColor = .ykn_tertiaryInfo
        view.numberOfLines = 1
        view.textAlignment = .left
        view.lineBreakMode = .byTruncatingTail
        view.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.tertiary_auxiliary_text().pointSize)
        return view
    }()
    
    lazy var rankLayer: SmallRankView = {
        let layer = SmallRankView.init(frame: CGRect(x: 0, y: 0, width: 10, height: 21))
        layer.customFontSize = 21
        return layer
    } ()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .clear
        self.addSubview(titleLabel)
        self.addSubview(subtitleLabel)
        self.addSubview(coverImage)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        NSLog("tg--------layoutSubviews +1")

        let titleHeight: CGFloat = YKNFont.height(with: titleLabel.font, lineNumber: 1)
        let subtitleHeight: CGFloat = YKNFont.height(with: subtitleLabel.font, lineNumber: 1)
        let textHeight: CGFloat = titleHeight + subtitleHeight + YKNGap.dim_4()
        titleLabel.frame = CGRect(x: coverImage.right + YKNGap.dim_5(), y: ceil((coverImage.height - textHeight)/2), width: width - (coverImage.right + YKNGap.dim_5()), height: titleHeight)
        subtitleLabel.frame = CGRect(x: coverImage.right + YKNGap.dim_5(), y: titleLabel.bottom + YKNGap.dim_4(), width: width - (coverImage.right + YKNGap.dim_5()), height: subtitleHeight)
    }
    
    func setUpData(_ item: IItem) {
        guard let model = item.model as? Item12154Model else {
            return
        }
        
        if let image = model.img, !image.isEmpty, let url = URL.init(string: image) {
            coverImage.sd_setImage(with: url)
            let rankIndex: Int = model.rankInvolved ? (1 + item.index) : 0
            if model.rankInvolved {
                coverImage.layer.ykn_showBottomShader(true, height: 14.0, rank: rankIndex)
                coverImage.addSubview(rankLayer)
                rankLayer.bottom = coverImage.bottom + 5.0
                rankLayer.left = coverImage.left
                rankLayer.setSquareRank(rankIndex)
            }
        }
        if let title = model.title, !title.isEmpty {
            titleLabel.text = title
        }
        if let subtitle = model.newReason?.text?.title, !subtitle.isEmpty {
            self.buildSutitleText(model.newReason)
        } else {
            subtitleLabel.text = model.subtitle
        }
    }
    
    func buildSutitleText(_ newReason: LabelModel?){
        guard let newReason = newReason else {
            return
        }
        
        if let iconType = newReason.iconType, let colorLevel = newReason.text?.colorLevel, iconType.contains("heat"){
            let iconText: String = "\u{e613}"
            var iconColor = UIColor.createColorWithHexRGB(colorStr: "#ff4a50")
            let attrText = NSMutableAttributedString.init()
            
            if colorLevel == 1 {
                iconColor = UIColor.createColorWithHexRGB(colorStr: "#ff4a50")
            } else if colorLevel == 2 {
                iconColor = UIColor.createColorWithHexRGB(colorStr: "#f65200")
            } else if colorLevel == 3 {
                iconColor = UIColor.createColorWithHexRGB(colorStr: "#fc9f00")
            }
            let iconAttrText = NSAttributedString.init(string: iconText + " ", attributes: [.foregroundColor: iconColor])
            attrText.append(iconAttrText)
            let subtitleText = NSAttributedString.init(string: newReason.text?.title ?? "", attributes: [.font: YKNFont.tertiary_auxiliary_text(),.foregroundColor: UIColor.ykn_tertiaryInfo])
            attrText.append(subtitleText)
            
            subtitleLabel.attributedText = attrText
        } else {
            subtitleLabel.text = newReason.text?.title
        }
    }

}

class Item12153ContentView : UIView {
    
    var forceTheme = ""
    
    lazy var itemsArray = [Item12153BillboardView]()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.numberOfLines = 1
        view.textAlignment = .center
        view.lineBreakMode = .byTruncatingTail
        view.font = YKNFont.discuss_content_text_weight(.medium)
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.numberOfLines = 1
        view.textAlignment = .center
        view.lineBreakMode = .byTruncatingTail
        view.font = YKNFont.tertiary_auxiliary_text()
        return view
    }()
    
    lazy var topGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init(x: 0.5, y: 0)
        layer.endPoint = CGPoint.init(x: 0.5, y: 1.0)
        let clr1 = UIColor.createColorWithHexRGB(colorStr: "#FFB82D").withAlphaComponent(0.2).cgColor
        let clr2 = UIColor.createColorWithHexRGB(colorStr: "#FFB82D").withAlphaComponent(0.0).cgColor
        layer.colors = [clr1, clr2]
        self.layer.insertSublayer(layer, at: 0)
        return layer
    }()
    
    lazy var bottomLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.textAlignment = .center
        view.textColor = .ykn_secondaryInfo
        view.backgroundColor = .ykn_secondaryBackground
        view.font = YKNFont.button_text()
        view.layer.masksToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var titleLeftLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.textColor = .ykn_primaryInfo
        view.textAlignment = .right
        view.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.discuss_content_text_weight(.medium).pointSize)
        view.text = "\u{e708}"
        return view
    }()
    
    lazy var titleRightLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.textColor = .ykn_primaryInfo
        view.textAlignment = .left
        view.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.discuss_content_text_weight(.medium).pointSize)
        view.text = "\u{e709}"
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(titleLabel)
        self.addSubview(subtitleLabel)
        self.addSubview(bottomLabel)
        self.addSubview(titleLeftLabel)
        self.addSubview(titleRightLabel)
        self.backgroundColor = UIColor.ykn_primaryBackground
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        self.clipsToBounds = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUpLayout(_ comp: IComponent?) {
        
        guard let comp = comp, let compModel = comp.model as? Component12142Model else {
            return
        }
        
        updateLabelColor()
        titleLabel.frame = compModel.layout.title?.renderRect ?? .zero
        titleLabel.sizeToFit()
        titleLabel.center = CGPoint(x: ceil(width / 2), y: titleLabel.center.y)
        titleLeftLabel.frame = CGRect(x: titleLabel.left - 14.0 - YKNGap.dim_4(), y: titleLabel.top, width: 14.0, height: titleLabel.height)
        titleRightLabel.frame = CGRect(x: titleLabel.right, y: titleLabel.top, width: 14.0, height: titleLabel.height)
        
        subtitleLabel.frame = compModel.layout.subtitle?.renderRect ?? .zero
        topGradientLayer.frame = CGRect(x: 0, y: 0, width: width, height: ceil(width * 100 / 170))
        
        if let layout = compModel.layout.extendExtra {
            var gap: CGFloat = 0
            if let itemsLayout = layout["items"] as? LayoutModel {
                for itemView in itemsArray {
                    itemView.frame = CGRect( x: itemsLayout.renderRect.minX, y: itemsLayout.renderRect.minY + gap, width: itemsLayout.renderRect.width, height: 51.0 * YKNSize.yk_icon_size_scale())
                    gap += (itemView.height + YKNGap.dim_6())
                }
            }
            if let moreTextLayout = layout["moreText"] as? TextLayoutModel {
                bottomLabel.frame = moreTextLayout.renderRect
            }
        }
    }
 
    func fillData(_ comp: IComponent?) {
        guard let comp = comp, let compModel = comp.model as? Component12142Model else {
            return
        }
        
        if let title = compModel.title, !title.isEmpty {
            titleLabel.text = title
        }
        if let subtitle = compModel.subtitle, !subtitle.isEmpty {
            subtitleLabel.text = subtitle
        }
        if let moreText = compModel.moreText, !moreText.isEmpty {
            bottomLabel.text = moreText
        } else {
            bottomLabel.text = "查看完整榜单"
        }
        
        if !self.itemsArray.isEmpty {
            for itemView in self.itemsArray {
                itemView.removeFromSuperview()
            }
            self.itemsArray.removeAll()
        }
        
        if let items = comp.getItems() {
            for item in items {
                if let itemModel = item.model as? Item12154Model {
                    let itemView = Item12153BillboardView()
                    itemView.setUpData(item)
                    Service.action.bind(itemModel.action, itemView)
                    self.addSubview(itemView)
                    self.itemsArray.append(itemView)
                }
            }
        }
        //绑定事件
        Service.action.bind(compModel.action, self)
        
        self.setUpLayout(comp)
    }
    
    func isDark() -> Bool {
        //强制暗黑
        if !self.forceTheme.isEmpty, self.forceTheme == "dark" {
            return true
        }
        //强制白天
        if !self.forceTheme.isEmpty, self.forceTheme == "light" {
            return false
        }

        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
    
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        weak var weakSelf = self
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            guard let weakSelf = weakSelf else {return}
                weakSelf.updateLabelColor()
        }
    }
    
    func updateLabelColor() {
        if isDark() {
            self.backgroundColor = .ykn_cg_11
            self.titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#ffdd9a")
            self.subtitleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#ffdd9a")
            self.titleLeftLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#ffdd9a")
            self.titleRightLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#ffdd9a")
            self.bottomLabel.backgroundColor = .ykn_co_2
        } else {
            self.backgroundColor = .ykn_primaryBackground
            self.titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#501618")
            self.subtitleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#501618")
            self.titleLeftLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#501618")
            self.titleRightLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#501618")
            self.bottomLabel.backgroundColor = .ykn_secondaryBackground
        }
    }

}

class SmallRankView: UILabel {
    
    var customFontSize: CGFloat = -1
    
    lazy var textGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        return layer
    }()
    
    func setSquareRank(_ rank: Int) {

        let fontSize: CGFloat = (customFontSize != -1) ? customFontSize : 21
        self.font = YKNFont.akrobatExtraBoldFont(ofSize: fontSize)
        self.text = "\(rank)"
        
        let clr1 = UIColor.createColorWithHexRGB(colorStr: "#ffffff").cgColor
        let clr2 = UIColor.createColorWithHexRGB(colorStr: "#ffffff").withAlphaComponent(0.76).cgColor
        let clr3 = UIColor.createColorWithHexRGB(colorStr: "#ffffff").withAlphaComponent(0.23).cgColor
        let clr4 = UIColor.createColorWithHexRGB(colorStr: "#ffffff").withAlphaComponent(0).cgColor

        let colors = [clr1, clr2, clr3, clr4]
        
        // 用 UIGraphicsImageRenderer 代替 UIGraphicsBeginImageContextWithOptions 提高性能和简化代码
        let renderer = UIGraphicsImageRenderer(size: self.bounds.size)
        let gradientImage = renderer.image { ctx in
            let context = ctx.cgContext
            let colorSpaceRef = CGColorSpaceCreateDeviceRGB()
            guard let gradientRef = CGGradient(colorsSpace: colorSpaceRef, colors: colors as CFArray, locations: nil) else {
                return
            }
            let startPoint = CGPoint(x: self.bounds.width * 0.5, y: 0)
            let endPoint = CGPoint(x: self.bounds.width * 0.5, y: self.bounds.height)

            context.drawLinearGradient(gradientRef, start: startPoint, end: endPoint, options: [.drawsBeforeStartLocation, .drawsAfterEndLocation])
        }

        self.textColor = UIColor(patternImage: gradientImage)
    }
}

class Item12163ContentView: Item12153ContentView {
    override func updateLabelColor() {
        super.updateLabelColor()
        self.backgroundColor = .ykn_tertiaryFill
        self.bottomLabel.backgroundColor = .ykn_elevatedButtonFill
        self.bottomLabel.layer.cornerRadius = 7.0
        self.bottomLabel.font = YKNFont.button_text_weight(.medium)
    }
}
