//
//  Item14013.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/28.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import SDWebImage

class Item14013: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    var viewSize = CGSize.zero
    var hasViewSize = false
    var isNewAdapt: Bool = false //新适配策略
    
    func itemDidInit() {
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        calcViewSize(itemWidth: itemWidth)
        return viewSize.height
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = ItemPlugin14013ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {

        guard let itemView = itemView as? ItemPlugin14013ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        
        itemView.imageView.frame = CGRect.init(x: 0, y: 0, width: itemView.width, height: itemView.height)
        itemView.isAccessibilityElement = true
        itemView.accessibilityLabel =  itemModel.config.getStringValue("contentDesc")
        if isNewAdapt {
            itemView.imageView.contentMode = .scaleAspectFill
        } else {
            itemView.imageView.contentMode = .scaleAspectFill
            if (ykrl_isResponsiveLayout()) {
                itemView.imageView.contentMode = .scaleAspectFit
            }
        }
        let urlString = itemModel.img ?? "" //scString(forKey: YKSCItemDataImagePath) ?? ""
        if isNewAdapt {
            downloadAndFillImageForNewAdapt(urlString: urlString, itemView: itemView, allowRetry: true)
        } else {
            downloadAndFillImage(urlString: urlString, itemView: itemView, allowRetry: true)
        }

        if itemModel.action?.type == "JUMP_TO_NORMAL_MODE" {
            itemView.whenTapped {
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "home.notify.enterNormalMode"), object: nil)
            }
        } else {
            Service.action.bind(itemModel.action, itemView)
        }
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }

    func downloadAndFillImage(urlString: String,
                              itemView: ItemPlugin14013ContentView,
                              allowRetry: Bool) {
        
        // ”start“ 循序OC版原文拼写错误
        self.sendAnalytics(status: "satrt", info: [String: Any](), originalURL: urlString, imageURL: "")
        
        var params = [String: Any]()
        params["fade"] = true
        itemView.imageView.ykn_setImage(withURLString: urlString,
                                        module: "home",
                                        imageSize: itemView.bounds.size,
                                        parameters: params) { [weak self, weak itemView] (image, error, info) in
            guard let self = self else {return}
            guard let itemView = itemView else {return}
            
            var errorInfo = [String: Any]()
            if let info = info {
                errorInfo["info"] = info
            }
            
            if image == nil || error != nil {
                if error != nil {
                    errorInfo["error"] = error
                    self.sendAnalytics(status: "fail", info: errorInfo, originalURL: urlString, imageURL: itemView.imageView.sd_imageURL().absoluteString)
                }
            } else {
                errorInfo["msg"] = allowRetry ? "first load image success" : "second load image success"
                self.sendAnalytics(status: "success", info: errorInfo, originalURL: urlString, imageURL: itemView.imageView.sd_imageURL().absoluteString)
            }
            
            if image == nil && allowRetry {
                DispatchQueue.main.async { [weak self] in
                    self?.downloadAndFillImage(urlString: urlString, itemView: itemView, allowRetry: false)
                }
            }
        }
    }
    
    func downloadAndFillImageForNewAdapt(urlString: String,
                              itemView: ItemPlugin14013ContentView,
                              allowRetry: Bool) {
        
        // ”start“ 循序OC版原文拼写错误
        self.sendAnalytics(status: "satrt", info: [String: Any](), originalURL: urlString, imageURL: "")
        
        itemView.imageView.sd_setImage(with: URL.init(string: urlString), module: "home", placeholderImage: nil, options: [.useScreenScale, .noParse]) { [weak self, weak itemView] (animatedImage: TBAnimatedImage?, error: Error?, cacheType: SDImageCacheType, imageURL: URL?) -> Void in
            guard let self = self else {return}
            guard let itemView = itemView else {return}
            
            var errorInfo = [String: Any]()
            
            if animatedImage == nil || error != nil {
                if error != nil {
                    errorInfo["error"] = error
                    self.sendAnalytics(status: "fail", info: errorInfo, originalURL: urlString, imageURL: itemView.imageView.sd_imageURL().absoluteString)
                }
            } else {
                errorInfo["msg"] = allowRetry ? "first load image success" : "second load image success"
                self.sendAnalytics(status: "success", info: errorInfo, originalURL: urlString, imageURL: itemView.imageView.sd_imageURL().absoluteString)
            }
            
            if animatedImage == nil && allowRetry {
                DispatchQueue.main.async { [weak self] in
                    self?.downloadAndFillImageForNewAdapt(urlString: urlString, itemView: itemView, allowRetry: false)
                }
            }
        }
    }
    
    func sendAnalytics(status: String, info: [String: Any], originalURL: String, imageURL: String) {
        var dict = [String: Any]()
        if !info.isEmpty {
            dict = dict.merging(info){ $1 }
        }
        dict["type"] = "14013"
        
        let reportOriURL = originalURL
        let reportImageURL = imageURL
        
        YoukuAnalytics.sharedInstance()?.collectALiCustomEvent(withEventID: "19999",
                                                               pageName: "ONE_IMG_LOAD",
                                                               arg1: status,
                                                               arg2: reportImageURL,
                                                               arg3: reportOriURL,
                                                               args: dict)
    }
    
    func calcViewSize(itemWidth: Double) {
        
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        
        let extraExtend = itemModel.extraExtend
        
        if !hasViewSize || ykrl_isResponsiveLayout() {
            hasViewSize = true
            viewSize = .zero
            isNewAdapt = false
            
            var width = itemWidth
            let mini = Double(min(YKRLLayoutManager.sharedInstance().screenSize.width, YKRLLayoutManager.sharedInstance().screenSize.height))
            if ykrl_isResponsiveLayout() && width > mini {
                width = mini
            }
            
            var ratio = 72.0/339.0
            if let extWidth = extraExtend["width"] as? Double,
               let extHeight = extraExtend["height"] as? Double,
               extWidth > 1,
               extHeight > 1
            {
                ratio = extHeight / extWidth
            }
            
            viewSize = CGSize.init(width: width, height: width * ratio)
            
            // 新适配方案
            if let extWidth = extraExtend["width"] as? Double,
               let extHeight = extraExtend["height"] as? Double,
               extWidth > 1,
               extHeight > 1,
               let cutModeWidths = item?.getComponent()?.model?.data?["cutModeWidth"] as? [Double], //服务端下发配置data下
               cutModeWidths.contains(extWidth)
            {
                var useHeight = extHeight
                let screenWidth = YKRLLayoutManager.sharedInstance().screenSize.width
                if screenWidth > extWidth {
                    useHeight = screenWidth * extHeight / extWidth
                }
                
                viewSize = CGSize.init(width: width, height: useHeight)
                isNewAdapt = true
            }
            
            print("[14013] calViewSize: \(viewSize)")
        }
    }
}
