//
//  Component14013.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/28.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource

class Component14013: NSObject, ComponentDelegate {
   
    func componentDidInit() {
        
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = 0
        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
    
    var componentWrapper: ComponentWrapper?
    

}
