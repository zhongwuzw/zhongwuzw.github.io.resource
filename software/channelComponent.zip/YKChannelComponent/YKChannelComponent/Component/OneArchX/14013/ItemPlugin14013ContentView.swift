//
//  ItemPlugin14013ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/3/5.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YKResponsiveLayout
import YoukuResource

class ItemPlugin14013ContentView: UIView {

    //MARK: Property
    lazy var imageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.backgroundColor = .clear
        view.contentMode = .scaleAspectFill
        if (ykrl_isResponsiveLayout()) {
            view.contentMode = .scaleAspectFit
        }
        view.layer.cornerRadius = YKNCorner.radius_medium()
        view.clipsToBounds = true
        view.isUserInteractionEnabled = true
        
        return view
    }()
    
    //MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        createSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        createSubviews()
    }
    
    //MARK: -
    func createSubviews() {
        layer.cornerRadius = YKNCorner.radius_medium()
        clipsToBounds = true
        
        imageView.frame = bounds
        addSubview(imageView)
    }
}
