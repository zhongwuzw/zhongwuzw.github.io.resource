//
//  Item14314.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/6/19.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout
import YoukuAnalytics
import NovelAdSDK

class Item14314: NSObject,ItemDelegate {
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14314Model.self as? T.Type
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return []
    }
    
    func itemDidInit() {
        
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView.init()
    }

    func reuseView(itemView: UIView) {
        
    }
}

class Item14314Model: HomeItem14016Model {
    public var adDict: [String: Any]?
    var adModel: OADModel?
    
    lazy var adAPI: NadAPI = {
        return NadAPI()
    } ()
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        guard let data = cmsInfo?["data"] as? [String : Any] else {
            return
        }
        self.adDict = data["ad"] as? [String: Any]
        
        if let adDict = self.adDict {
            self.adModel = self.adAPI.getAd(adDict)
        }
    }
}
