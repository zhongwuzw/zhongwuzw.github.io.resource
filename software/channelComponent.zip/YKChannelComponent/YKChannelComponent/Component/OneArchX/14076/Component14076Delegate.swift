//
//  Component14076Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/2/22.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import YKHome
import YKSCService
import YKResponsiveLayout
import OneArchSupport4Youku

@objcMembers
class Component14076Delegate:Component14016Delegate {
    override func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: 9, right: 0)
        config.preferredCardSpacingTop = 9.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0 //100
        return config
    }
    
    override func componentDidInit() {
//        self.component?.compModel?.extraExtend["yksc.data.comp.hwRatio"] = CGFloat(0.5)
        (self.component?.compModel as? HomeComponentModel)?.compHwRatio = CGFloat(0.5)
//        self.component?.compModel?.extraExtend["yksc.data.comp.slider.isFullWidthMode"] = true //先设置，基类再用
        (self.component?.compModel as? HomeComponentModel)?.sliderIsFullWidthMode = true
        super.componentDidInit()
    }
    
    override public func getItemJsonExtracter() -> ItemJsonExtracter? {
        let extracter = Comp14076JsonExtracter()
        extracter.component = self.component
        return extracter
    }
    
    override func create14346ADHandler() -> Slider14346ADHandler? {
        return Slider14346ADHandler()
    }

}
