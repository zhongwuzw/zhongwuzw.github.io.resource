//
//  Comp14076JsonExtracter.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/7/10.
//  Copyright © 2024 Youku. All rights reserved.
//

import UIKit
import OneArch
import XAdSDK
import YKSCService
import NovelAdSDK
import YKChannelPage

@objcMembers
open class Comp14076JsonExtracter: DefaultItemJsonExtracter {
    weak var component: IComponent?
    
    // MARK: - ItemJsonExtracter
    
    open override func getItemsJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error> {
       return self.getValidJson(componentJson: componentJson, component: component)
    }
    
    open func getValidJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error>{
        var originItemsJson: [[String: Any]] = [[String: Any]]()
        if let cmsItemsJson = componentJson?["nodes"] as? [[String: Any]], cmsItemsJson.count > 0 {
            originItemsJson = cmsItemsJson
        }
        
        let isPreload = isCacheData(componentJson)
        NSLog("[14076] 首页缓存状态:\(isPreload)")
        let validNodes = validNodes(nodes: originItemsJson, isCache: isPreload)
        return .success(validNodes)
    }
    
    open func validNodes(nodes: [[String: Any]], isCache: Bool) -> [[String: Any]] {
        let context = OADLunboContext()
        context.jsonArray = nodes
        context.isCache = isCache
        let result = OADUtil.validLunboAd(context)
        let respArr = result?.jsonArray as? [[String: Any]]
        YKSCScreenLogUtil.printLog("[14076] 数据 广告sdk校验前:\(nodes.count) 校验后:\(respArr?.count ?? 0) 缓存:\(isCache)", color: .purple)
        if let arr = respArr, arr.count > 0 {
            return arr
        }
        
        return nodes
    }
    

    open func isPageInPreload() -> Bool {
        if let page = self.component?.getPage()  {
            let state = page.dataState
            if state == .cache || state == .default {
                return true
            }
        }

        return false
    }
    
    func isCacheData(_ componentJson: [String: Any]?) -> Bool {
        return isPageInPreload()
    }
}
