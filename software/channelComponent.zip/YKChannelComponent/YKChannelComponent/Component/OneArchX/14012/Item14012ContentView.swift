//
//  Item14012ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/4/8.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import YKResponsiveLayout
import OneArch

class Item14012ContentView: UIView, ItemImmersionBackgroundViewContainer {

    //MARK: - Property
    lazy var imageView: UIImageGradientView = {
        let imageView = UIImageGradientView.init(frame: self.bounds)
        imageView.autoresizingMask = [.flexibleHeight]
        imageView.contentMode = .scaleAspectFill
        imageView.visualEffectView.isHidden = true
        return imageView
    }()
    
    lazy var contentView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 26, weight: .medium)
        label.textAlignment = .left
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.font = YKNFont.posteritem_maintitle()
        label.textAlignment = .left
        label.textColor = .white.withAlphaComponent(0.7)
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var descLabel: UILabel = {
        let label = UILabel()
        label.font = YKNFont.font_size_middle4()
        label.textAlignment = .left
        label.textColor = .white.withAlphaComponent(0.7)
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var bottomRoundSpacingView: UIView = {
        let view = UIView()
        
        view.backgroundColor = UIColor.ykn_primaryBackground
        
        let maskFrame = CGRect.init(x: 0, y: 0, width: self.width, height: 50)
        let maskPath = UIBezierPath.init(roundedRect: maskFrame,
                                         byRoundingCorners: [.topLeft, .topRight],
                                         cornerRadii: CGSize.init(width: 14, height: 14))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = maskFrame
        maskLayer.path = maskPath.cgPath
        
        view.layer.mask = maskLayer
        
        return view
    }()
    
    private var imageMaskColor: UIColor?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(imageView)
        addSubview(contentView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(subtitleLabel)
        contentView.addSubview(descLabel)
        contentView.addSubview(bottomRoundSpacingView)
        
        imageView.frame = self.bounds
        let statusBarOffset = STATUSBAR_HEIGHT - 20
        contentView.frame = CGRect.init(x: 0, y: statusBarOffset, width: self.width, height: self.height - statusBarOffset)
        
        let padding: CGFloat = YKNGap.youku_margin_left()
        titleLabel.frame = CGRect.init(x: padding, y: (64), width: self.width - 2 * padding, height: 37)
        subtitleLabel.frame = CGRect.init(x: padding, y: (100), width: self.width - 2 * padding, height: 17)
        descLabel.frame = CGRect.init(x: padding, y: (126), width: self.width - 2 * padding, height: 17)
    }
    
    func fillData(_ itemModel: Item14012Model) {
        
        // fill image
        var params = [String : Any]()
        params["fade"] = true
        let imageURL = itemModel.gifImg ?? itemModel.img
        imageView.ykn_setImage(withURLString: imageURL, module: "nodepage", imageSize: .zero, parameters: params, completed: nil)
        
        // fill texts
        titleLabel.text = itemModel.title
        subtitleLabel.text = itemModel.subtitle
        descLabel.text = itemModel.desc
        
        // fill maskcolor
        imageMaskColor = itemModel.imageMaskColor
        if let imageMaskColor = imageMaskColor {
            imageView.gradientView.isHidden = false
            imageView.gradientView.layer.startPoint = .zero
            imageView.gradientView.layer.startPoint = CGPoint.init(x: 1, y: 0)
            imageView.gradientView.layer.colors =  [imageMaskColor.withAlphaComponent(0.4).cgColor,
                                                    imageMaskColor.withAlphaComponent(0.4).cgColor]
        } else {
            imageView.gradientView.isHidden = true
        }
        
        // layout
        layoutWithData(itemModel)
    }
    
    func layoutWithData(_ itemModel: Item14012Model) {
        let isBottomRoundCorner = itemModel.isBottomRoundCorner
        if isBottomRoundCorner {
            bottomRoundSpacingView.isHidden = false
            
            let w: CGFloat = contentView.width
            let h: CGFloat = nodePageHeaderCompoenentBottomRoundSpacingHeight()
            let x: CGFloat = 0
            let y: CGFloat = contentView.height - h
            
            bottomRoundSpacingView.frame = CGRect.init(x: x, y: y, width: w, height: h)
        } else {
            bottomRoundSpacingView.isHidden = true
        }
        
        var titleTop: CGFloat = 64.0
        let subtitleDelta: CGFloat = 37.0
        var descDelta: CGFloat = 72
        
        if ykrl_isResponsiveLayout() { //响应式适配
            titleTop += 20
            if let subtitle = itemModel.subtitle, !subtitle.isEmpty {
                descLabel.textAlignment = .right
            } else {
                descLabel.textAlignment = .left
            }
            descDelta = subtitleDelta
        } else {
            if let desc = itemModel.desc, !desc.isEmpty {
                
            } else {
                //无第三行
                titleTop += 20
            }
            descLabel.textAlignment = .left
        }
        
        titleLabel.top = titleTop
        subtitleLabel.top = titleLabel.top + subtitleDelta
        descLabel.top = titleLabel.top + descDelta
        if let subtitle = itemModel.subtitle, !subtitle.isEmpty {
        } else {
            //无第二行（副标题），第三行顶上
            descLabel.top = subtitleLabel.top
        }
    }
    
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        if #available(iOS 13.0, *) {
            if self.traitCollection.hasDifferentColorAppearance(comparedTo: previousTraitCollection) {
                handleDarkMode()
            }
        }
    }
    
    func handleDarkMode() {
        if #available(iOS 13.0, *) {
            if imageMaskColor != nil {
                return //已有蒙层颜色，暗黑不再处理。
            }
            
            let isDark = self.traitCollection.userInterfaceStyle == .dark
            if isDark {
                let maskColor = UIColor.black.withAlphaComponent(0.4)
                imageView.gradientView.isHidden = false
                imageView.gradientView.layer.startPoint = .zero
                imageView.gradientView.layer.startPoint = CGPoint.init(x: 1, y: 0)
                imageView.gradientView.layer.colors =  [maskColor.withAlphaComponent(0.4).cgColor,
                                                        maskColor.withAlphaComponent(0.4).cgColor]
            } else {
                imageView.gradientView.isHidden = true
            }
        }
    }

    // MARK: ItemImmersionBackgroundViewContainer
    func immersionBackgroundView() -> UIView {
        return imageView
    }
}

