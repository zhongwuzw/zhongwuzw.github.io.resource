//
//  Item14012Model.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/4/8.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku
import YKResponsiveLayout

class Item14012Model: BaseItemModel {
    
    var imageMaskColor: UIColor?
    var isBottomRoundCorner: Bool = false
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        
        if ykrl_isResponsiveLayout() {
            if let bgImg = dataInfo["bgImg"] as? String, !bgImg.isEmpty {
                self.img = bgImg
            }
        }
        
        if let extraExtend = dataInfo["extraExtend"] as? [String: Any] {
            if let colorString = extraExtend["shadowColor"] as? String, !colorString.isEmpty {
                let color = UIColor.createColorWithHexRGB(colorStr: colorString)
                imageMaskColor = color
            }
        }
        
        if let isBottomRoundCorner = dataInfo["isBottomRoundCorner"] as? Bool {
            self.isBottomRoundCorner = isBottomRoundCorner
        }
    }
    
}

