//
//  UIImageGradientView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/4/8.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import OneArchSupport4Youku

class GradientView: UIView {
    
    override final class var layerClass: AnyClass {
        get {
            return CAGradientLayer.self
        }
    }
    
    override var layer: CAGradientLayer {
        return super.layer as! CAGradientLayer
    }
    
}

class UIImageGradientView: UIImageGIFView {

    lazy var gradientView: GradientView = {
        let gradientView = GradientView()
        gradientView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        gradientView.layer.opacity = 0.93
        gradientView.layer.locations = [0.0, 1.0]
        gradientView.layer.startPoint = CGPoint(x: 0, y: 0)
        gradientView.layer.endPoint = CGPoint(x: 0, y: 1)
        
        let color = UIColor.createColorWithHexRGB(colorStr: "#000000")
        gradientView.layer.colors = [color.withAlphaComponent(0).cgColor, color.withAlphaComponent(0.5).cgColor]
        return gradientView
    }()
    
    lazy var visualEffectView: UIVisualEffectView = {
        let beffect = UIBlurEffect.init(style: .light)
        let visualEffectView = UIVisualEffectView(effect: beffect)
        visualEffectView.backgroundColor = UIColor(white: 0, alpha: 0.4)
        visualEffectView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        return visualEffectView
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(gradientView)
        addSubview(visualEffectView)
    }

}
