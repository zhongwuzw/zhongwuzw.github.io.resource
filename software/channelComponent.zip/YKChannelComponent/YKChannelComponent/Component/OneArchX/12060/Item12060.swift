//
//  Item12078.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/26.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKAdSDK
import YKChannel

class Item12060:NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
    var ucAdModel: YKAdResponseModel?
    var isExposed = false
    
    static func create() -> ItemDelegate {
        return Item12078.init()
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }

    
    func columnCount() -> CGFloat {
        return 1.0
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.receiveEstimatedLayout(Double(itemWidth))
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler()]
    }
    
    func itemDidInit() {
    }
    
    func receiveEstimatedLayout(_ itemWidth: Double) {

    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView()
    }

    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? ItemPlugin12078ContentView else {
            return
        }
 
    }
}
