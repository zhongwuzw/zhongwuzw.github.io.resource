//
//  Item12060ContentView.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/25.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import Lottie
import YKHome
import OneArchSupport
import OneArchSupport4Youku
import OneArch
import OneTransition
import YKResponsiveLayout

class Item12060ContentView: AccessibilityView {
    
    weak var model:HomeItemModel?
    
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .ykn_primaryBackground
        view.layer.masksToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        return view
    }()
    
    public lazy var lunboImageView: ComponentDoubleFeedLunboView = {
        let view = ComponentDoubleFeedLunboView()
        view.backgroundColor = .ykn_primaryBackground
        view.layer.masksToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.isHidden = true
        return view
    }()
        
    lazy var categoryImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.layer.cornerRadius = 4
        return view
    }()
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle_weight(.medium)
        view.numberOfLines = 1
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_secondaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        return view
    }()
    
    lazy var reasonLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.tertiary_auxiliary_text().pointSize)
        view.numberOfLines = 1
        return view
    }()
    
    lazy var reasonArrowLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.text = "\u{e60f}"
        view.font = YKNIconFont.sharedInstance().font(withSize: YKNFont.tertiary_auxiliary_text().pointSize)
        view.numberOfLines = 1
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        self.backgroundColor = UIColor.ykn_primaryBackground
        
        self.addSubview(contentView)
        
        contentView.addSubview(videoImageView)
        let w = Double(self.frame.size.width);
        let h = Double(ceil(w * 4.0/3.0));
        videoImageView.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
        
        contentView.addSubview(lunboImageView)
        lunboImageView.frame = CGRect.init(x: 0, y: 0, width: w, height: h)

        
        contentView.addSubview(categoryImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(subtitleLabel)
        contentView.addSubview(reasonLabel)
        contentView.addSubview(reasonArrowLabel)
    }
    
    func relayoutSubviews(_ model: HomeItemModel) {
        let compModel = model.superModel as? BaseComponentModel
        let w = Item12060ContentView.imageViewSize(self.width, model:compModel).width
        let h = Item12060ContentView.imageViewSize(self.width, model:compModel).height
        contentView.frame = CGRect.init(x: 0, y: 0, width: self.width, height: self.height)
                
        videoImageView.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
        lunboImageView.frame = CGRect.init(x: 0, y: 0, width: w, height: h)

        var titleLeft = CGFloat(9)
        if !categoryImageView.isHidden {
            categoryImageView.frame = CGRect.init(x: 9, y: videoImageView.bottom + 9, width: 26 * YKNSize.yk_icon_size_scale(), height: 34 * YKNSize.yk_icon_size_scale())
            titleLeft = categoryImageView.right + 6
        } else {
            categoryImageView.frame = .zero
            titleLeft = 9
        }
        titleLabel.frame = CGRect.init(x: titleLeft, y: videoImageView.bottom + 9, width: contentView.width - 18 - titleLeft, height: YKNFont.height(with: titleLabel.font, lineNumber: 1))
        subtitleLabel.frame = CGRect.init(x: titleLabel.left, y: titleLabel.bottom + 5, width: contentView.width - 18 - titleLabel.left, height: YKNFont.height(with: subtitleLabel.font, lineNumber: 1))
        
        var reasonLabelW = contentView.width - 30
        if let reasonwidth = model.layout.extendExtra?["reasonwidth"] as? CGFloat {
            if reasonwidth > CGFloat(self.width - 30) {
                reasonLabelW = self.width - 30
            } else {
                reasonLabelW = reasonwidth
            }
        }
        reasonLabel.frame = CGRect.init(x: 9, y: subtitleLabel.bottom, width: reasonLabelW, height: 30)
        reasonArrowLabel.width = 12
        reasonArrowLabel.height = 30
        reasonArrowLabel.top = reasonLabel.top
        reasonArrowLabel.left = reasonLabel.right
    }
    
    func refreshScene() {
        titleLabel.textColor = sceneUtil(UIColor.ykn_primaryInfo, sceneColor: model?.scene?.sceneTitleColor())
        subtitleLabel.textColor = sceneUtil(UIColor.ykn_secondaryInfo, sceneColor: model?.scene?.sceneSubTitleColor())
        self.backgroundColor = .clear
        contentView.backgroundColor = sceneUtil(UIColor.ykn_elevatedPrimaryBackground, sceneColor: model?.scene?.sceneCardFooterBgColor())
    }
    
    func fillData(_ itemModel: HomeItemModel) {
        model = itemModel

        
        let compModel = model?.superModel as? BaseComponentModel
        let w = Item12060ContentView.imageViewSize(self.width, model:compModel).width
        let h = Item12060ContentView.imageViewSize(self.width, model:compModel).height
        videoImageView.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
        videoImageView.ykn_setImage(withURLString: itemModel.img,
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        if let imgs = model?.imgs {
            lunboImageView.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
            lunboImageView.setImages(images: imgs)
            lunboImageView.isHidden = false
            videoImageView.isHidden = true
        } else {
            lunboImageView.isHidden = true
            videoImageView.isHidden = false
        }
        
        titleLabel.text = itemModel.title
        subtitleLabel.text = itemModel.subtitle
        
        
        if let img = itemModel.categoryImg, !img.isEmpty {
            categoryImageView.frame = CGRect.init(x: 0, y: 0, width: 26 * YKNSize.yk_icon_size_scale(), height: 34 * YKNSize.yk_icon_size_scale())
            categoryImageView.ykn_setImage(withURLString: itemModel.categoryImg,
                                           module: "home",
                                           imageSize: CGSize.zero,
                                           parameters: nil,
                                           completed: nil)
            categoryImageView.isHidden = false
        } else {
            categoryImageView.isHidden = true
        }
        if let displayCategoryType = itemModel.extraExtend["displayCategoryType"] as? Int{
            if displayCategoryType == 0 {
                categoryImageView.isHidden = true
            }
        }
        
        if let r = itemModel.reasons?.first {
            reasonLabel.text = r.title
            reasonLabel.textColor = sceneUtil(r.titleColor, sceneColor: model?.scene?.sceneSubTitleColor())
            if let _ = r.action {
                reasonArrowLabel.isHidden = false
                if let reasonwidth = itemModel.layout.extendExtra?["reasonwidth"] as? CGFloat {
                    if reasonwidth > CGFloat(self.width - 30) {
                        reasonLabel.width = self.width - 30
                    } else {
                        reasonLabel.width = reasonwidth
                    }
                    reasonArrowLabel.left = reasonLabel.right
                }
                reasonArrowLabel.textColor = reasonLabel.textColor
            } else {
                reasonArrowLabel.isHidden = true
            }
            Service.action.bind(r.action, reasonLabel)
        }
        
        refreshScene()
        relayoutSubviews(itemModel)
    }
    
    public class func imageViewSize(_ width:CGFloat, model:BaseComponentModel?) -> CGSize {
        let w = CGFloat(width)
        var imgRatio = CGFloat(1.778)
        if let ratio = model?.imgRatio {
            imgRatio = ratio
        }
        if ykrl_isResponsiveLayout() {
            if YKRLHomeHelper.enableDoubleFeedRatio() {
                imgRatio = YKRLHomeHelper.doubleFeedRatio()
            }
        }
        if imgRatio <= 0.0001 {
            imgRatio = CGFloat(1.778)
        }
        let h = ceil(w / imgRatio)
        return CGSize.init(width: w, height: h)
    }
}
