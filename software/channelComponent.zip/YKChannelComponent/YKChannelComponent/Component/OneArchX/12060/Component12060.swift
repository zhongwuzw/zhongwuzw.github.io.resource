//
//  Component12060.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/22.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku
import OneArchSupport
import YKModeConfigFramework

class Component12060:NSObject, ComponentDelegate,ComponentLifeCycleDelegate {
    
    var itemModel: HomeItemModel? {
        return self.component?.getItems()?.first?.homeItemModel
    }
    lazy var lifeCycleHandler:ComponentLifeCycleEventHandler = {
        let handler = ComponentLifeCycleEventHandler()
        handler.delegate = self
        return handler
    }()
    
    static func create() -> ComponentDelegate {
        return Component12060.init()
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    var componentWrapper: ComponentWrapper?
    
    var itemWidth: CGFloat = 0.0
    var itemHeight: CGFloat = 0.0
    
    var itemWidths = [CGFloat]()
    var itemHeights = [CGFloat]()
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        
        var bottomPadding: CGFloat = 9
        if ykrl_isResponsiveLayout() {
            bottomPadding = 18
        }
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: bottomPadding, right: YKNGap.youku_margin_right())
//        config.preferredCardSpacingTop = 9.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 9.0
        config.preferredRowHeight = 0.0 //100
        return config
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [PlayerScrollEndCompEventHandler(), self.lifeCycleHandler]
    }
    
    func componentDidInit() {
        
    }
    
    func columnCount() -> CGFloat {
        return 2
    }

    /// item高度（slider布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let itemModel = self.component?.getItems()?.first?.model as? HomeItemModel
        let font = YKNIconFont.sharedInstance().font(withSize: YKNFont.tertiary_auxiliary_text().pointSize)
        
        if font == nil {
            return 0 //防oc crash
        }
        
        if let itemModel = itemModel,
           let r = itemModel.reasons?.first,
            let title = r.title {
            let size = (title as NSString).boundingRect(with: CGSize.zero,
                                                    options: [.usesLineFragmentOrigin, .usesFontLeading],
                                                    attributes: [.font: font],
                                                    context: nil).size
            itemModel.layout.extendExtra = ["reasonwidth" : size.width]
        }
        let imageHeight = Item12060ContentView.imageViewSize(itemWidth, model: self.component?.compModel).height
        return round(imageHeight + 77.0 * YKFontModeManager.sharedInstance().getFontScale());
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let view = Item12060ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return view
    }
    
    func reuseId() -> String? {
        var reuseId = "Component12060"
        if let ratio = self.component?.compModel?.imgRatio, let ratioStr = String.init(format: "%.2f", ratio) as? String {
            reuseId = reuseId + "_" + ratioStr
        }
        if let imgs = self.itemModel?.imgs {
            reuseId = reuseId + "__mutable_images"
        }
        return reuseId
    }

    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item12060ContentView else {
            return
        }
        guard let itemModel = self.component?.getItems()?.first?.model as? HomeItemModel else {
            return
        }
        
        itemView.fillData(itemModel)
        
        Service.action.bind(itemModel.action, itemView)

        let layout = itemModel.layout

        Service.summary.attach(itemModel.summary, toView: itemView.videoImageView, layout: layout.summary)
        Service.lbTexts.attach(itemModel.lbTexts, toView: itemView.videoImageView, layouts: layout.lbTexts)
//        Service.reasons.attach(itemModel.reasons, toView: itemView, layouts: layout.reasons)
        
        //角标
        Service.mark.attach(itemModel.mark, toView: itemView.videoImageView, layout: layout.mark)
        
        //埋点
        Service.statistics.bind(itemModel.action?.report, itemView, .Defalut)

        weak var weakself = self
        //负反馈
        Service.feedback.attach(itemModel.feedbackModel, toView: itemView, morePos: .BottomRightBorder, isSupportUndo: false) {
            if let weakself = weakself,
               let component = weakself.component
               {
                deleteComponentWithAnimation(component)
            }
        }
        if let feedbackBtn = itemView.viewWithTag(999998) {
            itemView.superview?.accessibilityElements = [itemView, feedbackBtn]
        }
        
        //        player
        if let playerModel = itemModel.playerModel {
            let size = Item12060ContentView.imageViewSize(itemView.width, model: self.component?.compModel)
            Service.player.attach(playerModel, toView: itemView, displayFrame: CGRect.init(origin: CGPoint.zero, size: size))
        }
    }
    
    func enterDisplayArea(itemView: UIView?) {
        guard let itemView = itemView as? Item12060ContentView else {
            return
        }

        var interval = self.component?.compModel?.config.getFloatValue("scrollInterval") ?? 2
        if interval < 0.0001 {
            interval = 2
        }
        itemView.lunboImageView.startTimer(interval: Int(interval))
    }
    
    func exitDisplayArea(itemView: UIView?) {
        guard let itemView = itemView as? Item12060ContentView else {
            return
        }
        itemView.lunboImageView.endTimer()
    }
    
    func didActivate() {
        
    }
    
    func didDeactivate() {
        
    }
}
