//
//  Item12089TailLabel.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2023/4/19.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import CoreText
import YKResponsiveLayout

class Item12089TailLabel: UILabel {
    
    var tailMoreFont: UIFont?
    var tailMoreColor: UIColor?

    func adjustToShortTail() {
        guard self.numberOfLines > 0 else {
            return
        }
        guard let text = self.text else {
            return
        }
        guard let font = self.font else {
            return
        }
        
        let array = self.getEachOfLineTexts()
//        print("dylantestingFF \(array)")
        
        var limitedText = ""
        let attrText = NSMutableAttributedString.init()
        
        
        let paragraphStyle = NSMutableParagraphStyle.init()
        paragraphStyle.lineSpacing = 3

        let normalAttributes: [NSAttributedString.Key : Any] = [
            .font: font,
            .paragraphStyle: paragraphStyle,
        ]
        
        if array.count >= self.numberOfLines {
            for (i, element) in array.enumerated() {
                if i >= self.numberOfLines {
                    break
                }
                
                if i == self.numberOfLines - 1 {
                    // 最后一行无需加页尾
                    if array.count == self.numberOfLines {
                        limitedText.append(contentsOf: element)
                        
                        let subAttrText = NSAttributedString.init(string: element, attributes: normalAttributes)
                        attrText.append(subAttrText)
                        break
                    }
                    
                    // 最后一行已写满，替换并添加自定义句尾
                    let taildots = "...  "
                    let tailMore = "详情"
                    let tailWords = taildots + tailMore
                    
                    let lastLineCalcLabel = Item12089TailLabel.init(frame: CGRect.init(x: 0, y: 0, width: self.bounds.size.width, height: 1000000))
                    lastLineCalcLabel.font = self.font
                    lastLineCalcLabel.text = tailWords + element
                    
                    if let lastLineText = lastLineCalcLabel.getEachOfLineTexts().first, !lastLineText.isEmpty {
                        //tailWords 替换到正确位置
                        var newLastLineText = lastLineText
                        if let tailWordsRange = newLastLineText.range(of: tailWords) {
                            newLastLineText.removeSubrange(tailWordsRange)
//                            newLastLineText.append(contentsOf: tailWords)
                            
                            let subAttrText = NSAttributedString.init(string: newLastLineText + taildots, attributes: normalAttributes)
                            attrText.append(subAttrText)
                            
                            
                            let tailMoreFont = self.tailMoreFont ?? UIFont.systemFont(ofSize: 10, weight: .medium)
                            let tailMoreColor = self.tailMoreColor ?? self.textColor
                            let moreAttrText = NSAttributedString.init(string: tailMore,
                                                                       attributes: [
                                                                        .font: tailMoreFont,
                                                                        .foregroundColor: tailMoreColor,
                                                                       ])
                            attrText.append(moreAttrText)
                            
                            
                            limitedText.append(contentsOf: newLastLineText)
                        }
                    }
                } else {
                    limitedText.append(contentsOf: element)
                    
                    let subAttrText = NSAttributedString.init(string: element, attributes: normalAttributes)
                    attrText.append(subAttrText)
                }
            }
        } else {
            limitedText.append(contentsOf: text)
            
            let subAttrText = NSAttributedString.init(string: text, attributes: normalAttributes)
            attrText.append(subAttrText)
        }
        
//        self.text = limitedText
        self.attributedText = attrText
    }
    
    func getEachOfLineTexts() -> [String] {
        guard let text = self.text,
              let font = self.font else {
            return []
        }
        
        guard let ctfont = CTFontCreateUIFontForLanguage(.system, font.pointSize, nil) else {
            return []
        }
        
        let rect = self.bounds
        let attributedString = NSMutableAttributedString.init(string: text)
        attributedString.addAttribute(NSAttributedString.Key(kCTFontAttributeName as String),
                                      value: ctfont,
                                      range: NSRange(location: 0, length: attributedString.length))
        
        let frameSetter = CTFramesetterCreateWithAttributedString(attributedString)
        let path = CGMutablePath()
        path.addRect(CGRect(x: 0, y: 0, width: rect.size.width, height: 100000), transform: .identity)
        let frame = CTFramesetterCreateFrame(frameSetter, CFRangeMake(0, 0), path, nil)
        let lines = CTFrameGetLines(frame)
        
        var linesArray: [String] = []
        for line in (lines as Array) {
            let lineRef = line as! CTLine
            let lineRange: CFRange = CTLineGetStringRange(lineRef)
            let range = NSRange(location: lineRange.location, length: lineRange.length)
            let lineString = (text as NSString).substring(with: range)
            linesArray.append(lineString)
        }
        
        if ykrl_isResponsiveLayout() { //响应式条件下补齐两行
            let blankLineCount: Int = max(0, 2 - linesArray.count)
            for _ in 0..<blankLineCount {
                linesArray.append("\n")
            }
        }
        return linesArray
    }

}
