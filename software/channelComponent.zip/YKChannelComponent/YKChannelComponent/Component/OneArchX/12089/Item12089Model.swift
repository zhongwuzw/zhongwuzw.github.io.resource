//
//  Item12089Model.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2023/4/23.
//  Copyright © 2023 Youku. All rights reserved.
//

import OneArchSupport4Youku
import YoukuResource

class Item12089Model: HomeItemModel {
    
    public var newMoreDesc: String?
    public var playButtonText: String?
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        
        if var reason = self.reason {
            // 组件12088 推荐理由强制使用品牌色填充
            reason.titleColorStr = "TOKEN_ykn_brandInfo"
            self.reason = reason
        }
        
        if let newMoreDesc = dataInfo["newMoreDesc"] as? String {
            self.newMoreDesc = newMoreDesc
        }
        
        if let playButtonText = dataInfo["playButtonText"] as? String {
            self.playButtonText = playButtonText
        }
    }
    
}
