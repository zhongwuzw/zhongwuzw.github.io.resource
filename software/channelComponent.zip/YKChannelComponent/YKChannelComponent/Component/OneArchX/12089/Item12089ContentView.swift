//
//  Item12089ContentView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/5/30.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import YKHome
import OneArchSupport
import OneArchSupport4Youku
import OneArch
import YKProtocolSDK
import YoukuResource

class Item12089ContentView: AccessibilityView, ReserveButtonDelegate, TrackShowButtonDelegate {
    
    weak var model: Item12089Model?
    
    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = .ykn_primaryBackground
        view.layer.masksToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.clipsToBounds = true
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var playIconView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFill
        view.image = UIImage.init(named: "st_player_plugin_icon_play")
        return view
    }()
    
    lazy var posterImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
        
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.tabbar_text_m_weight(.semibold)
        view.numberOfLines = 0
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_secondaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.numberOfLines = 1
        return view
    }()
    
    lazy var moreDescLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_recommend_info
        view.font = YKNFont.posteritem_subhead()
        view.lineBreakMode = .byTruncatingTail
        view.numberOfLines = 1
        return view
    }()
    
    lazy var favorBtn: Item12089TrackShowButton = {
        let view = Item12089TrackShowButton.init()
        view.whenTapped {
            self.favorAction()
        }
        view.isHidden = true
        view.delegate = self
        return view
    }()
    
    lazy var reserveView: Item12089ReserveButton = {
        let button = Item12089ReserveButton()
        button.delegate = self
        return button
    }()
    
    lazy var playBtn: UIButton = {
        let view = UIButton()
        view.backgroundColor = .clear
        view.clipsToBounds = true
        view.titleLabel?.font = YKNFont.posteritem_subhead_weight(.medium)
        view.isUserInteractionEnabled = true
        var titleColor = UIColor.ykn_brandInfo
        view.setTitleColor(titleColor, for: UIControl.State.normal)
        view.layer.borderColor = UIColor.ykn_border.cgColor
        view.layer.cornerRadius = 15
        view.isUserInteractionEnabled = false
        
        view.isHidden = true
        return view
    }()
    
    lazy var commentLabel: Item12089TailLabel = {
        let label = Item12089TailLabel()
        label.font = YKNFont.posteritem_subhead()
        label.tailMoreFont = YKNFont.posteritem_subhead_weight(.medium)
        label.tailMoreColor = UIColor.ykn_secondaryInfo
        label.textAlignment = .left
        label.numberOfLines = 2
        label.lineBreakMode = .byCharWrapping
        return label
    }()
    
    lazy var reasonList: ReasonListView = {
        let view = ReasonListView.init()
        return view
    }()
    
    //MARK:
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddCollectSuccessNotication), name: NSNotification.Name.init("kBSAddCollectSuccess"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelCollectSuccessNotication), name: NSNotification.Name.init("kBSCancelCollectSuccess"), object: nil)
        
        addSubview(contentView)
        contentView.addSubview(videoImageView)
        videoImageView.addSubview(playIconView)
        
        contentView.addSubview(posterImageView)
        contentView.addSubview(titleLabel)

        contentView.addSubview(subtitleLabel)
        contentView.addSubview(moreDescLabel)
        contentView.addSubview(favorBtn)
        contentView.addSubview(reasonList)
        contentView.addSubview(reserveView)
        contentView.addSubview(playBtn)

        contentView.addSubview(commentLabel)
    }
    
    var sceneTitleColor: UIColor?
    var sceneThemeColor: UIColor?
    var sceneButtonSelectBgColor: UIColor?
    
    func fillData(_ itemModel: Item12089Model, _ layout: OneArchSupport4Youku.LayoutModel, _ item: IItem?) {
        model = itemModel

        self.backgroundColor = .clear
        contentView.backgroundColor = .clear
        contentView.frame = CGRect.init(x: 0, y: 0, width: self.bounds.size.width, height: self.height)

        // 封面 (横版)
        let coverImage = itemModel.img ?? ""
        videoImageView.frame = itemModel.layout.cover?.renderRect ?? .zero
        videoImageView.ykn_setImage(withURLString: XCDNSTRING(coverImage),
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        // 播放按钮
        refreshPlayIconView()

        // poster (竖版)
        if let posterLayout = itemModel.layout.extendExtra?["poster"] as? ImageLayoutModel {
            posterImageView.frame = posterLayout.renderRect
        }
        posterImageView.ykn_setImage(withURLString: itemModel.verticalImg ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        Service.summary.attach(itemModel.summary, toView: posterImageView)
        Service.mark.attach(itemModel.mark, toView: posterImageView)
        
        if let cardData = item?.getCard()?.model?.data as? [String: Any], let startNum = cardData["start"] as? String{
            if let startNum = YKCCUtil.getIntValue(startNum) {
                let rankIndex: Int = itemModel.rankInvolved ? (startNum + ((item?.getComponent()?.index) ?? 0)) : 0
                Service.rank.attach(rankIndex, toView: self.posterImageView)
            }
        } else {
            let rankIndex: Int = itemModel.rankInvolved ? (((item?.getComponent()?.index) ?? 0) + 1) : 0
            Service.rank.attach(rankIndex, toView: self.posterImageView)
        }
        
        if let scene = item?.getPage()?.pageModel?.scene {
            itemModel.scene = scene
        }
                
        // 标题
        titleLabel.text = itemModel.title
        titleLabel.textColor = sceneUtil(UIColor.ykn_primaryInfo, sceneColor: itemModel.scene?.sceneTitleColor())
        titleLabel.frame = itemModel.layout.title?.renderRect ?? .zero
        
        // 票房信息
        if let moreDescLayout = layout.extendExtra?["newMoreDesc"] as? TextLayoutModel {
            moreDescLabel.text = itemModel.newMoreDesc
            moreDescLabel.frame = moreDescLayout.renderRect
        } else {
            moreDescLabel.frame = .zero
        }
        
        // 子标题
        Service.reasons.detach(fromView: contentView)
        
        subtitleLabel.text = itemModel.subtitle
        subtitleLabel.textColor = sceneUtil(UIColor.ykn_secondaryInfo, sceneColor: itemModel.scene?.sceneSubTitleColor())
        subtitleLabel.frame = itemModel.layout.subtitle?.renderRect ?? .zero

        // +追按钮 / 播放按钮
        favorBtn.isHidden = true
        reserveView.isHidden = true
        playBtn.isHidden = true
        if let trackShow = itemModel.trackShow {
            bindStatisticsService()
            favorBtn.isHidden = false
            //有+追按钮N刷指数不显示
            moreDescLabel.isHidden = true
            
            self.fillFavorBtn(model)
            if let trackShowButtonLayout = itemModel.layout.extendExtra?["trackShowButton"] as? TextLayoutModel {
                favorBtn.frame = trackShowButtonLayout.renderRect
            }
            if let trackShowButton12089 = itemModel.layout.extendExtra?["trackShowButton12089"] as? TrackShowButtonLayoutModel {
                favorBtn.fillModel(trackShow, layoutModel: trackShowButton12089)
            } else {
                favorBtn.fillModel(trackShow)
            }
            favorBtn.update(trackShow.isFavor ?? false)
            
        } else if let reserve = itemModel.reserveModel{
            reserveView.isHidden = false
            //有预约按钮N刷指数不显示
            moreDescLabel.isHidden = true
            
            if let reserveViewLayout = itemModel.layout.extendExtra?["reserveButton"] as? TextLayoutModel {
                reserveView.frame = reserveViewLayout.renderRect
            }
            reserveView.refresh(reserveModel: reserve, scene: model?.scene)
            
        } else {
            playBtn.isHidden = false
            
            if let playButtonLayout = itemModel.layout.extendExtra?["playButton"] as? TextLayoutModel {
                playBtn.frame = playButtonLayout.renderRect
            }

            if let playButtonText = itemModel.playButtonText {
                playBtn.setTitle(playButtonText, for: UIControl.State.normal)
            } else {
                playBtn.setTitle("看正片", for: UIControl.State.normal)
            }
            playBtn.layer.backgroundColor = UIColor.ykn_co_15.cgColor
            playBtn.setTitleColor(UIColor.ykn_brandInfo, for: UIControl.State.normal)
        }
        
        // 底部多行文案，先布局后填充文本
        if let layout = itemModel.layout.extendExtra?["commentDesc"] as? TextLayoutModel {
            self.commentLabel.frame = layout.renderRect
        } else {
            self.commentLabel.frame = .zero
        }
        
        self.commentLabel.text = ""
        if let text = model?.comment?.text, !text.isEmpty {
            commentLabel.text = text
            commentLabel.adjustToShortTail()
            commentLabel.textColor = sceneUtil(UIColor.ykn_secondaryInfo, sceneColor: itemModel.scene?.sceneSubTitleColor())
        }
        
        if let layout = itemModel.layout.extendExtra?["reasonList"] as? TextLayoutModel {
            self.reasonList.frame = layout.renderRect
        } else {
            self.reasonList.frame = .zero
        }
        
        if let reasonList = itemModel.reasonList, reasonList.count > 0, let layout = itemModel.layout.extendExtra?["reasonList"] as? TextLayoutModel {
            self.reasonList.fillData(itemModel, maxWidth: layout.renderRect.width)
            self.reasonList.isHidden = false
        } else {
            self.reasonList.isHidden = true
        }
        
        weak var weakItem = item
        Service.action.bind(itemModel.action, self) {
        } didAction: {
            weakItem?.sendEventMessage("yksc.event.item.rec.tap", params: ["recType":"card"])
        }
        
        // 播放
        let playerModel = itemModel.playerModel
        let size = videoImageView.bounds.size
        Service.player.attach(playerModel, toView: videoImageView, displayFrame: CGRect.init(origin: CGPoint.zero, size: size))
    }
        
    func refreshPlayIconView() {
        guard let itemModel = model else {
            playIconView.isHidden = true
            return
        }
        
        if let playerModel = itemModel.playerModel {
            let size = CGSize.init(width: 45, height: 45)
            let x = (videoImageView.bounds.width - size.width) / 2
            let y = (videoImageView.bounds.height - size.height) / 2
            playIconView.frame = CGRect.init(x: x, y: y, width: size.width, height: size.height)
            
            if playerModel.playerEngineType == .Live {
                //extraExtend.liveState:0 预约中 1直播中 2回看
                if let liveState = itemModel.extraExtend["liveState"] as? String, liveState == "1" {
                    playIconView.isHidden = false
                } else {
                    playIconView.isHidden = true
                }
            } else {
                playIconView.isHidden = !playerModel.canPlay
            }
        }
    }
    
    func bindStatisticsService() {
        guard let trackShow = model?.trackShow else {
            return
        }
        
        if let isFavor = trackShow.isFavor, isFavor == true {
            let actionModel =  self.model?.extraExtend["uncollectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        } else {
            let actionModel = self.model?.extraExtend["collectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        }
    }
    
    func favorAction() {
        guard let favor = model?.trackShow,
              let isFavor = favor.isFavor
        else {
            return
        }
        
        var params = [String : Any]()
        params["isFavor"] = isFavor
        params["id"] = favor.favorId ?? ""
    
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channel.function.adaptor.zhuiju"), object: nil, userInfo: params)
    }
    
    @objc func handleAddCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: true)
    }
    
    @objc func handleCancelCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: false)
    }
    
    func handleNotication(notification: Notification, favored: Bool) {
        guard let userInfo = notification.userInfo,
              let targetId = userInfo["targetId"] as? String
        else {
            return
        }
                
        guard let favor = model?.trackShow,
              let currentId = favor.favorId,
              let _ = favor.isFavor
        else {
            return
        }
        favor.isFavor = favored
        
        guard currentId == targetId else {
            return
        }
        
        if let trackShowButton12089 = model?.layout.extendExtra?["trackShowButton12089"] as? TrackShowButtonLayoutModel {
            favorBtn.fillModel(favor, layoutModel: trackShowButton12089)
        } else {
            favorBtn.fillModel(favor)
        }
        favorBtn.update(favored)
        
        bindStatisticsService()
    }

    func didUpdateReserveButtonFrame() {
        guard let itemModel = model else {
            return
        }
        
        if let reserveViewLayout = itemModel.layout.extendExtra?["reserveButton"] as? TextLayoutModel {
            reserveView.right = self.width
            reserveView.centerY = reserveViewLayout.renderRect.maxY - 14
        }
    }
    
    func trackShowButtonRenderSizeDidChange(button: TrackShowButton) {
        guard let itemModel = model else {
            return
        }
        
        if let reserveViewLayout = itemModel.layout.extendExtra?["trackShowButton"] as? TextLayoutModel {
            button.right = self.width
            button.centerY = reserveViewLayout.renderRect.maxY - 14
        }
    }
    
    private func fillFavorBtn(_ model: BaseItemModel?) {
        guard let model = model, let favor = model.trackShow, !favorBtn.isHidden else {
            return
        }
        
        favorBtn.countLabel.font = YKNFont.button_text()
        favorBtn.canShowGradientLayer = false
        favorBtn.selectTextColor = .ykn_quaternaryInfo
        favorBtn.selectBgColor = .ykn_seconarySeparator
        favorBtn.selectBorderWidth = 0.0
        
        favorBtn.unselectTextColor = .ykn_brandInfo
        favorBtn.unselectBgColor = .ykn_border
        favorBtn.unselectBorderWidth = 0.0
    }
}
