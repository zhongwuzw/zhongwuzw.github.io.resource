//
//  Component12089Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/5/30.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import YoukuAnalytics

class Component12089Delegate: NSObject, ComponentDelegate {
    
    var compPaddingTop:CGFloat = 0
    weak var displayingItemView: Item12089ContentView?
    
    static func create() -> ComponentDelegate {
        return Component12089Delegate.init()
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_line_spacing() /* 不能用token YKNGap.youku_comp_margin_bottom() */, right: YKNGap.youku_margin_right())
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        config.responsiveAdjustableMinColumnCount = 2
        config.responsiveMinColumnCount = 2
        config.responsiveMaxColumnCount = 2
        return config
        
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [PlayerScrollEndCompEventHandler()]
    }
    
    var componentWrapper: ComponentWrapper?
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.receiveEstimatedLayout(itemWidth)
        let item = self.component?.getItems()?.first as? IItem
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    
    func componentDidInit() {
        let item = self.component?.getItems()?.first as? IItem

        if let title = item?.itemModel?.title, title.count > 0 {
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 3.0
            paragraphStyle.lineBreakMode = .byTruncatingTail
            let attributedTitle = NSAttributedString.init(string: title, attributes: [.paragraphStyle: paragraphStyle])
            item?.itemModel?.attributedTitle = attributedTitle
        }
   
        if let itemModel = item?.itemModel {
            
            let followActionModel = ActionFactoryV2(itemModel, spmDExt: "_watching")
            
            let unfollowActionModel = ActionFactoryV2(itemModel, spmDExt: "_cancelwatching")
            
            if followActionModel != nil {
                itemModel.extraExtend["collectActionModel"] = followActionModel
            }
            
            if unfollowActionModel != nil {
                itemModel.extraExtend["uncollectActionModel"] = unfollowActionModel
            }
            
        }
        
        //TODO:
        self.sendCustomPlayerStatistic()
        
//        DispatchQueue.main.async {
//            self.addObservers()
//        }
    }
    
    func receiveEstimatedLayout(_ itemWidth: Double) {
        let item = self.component?.getItems()?.first as? IItem

        let itemLayout = item?.itemModel?.layout
        
        let itemHeight = self.calcItemHeight(itemWidth)
        
        itemLayout?.renderRect = CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight)
    }
    
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item12089ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }

    func reuseView(itemView: UIView) {
        let item = self.component?.getItems()?.first as? IItem

        guard let itemView = itemView as? Item12089ContentView else {
            return
        }
        guard let itemModel = item?.itemModel as? Item12089Model else {
            return
        }
        guard let itemLayout = item?.itemModel?.layout else {
            return
        }

        displayingItemView = itemView
        itemView.fillData(itemModel, itemLayout, item)
    }

    // MARK: 坑位布局计算
    func calcItemHeight(_ itemWidth: Double) -> Double {
        let item = self.component?.getItems()?.first as? IItem

        guard let itemLayout = item?.itemModel?.layout else { return 0 }
        guard let itemModel = item?.itemModel as? Item12089Model else { return 0 }
        
        itemLayout.extendExtra = [String: Any]()
         
        let posterImageWidthFactor: CGFloat = 3.0
        let videoImageWidthFactor: CGFloat = 16 * (4.0 / 9.0)
        let a: CGFloat = (itemWidth - YKNGap.youku_picture_title_spacing()) / (posterImageWidthFactor + videoImageWidthFactor)
        
        let posterImageWidth: CGFloat = ceil(posterImageWidthFactor * a)
        let posterImageHeight: CGFloat = ceil((posterImageWidthFactor * a) * 4.0/3.0)
        let poster = ImageLayoutModel.init()
        poster.renderRect = CGRect.init(origin: .zero, size: CGSize.init(width: posterImageWidth, height: posterImageHeight))
        itemLayout.extendExtra?["poster"] = poster
        
        if let mark = itemModel.mark {
            itemLayout.mark = Service.mark.estimatedLayout(mark, toViewSize: poster.renderRect.size)
        }
        
        if let summary = itemModel.summary {
            itemLayout.summary = Service.summary.estimatedLayout(summary, toViewSize: poster.renderRect.size)
        }
             
        let videoImgX: CGFloat = posterImageWidth + YKNGap.youku_picture_title_spacing()
        let videoImgWidth: CGFloat = itemWidth - videoImgX
        let videoImgHeight: CGFloat = posterImageHeight
        let cover = ImageLayoutModel.init()
        cover.renderRect = CGRect.init(origin: .init(x: videoImgX, y: 0), size: CGSize.init(width: videoImgWidth, height: videoImgHeight))
        itemLayout.cover = cover
        
        if let lbtexts = itemModel.lbTexts {
            itemLayout.lbTexts = Service.lbTexts.estimatedLayout(lbtexts, toViewSize: cover.renderRect.size)
        }
        
        var textWidthMax: CGFloat = itemWidth
        
        let midAreaStartY: CGFloat = cover.renderRect.maxY + YKNGap.dim_6()
        var descStartY: CGFloat = 0
        if let trackShow = itemModel.trackShow {
            let buttonLayout = TextLayoutModel.init()
            let buttonSize = CGSize.init(width: 110, height: 28)
            let x: CGFloat = itemWidth - buttonSize.width
            let y: CGFloat = midAreaStartY
            
            let trackShowBtnLayout = Item12089TrackShowButton.getEstimatedLayout(trackShow)
            itemLayout.extendExtra?["trackShowButton12089"] = trackShowBtnLayout
            buttonLayout.renderRect = CGRect.init(origin: CGPoint.init(x: x, y: y), size: buttonSize)
            itemLayout.extendExtra?["trackShowButton"] = buttonLayout
            
            textWidthMax = x - 20.0
            descStartY = max(descStartY, buttonLayout.renderRect.maxY + YKNGap.dim_6())
            
        } else if itemModel.reserveModel != nil {
            let buttonLayout = TextLayoutModel.init()
            let buttonSize = CGSize.init(width: 110, height: 28)
            let x: CGFloat = itemWidth - buttonSize.width
            let y: CGFloat = midAreaStartY
            buttonLayout.renderRect = CGRect.init(origin: CGPoint.init(x: x, y: y), size: buttonSize)
            itemLayout.extendExtra?["reserveButton"] = buttonLayout
            
            textWidthMax = x - 20.0
            descStartY = max(descStartY, buttonLayout.renderRect.maxY + YKNGap.dim_6())
            
        } else {
            // 看正片按钮
            let buttonLayout = TextLayoutModel.init()
            let buttonSize = CGSize.init(width: 60, height: 28)
            let x: CGFloat = itemWidth - buttonSize.width
            let y: CGFloat = midAreaStartY
            buttonLayout.renderRect = CGRect.init(origin: CGPoint.init(x: x, y: y), size: buttonSize)
            itemLayout.extendExtra?["playButton"] = buttonLayout
            
            textWidthMax = x - 84.0 - YKNGap.dim_5() - YKNGap.dim_6()
            descStartY = max(descStartY, buttonLayout.renderRect.maxY + YKNGap.dim_6())
        }
        
        let titleFont = YKNFont.top_navbar_text_weight(.semibold)
        let titleHeight = YKNFont.height(with: titleFont, lineNumber: 1)
        let subtitleFont = YKNFont.posteritem_subhead()
        let subtitleHeight = YKNFont.height(with: subtitleFont, lineNumber: 1)
        
        // 标题
        let titleLayout = TextLayoutModel()
        titleLayout.font = titleFont
        let x: CGFloat = 0
        let y: CGFloat = midAreaStartY + 4.0
        titleLayout.renderRect = CGRect.init(x: x, y: y, width: textWidthMax, height: titleHeight)
        itemLayout.title = titleLayout
        
        let subtitleY: CGFloat = titleLayout.renderRect.maxY + 6.0
        
        // 副标题
        let subtitleLayout = TextLayoutModel()
        subtitleLayout.font = subtitleFont
        subtitleLayout.renderRect = CGRect.init(x: x, y: subtitleY, width: itemWidth, height: subtitleHeight)
        itemLayout.subtitle = subtitleLayout
        descStartY = subtitleLayout.renderRect.maxY + YKNGap.dim_2()
        
        // 票房信息 (如有) newMoreDesc
        if let newMoreDesc = itemModel.newMoreDesc, newMoreDesc.isEmpty == false {
            let newMoreDescLayout = TextLayoutModel()
            newMoreDescLayout.font = subtitleFont
            let moreDescY: CGFloat = titleLayout.renderRect.minY + 6
            newMoreDescLayout.renderRect = CGRect.init(x: textWidthMax + YKNGap.dim_6(), y: moreDescY, width: 85.0, height: subtitleHeight)
            itemLayout.extendExtra?["newMoreDesc"] = newMoreDescLayout
        }
        
        if let comment = itemModel.comment,
           let desc = comment.text,
           !desc.isEmpty {
            
            let descLayout = TextLayoutModel()
            descLayout.font = YKNFont.posteritem_subhead()
            var descLineHeight = YKNFont.height(with: descLayout.font, lineNumber: 1)
            let _: CGSize = calcStringSize(desc, font: descLayout.font, size: .zero)
            descLineHeight = descLineHeight + 3
            
            descLayout.renderRect = CGRect.init(x: x, y: descStartY, width: itemWidth, height: descLineHeight)
            itemLayout.extendExtra?["commentDesc"] = descLayout
            
            descStartY = descStartY + descLineHeight + YKNGap.dim_6()
        }
        
        // 推荐理由
        var reasonListMaxY: CGFloat = 0
        if let reasonList = itemModel.reasonList, !reasonList.isEmpty {
            let reasonListLayout = TextLayoutModel()
            let height = ReasonListView.titleHeight()
            reasonListLayout.renderRect = CGRect.init(origin: CGPoint.init(x: 0, y: descStartY), size: CGSize.init(width: itemWidth, height: height))
            itemLayout.extendExtra?["reasonList"] = reasonListLayout
            reasonListMaxY = reasonListLayout.renderRect.maxY
        }
        
        itemLayout.renderRect = .init(x: 0, y: 0, width: itemWidth, height: reasonListMaxY)
        return Double(itemLayout.renderRect.height)
    }
    
    func sendCustomPlayerStatistic() {
        let item = self.component?.getItems()?.first as? IItem

        guard let itemModel = item?.itemModel else {
            return
        }
        if let canPlay = itemModel.playerModel?.canPlay, !canPlay {
            return
        }
        if itemModel.playerModel?.playerEngineType != .Live {
            return
        }
        let report = itemModel.action?.report
        let pageName = report?.pageName ?? "page_homeselect"
        let arg1 = "PREVIEW_LIVE_PREVIEW_STAT"
        let arg2 = report?.spm
        let arg3 = report?.scm

        var args = [String: Any]()
        if let spm = report?.spm {
            args["spm"] = spm
        }
        if let scm = report?.scm {
            args["scm"] = scm
        }
        if let utparam = report?.utparam {
            args["utparam"] = utparam
        }

        if let itemTag = itemModel.type {
            args["item"] = itemTag
        }

        if self.isPageInPreload() {
            args["is_home_cache"] = "1"
        } else {
            args["is_home_cache"] = "0"
        }

        if let liveState = itemModel.extraExtend["liveState"] {
            args["live_state"] = liveState
        }

        args["pageName"] = pageName

        YoukuAnalytics.sharedInstance()?.collectALiCustomEvent(withEventID: "19999",
                                                               pageName: pageName,
                                                               arg1: arg1,
                                                               arg2: arg2,
                                                               arg3: arg3,
                                                               args: args
        )
    }
    
    func isPageInPreload() -> Bool {
        let item = self.component?.getItems()?.first as? IItem

        guard let pageModel = item?.getPage()?.pageModel else {
            return false
        }
        if pageModel.dataState == .cache || pageModel.dataState == .default {
            return true
        }
        return false
    }

    
}
