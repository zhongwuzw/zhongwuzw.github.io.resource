//
//  Item12089Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/5/30.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item12089Delegate: NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item12089Model.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    
    func columnCount() -> CGFloat {
        return 1.0
    }
    
    //改为custom布局 以下实现不生效
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler(),
                PlayerToolsEventHandler(),
                ItemPlayerProgressEventHandler()]
    }
    
    func itemDidInit() {
        
    }

    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item12089ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }

    func reuseView(itemView: UIView) {
        
    }

}
