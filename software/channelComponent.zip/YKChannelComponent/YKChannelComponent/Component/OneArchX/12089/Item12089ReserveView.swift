//
//  Item12089ReserveView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2023/4/19.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArchSupport4Youku

class Item12089ReserveButton: ReserveCountButton {
    
    override func refreshButtonStatus() {
        super.refreshButtonStatus()
        
        guard let reserveModel = reserveModel else {
            return
        }
        
        let reserved = reserveModel.isReserve
        if !reserved {
            self.gradientLayerView.removeFromSuperview()
            self.backgroundColor = .ykn_brandInfo.withAlphaComponent(0.12)
            countLabel.textColor = .ykn_brandInfo
            titleLabel.textColor = .ykn_brandInfo
            unitLabel.textColor = .ykn_brandInfo
            verticalBar.backgroundColor = .ykn_brandInfo.withAlphaComponent(0.5)
        }
        refreshButtonFrame()
    }
    
    override func refreshButtonFrame() {
        super.refreshButtonFrame()
        
        if countLabel.isHidden == false {
            countLabel.sizeToFit()
            verticalBar.bounds = CGRect.init(x: 0, y: 0, width: 1, height: 14)
            unitLabel.sizeToFit()
        }
        
        titleLabel.sizeToFit()
        
        let countSize = countLabel.bounds.size
        let unitSize = unitLabel.isHidden ? .zero : unitLabel.bounds.size
        let imageSize = CGSize.init(width: 14, height: 14)
        let textSize = titleLabel.bounds.size
        
        //预约按钮起始欢度
        var width = textSize.width + YKNGap.dim_7() * 2
        
        if countLabel.isHidden == false {
            width += countSize.width
            width += unitSize.width
            width += (YKNGap.dim_5() * 2)
            width += verticalBar.bounds.width
            width -= 1
        }
        
        if !imageView.isHidden, let icon = reserveModel?.icon, !icon.isEmpty {
            width += imageSize.width + YKNGap.dim_4() // +icon 大小
        }
        
        //设置最大最小宽度
        width = max(ReserveCountButton.buttonWidth(), width)
        width = min(250, width)
        
        let origin = self.frame.origin
        self.frame = CGRect.init(x: origin.x, y: origin.y, width: width, height: Item12089ReserveButton.buttonHeight())
        self.layer.cornerRadius = self.height / 2.0
    }
        
    override class func buttonHeight() -> CGFloat {
        let base: CGFloat = 28
        if ykrl_isResponsiveLayout() {
            return base * 1.1 // 20221129版本 目标值1.1倍，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        } else {
            return base
        }
    }
}


class Item12089TrackShowButton: TrackShowButton{
    
    static let regalarSizeFor12089: CGSize = CGSize.init(width: 42.0, height: 28.0)
    static let zhuiCharSizeFor12089: CGSize = CGSize.init(width: 14, height: 14)
    
    override func fillModel(_ model: FavorModel) {
        
        super.fillModel(model)
        
        if model.needShowCount {
            countLabel.text = model.formatCountText
            countLabel.isHidden = false
            verticalBar.isHidden = false
            
            countLabel.sizeToFit()
            countLabel.left = 15
            countLabel.centerY = self.height / 2
            
            let verticalBarHeight: CGFloat = 12
            let verticalBarWidth: CGFloat = 1
            let verticalBarX: CGFloat = countLabel.frame.maxX + 4
            let verticalBarY: CGFloat = (self.height - verticalBarHeight) / 2
            verticalBar.frame = CGRect.init(x: verticalBarX, y: verticalBarY, width: verticalBarWidth, height: verticalBarHeight)
            
            let titleSize = Item12089TrackShowButton.zhuiCharSizeFor12089
            let titleX: CGFloat = verticalBar.frame.maxX + 4
            let titleY: CGFloat = (self.height - titleSize.height) / 2
            titleLabel.frame = CGRect.init(origin: CGPoint.init(x: titleX, y: titleY), size: titleSize)
            
            let totalWidth: CGFloat = titleLabel.frame.maxX + 15
            self.bounds = CGRect.init(origin: .zero, size: CGSize.init(width: totalWidth, height: Item12089TrackShowButton.regalarSizeFor12089.height))
        } else {
            countLabel.isHidden = true
            verticalBar.isHidden = true
            
            self.bounds = CGRect(origin: .zero, size: Item12089TrackShowButton.regalarSizeFor12089)
            self.gradientLayerView.frame = self.bounds
            self.gradientLayer.frame = self.gradientLayerView.bounds
            
            self.titleLabel.frame = self.bounds
        }
        
        self.delegate?.trackShowButtonRenderSizeDidChange(button: self)
    }
    
    static func getEstimatedLayout(_ model: FavorModel) -> TrackShowButtonLayoutModel {
        var layModel = TrackShowButtonLayoutModel()
        
        if model.needShowCount {
            let boundsHeight = Item12089TrackShowButton.regalarSizeFor12089.height
            
            let countLabelSize = calcStringSize(model.formatCountText, font: YKNFont.button_text_weight(.semibold), size: .zero)
            let countLabelX: CGFloat = 15
            let countLabelY: CGFloat = (boundsHeight - countLabelSize.height) / 2
            let countLabelFrame = CGRect.init(x: countLabelX, y: countLabelY, width: countLabelSize.width, height: countLabelSize.height)
            
            let verticalBarHeight: CGFloat = 12
            let verticalBarWidth: CGFloat = 1
            let verticalBarX: CGFloat = countLabelSize.width + countLabelX + 4
            let verticalBarY: CGFloat = (boundsHeight - verticalBarHeight) / 2
            let verticalBarFrame = CGRect.init(x: verticalBarX, y: verticalBarY, width: verticalBarWidth, height: verticalBarHeight)
            
            let titleSize = Item12089TrackShowButton.zhuiCharSizeFor12089
            let titleX: CGFloat = verticalBarFrame.maxX + 4
            let titleY: CGFloat = (boundsHeight - titleSize.height) / 2
            let titleLabelFrame = CGRect.init(origin: CGPoint.init(x: titleX, y: titleY), size: titleSize)
            
            let totalWidth: CGFloat = titleLabelFrame.maxX + 15
            let totalSize = CGSize.init(width: totalWidth, height: boundsHeight)
            
            layModel.countLabelFrame = countLabelFrame
            layModel.verticalBarFrame = verticalBarFrame
            layModel.titleLabelFrame = titleLabelFrame
            layModel.totalSize = totalSize
        } else {
            layModel.titleLabelFrame = CGRect(origin: .zero, size: Item12089TrackShowButton.regalarSizeFor12089)
            layModel.totalSize = Item12089TrackShowButton.regalarSizeFor12089
        }
        
        return layModel
    }
    
    override func update(_ state : Bool) {
        
        if state {
            titleLabel.text = "\u{e714}"
            layer.borderWidth = selectBorderWidth
            layer.borderColor = selectBorderColor.cgColor
            backgroundColor = selectBgColor
            gradientLayerView.isHidden = true
            gradientLayer.isHidden = true
            titleLabel.textColor = selectTextColor
            countLabel.textColor = selectTextColor
            verticalBar.backgroundColor = selectTextColor
        } else {
            titleLabel.text = "\u{e712}"
            layer.borderWidth = unselectBorderWidth
            layer.borderColor = unselectBorderColor.cgColor
            backgroundColor = unselectBgColor
            if canShowGradientLayer {
                gradientLayerView.isHidden = false
                gradientLayer.isHidden = false
            } else {
                gradientLayerView.isHidden = true
                gradientLayer.isHidden = true
            }
            titleLabel.textColor = unselectTextColor
            countLabel.textColor = unselectTextColor
            verticalBar.backgroundColor = unselectTextColor
        }
        countLabel.font = YKNFont.button_text_weight(.semibold)
    }
    
    override func darkModeIsChanged() {
        //
    }
    
}
