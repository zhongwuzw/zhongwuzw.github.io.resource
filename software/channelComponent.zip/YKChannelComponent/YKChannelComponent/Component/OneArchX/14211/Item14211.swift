//
//  Item14211.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/3.
//  Copyright © 2023 Youku. All rights reserved.
//

import OneArch
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout

class Item14211: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T: NodeModel>() -> T.Type? {
        return HomeItemModel.self as? T.Type
    }
    
    func itemDidInit() {
        
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return backgroundImageSize().height
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14211ContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14211ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? HomeItemModel else {
            return
        }

        itemView.fillData(itemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [
            ItemImmersionBackgroundAdapterPlugin()
        ]
    }
    
    func backgroundImageSize() -> CGSize {
        var itemHeight: CGFloat = 0
        
        itemHeight += STATUSBAR_HEIGHT
        itemHeight += 44 // 普通navigationbar height
        itemHeight += 1
        itemHeight += YKNFont.height(with: Item14211ContentView.getSubtitleFont(), lineNumber: 1)
        itemHeight += 9
        
        return .init(width: YKRLScreenWidth(), height: itemHeight)
    }

}
