//
//  Item14211ContentView.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/3.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import YKResponsiveLayout
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item14211ContentView: UIView, ItemImmersionBackgroundViewContainer {

    //MARK: - Property
    lazy var imageView: UIImageGradientView = {
        let imageView = UIImageGradientView.init(frame: CGRect.zero)
        imageView.contentMode = .scaleAspectFill
        imageView.visualEffectView.isHidden = false
        imageView.visualEffectView.backgroundColor = .clear
        imageView.gradientView.isHidden = true
        return imageView
    }()
    
    lazy var contentView: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var imageShadowViewContainer: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var imageShadowView: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var iconImageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFit
        imageView.layer.masksToBounds = true
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.font = Item14211ContentView.getSubtitleFont()
        label.textAlignment = .center
        label.textColor = .white.withAlphaComponent(0.3)
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        label.isUserInteractionEnabled = true
        return label
    }()
    
    private var imageMaskColor: UIColor?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        let navigationbarHeight: CGFloat = 44
        
        addSubview(imageView)
        let imageViewHeight: CGFloat = STATUSBAR_HEIGHT + navigationbarHeight
        let imageViewWidth: CGFloat = self.width
        imageView.frame = CGRect.init(origin: .zero, size: CGSize.init(width: imageViewWidth, height: imageViewHeight))
        
        addSubview(imageShadowViewContainer)
        imageShadowViewContainer.frame = self.bounds
        
        imageShadowViewContainer.addSubview(imageShadowView)
        imageShadowView.frame = imageView.frame
        let startColor = UIColor.createColorWithHexRGB(colorStr: "#4C222226").withAlphaComponent(0.01)
        let endColor = UIColor.createColorWithHexRGB(colorStr: "#16161a")
        Service.viewInnerGradient.attach(.bottom, toView: imageShadowView, scope: imageViewHeight, startColor: startColor, endColor: endColor)
        
        let pureColorView = UIView.init()
        let pureColorViewHeight: CGFloat = self.height - imageViewHeight
        let pureColorViewY: CGFloat = imageShadowView.frame.maxY
        pureColorView.frame = CGRect.init(x: 0, y: pureColorViewY, width: self.width, height: pureColorViewHeight)
        pureColorView.backgroundColor = endColor
        imageShadowViewContainer.addSubview(pureColorView)
        
        addSubview(contentView)
        contentView.addSubview(iconImageView)
        contentView.addSubview(subtitleLabel)
        
        let statusBarHeight = STATUSBAR_HEIGHT
        contentView.frame = CGRect.init(x: 0, y: statusBarHeight, width: self.width, height: self.height - statusBarHeight)
        
        let iconImageHeight: CGFloat = 28
        let iconImageWidth: CGFloat = self.width - 60 * 2
        let iconImageY: CGFloat = (navigationbarHeight - iconImageHeight) / 2
        iconImageView.frame = CGRect.init(x: 0, y: iconImageY, width: iconImageWidth, height: iconImageHeight)
        
        let subtitleX: CGFloat = YKNGap.youku_margin_left()
        let subtitleY: CGFloat = navigationbarHeight + 1
        let subtitleWidth: CGFloat = self.width - subtitleX * 2
        let subtitleHeight: CGFloat = YKNFont.height(with: subtitleLabel.font, lineNumber: 1)
        subtitleLabel.frame = CGRect.init(x: subtitleX, y: subtitleY, width: subtitleWidth, height: subtitleHeight)
    }
    
    func fillData(_ itemModel: HomeItemModel) {
        
        // fill background image
        var params = [String : Any]()
        params["fade"] = true
        let imageURL = itemModel.gifImg ?? itemModel.img
        imageView.ykn_setImage(withURLString: imageURL, module: "nodepage", imageSize: .zero, parameters: params, completed: nil)
        
        // fill title image
        if let iconURL = itemModel.icon {
            let navigationbarHeight: CGFloat = 44
            let iconImageHeight: CGFloat = 28
            let iconImageWidth: CGFloat = self.width - 60 * 2
            let iconImageY: CGFloat = (navigationbarHeight - iconImageHeight) / 2
            iconImageView.frame = CGRect.init(x: 0, y: iconImageY, width: iconImageWidth, height: iconImageHeight)
            
            var params = [String : Any]()
            params["fade"] = true
            params["placeholderColor"] = UIColor.clear
            
            iconImageView.ykn_setImage(withURLString: iconURL, module: "nodepage", imageSize: .zero, parameters: params) { [weak self] (image, error, info) in
                if let self = self,
                   let image = image,
                   image.size.height > 0 {
                    
                    let imageRenderWidth: CGFloat = min(iconImageWidth, image.size.width/image.size.height * iconImageHeight)
                    
                    //先恢复正常
                    self.iconImageView.frame = CGRect.init(x: 0, y: iconImageY, width: imageRenderWidth, height: iconImageHeight)
                    //再居中对齐
                    self.iconImageView.left = (self.width - imageRenderWidth) * 0.5
                }
            }
        } else {
            iconImageView.image = nil
        }
        
        // fill subtitle
        subtitleLabel.text = itemModel.subtitle
    }
    
    static func getSubtitleFont() -> UIFont  {
        return YKNFont.quaternary_auxiliary_text()
    }

    // MARK: ItemImmersionBackgroundViewContainer
    func immersionBackgroundView() -> UIView {
        return imageView
    }
}

