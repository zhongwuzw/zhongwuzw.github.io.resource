//
//  Card15048.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/10/25.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import OneArch
import YKResponsiveLayout
import OneArchSupport4Youku
import YoukuResource


public class Card15048BackgroundViewHelper:NSObject, CAAnimationDelegate {
    public static let shared =  Card15048BackgroundViewHelper()
    public static let height:CGFloat = 146.0
    public var showCardBg:Bool = false
    
    var bgLevel:Component14343BgLevel = .vip
    var grayAnimating:Bool = false
    var grayAnimationFinished:Bool = false
    var grayAnimationCompletion:((Bool) -> Void)?
    
    var alphaAnimationCompletion:((Bool) -> Void)?

    lazy var backgroundView: UIView = {
        let view = UIView.init(frame: CGRect(x: 0, y: 0, width: SCREEN_WIDTH, height: Card15048BackgroundViewHelper.height))
        view.layer.masksToBounds = true
        view.layer.cornerRadius = 14.0
        view.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner, .layerMaxXMaxYCorner]
        return view
    }()
    
    lazy var backgroundGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
//        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init(x: 0, y: 0)
        layer.endPoint = CGPoint.init(x: 1, y: 0)

        self.backgroundView.layer.insertSublayer(layer, at: 0)
        
        layer.frame = self.backgroundView.bounds
        return layer
    }()
    
    lazy var vipImageView: UIImageGIFView = {
        let view = UIImageGIFView.init(frame: CGRect.init(x: 0, y: 0, width: 140, height: 66))
        view.contentMode = .scaleAspectFill
        view.layer.masksToBounds = true
        view.isUserInteractionEnabled = true
        self.backgroundView.addSubview(view)
        return view
    }()
    
    lazy var bottomSceneView: UIView = {
        let view = UIView.init(frame: CGRect(x: 0, y: Card15048BackgroundViewHelper.height - 80, width: backgroundView.width, height: 80))
        self.backgroundView.addSubview(view)
        return view
    }()
    
    lazy var bottomSceneGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 0.5), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init(x: 0, y: 0)
        layer.endPoint = CGPoint.init(x: 0, y: 1)

        self.bottomSceneView.layer.insertSublayer(layer, at: 0)
        
        layer.colors = [UIColor.ykn_primaryBackground.withAlphaComponent(0).cgColor, UIColor.ykn_primaryBackground.withAlphaComponent(1).cgColor]
        layer.frame = self.bottomSceneView.bounds
        return layer
    }()
    
    
    override init() {
        super.init()
        NotificationCenter.default.addObserver(self, selector: #selector(refreshTheme), name: Notification.Name(rawValue: "YKNThemeDidChangeNotification"), object: nil)
        
        vipImageView.sd_setImage(with: URL(string: self.getVipBgUrl(.vip))) { image, error, type, url in
            
        }
    }
    
    func refreshUIStatus(_ showCardBg:Bool, grayAnimationFinished:Bool, bgLevel:Component14343BgLevel, completion: ((Bool) -> Void)? = nil) {
        
        weak var weakSelf = self
        DispatchQueue.main.async {
            self.backgroundGradientLayer.frame = self.backgroundView.bounds
            self.bottomSceneView.frame = self.backgroundView.bounds
            self.bottomSceneView.height = 80.0
            self.bottomSceneView.bottom = self.backgroundView.height
            self.bottomSceneGradientLayer.frame = self.bottomSceneView.bounds
            self.vipImageView.right = self.backgroundView.width
            
            self.bgLevel = bgLevel
            self.grayAnimationFinished = grayAnimationFinished
            self.refreshBgColors(grayAnimationFinished, bgLevel: bgLevel)
            
            if showCardBg == self.showCardBg {
                return
            }
            guard let weakSelf = weakSelf else { return }
            weakSelf.showCardBg = showCardBg
            weakSelf.backgroundView.isHidden = !showCardBg
            if showCardBg {
                self.alphaAnimationCompletion = completion
                weakSelf.backgroundView.alpha = 0
                UIView.animate(withDuration: 0.33) {
                    weakSelf.backgroundView.alpha = 1
                } completion: { finished in
                    weakSelf.backgroundView.alpha = 1
                    weakSelf.alphaAnimationCompletion?(true)
                }
            }
            
        }
    }
    
    func getVipBgUrl(_ bgLevel: Component14343BgLevel) -> String {
        
        switch bgLevel {
        case .svip:
            return  "https://liangcang-material.alicdn.com/prod/upload/6315ae7f9c604aa49a31094f13220ebd.webp.png"
        case .noGradient:
            return "https://liangcang-material.alicdn.com/prod/upload/3dd2148f88244da6aecc8710191571fd.webp.png"
        case .vip, .gradient:
            return "https://gw.alicdn.com/imgextra/i4/O1CN016rLQvX1cBRn2wtKDK_!!6000000003562-2-tps-420-198.png"
        }
    }
    
    func refreshBgColors(_ grayAnimationFinished:Bool, bgLevel:Component14343BgLevel) {
        NSLog("[14343] refreshBgColors grayAnimationFinished:\(grayAnimationFinished), bgLevel:\(bgLevel)")

        var colors = [CGColor]()
        switch bgLevel {
        case .svip:
            colors = getSvipColors()
            self.backgroundGradientLayer.colors = colors
            break
        case .vip:
            colors = getVipColors()
            self.backgroundGradientLayer.colors = colors
            break
        case .gradient:
            if !grayAnimating {
                if !grayAnimationFinished {
                    colors = getVipColors()
                    self.backgroundGradientLayer.colors = colors
                    NSLog("[14343] refreshBgColors set vip colors")
                } else {
                    colors = getGrayColors()
                    self.backgroundGradientLayer.colors = colors
                    NSLog("[14343] refreshBgColors set gray vip colors")
                }
            }
            
            break
        case .noGradient:
            colors = getVipColors()
            self.backgroundGradientLayer.colors = colors
            break
        }
        let isSvip = bgLevel == .svip
        vipImageView.sd_setImage(with: URL(string: self.getVipBgUrl(bgLevel))) { image, error, type, url in
            
        }
        if isDarkMode() {
            vipImageView.alpha = 0.08
        } else {
            vipImageView.alpha = 1.0
        }
    }
    
    func startGrayAnimation(_ completion:@escaping ((Bool) -> Void)) {
        NSLog("[14343] startGrayAnimation")

        self.grayAnimating = true
        self.grayAnimationCompletion = completion
        self.backgroundGradientLayer.colors = getVipColors()
        let animation = CABasicAnimation(keyPath: "colors")
//        animation.fromValue = getVipColors()
        animation.toValue = getGrayColors()
        animation.duration = 0.5
        animation.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
        animation.delegate = self
        animation.isRemovedOnCompletion = false
        animation.fillMode = .forwards
        self.backgroundGradientLayer.add(animation, forKey: "bgGrayAnimation")
    }
    
    public func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        NSLog("[14343] animationDidStop")

        if flag {
            self.grayAnimationFinished = true
            self.grayAnimating = false
            self.grayAnimationCompletion?(true)
            if bgLevel == .gradient {
                self.refreshBgColors(true, bgLevel: bgLevel)
            }
            self.backgroundGradientLayer.removeAllAnimations()
        }
    }
    
    let vipColors:[CGColor] = [UIColor.createColorWithHexRGB(colorStr: "#FFE6B5").cgColor,
                     UIColor.createColorWithHexRGB(colorStr: "#FFECC8").cgColor]
    let vipDarkColors:[CGColor] = [UIColor.createColorWithHexRGB(colorStr: "#201203").cgColor,
                                   UIColor.createColorWithHexRGB(colorStr: "#261502").cgColor,
                     UIColor.createColorWithHexRGB(colorStr: "#4A3723").cgColor]
    
    let svipColors:[CGColor] = [UIColor.createColorWithHexRGB(colorStr: "#F2D8FF").cgColor,
              UIColor.createColorWithHexRGB(colorStr: "#FDDDF0").cgColor,
              UIColor.createColorWithHexRGB(colorStr: "#FFF0D1").cgColor]
    let svipDarkColors:[CGColor] = [UIColor.createColorWithHexRGB(colorStr: "#1F0D27").cgColor,
              UIColor.createColorWithHexRGB(colorStr: "#381C2C").cgColor]

    let grayColors:[CGColor] = [UIColor.createColorWithHexRGB(colorStr: "#E5E0D7").cgColor,
                                UIColor.createColorWithHexRGB(colorStr: "#F3F0EC").cgColor]
    let grayDarkColors:[CGColor] = [UIColor.createColorWithHexRGB(colorStr: "#201203").cgColor,
                                    UIColor.createColorWithHexRGB(colorStr: "#25252B").cgColor,
                                    UIColor.createColorWithHexRGB(colorStr: "#35312D").cgColor]
    
    func getVipColors() -> [CGColor] {
        if isDark() {
            return self.vipDarkColors
        }
        return self.vipColors
    }
    
    func getSvipColors() -> [CGColor] {
        if isDark() {
            return self.svipDarkColors
        }
        return self.svipColors
    }
     
    func getGrayColors() -> [CGColor] {
        if isDark() {
            return self.grayDarkColors
        }
        return self.grayColors
    }
    
    
    @objc func refreshTheme() {
        weak var weakSelf = self
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
            guard let weakSelf = weakSelf else { return }
            
            NSLog("[14343][dark] app dark mode:\(isDarkMode())")
            weakSelf.bottomSceneGradientLayer.colors = [UIColor.ykn_primaryBackground.withAlphaComponent(0).cgColor, UIColor.ykn_primaryBackground.withAlphaComponent(1).cgColor]
            
            weakSelf.refreshBgColors(self.grayAnimationFinished, bgLevel: self.bgLevel)

        }
    }
    
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
}

open class Card15048: BaseCardDelegate {
    open override func getCardBackgroundConfig() -> CardBackgroundConfig? {
        var config = CardBackgroundConfig()
        
        if let sceneModel = card?.cardModel?.scene,
           let backgroundColor = sceneModel.sceneBgColor() {
            config.backgroundColor = backgroundColor
        } else {
            config.backgroundImageHeight = Card15048BackgroundViewHelper.height
            config.backgroundRenderView = Card15048BackgroundViewHelper.shared.backgroundView
            config.backgroundRenderView?.isHidden = !Card15048BackgroundViewHelper.shared.showCardBg
            config.backgroundImage = nil
        }
        return config
    }
    
    open override func isShowHeader() -> Bool {
        return false
    }
    
    open override func cardDidInit() {
        self.card?.sendEventMessage("cardDidInit", params: nil)
    }
}
