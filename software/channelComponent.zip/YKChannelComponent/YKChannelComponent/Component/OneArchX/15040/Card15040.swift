//
//  Card15040.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/12/7.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuResource

class Card15040: BaseCardDelegate {
    override func layoutConfig() -> CardLayoutConfig {
        var config = super.layoutConfig()
        config.padding = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        return config
    }
    override func isShowHeader() -> Bool {
        return false
    }
}
