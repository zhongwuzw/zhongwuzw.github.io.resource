//
//  Item14053.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item14053: ComponentNavigateItem {
    override func itemWidth() -> CGFloat {
        return 48
    }
    override func reuseView(itemView: UIView) {
        super.reuseView(itemView: itemView)
        guard let itemView = itemView as? ComponentNavigateItemView else {
            return
        }
        guard let text = itemView.label.text else {
            return
        }
        let weekday = weekday()
        if text == weekday {
            itemView.label.text = "今"
            if let item = self.item, let componentModel = item.getComponent()?.model as? BaseComponentModel {
                if let index = componentModel.extraExtend["navigate.index"] as? Int {
                    return
                }
                itemView.selectItem() //首次锚定到该index
            }
        }
    }
    
    func weekday() -> String {
        let date = Date.init()
        var calendar = Calendar.init(identifier: .gregorian)
        guard let zone = TimeZone.init(identifier: "Asia/Shanghai") else {
            return "日"
        }
        calendar.timeZone = zone
        let components = calendar.dateComponents(in: zone, from: date)
        guard let weekday = components.weekday else {
            return "日"
        }
        let list = ["日", "一", "二", "三", "四", "五", "六"]
        let index = (weekday + 6) % 7
        if index < list.count {
            return list[index]
        }
        return "日"
    }
    
}
