//
//  Component14309.swift
//  YKChannelComponent
//
//  Created by better on 2023/5/17.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit

class Component14309: Component14308 {
    override func columnCount() -> CGFloat {
        return 1
    }
}
