//
//  BizDailyLimitService.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/12/26.
//  Copyright © 2023 Youku. All rights reserved.
//  封装每日频控逻辑

import Foundation
import YKSCService

public class BizDailyLimitService {
    var dailyCountKey = "" //每日次数key
    var saveDateKey = ""  //日期key
    var limit = 0 // 总次数
    
    var userInfo: String = ""
    
    lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        return formatter
    } ()
    
    public init(dailyCountKey: String, saveDateKey: String) {
        self.dailyCountKey = dailyCountKey
        self.saveDateKey = saveDateKey
    }
    
    // userInfo: 可以传业务域说明，便于打印区分
    public func canShowOnce(_ userInfo: String = "") -> Bool {
        self.userInfo = userInfo
        
        let currentDate = self.dateFormatter.string(from: Date())
        let todayShowNum = self.todayShowNum(currentDate)
        let serverTotalNum = self.limit
        YKSCScreenLogUtil.printLog("[\(userInfo)] 今日已看\(todayShowNum)次 总共可看\(serverTotalNum)次", color: .green)
        return serverTotalNum > 0 && serverTotalNum > todayShowNum
    }
    
    public func saveShowNum() {
        let currentDate = self.dateFormatter.string(from: Date())
        var dailyCount = self.todayShowNum(currentDate)
        dailyCount += 1
        
        UserDefaults.standard.set(dailyCount, forKey: dailyCountKey)
        UserDefaults.standard.set(currentDate, forKey: saveDateKey)
        YKSCScreenLogUtil.printLog("[\(userInfo)] 更新已看次数\(dailyCount)", color: .green)
    }
    
    func todayShowNum(_ currentDate: String) -> Int {
        var dailyCount = 0
        let savedDate = UserDefaults.standard.string(forKey: saveDateKey)
        if savedDate != currentDate {
            dailyCount = 0
        } else {
            dailyCount = UserDefaults.standard.integer(forKey: dailyCountKey)
        }
        return dailyCount
    }
}
