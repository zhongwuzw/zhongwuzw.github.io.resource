//
//  BizUtil.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/3/22.
//  Copyright © 2024 Youku. All rights reserved.
//  分发业务通用能力，当前是精选等

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKChannelPage

class HomeBizUtil {
    // 判断当前是精选页
    static func isSelectionPage(_ page: IPage?) -> Bool {
        return (page?.model as? SelectionPageModel) != nil
    }
    
    // 首页当前在请求中
    static func currentIsFirstPageRequest(_ page: IPage?) -> Bool {
        return (page?.pageContext?.concurrentDataMap["currentIsRequest"] as? Bool) ?? false
    }
    
    // 替换抽屉头
    static func replaceCardHeader(oriCardModel: BaseCardModel?, newCardModel: BaseCardModel?) {
        guard let oriCardModel = oriCardModel,
              let newCardModel = newCardModel else {
            return
        }
        
        oriCardModel.titleImg = newCardModel.titleImg
        oriCardModel.title = newCardModel.title
        oriCardModel.titleImgDark = newCardModel.titleImgDark
        oriCardModel.icon = newCardModel.icon
        
        oriCardModel.keywords = newCardModel.keywords
        oriCardModel.keywordsScrollInterval = newCardModel.keywordsScrollInterval
        
        oriCardModel.moduleId = newCardModel.moduleId
        oriCardModel.moduleTitleType = newCardModel.moduleTitleType
        
        oriCardModel.vipSaleModel = newCardModel.vipSaleModel
    }
    
    // 是猜追抽屉
    static func isCaiZhuiCard(_ card: ICard?) -> Bool {
        if let comps = card?.getComponents() {
            for comp in comps {
                if let model = comp.model, (model.type == "14027" || model.type == "14299") {
                    return true
                }
            }
        }
        
        return false
    }
    
    static func isLunboType(_ type: String) -> Bool {
        let sliders = ["14016", "14049", "14052", "14076", "14204", "14298", "14313", "14336"]

        if sliders.contains(type) {
            return true
        }
        return false
    }
    
    // 从cms原始数据,解析抽屉data数据
    static func parseCardJson(result: [String:Any]?, requestModel: RequestModel?) -> [String:Any]? {
        //->data -> mscode -> data
        guard let data = result?["data"] as? [String:Any] else {
            return nil
        }
        let mscode = requestModel?.mscode ?? "2019061000"
        guard let mscodeJson = data[mscode] as? [String:Any] else {
            return nil
        }
        guard let dataJson = mscodeJson["data"] as? [String:Any], 
                let level = YKCCUtil.getIntValue(dataJson["level"]),
                level == 1, 
                let data = dataJson["data"] as? [String:Any] , data.count > 0 else {
            return nil
        }
        return dataJson
    }
}
