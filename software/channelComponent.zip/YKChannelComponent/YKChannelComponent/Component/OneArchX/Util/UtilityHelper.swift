//
//  UtilityHelper.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/5.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArchSupport
import OneArchSupport4Youku
import YKProtocolSDK
import YoukuResource
import AliReachability
import DYKIOSCategory

class UtilityHelper: NSObject {
    
    //预约操作
    class func doReservation(reserveModel:ReserveModel?) {
        guard let reserveModel = reserveModel else {
            return
        }
        guard let dingyueSDK = DYKServiceManager.sharedInstance().service(forProtocolName: "YKDingYueProtocol") as? YKDingYueProtocol else {
            return
        }
        
        var params = [String:Any]()
        params["bizId"] = reserveModel.bizId
        params["reservationId"] = reserveModel.rid
        params["reservationType"] = reserveModel.reservationType
        params["deviceType"] = "IPHONE"
        let report = reserveModel.isReserve ? reserveModel.cancelReserveReport : reserveModel.addReserveReport
        params["src"] = report?.spm
        if reserveModel.isReserve {
            dingyueSDK.help_cancelReservation?(params) { _, _, _ in
                
            }
        } else {
            dingyueSDK.help_addReservation?(params) { _, _, _ in

            }
        }
    }
    
    class func doBatchReservation(models: [ReserveModel]?, successCallback:((Bool) -> Void)?) {
        guard let dingyueSDK = DYKServiceManager.sharedInstance().service(forProtocolName: "YKDingYueProtocol") as? YKDingYueProtocol else {
            return
        }
        guard let models = models, models.count > 0 else {
            return
        }

        let firstModel = models[0]
        
        var params = [String:Any]()
        params["bizId"] = firstModel.bizId
        
        var contentIdList = [String]()
        var contentVmpCodeMap = [String:String]()
        for model in models {
            if let rid = model.rid {
                contentIdList.append(rid)
                if let vmpCode = model.vmpCode {
                    contentVmpCodeMap[rid] = vmpCode
                }
            }
        }
        params["contentIdList"] = contentIdList
        params["contentVmpCodeMap"] = contentVmpCodeMap

        params["reservationType"] = firstModel.reservationType
        params["deviceType"] = "IPHONE"
        let report = firstModel.addReserveReport
        params["src"] = report?.spm
        params["showSDKToast"] = true

        dingyueSDK.help_batchAddReservation?(params) { isSuccess, status, json in
            successCallback?(isSuccess)
        }
    }

    //是否wifi
    class func isWifi() -> Bool {
        return NWReachabilityManager.shareInstance()?.currentNetworkStatus() == NetworkStatus.ReachableViaWiFi
    }

    //判断播放器是否在可见区域
    class func isPlayerInValidArea(playerView:UIView) -> Bool {
        let navheight = STATUSBAR_HEIGHT + 84
        let playerFrame = playerView.convert(playerView.bounds, to: nil)
        if playerFrame.maxY > navheight, playerFrame.minY < SCREEN_HEIGHT - 49 {
            return true
        }
        return false
    }

    //使用预览视频vid，处理report的spmD、scm
    class func replaceReportModelForPreview(actionModel: ActionModel?, previewVid: String?) {
        let newReport = actionModel?.report?.replaceSpmD(spmd: "superpreview")
        if let scm = newReport?.scm, scm.isEmpty == false, let index = scm.lastIndex(of: "."),
            let previewVid = previewVid, previewVid.count > 0 {
            let scm1 = scm.prefix(upTo: index)
            let newScm = scm1 + ".\(previewVid)"
            newReport?.args?["scm"] = newScm
        }
        actionModel?.report = newReport
    }
}

func getDataFromYKHomeAdapter(_ event: String, _ params: NSMutableDictionary = NSMutableDictionary.init()) -> NSMutableDictionary {
    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channelComponent.onearch.adaptor.getparams"), object: nil, userInfo: [
                "event" : event,
                "params": params,
            ])
    return params
}

public func isiPad() -> Bool {
    return UIDevice().userInterfaceIdiom == .pad
}
