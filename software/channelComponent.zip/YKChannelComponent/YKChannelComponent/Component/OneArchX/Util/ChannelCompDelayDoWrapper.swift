//
//  ChannelCompDelayDoWrapper.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/2/29.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
protocol ChannelCompDelayDoWrapperDelegate : NSObjectProtocol {
    func wrapperDelayDo(_ wrapper: ChannelCompDelayDoWrapper)
}

class ChannelCompDelayDoWrapper: NSObject {
    var started: Bool = false
    
    weak var delegate: ChannelCompDelayDoWrapperDelegate?
    
    func delayTimeDo(_ delayTime: TimeInterval) {
        started = true
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        if delayTime > 0 {
            self.perform(#selector(delayDo), with: nil, afterDelay: delayTime)
        } else {
            delayDo()
        }
    }
    
    func cancelDelayDo() {
        NSObject.cancelPreviousPerformRequests(withTarget: self)
    }
    
    @objc func delayDo() {
        if delegate != nil {
            delegate?.wrapperDelayDo(self)
        }
        started = false
    }
    
    deinit {
        NSObject.cancelPreviousPerformRequests(withTarget: self)
    }
}
