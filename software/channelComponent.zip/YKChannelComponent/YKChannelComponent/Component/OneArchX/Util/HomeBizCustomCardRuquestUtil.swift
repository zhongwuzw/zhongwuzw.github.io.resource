//
//  HomeBizCustomRuquestUtil.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/3/22.
//  Copyright © 2024 Youku. All rights reserved.
//  自定义抽屉请求服务封装

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKChannelPage

class HomeBizCustomCardRuquestUtil {
    weak var domainModel: YoukuNodeModel?
    var requestModel: RequestModel? {
        get {
            if let model = domainModel {
                return model.requestModel
            }
            
            return nil
        }
    }
    
    func buildRequestParams(_ appendParams:[String:Any]?) -> [String: Any] {
        
        var requestParams = [String: Any]()

        //接口版本
        requestParams["api_version"] = "1.0"
        
        //业务参数
        requestParams["ms_codes"] = requestModel?.mscode ?? "2019061000"
        
        requestParams["debug"] = 0
        requestParams["device"] = "IPHONE"
        
        let params = NSMutableDictionary.init()
        
        params["bizKey"] = requestModel?.bizKey ?? requestParamsDefaultBizKey()
        params["nodeKey"] = requestModel?.nodeKey ?? "SELECTION"
        params["pageSize"] = 10
        params["pageNo"] = 1
        params["session"] = buildSession()
        params["bizContext"] = buildBizContext(appendParams)
        
        params["debug"] = "0"
        params["gray"] = "0"
        params["device"] = "IPHONE"

        requestParams["params"] =  getJSONStringFromDictionary(dictionary: params)

        return requestParams
    }
    
    //MARK: - private
    func buildReqAPI() -> String {
        if let apiName = requestModel?.apiName , apiName.isEmpty == false {
            return apiName
        }
        return "mtop.youku.columbus.home.query"
    }
    
    func buildSession() -> String? {
        if let session = requestModel?.session as? NSDictionary , session.allKeys.count > 0 {
            return getJSONStringFromDictionary(dictionary: session)
        }
        return nil
    }
    
    func buildBizContext(_ appendParams: [String:Any]?) -> String? {
        let tempDict = NSMutableDictionary.init()
        if let originContext = requestModel?.bizContext as? [String : Any], originContext.keys.count > 0 {
            for (k, v) in originContext {
                tempDict[k] = v
            }
        }
        
        // extra extend
        if let requestModel = requestModel {
            tempDict.addEntries(from: requestModel.extraExtend)
        }
        
        if let appendParams = appendParams, appendParams.count > 0 {
            tempDict.addEntries(from: appendParams)
        }
        
        if tempDict.allKeys.count > 0 {
            return getJSONStringFromDictionary(dictionary: tempDict)
        }
        
        return nil
    }
}
