//
//  SliderAdUtil.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/3/6.
//  Copyright © 2024 Youku. All rights reserved.
//  新轮播通用方法封装

import Foundation
import YKSCService

class SliderNewUtil {
    static func replaceItemsSpmD(_ originItemsJson: [[String: Any]]) -> [[String: Any]] {
        var itemsJson = originItemsJson
        
        // 更新spmD (数据位置：data.action.report.spmD)
        var replaceDItemsJson = [[String: Any]]()
        var spmDHasChanged = false
            
        for i in 0..<originItemsJson.count {
            var item = originItemsJson[i]
            if var data = item["data"] as? [String: Any],
               var action = data["action"] as? [String: Any],
               var report = action["report"] as? [String: Any],
               var trackInfo = report["trackInfo"] as? [String: Any],
               let oSpmD = report["spmD"] as? String, oSpmD.isEmpty == false {
                if let lastCharacter = oSpmD.last, let lastDigit = Int(String(lastCharacter)), lastDigit > 0 , lastDigit <= itemsJson.count {
                    if lastDigit != (i + 1) {
                        var spmD = oSpmD
                        spmD.removeLast()
                        spmD = spmD + "\(i + 1)"
                        NSLog("[新轮播] 数据 埋点更新spmD o:\(oSpmD) n:\(spmD)")
                        report["spmD"] = spmD
                        trackInfo["originalSpmD"] = oSpmD
                        report["trackInfo"] = trackInfo
                        action["report"] = report
                        data["action"] = action
                        item["data"] = data
                        replaceDItemsJson.append(item)
                        
                        spmDHasChanged = true
                        continue
                    }
                }
            }
            
            replaceDItemsJson.append(item)
        }
         
        YKSCScreenLogUtil.printLog("新轮播 数据 埋点更新完spmD 原:\(itemsJson.count) 新:\(replaceDItemsJson.count) 有做替换:\(spmDHasChanged)", color: .purple)
        if spmDHasChanged {
            itemsJson = replaceDItemsJson
        }
        return itemsJson
    }
}
