//
//  Component14295.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/3/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import SwiftUI
import OneArchBridge
import OneArchSupport
import WindVane
import YoukuCore
import DYKNavigator
import SVPullToRefresh

class Component14295: NSObject, ComponentDelegate {

    weak var view: UIView? = nil
    var componentWrapper: ComponentWrapper?
    
    func componentDidInit() {
        NotificationCenter.default.addObserver(self, selector: #selector(authSuccessNotification(_:)), name: Notification.Name(rawValue: "WVUIAccessbilityBridgeAuthSuccess"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(authSuccessNotification(_:)), name: Notification.Name(rawValue: "AccessbilityAuthSuccess"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(loginChanged(_:)), name: Notification.Name(rawValue: "HYUserSessionUpdatedNotification"), object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    public func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeComponentModel.self as? T.Type
    }
 
    public func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        config.preferredCardSpacingTop = 6.0
        config.headerBottomMargin = 0.0
        config.rowSpacing = 0.0
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.footerTopMargin = 0.0
        config.preferredRowHeight = 0.0
        return config
    }
    
    @objc func authSuccessNotification(_ notif: Notification?) {
        if let item = self.component?.getItems()?.first,
           let model = item.homeItemModel {
            model.state = 1
            model.title = "已完成视障碍人员身份认证"
            model.subtitle = "优酷无障碍剧场"
            setup()
        }
    }
    
    @objc func loginChanged(_ notif: Notification?) {
        if let scrollView = self.component?.pageContext?.getContainerView() as? UICollectionView {
            scrollView.triggerPullToRefresh()
        }
    }
    
    func userIsLogin() -> Bool {
        return User.current() != nil
    }
    
    func showLoginPage() {
        let loginSuccessBlock: @convention(block) () -> Void = { [weak self] in
            self?.component?.getPage()?.triggerFirstPageRequest()
        }
        
        let castBlock = unsafeBitCast(loginSuccessBlock, to: AnyObject.self)

        let navparam = DYKNavigatorParamers.init()
        navparam.nativParamers = ["finishLogin" : castBlock]
        DYKNavigatorManager.sharedInstance().openURL("youku://UserLogin", navigatorParams: navparam)
    }
    
    func columnCount() -> CGFloat {
        return 1
    }

    func reuseId() -> String? {
        return "14295"
    }
    
    /// item高度
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 61
    }

    /// 初始化item view
    func createView(_ itemSize: CGSize) -> UIView {
        let frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
        let v = UIView.init(frame:frame)
        v.backgroundColor = .clear
        v.isAccessibilityElement = true
        return v
    }
    
    /// 复用
    func reuseView(itemView: UIView) {
        guard let v = itemView as? UIView else {
            return
        }
        view = v
        setup()
    }
    
    func setup() {
        guard let view = view else {
            return
        }

        view.removeAllSubviews()
        
        var paddingHorizontal = YKNGap.youku_margin_left()
        if ykrl_isResponsiveLayout() {
            let contentMaxWidth: CGFloat = min(675, ceil(view.width * 645.0 / 768.0)) /* 对齐规则12004组件 */
            paddingHorizontal = (view.width - contentMaxWidth) / 2
            paddingHorizontal = max(0, paddingHorizontal)
        }
        
        let title = UILabel()
        title.frame = CGRect.init(x: paddingHorizontal, y: 18, width: 300, height: 20)
        title.font = UIFont.systemFont(ofSize: 18)
        title.textColor = UIColor.ykn_primaryInfo
        if let color = self.component?.compModel?.scene?.sceneTitleColor() {
            title.textColor = color
        }
        
        view.addSubview(title)
        
        let subtitle = UILabel()
        subtitle.frame = CGRect.init(x: paddingHorizontal, y: 41, width: 300, height: 20)
        subtitle.font = UIFont.systemFont(ofSize: 14)
        subtitle.textColor = UIColor.ykn_tertiaryInfo
        if let color = self.component?.compModel?.scene?.sceneSubTitleColor() {
            subtitle.textColor = color
        }
        view.addSubview(subtitle)

        let action = UILabel()
        let actionWidth: CGFloat = 80
        let actionHeight: CGFloat = 36
        let actionX: CGFloat = view.width - actionWidth - paddingHorizontal
        let actionY: CGFloat = title.frame.minY + (subtitle.frame.maxY - title.frame.minY - actionHeight) / 2
        
        action.frame = CGRect.init(x: actionX, y: actionY, width: actionWidth, height: actionHeight)
        action.font = UIFont.systemFont(ofSize: 14)
        action.textAlignment = .center
        action.backgroundColor = UIColor(white: 1, alpha: 0.1)
        action.clipsToBounds = true
        action.layer.cornerRadius = 18
        view.addSubview(action)
        view.isUserInteractionEnabled = true

        if let item = self.component?.getItems()?.first,
           let model = item.homeItemModel {
            title.text = model.title
            subtitle.text = model.subtitle
            if model.state > 0 {
                action.text = "已认证"
                action.accessibilityLabel = "已认证"
                action.textColor = UIColor.wvColor(withHex: 0x999999)
                Service.action.bind(nil, view)
                view.isUserInteractionEnabled = false
            } else {
                action.text = "去认证"
                action.accessibilityLabel = "去认证,按钮"
                action.textColor = UIColor.wvColor(withHex: 0xeaeaea)
                view.isUserInteractionEnabled = true

                if userIsLogin() {
                    Service.action.bind(model.action, view)
                } else {
                    view.whenTapped { [weak self] in
                        self?.showLoginPage()
                    }
                }
            }
            view.accessibilityLabel = (title.text ?? "") + "," + (subtitle.text ?? "") + "," + (action.accessibilityLabel ?? "")
        }
    }
}

class Item14295: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T: NodeModel>() -> T.Type? {
        return HomeItemModel.self as? T.Type
    }
    
    func itemDidInit() {

    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0.0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView()
    }
    
    func reuseView(itemView: UIView) {
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
}
