//
//  Card15001.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/14.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku

class Card15001ComponentJsonExtracter: DefaultComponentJsonExtracter {

    override public init() {
        super.init()
    }

    // MARK: - 原始数据加工

    override public func getComponentsJson(cardJson: [String : Any]?, card: ICard?) -> Result<[[String : Any]], Error> {
        guard let subCardsJson = cardJson?["nodes"] as? [[String: Any]] else {
            return .success([[String : Any]]()) //允许没有组件列表
        }
        var componentJson = [String:Any]()
        componentJson["type"] = "15001.multitab.header"
        var itemsJson = [[String:Any]]()
        for subCard in subCardsJson {
            var itemJson = [String:Any]()
            itemJson["type"] = "15001.multitab.header.item"
            itemJson["data"] = subCard["data"]
            itemsJson.append(itemJson)
        }
        componentJson["nodes"] = itemsJson
        return .success([componentJson])
    }
}

class Card15001: BaseCardDelegate {

    override func enableMultiTabCard() -> Bool {
        return true
    }

    /// component数据解析格式代理
    override func getComponentJsonExtracter() -> ComponentJsonExtracter? {
        return Card15001ComponentJsonExtracter.init()
    }
}
