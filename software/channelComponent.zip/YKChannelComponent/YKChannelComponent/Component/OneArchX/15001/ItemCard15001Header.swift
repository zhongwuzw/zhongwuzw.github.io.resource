//
//  ItemCard15001Header.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/14.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

class ItemCard15001HeaderView: AccessibilityView {

    weak var item:IItem?
    
    //MARK: Property
    lazy var titleLabel:UILabel = {
        let label = UILabel(frame:CGRect.init(x: 0, y: 0, width: 30 * YKNSize.yk_icon_size_scale(), height: 30 * YKNSize.yk_icon_size_scale()))
        label.backgroundColor = .clear
        label.textAlignment = .center
        label.font = YKNFont.akrobatFont(ofSize: 18)
        label.textColor = UIColor.ykn_primaryInfo
        return label
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.titleLabel)
        NotificationCenter.default.addObserver(self, selector: #selector(selectItemChanged), name: NSNotification.Name("item.sel.index.changed"), object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(item: IItem?, component: IComponent?, clickCallback:(()->Void)?) {
        self.item = item
        guard let item = item, let itemModel = item.model as? BaseItemModel else {
            return
        }
        guard let compModel = component?.model as? BaseComponentModel else {
            return
        }
        refreshSelectItem()
        self.titleLabel.text = itemModel.title
        titleLabel.sizeToFit()
        self.width = titleLabel.width

        // action
        Service.statistics.bind(itemModel.action?.report, self, .Defalut)
        weak var weakself = self
        self.whenTapped {
            if weakself?.isItemSelected() == true {
                return
            }
            if weakself?.isItemSelected() == false {
                weakself?.item?.scrollTo(at: .center, animated: true)
                compModel.extraExtend["item.select.index"] = item.index
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "item.sel.index.changed"), object: nil, userInfo: nil)
            }
            component?.getCard()?.changeMultiTabCardIndex(item.index)

            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "card.15001.subcard.changed"), object: nil, userInfo: nil)

            clickCallback?()
        }
    }

    func isItemSelected() -> Bool {
        guard let item = self.item else {
            return ((self.item?.index) ?? 0) == 0
        }
        if let componentModel = item.getComponent()?.model as? BaseComponentModel {
            if let selIndex = componentModel.extraExtend["item.select.index"] as? Int {
                return (selIndex == item.index)
            }
        }
        return ((self.item?.index) ?? 0) == 0
    }
    
    func refreshSelectItem() {
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        if isItemSelected() {
            self.titleLabel.font = YKNFont.module_headline_weight(.medium)
            self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor:itemModel.scene?.sceneCardHeaderTitleColor())
        } else {
            self.titleLabel.font = YKNFont.module_headline()
            titleLabel.textColor = sceneUtil(.ykn_secondaryInfo, sceneColor:itemModel.scene?.sceneSubTitleColor())
        }
    }
    
    @objc func selectItemChanged() {
        refreshSelectItem()
    }
    
    func refreshLayout() {
        titleLabel.sizeToFit()
        self.width = titleLabel.width
    }
    
}

class ItemCard15001Header: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {
        
    }
    
    func itemWidth() -> CGFloat {
        return 30
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return YKNGap.dim_3() + 30 + 17
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = ItemCard15001HeaderView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? ItemCard15001HeaderView else {
            return
        }
        itemView.fillData(item:self.item, component:self.item?.getComponent(), clickCallback: {
            
        })
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }

}
