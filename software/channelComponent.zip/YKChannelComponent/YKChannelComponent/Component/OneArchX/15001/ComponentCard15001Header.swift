//
//  ComponentCard15001Header.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/14.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout
import OneArchSupport4Youku
import PromptControl
import YKChannel

class ComponentCard15001Header2View: CardHeaderBaseView {
    
    lazy var scrollView: UIScrollView = {
        let view = UIScrollView(frame:self.bounds)
        view.contentInset = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        view.showsHorizontalScrollIndicator = false
        view.isScrollEnabled = false
        return view
    }()
    
    lazy var itemViews: [ItemCard15001HeaderView] = {
        var result = [ItemCard15001HeaderView]()
        var x = 0.0
        let itemWidth:CGFloat = 100
        for i in 0..<7 {
            let itemView = ItemCard15001HeaderView.init(frame: CGRect.init(x: x, y: 0, width: itemWidth, height: 40))
            x = x + itemWidth + columSpacing()
            self.scrollView.addSubview(itemView)
            result.append(itemView)
        }
        return result
    }()
    
    var rightViews: [UIView]?
    var currentRightView: UIView?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.scrollView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func columSpacing() -> CGFloat {
        var colSpacing = (SCREEN_WIDTH - 2 * YKNGap.youku_margin_left() - 7 * 30 * YKNSize.yk_icon_size_scale()) / 6.0
        colSpacing = max(colSpacing, YKNGap.youku_column_spacing())
        return colSpacing
    }

    func fillData(component: IComponent?, rightViews:[UIView]?) {
        super.fillData(component)
                
        guard let items = component?.getItems() else {
            return
        }
        
        if let rightViews = rightViews {
            for view in rightViews {
                view.removeFromSuperview()
            }
        }
        self.rightViews = rightViews
        self.refreshRightView()

        var x:CGFloat = 0
        for i in 0..<self.itemViews.count {
            self.itemViews[i].isHidden = (i >= items.count)
            if i < items.count {
                weak var weakself = self
                self.itemViews[i].fillData(item: items[i], component: component) {
                    weakself?.refreshLayout()
                    weakself?.refreshRightView()
                }
                self.itemViews[i].left = x
                x += self.itemViews[i].width + 18.0
            }
        }
        self.scrollView.contentSize = CGSize.init(width: max(self.scrollView.width, x-18), height: 20.0)
        self.scrollView.isScrollEnabled = self.scrollView.contentSize.width > self.scrollView.width
        
        // scene
        self.backgroundColor = sceneUtil(.ykn_primaryBackground, sceneColor: component?.compModel?.scene?.sceneBgColor())
    }

    func refreshRightView() {
        guard let componentModel = component?.model as? BaseComponentModel else {
            return
        }
        
        let selIndex = componentModel.extraExtend["item.select.index"] as? Int ?? 0
        guard let rightViews = rightViews, selIndex >= 0, selIndex < rightViews.count else {
            return
        }
        guard let subCards = component?.getCard()?.getMultiTabCardAllSubCards(), selIndex < subCards.count else {
            return
        }
        
        let rightView = rightViews[selIndex]
        if let v = rightView as? CardHeaderMoreViewProtocol {
            v.parentView = self
        }

        self.currentRightView?.removeFromSuperview()
        self.currentRightView = rightView
        self.addSubview(rightView)
        if let keyword = rightView as? HeaderKeyWordView {
            keyword.fillData(component, card: subCards[selIndex])
        } else if let calendar = rightView as? HeaderCalendarView {
            calendar.fillData(component, card: subCards[selIndex])
        }
        print("[jbp] calendar refreshRightView")
    }
    
    func refreshLayout() {
        guard let items = component?.getItems() else {
            return
        }
        
        var x:CGFloat = 0
        for i in 0..<self.itemViews.count {
            self.itemViews[i].isHidden = (i >= items.count)
            if i < items.count {
                let ItemCard15001HeaderView = self.itemViews[i]
                ItemCard15001HeaderView.refreshLayout()
                ItemCard15001HeaderView.left = x
                x += ItemCard15001HeaderView.width + 18.0
            }
        }
        self.scrollView.contentSize = CGSize.init(width: max(self.scrollView.width, x-18), height: 20.0)
        self.scrollView.isScrollEnabled = self.scrollView.contentSize.width > self.scrollView.width
    }
}

class ComponentCard15001Header: ComponentEventHandler, ComponentDelegate, ComponentLifeCycleDelegate, PCLayerRequestDelegate {
    
    //接入poplayer
    var toastLayerRequest: PCLayerRequest?

    var componentWrapper: ComponentWrapper?
    var isVisible: Bool = false
    
    weak var reuseView: ComponentCard15001Header2View?
    var rightViews = [UIView]()

    weak var popLayerRightView:UIView?
    weak var popLayerCard:ICard?
    weak var calendarVC:UIViewController?

    func componentDidInit() {
        guard let subCards = self.component?.getCard()?.getMultiTabCardAllSubCards() else {
            return
        }
        for (currentSubcardIndex, currentSubCard) in subCards.enumerated() {
            if CardHeaderUtil.isCalendar(card: currentSubCard) {
                weak var weakself = self
                CalendarManager.requestCalendarData(component: component, card:currentSubCard) {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        if let rightviews = weakself?.rightViews {
                            if weakself?.rightViews.count == 0 {
                                weakself?.createRightViews()
                            }
                            weakself?.reuseView?.fillData(component: weakself?.component, rightViews: rightviews)
                        }
                        
                        if let rightviews = weakself?.rightViews {
                            if currentSubcardIndex < rightviews.count {
                                if let rightView = rightviews[currentSubcardIndex] as? HeaderCalendarView {
                                    if weakself?.rightViews.count == 0 {
                                        weakself?.createRightViews()
                                    }
                                    //tryopen
                                    weakself?.popLayerRightView = rightView
                                    weakself?.popLayerCard = currentSubCard
                                    weakself?.addToastLayerRequest()
                                }
                            }
                        }
                    }
                }
            }
        }
        NotificationCenter.default.addObserver(self, selector: #selector(calendarCardVCHasHide), name: Notification.Name(rawValue: "YKChannel.Notification.calCardVC.hide"), object: nil)
    }

    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: 0, right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.youku_module_margin_top()
        return config
    }

    func columnCount() -> CGFloat {
        return 1
    }

    func loadEventHandlers() -> [ComponentEventHandler]? {
        let lifeCycleEventHandler = ComponentLifeCycleEventHandler()
        lifeCycleEventHandler.delegate = self
        
        return [
            self,
            lifeCycleEventHandler,
        ]
    }

    func reuseId() -> String? {
        let addressString = self.description
        return "card15001header" + addressString
    }

    /// item高度
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return YKNFont.height(with: YKNFont.module_headline_weight(.medium), lineNumber: 1)
    }

    /// 初始化item view
    func createView(_ itemSize: CGSize) -> UIView {
        let frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
        let view = ComponentCard15001Header2View.init(frame:frame)
        reuseView = view
        
        createRightViews()
        
        return view
    }
    
    func createRightViews() {
        rightViews.removeAll()
        if let subCards = self.component?.getCard()?.getMultiTabCardAllSubCards() {
            for subCard in subCards {
                if let rightView = CardHeaderUtil.createRightView(card: subCard) {
                    self.rightViews.append(rightView)
                }
            }
        }
    }

    /// 复用
    func reuseView(itemView: UIView) {
        guard let view = itemView as? ComponentCard15001Header2View else {
            return
        }
        if rightViews.count == 0 {
            createRightViews()
        }
        self.reuseView = view
        view.fillData(component: self.component, rightViews:self.rightViews)
    }
    
    func enterDisplayArea(itemView: UIView?) {
        self.isVisible = true
    }
    
    func exitDisplayArea(itemView: UIView?) {
        self.isVisible = false
    }
    
    func didActivate() {
        
    }
    
    func didDeactivate() {
        if self.calendarVC != nil {
            hideCalendarVC()
        }
    }

    deinit {
        removeToastLayerRequest()
        NotificationCenter.default.removeObserver(self)
    }
    
    func addToastLayerRequest() {
        createLayerRequestIfNeeded()
        PCLayerManager.sharedInstance().tryOpen(self.toastLayerRequest)
    }
    func removeToastLayerRequest() {
        if toastLayerRequest != nil {
            PCLayerManager.sharedInstance().remove(toastLayerRequest)
            toastLayerRequest?.layer = nil
            toastLayerRequest = nil
        }
    }
    func createLayerRequestIfNeeded() {
        if  toastLayerRequest == nil {
            toastLayerRequest = PCLayerRequest.init(layerID: "LAYER_ID_MOVIE_CALENDAR")
            toastLayerRequest?.delegate = self
        }
    }
    
    // MARK: - PCLayerDelegate
    
    @objc public func onReady(_ request: PCLayerRequest?) {
        if !isPageInActive() {
            return
        }
        weak var weakSelf = self
        if let rightView = self.popLayerRightView, let card = self.popLayerCard {
            CalendarManager.autoShowCalendarCard(component: self.component, card:card, rightView: rightView) { calendarCardVC in
                weakSelf?.calendarVC = calendarCardVC
                weakSelf?.toastLayerRequest?.layer = calendarCardVC?.view
            }
        }
    }

    @objc public func onForceRemoved(_ request: PCLayerRequest?) {
        hideCalendarVC()
    }
    
    @objc public func hideCalendarVC() {
        if let calendarVC = calendarVC as? YKCCalCardViewController {
            calendarVC.perform(Selector.init("hide:"), with: false, afterDelay: 0)
        }
    }
    
    @objc public func calendarCardVCHasHide() {
        removeToastLayerRequest()
    }
     
    func isPageInActive() -> Bool {
        if let page = self.component?.getPage() {
            if let state = page.activeState, state == true {
                return true
            }
        }
        return false
    }
}

