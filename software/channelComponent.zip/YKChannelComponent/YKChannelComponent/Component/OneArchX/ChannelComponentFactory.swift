//
//  ChannelComponentFactory.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/13.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku
import OADComponent

@objc class ChannelComponentFactoryCreator: NSObject, IFactoryCreator {
    
    func getItemFactory() -> IItemDelegateFactory? {
        return ChannelComponentItemFactory.init()
    }
    
    func getComponentFactory() -> IComponentDelegateFactory? {
        return ChannelComponentCompFactory.init()
    }
    
    func getCardFactory() -> ICardDelegateFactory? {
        return ChannelComponentCardFactory.init()
    }
    
}

class ChannelComponentCompFactory: IComponentDelegateFactory {

    func create(_ tag: String) -> ComponentDelegate? {
        
        /*  停止使用if-else形式，改用switch-case形式
            优势：1.编译器检查重复项，避免同一个tag出现两个或以上实现的歧义。
                 2.单行代码即表示一项，更直观简洁清爽，减少合并代码if-else花括号可能冲突的问题。
           
            备注：1.静态字典出现重复KEY时编译器无法检查，相同原因故弃用。
                 2.每项注释应在右侧，而不是在其上方另起一行。
                 3.复用请用注释强调注明，表示故意为之而不是笔误。
         */
        
        var value: ComponentDelegate?
        switch tag {
        
        case "card.header": value = CardGeneralHeader.init()
        case "card.header.0": value = CardGeneralHeader.init()
        case "card.header.10004": value = CardGeneralHeader.init()
        case "card.header.15010": value = CardGeneralHeader.init()
        case "card.header.15016": value = CardGeneralHeader.init()
        case "card.header.15022": value = CardGeneralHeader.init()
//        case "comp.home.topMovie": value = ComponentTopMovie.init()
        case "15001.multitab.header": value = ComponentCard15001Header.init()
        case "card.header.15025": value = CardGeneralHeader.init()
        case "card.header.15028": value = CardGeneralHeader.init()
        case "card.header.15029": value = CardGeneralHeader.init()
        case "card.header.15031": value = Card15031Header.init()
        case "card.15025.empty.component": value = Card15025EmptyComponent.init()
        case "15027.multitab.header": value = ComponentCard15027Header2.init()
        case "15032.multitab.header": value = ComponentCard15032Header.init()
        case "15009.multitab.header": value = ComponentCard15009Header.init()
        case "15044.multitab.header": value = ComponentCard15044Header.init()
        case "15046.multitab.header": value = ComponentCard15046Header.init()
        case "card.empty.component": value = CardEmptyComponent.init()
        case "card.nodata.component": value = CardNoDataComponent.init()
        case "homeReadLocationRefresh": value = CompHomeReadLocation.init()
        case "component.empty.noresults": value = ComponentEmptyTips.init()
        case "card.header.15036": value = CardGeneralHeader.init()
        case "card.header.15037": value = Card15037Header.init()
        case "card.header.15038": value = Card15038Header.init()

        // 以下组件按序号排序
        // 12xxx
        case "12004": value = Component12004.init()
        case "12008": value = Component12008.init() //老单列广告大卡，如：格斗频道
        case "12011": value = Component12083Delegate.init() //复用12083
        case "12012": value = Component12012Delegate.init()
        case "12013": value = Component12061.init()
        case "12014": value = Component12061.init()
        case "12015": value = Component12015.init()
        case "12016": value = Component12016.init()
        case "12019": value = Component12061.init()
        case "12060": value = Component12060.init()
        case "12061": value = Component12061.init()
        case "12062": value = Component12062.init()
        case "12073": value = Component12073.init()
        case "12075": value = Component12075.init()
        case "12076": value = Component12076.init()
        case "12078": value = Component12078.init()
        case "12079": value = Component12079.init()
        case "12083": value = Component12083Delegate.init()
        case "12084": value = Component12084Delegate.init()
        case "12085": value = Component12083Delegate.init() //复用12083
        case "12086": value = Component12086Delegate.init()
        case "12088": value = Component12088.init()
        case "12089": value = Component12089Delegate.init()
        case "12091": value = Component12088.init() //复用12088
        case "12092": value = Component12092Delegate.init()
        case "12093": value = Component12093Delegate.init()
        case "12095": value = Component12095Delegate.init()
        case "12104": value = Component12104Delegate.init()
        case "12113": value = Component12113.init()
        case "12116": value = Component12116.init()
        case "12117": value = Component12117.init()
        case "12118": value = Component12118.init()
        case "12120": value = Component12120.init()
        case "12134": value = Component12134.init()
        case "12137": value = Component12137.init()
        case "12139": value = Component12139.init()
        case "12140": value = Component12140.init()
        case "12141": value = Component12141.init()
        case "12142": value = Component12142.init()
        case "12143": value = Component12143.init()
        case "12144": value = Component12144.init()
        case "12152": value = Component12152.init()
        case "12153": value = Component12153.init()
        case "12154": value = Component12154.init()
        case "12155": value = Component12155.init()
        case "12156": value = Component12156.init()
        case "12157": value = Component12157.init() //mini播放页视频卡片
        case "12158": value = Component12139.init()
        case "12159": value = Component12159.init()
        case "12160": value = Component12160.init()
        case "12161": value = Component12161.init()
        case "12162": value = Component12162.init()
        case "12163": value = Component12163.init()
        case "12164": value = Component12164.init()
        case "12165": value = Component12165.init()
        case "12166": value = Component12166.init()
        case "12167": value = Component12167.init()
        case "12168": value = Component12168.init() //feed视频大卡，播放结束时有蒙版
            
        // 13xxx
        case "13500": value = Component13500.init()
        
        // 14xxx
        case "14000": value = Component14000.init()
        case "14001": value = Component14001.init()
        case "14007": value = Component14007.init()
        case "14091": value = Component14091.init()
        case "14002": value = Component14002.init()
        case "14006": value = Component14098.init() //复用14098，自20200520版本起
        case "14010": value = Component14010.init()
        case "14012": value = Component14010.init() //复用14010
        case "14013": value = Component14013.init()
        case "14014": value = Component14014.init()
        case "14016": value = Component14016Delegate.init()
        case "14120": value = Component14016Delegate.init()
        case "14022": value = Component14022.init()
        case "14027": value = Component14027Delegate.init()
        case "14030": value = Component14030.init()
        case "14121": value = Component14030.init()
        case "14031": value = Component14031.init()
        case "14032": value = Component14032.init()
        case "14034": value = Component14034V2.init() // 历史版本：Component14034.init()
        case "14035": value = Component14035.init()
        case "18231": value = Component14035.init() // 个人中心 18231
        case "14036": value = Component14040.init() //复用14040
        case "14037": value = Component14037.init()
        case "14037_14037": value = Component14037_14037.init()
        case "14037A": value = Component14037_14037.init()
        case "14038": value = Component14038.init()
        case "14038_14038": value = Component14038_14038.init()
        case "14039": value = Component14040.init()
        case "14040": value = Component14040.init()
        case "14041": value = Component14041.init()
        case "14045": value = Component14045.init()
        case "14049": value = Component14049Delegate.init()
        case "14052": value = Component14052Delegate.init()
        case "14053": value = Component14053.init()
        case "14053_14053": value = Component14053_14053.init()
        case "14055": value = Component14055.init()
        case "14058": value = Component14058.init()
        case "14061": value = Comp14061.init()
        case "14063": value = Component14063.init()
        case "14076": value = Component14076Delegate.init()
        case "14080": value = Component14081.init() //复用14081
        case "14081": value = Component14081.init()
        case "14097": value = Component14097.init()
        case "14098": value = Component14098.init()
        case "14101": value = Component14101.init()
        case "14102": value = Component14010.init() //复用14010
        case "14103": value = Component14103.init()
        case "14105": value = Component14103.init() //复用14103
        case "14110": value = Component14110.init() //电影频道 -> 有好片 -> 13007 和 13008坑位
        case "14111": value = Component14111.init() //电影频道 -> 有好片 -> 轮播
        case "14115": value = Component14115.init()
        case "14126": value = Component14126.init()
        case "14135": value = Component14135.init()
        case "14136": value = Component14136.init()
        case "14137": value = Component14137.init()
        case "14138": value = Component14098.init() //复用14098
        case "14145": value = Component14001.init() //复用14001
        case "14146": value = Component14146.init()
        case "14148": value = Component14010.init() //复用14010
        case "14151": value = Component14151Delegate.init()
        case "14155": value = Component14155.init()
        case "14157": value = Component14010.init() //复用14010x
        case "14158": value = Component14158.init()
        case "14165": value = Component14165.init()
        case "14168": value = Component14168.init()
        case "14168-History": value = Component14168.init()
        case "14176": value = Component14176.init()
        case "14177": value = Component14177.init()
        case "14179": value = Component14179.init()
        case "14180": value = Component14180.init()
        case "14182": value = Component14182.init()
        case "14183": value = Component14183Delegate.init()
        case "14185": value = Component14185Delegate.init()
        case "14192": value = Component14192.init()
        case "14193": value = Component14193.init()
        case "14194": value = Component14194.init()
        case "14195": value = Component14195.init()
        case "14196": value = Component14196.init()
        case "14197": value = Component14197Delegate.init()
        case "14198": value = Component14198Delegate.init() //坑位：14198.13011.13012  14198.14198
        case "14199": value = Component14010.init() //复用14010
        case "14200": value = Component14200.init()
        case "14201": value = BaseGaiaXComponentConfig.getGaiaXComponentDelegate(Component14201.init(), type: "14201")
        case "14202": value = Component14010.init() //复用14010
        case "14203": value = Component14203Delegate.init() //复用14010
        case "14204": value = Component14204Delegate.init()
        case "14205": value = Component14205.init()
        case "14206": value = Component14206.init()
        case "14207": value = Component14207Delegate.init()
        case "14208": value = Component14208.init()
        case "14209": value = Component14010.init() //复用14010
        case "14210": value = Component14210.init()
        case "14211": value = Component14010.init() //复用14010
        case "14212": value = Component14098.init() //预约榜卡片微调，复用14098
        case "14213": value = Component14213.init()
        case "14214": value = Component14214.init()
            
        case "14293": value = Component14293.init()
        case "14294": value = Component14294.init()
        case "14295": value = Component14295.init()
        case "14297": value = Component14297.init() //老NU导购组件
        case "14298": value = Component14298.init() //响应式新轮播
        case "14299": value = Component14299.init() //响应式新猜追
        case "14300": value = Component14300.init() //响应式新热播
        case "14301": value = Component14301.init() //观影页带播放大组件
        case "14304": value = Component14304.init() //大剧特刊
        case "14306": value = Component14306.init()
        case "14308": value = Component14308.init()
        case "14309": value = Component14309.init()
        case "14310": value = Component14310.init()
        case "14312": value = Component14035.init()
            
        case "14313": value = Component14313Delegate.init()
        case "14315": value = OADComponent14315.init()
        case "14316": value = Component14316.init()
        case "14318": value = Component14318.init()
        case "14322": value = Component14322.init()
        case "14325": value = Component14325.init()
        case "14326": value = Component14326.init()
            
        case "14327": value = RoleRankGaiaXComponent.init() //角色榜1
        case "14328": value = RoleRankGaiaXComponent.init() //角色榜2
        case "14329": value = RoleRankGaiaXComponent.init() //CP榜1
        case "14330": value = RoleRankGaiaXComponent.init() //CP榜2
        case "14331": value = RoleRankGaiaXComponent.init() //角色信息
        case "14332": value = RoleRankGaiaXComponent.init() //角色故事
        case "14333": value = Component14333.init()
        case "14334": value = Component14334.init() //新NU导购组件
        case "14335": value = Component14335.init() //角色榜个人主页组件
        case "14336": value = Component14336.init() //角色榜个人主页组件
        case "14340": value = Component14340.init()
        case "14341": value = Component14341.init() //nu热播组件
        case "14342": value = Component14342.init()
        case "14343": value = Component14343.init() //热播crm
        case "14347": value = Component14347.init() //头部小阁楼猜追组件
        case "14348": value = Component14348.init()
        case "14349": value = Component14349.init() //pad新轮播
            
        // 15xxx
        case "15004": value = Component15004.init()
        case "15042": value = Component15004.init()
        case "15043.header" : value = Comp15043Header.init()
            
        // 3xxxx
        case "30801": value = Component30801.init()
        case "31002": value = Component31002.init()
        default: break
        }
        
        return value
    }
}

class ChannelComponentItemFactory: IItemDelegateFactory {
    
    func create(_ tag: String) -> ItemDelegate? {
        var value: ItemDelegate?
        switch tag {
        
        case "comp.generic.header": value = ComponentGeneralHeader.init()
        case "comp.generic.footer": value = ComponentGeneralFooter.init()
        
        case "item.home.topMovie": value = BaseItemDelegate.init()

        // 以下组件按序号排序
        // 12xxx
        case "12004": value = Item12004.init()
        case "12008": value = Item12012Delegate.init()
        case "12011": value = Item12011.init()
        case "12012": value = Item12012Delegate.init()
        case "12013": value = BaseDFItemDelegate.init()
        case "12014": value = BaseDFItemDelegate.init()
        case "12015": value = Item12015.init()
        case "12016": value = Item12016.init()
        case "12019": value = BaseDFItemDelegate.init()
        case "12060": value = Item12060.init()
        case "12061": value = BaseDFItemDelegate.init()
        case "12062": value = BaseDFItemDelegate.init()
        case "12073": value = Item12073.init()
        case "12074": value = Item12074.init()
        case "12075": value = Item12075.init()
        case "12076": value = Item12076.init()
        case "12077": value = Item12077.init()
        case "12078": value = Item12078.init()
        case "12079": value = Item12079.init()
        case "12083": value = Item12083Delegate.init()
        case "12084": value = Item12084Delegate.init()
        case "12085": value = Item12085Delegate.init()
        case "12086": value = Item12086Delegate.init()
        case "12087": value = Item12086Delegate.init()
        case "12088": value = Item12088.init()
        case "12089": value = Item12089Delegate.init()
        case "12091": value = Item12091.init()
        case "12092": value = BaseItemDelegate.init()
        case "12093": value = Item12093Delegate.init()
        case "12095": value = Item12095Delegate.init()
        case "12104": value = Item12104Delegate.init()
        case "12113": value = Item12113.init()
        case "12114": value = Item12114.init()
        case "12115":
            value = Item12115.init()
        case "12116": value = Item12116.init()
        case "12117": value = Item12117.init()
        case "12118": value = Item12118.init()
        case "12120": value = Item12120.init()
        case "12134": value = Item12134.init()
        case "12137": value = Item12137.init()
        case "12138": value = Item12138.init()
        case "12139": value = Item12139.init() //找片feed接csj，1像素高度占位组件
        case "12140": value = Item12140.init() //找片feed接csj，广告小卡（基于12138做包卡）
        case "12141": value = Item12141.init()
        case "12142": value = Item12142.init()
        case "12143": value = Item12143.init()
        case "12144": value = Item12144.init()
        case "12152": value = Item12152.init()
        case "12153": value = Item12154.init()
        case "12154": value = Item12154.init()
        case "12155": value = Item12155.init()
        case "12156": value = Item12156.init()
        case "12157": value = Item12157.init()
        case "12158": value = Item12139.init()
        case "12159": value = Item12159.init()
        case "12160": value = Item12160.init()
        case "12161": value = Item12161.init()
        case "12162": value = Item12162.init()
        case "12163": value = Item12163.init()
        case "12164": value = Item12164.init()
        case "12165": value = Item12165.init()
        case "12166": value = Item12166.init()
        case "12167": value = Item12156.init()
        case "12168": value = Item12168.init() //feed视频大卡，播放结束时有蒙版

        // 13xxx
        case "13003": value = Item13003.init()
        case "13007": value = Item13007.init()
        case "13008": value = Item13008.init()
        case "13010": value = Item13010.init()
        case "13011": value = Item13011Delegate.init()
        case "13012": value = Item13012Delegate.init()
        case "13015": value = Item13015.init()
        case "13016": value = Item13016.init()
        case "13017": value = Item13017.init() //热播中插播放大卡
        case "13500": value = BaseItemDelegate.init()
        
        // 14xxx
        case "14000": value = BaseItemDelegate.init()
        case "14001": value = Item14001.init()
        case "14007": value = Item14007.init()
        case "14091": value = Item14091.init()
        case "component.background.14091": value = Item14091Background.init()
        case "14002": value = Item14002.init()
        case "14006": value = Item14098.init() //复用14098
        case "14010": value = Item14010.init()
        case "14012": value = Item14012.init()
        case "14013": value = Item14013.init()
        case "14014": value = Item14014.init()
        case "component.background.14014": value = Item14014Background.init()
        case "14016": value = Item14016Delegate.init()
        case "14120": value = Item14016Delegate.init()
        case "14022": value = Item14022.init()
        case "14027": value = Item14027Delegate.init()
        case "14030": value = BaseItemDelegate.init()
        case "14121": value = BaseItemDelegate.init()
        case "14031": value = BaseItemDelegate.init()
        case "14032": value = Item14032.init()
        case "14034": value = Item14034V2.init() // 历史版本：Item14034.init()
        case "14035": value = Item14035.init()
        case "18048": value = Item18048.init()
        case "18548": value = Item18048.init()
        case "18231": value = Item14035.init()  // 个人中心 18231
        case "14036": value = Item14040.init()  //复用14040
        case "14037": value = ComponentNavigateItem.init()
        case "14037_14037": value = BaseItemDelegate.init()
        case "14037_13003": value = Item13003.init()
        case "14038": value = Item14038.init()
        case "14038_14038": value = BaseItemDelegate.init()
        case "14038_13003": value = Item13003.init()
        case "14039": value = Item14040.init()
        case "14040": value = Item14040.init()
        case "14041": value = Item14027Delegate.init()  //复用14027
        case "14045": value = Item14045.init()
        case "14049": value = Item14016Delegate.init()  //复用14016
        case "14052": value = Item14016Delegate.init()
        case "14053": value = Item14053.init()
        case "14053_14053": value = BaseItemDelegate.init()
        case "14055": value = BaseItemDelegate.init()
        case "14058": value = Item14180.init()  //复用14180
        case "14061": value = Item14061.init()
        case "14063": value = Item12012Delegate.init()  //复用12012
        case "14076": value = Item14016Delegate.init()  //复用14016
        case "14080": value = Item14081.init()  //复用14081
        case "14081": value = Item14081.init()
        case "14097": value = Item14097.init()
        case "14098": value = Item14098.init()
        case "14101": value = Item14101.init()
        case "14102": value = Item14102.init()
        case "14103": value = Item14103.init()
        case "14105": value = Item14105.init()
        case "14111": value = Item14111.init()
        case "14115": value = Item14115.init() 
        case "14126": value = Item14126.init()
        case "14135": value = Item14135.init()
        case "14136": value = Item14136.init()
        case "14137": value = Item14136.init()  //复用14136
        case "14138": value = Item14138.init()
        case "14145": value = Item14145.init()
        case "14146": value = BaseItemDelegate.init()
        case "component.background.14146": value = Item14146Background.init()
        case "14148": value = Item14148.init()
        case "14151": value = Item14151Delegate.init()
        case "14155": value = Item14155.init()
        case "14157": value = Item14157.init()
        case "14158": value = Item14158.init()
        case "14165": value = Item14165.init()
        case "14168": value = Item14168.init()
        case "14168-History": value = Item14158.init()
        case "14176": value = Item14176.init()
        case "14177": value = Item14177.init()
        case "14179": value = Item14179.init()
        case "14180": value = Item14180.init()
        case "14182": value = Item14182.init()
        case "14183": value = Item14183Delegate.init()
        case "14185": value = Item14185Delegate.init()
        case "14192": value = Item14192.init()
        case "14193": value = BaseItemDelegate.init()
        case "14194": value = Item14194.init()
        case "14195": value = Item14195.init()
        case "14196": value = Item14196.init()
        case "comp.14196.header": value = Item14196Header.init()
        case "14291": value = BaseItemDelegate.init()
        case "14292": value = BaseItemDelegate.init()
        case "14197": value = Item14027Delegate.init() //复用14027
        case "14198": value = Item14198Delegate.init()
        case "14199": value = Item14199.init()
        case "14200": value = Item14200.init()
        case "14201": value = BaseGaiaXComponentConfig.getGaiaXItemDelegate(Item14201.init(), type: "14201")
        case "14202": value = Item14202.init()
        case "14203": value = Item14203Delegate.init()
        case "14204": value = Item14204Delegate.init()
        case "14205": value = Item14205.init()
        case "14206": value = Item14206.init()
        case "14207": value = Item14207Delegate.init()
        case "14208": value = Item14208.init()
        case "14209": value = Item14209.init()
        case "14210": value = Item14210.init()
        case "14211": value = Item14211.init()
        case "14212": value = Item14212.init()
        case "14213": value = Item14213.init()
        case "14214": value = Item14214.init()
            
        case "14293": value = Item14293.init()
        case "14294": value = Item14294.init()
        case "14295": value = Item14295.init()
        case "14296": value = Item14296.init()
        case "14297": value = Item14297.init()
        case "14298": value = Item14298.init()
        case "14299": value = Item14299.init()
        case "14300": value = Item14300.init()
        case "14301": value = Item14301.init() //观影页带播放大组件
        case "14304": value = Item14304.init() //大剧特刊左侧坑位
        case "14305": value = Item14305.init() //大剧特刊右侧坑位
        case "14306": value = Item14195.init() //频道feed化，样式完全复用14195组件
        case "14308": value = BaseItemDelegate.init()
        case "component.background.14308": value = Component14308Background.init()
        case "14309": value = BaseItemDelegate.init()
        case "component.background.14309": value = Component14308Background.init()
        case "14310": value = Item14040.init()
        case "14312": value = Item14312.init()
        case "14313": value = Item14204Delegate.init() //新轮播，内容坑位
        case "14314": value = Item14314.init() //新轮播，广告坑位
        case "14315": value = OADItem14315.init()
        case "14316": value = BaseItemDelegate.init()
        case "14325": value = Item14325.init()
        case "14326" : value = Item14326.init()
        case "comp.header.14326": value = ComponentHeader14326.init()
            
        case "14327": value = RoleRankGaiaXItem.init() //角色榜1
        case "14328": value = RoleRankGaiaXItem.init() //角色榜2
        case "14329": value = RoleRankGaiaXItem.init() //CP榜1
        case "14330": value = RoleRankGaiaXItem.init() //CP榜2
        case "14331": value = RoleRankGaiaXItem.init() //角色信息
        case "14332": value = RoleRankGaiaXItem.init() //角色故事
        case "14333": value = Item14333.init()
        case "14334": value = Item14334.init() //导购坑位
        case "14335": value = Item14335.init() //角色榜个人主页坑位
        case "14336": value = Item14204Delegate.init() //首页新轮播，内容坑位
        case "14338": value = Item14338.init() //14001坑位替换广告类型
        case "14339": value = Item14339.init() //14002坑位替换广告类型
        case "14345": value = Item14345.init()
        case "14340": value = Item14340.init()
        case "14341": value = Item14341.init() //nu热播组件
        case "14346": value = Item14016Delegate.init() //频道页老轮播焦1广告位
        case "14342": value = Item14342.init()
        case "14343": value = Item14343.init() //热播crm
        case "14347": value = Item14347.init() //头部小阁楼猜追组件
        case "14348": value = Item14348.init()
        case "14349": value = Item14349.init() //pad新轮播
            
        // 15xxx
        case "15001.multitab.header.item": value = ItemCard15001Header.init()
        case "15009.multitab.header.item": value = ItemCard15009Header.init()
        case "15027.multitab.header.item": value = ItemCard15027Header.init()
        case "15032.multitab.header.item": value = ItemCard15032Header.init()
        case "15043.header" : value = BasePlaceholderItem.init()
        case "15044.multitab.header.item": value = ItemCard15044Header.init()
        case "15046.multitab.header.item": value = ItemCard15046Header.init()
            
        // 17xxx
        case "17710": value = BaseItemDelegate.init()
            
        // 3xxxx
        case "30801": value = Item30801.init()
        case "31002": value = Item31002.init()
        case "31001": value = Item31001.init()
        default: break
        }
        
        return value
    }
}

class ChannelComponentCardFactory: ICardDelegateFactory {
    
    func create(_ tag: String) -> CardDelegate? {
        var value: CardDelegate?
        switch tag {
        
        case "card.default": value = BaseCardDelegate.init()
        
        // 以下组件按序号排序
        case "0": value = BaseCardDelegate.init()
        case "10004": value = Card10004.init()
        case "15001": value = Card15001.init()
        case "15002": value = BaseCardDelegate.init()
        case "15004": value = Card15004.init()
        case "15042": value = Card15004.init()

        case "15008": value = BaseCardDelegate.init()
        case "15009": value = Card15009.init()
        case "15010": value = Card15010.init()
        case "15016": value = Card15016.init()
        case "15022": value = Card15022.init()
        case "15025": value = Card15025.init()
        case "15027": value = Card15027.init()
        case "15028": value = Card15028.init()
        case "15029": value = Card15029.init()
        case "15030": value = Card15030.init()
        case "15031": value = BaseCardDelegate.init()
        case "15032": value = Card15032.init()
        case "15033": value = BaseCardDelegate.init() //已下线
        case "ImmersiveCustomCard": value = ImmersiveCustomCardDelegate.init()
        case "15034": value = Card15034.init()
        case "15035": value = Card15035.init()
        case "15036": value = Card15036.init()
        case "15037": value = Card15037.init()
        case "15038": value = Card15038.init()
        case "15039": value = Card15039.init()
        case "15040": value = Card15040.init()
        case "15041": value = Card15041.init()
        case "15043": value = Card15043.init()
        case "15044": value = Card15044.init()
        case "15046": value = Card15046.init()
        case "15047": value = Card15047.init()
        case "15048": value = Card15048.init()
        default: break
        }
        
        return value
    }

}
