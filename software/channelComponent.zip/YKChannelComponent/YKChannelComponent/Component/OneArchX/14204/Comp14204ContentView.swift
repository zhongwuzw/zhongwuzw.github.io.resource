//
//  Comp14204ContentView.swift
//  YKChannelComponent
//
//  Created by better on 2022/11/2.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKUIComponent
import YKModeConfigFramework
import YKProtocolSDK
import OneArchSupport
import OneArchSupport4Youku
import YKChannelPage

class Comp14204ContentView: Comp14016ContentViewV2, SliderScrollingObserver {

    var maxScale: CGFloat = 0.0
    var changingProgress: CGFloat = 1.0
    
    var itemIndex = -1
    var itemSection = 0
    weak var sliderDelegate: CompSliderLayoutDelegate?
    
    lazy var shadowView:BottomGradientShadowView = {
        let frame = CGRect.init(x: -YKNGap.youku_margin_left(), y: self.height + CONSTANT.LUNBO_BIGCARD_EXTEND_BOTTOM - 51, width: self.width + YKNGap.youku_margin_left()*2, height: 51)
        let shadowView = BottomGradientShadowView.init(frame: frame, shadowHeight: 51)
        self.addSubview(shadowView)
        return shadowView
    }()
    
    let BIGIMG_HW_RATIO: CGFloat = 526.0/750.0
    lazy var bigVideoImageView: UIImageGIFView = {
        let view = createVideoImageView()
        view.frame = CGRect.init(x: 0, y: 0, width: self.videoImageView.width, height: self.videoImageView.width*BIGIMG_HW_RATIO)
        view.bottom = self.videoImageView.height
        self.videoImageView.addSubview(view)
        self.videoImageView.sendSubviewToBack(self.gradientLayerView)
        self.videoImageView.sendSubviewToBack(view)
        view.addSubview(self.bigCardTopGradientView)
        return view
    }()
    
    lazy var bigCardTopGradientView: BigCardTopGradientView = {
        let bigViewMaxWidth = self.width + YKNGap.youku_margin_left() * 2
        let bigViewMaxHeight = bigViewMaxWidth * BIGIMG_HW_RATIO
        let clipViewMaxHeight = self.height + CONSTANT.LUNBO_BIGCARD_EXTEND_TOP + CONSTANT.LUNBO_BIGCARD_EXTEND_BOTTOM
        let bigcardDiff:CGFloat = max(bigViewMaxHeight - clipViewMaxHeight, 0.0)
        let gradientHeight:CGFloat = 75 + bigcardDiff
        print("[14204] bigcard diff \(bigcardDiff)")
        let view = BigCardTopGradientView.init(frame: CGRect.init(x: 0, y: bigcardDiff, width: bigViewMaxWidth, height: gradientHeight))
        view.midLoc = bigcardDiff / gradientHeight
        
//        view.layer.borderColor = UIColor.yellow.cgColor
//        view.layer.borderWidth = 2.0
        
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.gradientLayerView.alpha = 0.0
        self.sendSubviewToBack(self.shadowView)
        self.sendSubviewToBack(self.videoImageView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func customImageViewFrame() -> CGRect {
        var result = self.bounds
        
        var topExtend = CONSTANT.LUNBO_BIGCARD_EXTEND_TOP
        let heightMaxExtend: CGFloat = (topExtend + CONSTANT.LUNBO_BIGCARD_EXTEND_BOTTOM)
        let widthMaxExtend: CGFloat = YKNGap.youku_margin_left() * 2

        var heightExtend = heightMaxExtend * maxScale
        var widthExtend = widthMaxExtend * maxScale
        
        heightExtend *= changingProgress
        widthExtend *= changingProgress
        
        if let homeModel = self.itemModel as? HomeItemModel, !homeModel.isBigCard {
            heightExtend = 0.0
            widthExtend = 0.0
            topExtend = 0
        }

        result.size.width += widthExtend
        result.size.height += heightExtend
        result.origin.y = -(topExtend * maxScale * changingProgress)
        result.origin.x = -widthExtend/2.0

        print("[lunbo] frame \(self.itemIndex) ratio \(maxScale) progress \(changingProgress)")

        return result
    }
    
    override func fillData(itemModel: BaseItemModel?, titleRightMargin: CGFloat) {
        guard let homeModel = itemModel as? HomeItemModel else {
            return
        }
        
        self.forbiddenDownloadImage = homeModel.isBigCard

        super.fillData(itemModel: itemModel, titleRightMargin: titleRightMargin)

        //shadow
        self.shadowView.refreshFrame(frame: CGRect.init(x: -YKNGap.youku_margin_left(), y: self.height + CONSTANT.LUNBO_BIGCARD_EXTEND_BOTTOM - 51, width: self.width + YKNGap.youku_margin_left()*2, height: 51))

        //imageview
        changeImageViewSize()
                
        self.bigVideoImageView.isHidden = !homeModel.isBigCard
        if homeModel.isBigCard {
            self.videoImageView.ykn_setImage(withURLString: "",
                                        module: "home",
                                        imageSize: CGSize.zero,
                                        parameters: ["placeholderColor":UIColor.clear],
                                        completed: nil)
            let downloadWidth = (YKRLScreenWidth() - 30) * 3
            let downloadSize = CGSize.init(width: downloadWidth, height: downloadWidth * BIGIMG_HW_RATIO)
            self.bigVideoImageView.ykn_setImage(withURLString: self.itemModel?.img,
                                                module: "home",
                                                imageSize: downloadSize,
                                                parameters: ["placeholderColor":UIColor.clear],
                                                completed: nil)
            //顶部渐变
            self.bigCardTopGradientView.updateGradientColor(fromColor: homeModel.absorbColor, toColor: homeModel.absorbColor?.withAlphaComponent(0.0))
        }

    }

    private func changeImageViewSize() {
        self.videoImageView.frame = self.customImageViewFrame()
        self.bigVideoImageView.frame = CGRect.init(x: 0, y: 0, width: self.videoImageView.width, height: self.videoImageView.width*BIGIMG_HW_RATIO)
        self.bigVideoImageView.bottom = self.videoImageView.height
//        self.bigCardTopGradientView.top = self.bigVideoImageView.height -
        let radiusRatio = 1.0 - (self.videoImageView.width - self.width)/(YKNGap.youku_margin_left()*2.0)
        let is14336Flag = (self.itemModel?.domainObject as? IItem)?.getComponent()?.model?.type == "14336"
        if !is14336Flag {
            self.videoImageView.layer.cornerRadius = YKNCorner.radius_secondary_medium() * radiusRatio
        }

        guard let homeModel = itemModel as? HomeItemModel else {
            return
        }
        if !homeModel.isBigCard {
            self.shadowView.isHidden = true
            self.gradientLayerView.alpha = 1.0
        } else {
            self.shadowView.isHidden = false
            self.shadowView.alpha = self.maxScale
            self.gradientLayerView.alpha = max((1.0 - self.maxScale), 0.0)
        }
        self.gradientLayerView.bottom = self.videoImageView.height
        self.gradientLayerView.width = self.videoImageView.width
        self.gradientLayer.frame = self.gradientLayerView.bounds
        self.videoImageView.sendSubviewToBack(self.gradientLayerView)
        self.videoImageView.sendSubviewToBack(self.bigVideoImageView)
    }

    private func isNormalItem(index: Int) -> Bool {
        guard let allDatas = self.sliderDelegate?.allDatas else {
            return false
        }
        if index < 0 || index >= allDatas.count {
            return false
        }
        let data = allDatas[index]
        if let item = data as? IItem {
            if item.model?.type == "14204" || item.model?.type == "14313" {
                return true
            }
        }
        return false
    }
    
    //MARK: SliderScrollObserver
    
    func itemMaxScaleChanged(scale: CGFloat) {
        self.maxScale = scale
        changeImageViewSize()
    }

    func indexChanging(fromIndex: Int, toIndex: Int, progress: CGFloat) {
        if self.itemIndex == fromIndex {
            self.changingProgress = progress
        } else if self.itemIndex == toIndex {
            self.changingProgress = 1.0 - progress
        } else {
            self.changingProgress = 0.0
        }
        changeImageViewSize()
    }

}
