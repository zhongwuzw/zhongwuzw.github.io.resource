//
//  BigCardTopGradientView.swift
//  YKChannelComponent
//
//  Created by better on 2023/1/6.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import SwiftUI
import YoukuResource
import YKChannelPage

class BigCardTopGradientView: UIView {
   
    var midLoc: CGFloat = 0.0
    
    lazy var gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 0.0, y: 1.0)
        self.layer.addSublayer(layer)
        layer.frame = self.bounds
        return layer
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.gradientLayer.frame = self.bounds
        self.backgroundColor = .clear
        self.isUserInteractionEnabled = false
        self.clipsToBounds = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func updateGradientColor(fromColor: UIColor?, toColor: UIColor?) {
        guard let fromColor = fromColor else {
            return
        }
        guard let toColor = toColor else {
            return
        }
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        self.gradientLayer.colors = [fromColor.cgColor, fromColor.cgColor, toColor.cgColor]
        CATransaction.commit()
    }
}


