//
//  Comp14204Model.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/4/12.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku
import YoukuResource
import NovelAdSDK

open class Comp14204Model : Comp14016Model {
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
    }
}

class Item14204Model: HomeItem14016Model {
    var contentDataAdHasParsed: Bool = false //标识data.ad已经解析过
    var nadApi: NadAPI? = nil
    var contentOadModel: OADModel? = nil
    var contentHasSendAdExposed: Bool = false //广告曝光只发一次
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
    }
    
    // 主线程解析
    func parseContentAdDataIfNeeded() {
        guard !self.contentDataAdHasParsed else {
            return
        }
        self.contentDataAdHasParsed = true
        
        if let data = self.data, let adJson = data["ad"] as? [String: Any], adJson.isEmpty == false {
            let nadApi = NadAPI()
            self.contentOadModel = nadApi.getAd(adJson)
            self.nadApi = nadApi
            print("[广告补发埋点] 解析model:\(self.contentOadModel)")
        }
    }
}
