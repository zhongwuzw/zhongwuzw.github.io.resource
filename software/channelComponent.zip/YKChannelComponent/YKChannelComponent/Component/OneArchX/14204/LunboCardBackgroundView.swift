//
//  LunboCardBackgroundView.swift
//  YKChannelComponent
//
//  Created by better on 2023/3/1.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import SwiftUI
import YoukuResource
import YKChannelPage

class LunboCardBackgroundView: UIView {

    static let TAG = 20230301
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.isUserInteractionEnabled = false
        NotificationCenter.default.addObserver(self, selector: #selector(receiveAlphaChangedNotification(_:)), name: Notification.Name(rawValue:"home.topMovieComponent.alpha.changed"), object: nil)
    }
    
    weak var container: UICollectionView?
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    @objc func receiveAlphaChangedNotification(_ notif: Notification?) {
        guard let userInfo = notif?.userInfo else {
            return
        }
        guard let alpha = userInfo["alpha"] as? CGFloat else {
            return
        }
//        self.isHidden = true //alpha == 0
    }
    
    static func config(_ component: IComponent?, maxScale: CGFloat) -> LunboCardBackgroundView? {
        guard let component = component else {
            return nil
        }
        guard let container = component.pageContext?.getContainerView() as? UICollectionView else {
            return nil
        }
        
        var cardView = container.viewWithTag(TAG) as? LunboCardBackgroundView
        if cardView == nil {
            let tmpView = LunboCardBackgroundView()
            tmpView.isHidden = true
            tmpView.tag = TAG
            tmpView.layer.zPosition = -999
            container.addSubview(tmpView)
            cardView = tmpView
        }
        cardView?.reuse(component)
        
        if let model = component.getPage()?.model as? BasePageModel {
            cardView?.backgroundColor = sceneUtil(.ykn_primaryBackground, sceneColor: model.scene?.sceneBgColor())
        } else {
            cardView?.backgroundColor = .ykn_primaryBackground
        }
        
        cardView?.container = container
        
        let cardBottom = component.getLayoutInfo().y + component.getLayoutInfo().height
        cardView?.width = container.width
        cardView?.height = calcCardHeight(maxScale: maxScale, lunboHeight: component.getLayoutInfo().height)
        cardView?.bottom = cardBottom
        cardView?.updateCornerRadius(maxScale: maxScale, lunboGradientColors: nil, lunboBackgroundView: nil)
    
        return cardView
    }
    
    static func calcCardHeight(maxScale: CGFloat, lunboHeight: CGFloat) -> CGFloat {
        let topExtend = CONSTANT.LUNBO_BIGCARD_EXTEND_TOP
        let heightExtend = (topExtend - 15) * maxScale + 15
        return lunboHeight + heightExtend
    }
    
    static func remove(_ component: IComponent?) {
        guard let component = component else {
            return
        }
        guard let container = component.pageContext?.getContainerView() as? UICollectionView else {
            return
        }
        let bgView = container.viewWithTag(TAG)
        bgView?.removeFromSuperview()
    }
    
    func reuse(_ component: IComponent?) {
        
    }
    
    func updateMaxScale(maxScale: CGFloat, lunboHeight: CGFloat, lunboGradientColors: [CGColor]?, lunboBackgroundView:UIView?) {
        let cardBottom = self.bottom
        self.height = LunboCardBackgroundView.calcCardHeight(maxScale: maxScale, lunboHeight:lunboHeight) - 14 * (1.0 - maxScale)
        self.bottom = cardBottom
        updateCornerRadius(maxScale: maxScale, lunboGradientColors: lunboGradientColors, lunboBackgroundView: lunboBackgroundView)
    }
    
    func updateCornerRadius(maxScale: CGFloat, lunboGradientColors: [CGColor]?, lunboBackgroundView: UIView?) {
        /*
        if container?.viewWithTag(202303176)?.alpha == 0.0 { //判断影厅模式
            let alpha = min((1.0 - maxScale) * 90 / 45.0, 1.0)
            self.alpha = max(alpha, 0.0)
        } else {
            self.alpha = 1.0
        }*/
        
        var userInfo = [String: Any]()
        userInfo["maxScale"] = maxScale
        if let color = lunboGradientColors?.first {
            userInfo["containerColor"] = UIColor(cgColor: color)
        } else {
            userInfo["containerColor"] = self.backgroundColor
        }
        userInfo["container"] = self.container
        if let lunboBackgroundView = lunboBackgroundView {
            userInfo["lunboBackgroundView"] = lunboBackgroundView
        }
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "home.event.topmove.position"), object: nil, userInfo: userInfo)
    }

}
