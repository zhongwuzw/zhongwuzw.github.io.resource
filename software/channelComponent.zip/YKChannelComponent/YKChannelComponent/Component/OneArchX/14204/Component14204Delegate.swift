//
//  Component14204Delegate.swift
//  YKChannelComponent
//
//  Created by better on 2022/11/2.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import UIKit
import OneArch
import YoukuResource
import YKHome
import YKSCService
import YKResponsiveLayout
import OneArchSupport4Youku
import YKChannelPage
import YKModeConfigFramework
import YoukuAnalytics
import YKChannel

@objcMembers
class Component14204Delegate: Component14016Delegate {

    var isAfterReuse = false //reuse标记

    var isInRefreshingOfHomeIcon = false
    
    var isThemeMode = false //是否是氛围模式

    var bigCardMaxHeight: CGFloat = 0.0
    var hasAppleAdv = false
    
    let LOADING_OFFSET:CGFloat = 67
    
    let TOP_CENEMA_OFFSET_NAV_TRANSPARENT: CGFloat = 45
    let TOP_CENEMA_OFFSET_SMALLCARD: CGFloat = 90

    weak var lunboBackgroundView: LunboBackgroundView?
//    weak var topMovieLunboBackgroundView: TopMovieLunboBackgroundView?
    weak var lunboCardBackgroundView: LunboCardBackgroundView?
    ///广告小阁楼
    weak var topAnimationADLunboBackgroundView: TopAnimationADLunboBackgroundView?
    var topADCardIsShow:Bool = false
    
    required init() {
        super.init()
        NotificationCenter.default.addObserver(self, selector: #selector(receiveAdaptorEvent(_:)), name: NSNotification.Name.init(rawValue: "yk.selection.onearch.channelPage.adaptor"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(triggerRefreshByIcon), name: NSNotification.Name.init(rawValue: "home.refresh.triggerByIcon"), object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(themeDidChanged), name: NSNotification.Name.init(rawValue: "YKThemeDidChange"), object: nil)
    
        NotificationCenter.default.addObserver(self, selector: #selector(reloadScrollToLunbo), name: NSNotification.Name.init(rawValue: "home.reload.scroll.to.lunbo"), object: nil)

//        NotificationCenter.default.addObserver(self, selector: #selector(topMovieGuidShow), name: NSNotification.Name.init(rawValue: "home.topMovieComponent.guide.show"), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(topMovieGuidHide), name: NSNotification.Name.init(rawValue: "home.topMovieComponent.guide.dismiss"), object: nil)
    }
    
//    @objc func topMovieGuidShow() {
//        self.sliderView?.pauseSliding()
//    }
//    
//    @objc func topMovieGuidHide() {
//        guard let container = self.component?.pageContext?.getContainerView() as? UICollectionView else {
//            return
//        }
//        if container.isDragging {
//            return
//        }
//        self.sliderView?.resumeSliding()
//    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
        if YKElderModeManager.sharedInstance()?.isElderMode ?? false {
            let backgroundView = self.lunboBackgroundView
//            let topmovieBackGround = self.topMovieLunboBackgroundView
            DispatchQueue.main.async {
//                topmovieBackGround?.isHidden = true
                backgroundView?.isHidden = true
            }
            print("[14204] deinit elder mode")
        }
//        if UserDefaults.standard.bool(forKey: "yk.appMode.isAdolescentMode") {
//            let topmovieBackGround = self.topMovieLunboBackgroundView
//            DispatchQueue.main.async {
//                topmovieBackGround?.isHidden = true
//            }
//        }
    }
    
    /// 获取item格式解析代理
    override public func getItemJsonExtracter() -> ItemJsonExtracter? {
        return ItemJsonExtractor14204.init()
    }
    
    override func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let width = itemWidth - YKNGap.youku_margin_left() * 2
//        var ratio = self.compModel?.extraExtend["yksc.data.comp.hwRatio"] as? CGFloat ?? 0
//        var ratio: CGFloat = (self.component?.compModel as? HomeComponentModel)?.compHwRatio ?? 0
//        if ratio < 0.01 {
//            ratio = 170.0 / 339.0
//        }
        var itemHeight = getRoundItemHeight(width: width)
//        let hasAdv = self.component?.compModel?.extraExtend["yksc.data.comp.appleAD.hasAdv"] as? Bool ?? false
        let hasAdv = (self.component?.compModel as? HomeComponentModel)?.hasAppleAD ?? false
//        if hasAdv, !ykrl_isResponsiveLayout(), let adItemHeight = self.component?.compModel?.extraExtend["yksc.data.comp.adItemHeight"] as? CGFloat, adItemHeight > 0 { // 考虑苹果广告高度(响应式无需考虑)
        if hasAdv, !ykrl_isResponsiveLayout(), let adItemHeight = (self.component?.compModel as? HomeComponentModel)?.adItemHeight, adItemHeight > 0 { // 考虑苹果广告高度(响应式无需考虑)
            itemHeight = adItemHeight
        }
        self.hasAppleAdv = hasAdv
        print("[new apple AD] return itemHeight:\(itemHeight) on sub thread")
        return itemHeight
    }
    
    override func createView(_ itemSize: CGSize) -> UIView {
        let itemView = super.createView(itemSize)
        if let sliderView = itemView as? SliderView {
            sliderView.itemContentBorderMargin = YKNGap.youku_margin_left()
            sliderView.collectionViewBg.clipsToBounds = false
            sliderView.collectionView.clipsToBounds = false
            sliderView.customPageViewPadding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_column_spacing(), right: YKNGap.youku_margin_right() + 12)
        }
        return itemView
    }
    
    override func reuseView(itemView: UIView) {
        isAfterReuse = true

        print("[lunbo] isPullDrawerMode \(isPullDrawerMode)")
        
        super.reuseView(itemView: itemView)
        if let superview = itemView.superview {
            superview.clipsToBounds = false
            itemView.superview?.layer.zPosition = 100
        }

        //最大卡片高度
        bigCardMaxHeight = itemView.height + CONSTANT.LUNBO_BIGCARD_EXTEND_TOP + CONSTANT.LUNBO_BIGCARD_EXTEND_BOTTOM
        print("bigCardMaxHeight \(bigCardMaxHeight)")
        
        //是否分为氛围模式
        self.isThemeMode = getIsThemeMode()

        print("lunbo isThemeMode \(isThemeMode)")

        let maxScale = calcLunboItemRatio()
        clipContainer(maxScale)

//        self.lunboBackgroundView = LunboBackgroundView.config(self.component, isThemeMode: isThemeMode)
//        self.lunboBackgroundView?.currentLunboDelegate = self
        
//        if self.isTopCinemaMode {
//            self.lunboCardBackgroundView = LunboCardBackgroundView.config(self.component, maxScale: topCinemaCompChangeProgress())
//            self.topMovieLunboBackgroundView = TopMovieLunboBackgroundView.configTopMovie(self.component, isThemeMode: isThemeMode)
//            self.topMovieLunboBackgroundView?.updateTopMovieMode(self.isTopCinemaMode)
//            self.topMovieLunboBackgroundView?.isHidden = true
//        } else {
//            self.component?.pageContext?.getContainerView()?.viewWithTag(LunboCardBackgroundView.TAG)?.removeFromSuperview()
//            self.lunboCardBackgroundView = nil
//            TopMovieLunboBackgroundView.removeTopMovieLunboBackground(self.component)
//            self.topMovieLunboBackgroundView = nil
//        }
        if self.isTopAnimationADMode {
            let adCompModel = getTopAnimatioADComponent(self.component?.getPage())?.compModel as? Comp14325Model
            self.topAnimationADLunboBackgroundView = TopAnimationADLunboBackgroundView.config(self.component, isThemeMode: isThemeMode, compModel: adCompModel)
            
        } else {
            TopAnimationADLunboBackgroundView.removeLunboBackground(self.component)
        }
        
        //顶导渐变通知
        notifyNavigatinBar()
        
        //防止下发一个坑位
        if let itemData = self.component?.getItems()?.first?.model?.data, let onlyOneItemFromServer = itemData["onlyOneItemFromServer"] as? Bool {
            self.sliderView?.collectionView.isScrollEnabled = false
            self.sliderView?.pageView.isHidden = true
        } else {
            self.sliderView?.collectionView.isScrollEnabled = true
            self.sliderView?.pageView.isHidden = false
        }
        self.appleADHandler.hiddenSliderWhenShowAd(itemView)
    }
    
    public override func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Comp14204Model.self as? T.Type
    }
    
    private func getIsThemeMode() -> Bool {
        return isPageInThemeMode(self.component?.getPage())
    }
    
    public override func createItemView(index: Int, itemSize: CGSize) -> UIView {
    
        let frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
        var itemView: UIView?
        var needClip = true
        if index < self.allDatas.count {
            let data = self.allDatas[index]
            if let item = data as? IItem {
                if item.model?.type == "14296" {
                    itemView = Item14296View(frame: frame)
                } else {
                    let tmpItemView = Comp14204ContentView.init(frame: frame)
                    self.sliderView?.sliderScrollObservers.append(tmpItemView)
                    itemView = tmpItemView
                    needClip = false
                }
            } else if isAdvertItem(index: index) {
                itemView = Comp14016ADView.init(frame: frame)
            }
        }
        if let itemView = itemView {
            if needClip {
                itemView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
                itemView.clipsToBounds = true
            }
            return itemView
        } else {
            let tmpView = super.createItemView(index: index, itemSize: itemSize)
            if needClip {
                tmpView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
                tmpView.clipsToBounds = true
            }
            return tmpView
        }
    }
    
    public override func reuseItemView(index: Int, itemView: UIView) {
        if let view = itemView as? Comp14204ContentView {
            if index < self.allDatas.count,
                let item = self.allDatas[index] as? IItem {
                view.maxScale = calcLunboItemRatio()
                view.itemIndex = index
                view.sliderDelegate = self
                view.fillData(itemModel: item.itemModel, titleRightMargin: self.content14204ViewTitleRightMagin(self.allDatas.count))
                YKSCScreenLogUtil.printLog("[新轮播] reuse index:\(index) 14336", color: .red)
            }
        } else if let view = itemView as? Item14296View {
            if index < self.allDatas.count,
                let item = self.allDatas[index] as? IItem,
                let items = self.component?.getItems() {
                view.fillData(item:item, titleRightMargin: CGFloat((items.count - 1) * 6 + 9 + 12 + 12))
            }
        } else if let _ = itemView as? Comp14016ADView {
            if let adView = self.adView {
                adView.frame = itemView.bounds
                itemView.addSubview(adView)
            }
        } else {
            super.reuseItemView(index: index, itemView: itemView)
        }
    }
    
    func content14204ViewTitleRightMagin(_ itemCount: Int) -> CGFloat {
        // 指示器间距2、短指示器4、长指示器9
        return CGFloat((itemCount - 1) * 6 + 9 + 12 + 12)
    }
    
    override public func leftMargin() -> CGFloat {
        return 0.0
    }
    
    override public func rightMargin() -> CGFloat {
        return 0.0
    }

    func indexChanging(fromIndex: Int, fromSection: Int, toIndex: Int, progress: CGFloat) {
        guard fromIndex < self.allDatas.count, toIndex < self.allDatas.count else {
            return
        }
        
//        if toIndex >= 1 {
//            Comp14204PreviewManager.shared.judgeRemove()
//        }
        
        if !isCurrentLunbo() {
            return
        }
        
        let (fromColor, fromImgUrl) = itemAbsorbColor(index:fromIndex)
        let (toColor, toImgUrl) = itemAbsorbColor(index:toIndex)
        print("[lunbo] indexChanging {\(fromIndex) to \(toIndex) progress \(progress)} \(isAdvertItemFor14204(index: fromIndex)) \(isAdvertItemFor14204(index: toIndex))")
        self.lunboBackgroundView?.updateGradientColor(allDatas:self.allDatas, fromIndex:fromIndex, fromColor: fromColor, fromImgUrl:fromImgUrl, toIndex: toIndex, toColor:toColor, toImgurl: toImgUrl, progress: progress, fromIsAdv:isAdvertItemFor14204(index: fromIndex), toIsAdv:isAdvertItemFor14204(index: toIndex))
//        self.topMovieLunboBackgroundView?.updateGradientColor(fromColor: fromColor, fromImgUrl:nil, toColor:toColor, toImgurl: nil, progress: progress, fromIsAdv:isAdvertItemFor14204(index: fromIndex), toIsAdv:isAdvertItemFor14204(index: toIndex))
    }

    func itemAbsorbColor(index: Int) -> (UIColor, String?) {
        let DEFAULT_COLOR = UIColor.createColorWithHexRGB(colorStr: "#463B5D")
        
        var color = DEFAULT_COLOR
        var imgUrl: String?
        
        if index >= 0, index < self.allDatas.count, let item = self.allDatas[index] as? IItem {
            if let absorbColor = item.homeItemModel?.absorbColor {
                color = absorbColor
            }
            imgUrl = item.homeItemModel?.img
        }
        return (color, imgUrl)
    }
    
    //用作顶部背景
    func isAdvertItemFor14204(index: Int) -> Bool {
        if index > 0, index < self.allDatas.count {
            if let itemData = self.allDatas[index] as? String {
                return itemData == "advert" || itemData == ComponentNewNovelAdIdetifier
            } else if let item = self.allDatas[index] as? IItem, let model = item.itemModel as? HomeItemModel {
                if model.isBigCard == false, model.absorbColor == nil {
                    return true
                }
            }
        }
        return false
    }
    
    override func containerDidScroll(_ scrollView: UIScrollView) {
        super.containerDidScroll(scrollView)
        guard let card = self.component?.getCard() else {
            return
        }
        
        if !self.isAfterReuse {
            return
        }
        
        if !isCurrentLunbo() {
            return
        }
        
        let maxScale = calcLunboItemRatio()
        self.sliderView?.notifyItemMaxScaleChanged(scale: maxScale)
        clipContainer(maxScale)
        
//        self.topMovieLunboBackgroundView?.updateTopMovieMode(self.isTopCinemaMode)
//        self.topMovieLunboBackgroundView?.updateBackgroundPosition(scrollView)

        self.lunboBackgroundView?.updateBackgroundPosition(scrollView)
        
//        if isTopCinemaMode {
//            let pageModel = self.component?.getPage()?.pageModel as? SelectionPageModel
//            let inLoadingState = pageModel?.inLoadingState ?? false
//            if !inLoadingState {
//                self.topMovieLunboBackgroundView?.alpha = 1.0
//                self.topMovieLunboBackgroundView?.updateMaxScale(maxScale: topCinemaCompChangeProgress(), lunboHeight: self.component?.getLayoutInfo().height ?? 0.0)
//            } else {
//                self.topMovieLunboBackgroundView?.alpha = 0.0
//            }
//            let colors = self.lunboBackgroundView?.gradientLayer.colors as? [CGColor]
//            self.lunboCardBackgroundView?.updateMaxScale(maxScale: topCinemaCompChangeProgress(), lunboHeight: self.component?.getLayoutInfo().height ?? 0.0, lunboGradientColors: colors, lunboBackgroundView: self.topMovieLunboBackgroundView)
//            if !isInRefreshingOfHomeIcon {
//                let topInset = scrollView.contentInset.top
//                let lunboY = card.getLayoutInfo().y
//                let lunboOffset = lunboY - topInset
//                self.sliderView?.backgroundView.gradientLayer.isHidden = scrollView.contentOffset.y < lunboOffset - 0.01
//                self.sliderView?.backgroundView.backgroundColor = scrollView.backgroundColor
//            } else {
//                self.sliderView?.backgroundView.gradientLayer.isHidden = false
//                self.sliderView?.backgroundView.backgroundColor = scrollView.backgroundColor
//            }
//        } else {
//            self.topMovieLunboBackgroundView?.removeQuadCurveMask()
//            self.sliderView?.backgroundView.gradientLayer.isHidden = false
//            self.sliderView?.backgroundView.backgroundColor = scrollView.backgroundColor
//        }
        if isTopAnimationADMode {
            self.topAnimationADLunboBackgroundView?.containerDidScroll(scrollView)
            var realLunboY = card.getLayoutInfo().y
            if SelectionTopAnimationADManager.shareInstance().canDisplayGuide(self.component?.getPage()) {
                let guideHeight = SelectionTopAnimationADManager.guideViewHeight
                let guideViewTop = realLunboY - guideHeight
                realLunboY = guideViewTop
            }
            let topInset = scrollView.contentInset.top
            let offsetY:CGFloat = scrollView.contentOffset.y
            let realOffset:CGFloat = offsetY + topInset
            if let sliderView = self.sliderView {
                if !isInRefreshingOfHomeIcon {
                    if realLunboY != realOffset  {
                        sliderView.backgroundView.gradientLayer.isHidden = true
                        showTopGuideViewBgColor(false)
                    } else {
                        sliderView.backgroundView.gradientLayer.isHidden = false
                        showTopGuideViewBgColor(true)
                    }
                } else {
                    self.sliderView?.backgroundView.gradientLayer.isHidden = false
                    showTopGuideViewBgColor(true)
                }
            }
        } else {
            self.sliderView?.backgroundView.gradientLayer.isHidden = false
        }

        //顶导渐变通知
        notifyNavigatinBar()
    }
    
    
    override func containerWillBeginDragging(_ scrollView: UIScrollView) {
        super.containerWillBeginDragging(scrollView)
        self.sliderView?.pauseSliding()
    }
    
    override func containerWillEndDragging(_ scrollView: UIScrollView, withVelocity velocity: CGPoint, targetContentOffset: UnsafeMutablePointer<CGPoint>) {
        super.containerWillEndDragging(scrollView, withVelocity: velocity, targetContentOffset: targetContentOffset)
    }
    
    /// 拖拽容器已结束
    override func containerDidEndDragging(_ scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        super.containerDidEndDragging(scrollView, willDecelerate: decelerate)
        if isTopAnimationADMode {
            if !topADCardIsShow {
                self.sliderView?.resumeSliding()
            }
        } else {
            self.sliderView?.resumeSliding()
        }
        
    }
    
    /// 容器滚动减速结束
    override func containerDidEndDecelerating(_ scrollView: UIScrollView) {
        super.containerDidEndDecelerating(scrollView)
        if isTopAnimationADMode {
            if !topADCardIsShow {
                self.sliderView?.resumeSliding()
            }
        } else {
            self.sliderView?.resumeSliding()
        }
    }

    /// 容器滚动动画结束
    override func containerDidEndScrollingAnimation(_ scrollView: UIScrollView) {
        super.containerDidEndScrollingAnimation(scrollView)

        if isTopAnimationADMode {
            if !topADCardIsShow {
                if canResumeSlider() {
                    self.sliderView?.resumeSliding()
                }
            }
        } else {
            if canResumeSlider() {
                self.sliderView?.resumeSliding()
            }
        }
    }
    
    func canResumeSlider() -> Bool {
        return true
    }

    func isCurrentLunbo() -> Bool {
        //暂时不需要lunboBackgroundView展示了
//        guard let lunboBackgroundView = self.lunboBackgroundView, let curDelegate = lunboBackgroundView.currentLunboDelegate else {
//            return false
//        }
//        guard isSameobject(object1: curDelegate, object2: self) else {
//            print("[lunbo] is not same object")
//            return false
//        }
        return true
    }
    
    func clipContainer(_ ratio: CGFloat) {
        //容器裁剪
        if let sliderView = self.sliderView {
            sliderView.collectionViewBg.backgroundColor = .clear
            let det = YKNGap.youku_margin_left() * 2 * (1 - ratio)
            sliderView.collectionViewBg.width = sliderView.width - det
            sliderView.collectionViewBg.height = sliderView.height + CONSTANT.LUNBO_BIGCARD_EXTEND_TOP + CONSTANT.LUNBO_BIGCARD_EXTEND_BOTTOM
            sliderView.collectionViewBg.centerX = sliderView.width / 2.0
            sliderView.collectionViewBg.top = -CONSTANT.LUNBO_BIGCARD_EXTEND_TOP
            sliderView.collectionView.left = -det * 0.5
            sliderView.collectionView.top = CONSTANT.LUNBO_BIGCARD_EXTEND_TOP
            sliderView.collectionViewBg.layer.cornerRadius = 0.0
            if ratio > 0.998 {
                sliderView.collectionViewBg.clipsToBounds = false
            } else {
                sliderView.collectionViewBg.clipsToBounds = true
            }
        }
    }
    
    func notifyNavigatinBar() {
        if !self.isAfterReuse {
            return
        }
        
        if self.isThemeMode, !self.isTopAnimationADMode, !self.isLunboAppleCNYADMode {
            return
        }
        
        var (progress, navAlpha) = calcNavigationAlphaProgress()
        if LunboBackgroundView.currentLunboIs14204 == false {
            progress = 1.0
        }
        print("calcNavigationAlphaProgress \(progress) \(navAlpha)")

        //设置大背景透明度
        let bgAlpha = (progress < 0.5) ? 1.0 : max(1.0 - progress, 0.0)
        self.lunboBackgroundView?.alpha = bgAlpha
        
        //通知顶导
        var userInfo = [String: Any]()
        userInfo["backgroundAlpha"] = progress
        userInfo["navAlpha"] = navAlpha
        if isTopAnimationADMode {
            var naviProgress = calcNavigationAlphaProgressOfTopAnimationADMode().1
            if isInRefreshingOfHomeIcon {
                naviProgress = calcNavigationAlphaProgressOfTopAnimationLoaing().1
            }
            userInfo["naviBackgroundAlpha"] = CGFloat(naviProgress)
            userInfo["backgroundAlpha"] = CGFloat(progress)
            userInfo["realBackgroundAlpha"] = CGFloat(progress)
            print("[top ad] notifyNavi backgroundAlpha:\(progress), naviBackgroundAlpha:\(naviProgress)")
        } else if isLunboAppleCNYADMode {
            var naviProgress = calcNavigationAlphaProgressOfLunboAppleCNYMode().1
            if isInRefreshingOfHomeIcon {
                naviProgress = calcNavigationAlphaProgressOfAppleCNYADLoaing().1
            }
//            userInfo["navAlpha"] = CGFloat(1.0)
            userInfo["naviBackgroundAlpha"] = naviProgress
            userInfo["backgroundAlpha"] = CGFloat(1.0)
            userInfo["realBackgroundAlpha"] = CGFloat(1.0)
            print("[apple cny] notifyNavi backgroundAlpha:\(progress), naviBackgroundAlpha:\(naviProgress)")
        }
        
        postNotification("KRefreshHomeTopViewByNewLunboNotification", nil, userInfo)
        
        //影厅模式透明度保持和顶导一致
//        if self.isTopCinemaMode {
//            if self.isThemeMode {
//                self.lunboBackgroundView?.isHidden = true
//            } else {
//                self.lunboBackgroundView?.alpha = navAlpha;
//                self.lunboBackgroundView?.isHidden = (navAlpha < 0.00001);
//            }
//        } else 
        if self.isTopAnimationADMode {
            self.topAnimationADLunboBackgroundView?.alpha = progress
            self.topAnimationADLunboBackgroundView?.isHidden = (progress <= 0.0001)
        } else if self.isLunboAppleCNYADMode {
            if self.isThemeMode {
                self.lunboBackgroundView?.isHidden = true
            } else {
                self.lunboBackgroundView?.alpha = navAlpha;
                self.lunboBackgroundView?.isHidden = (navAlpha < 0.00001);
            }
            var naviProgress = calcNavigationAlphaProgressOfLunboAppleCNYMode().1
            if isInRefreshingOfHomeIcon {
                naviProgress = calcNavigationAlphaProgressOfAppleCNYADLoaing().1
            }
            if naviProgress > 0.1 {
                var themeColors = self.themeBgColors
                if !forceShowThemeBgColor  {
                    themeColors = nil
                }
                var userInfo = [String:Any]()
                if let themeColors = themeColors {
                    userInfo["themeColors"] = themeColors
                }
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yksc.event.comp.lunbo.14333.refreshTheme"), object: nil, userInfo: userInfo)
                let containerView = self.component?.pageContext?.getContainerView()
                let topBgColorView = containerView?.viewWithTag(202303176)
                topBgColorView?.alpha = 0
            } else {
                var themeColors = self.themeBgColors
                if !forceShowThemeBgColor  {
                    themeColors = nil
                }
                var userInfo = [String:Any]()
                if let themeColors = themeColors {
                    userInfo["themeColors"] = themeColors
                }
                NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yksc.event.comp.lunbo.14333.refreshTheme"), object: nil, userInfo: userInfo)
                let containerView = self.component?.pageContext?.getContainerView()
                let topBgColorView = containerView?.viewWithTag(202303176)
                topBgColorView?.alpha = 1
            }
        }
    }
    
    func showTopGuideViewBgColor(_ show: Bool) {
        if self.isTopAnimationADMode {
            let container = self.component?.getPage()?.containerView
            let tag = SelectionTopAnimationADManager.guideViewTag
            let topAniView = container?.viewWithTag(tag) as? TopAnimationADGuideView
            if !show {
//                UIView.animate(withDuration: 0.3) {
//                    topAniView?.themesColorBgView.alpha = 0.0
//                } completion: { finish in
                    topAniView?.themesColorBgView.alpha = 0.0
                    topAniView?.themesColorBgView.isHidden = true
                    topAniView?.themesColorBgView.backgroundColor = .clear
//                }
            } else {
                topAniView?.themesColorBgView.alpha = 1.0
                topAniView?.themesColorBgView.isHidden = false
                topAniView?.themesColorBgView.backgroundColor = self.themeBgColors?.first ?? .clear
            }
        }
    }
    
    override func refreshSliderBackground() {
        super.refreshSliderBackground()
        var themeColors = self.themeBgColors
        if !isFirstComponent() {
            themeColors = nil
        } else {
            if self.isTopAnimationADMode && forceShowThemeBgColor == false { //新刷新模式，上拉到顶部强制关闭
                themeColors = nil
            }
        }
        if themeColors == nil {
            showTopGuideViewBgColor(false)
        } else {
            showTopGuideViewBgColor(true)
        }
    }
    
    @objc func themeDidChanged() {
        let preIsThemeMode = self.isThemeMode
        
        //是否分为氛围模式
        self.isThemeMode = getIsThemeMode()
        print("lunbo isThemeMode \(isThemeMode)")
        
        //轮播大小
        let maxScale = calcLunboItemRatio()
        self.sliderView?.notifyItemMaxScaleChanged(scale: maxScale)
        clipContainer(maxScale)
        if let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView {
            self.lunboBackgroundView?.updateBackgroundPosition(scrollView)
        }
        self.lunboBackgroundView?.isHidden = self.isThemeMode
//        if isTopCinemaMode {
//            self.topMovieLunboBackgroundView?.isHidden = self.isThemeMode
//        } else {
//            self.topMovieLunboBackgroundView?.isHidden = true
//        }
        if preIsThemeMode == self.isThemeMode {
            return
        }
        
        //通知顶导
        if self.isThemeMode {
            //设置大背景透明度
            self.lunboBackgroundView?.alpha = 1.0
            //通知顶导
            var userInfo = [String: Any]()
            userInfo["backgroundAlpha"] = CGFloat(1.0)
            postNotification("KRefreshHomeTopViewByNewLunboNotification", nil, userInfo)
        } else {
            notifyNavigatinBar()
        }
    }
    
    @objc func reloadScrollToLunbo() {
        weak var weakself = self
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05) {
            guard let weakself = weakself else {
                return
            }
            let maxScale = weakself.calcLunboItemRatio()
            weakself.sliderView?.notifyItemMaxScaleChanged(scale: maxScale)
            weakself.clipContainer(maxScale)
            if let scrollView = weakself.component?.pageContext?.getContainerView() as? UIScrollView {
                weakself.lunboBackgroundView?.updateBackgroundPosition(scrollView)
            }
            //顶导渐变通知
            weakself.notifyNavigatinBar()
        }
    }
    
    func getUserInfo() -> (String, Int) {
     return ("Tom",25)
    }


    func calcNavigationAlphaProgress() -> (CGFloat, CGFloat) {
        if isPullDrawerMode {
            if isInRefreshingOfHomeIcon {
                let value = calcNavigationAlphaProgressOfPullDrawerModeLoaing()
                return (value, 1.0)
            } else {
                let value = calcNavigationAlphaProgressOfPullDrawerMode()
                return (value, 1.0)
            }
        } 
//        else if isTopCinemaMode {
//            if isInRefreshingOfHomeIcon {
//                let value = calcNavigationAlphaProgressOfPullDrawerModeLoaing()
//                return (value, 1.0)
//            } else {
//                return calcNavigationAlphaProgressOfTopMovieMode()
//            }
//        } 
        else if isTopAnimationADMode {
            if isInRefreshingOfHomeIcon {
                let value = calcNavigationAlphaProgressOfTopAnimationLoaing().0
                return (value, 1.0)
            } else {
                let value = calcNavigationAlphaProgressOfTopAnimationADMode().0
                return (value, 1.0)
            }
        } else if isLunboAppleCNYADMode {
            if isInRefreshingOfHomeIcon {
                let value = calcNavigationAlphaProgressOfTopAnimationLoaing().0
                return (value, 1.0)
            } else {
                let value = calcNavigationAlphaProgressOfTopAnimationADMode().0
                return (value, 1.0)
            }
        } else {
            let value = calcNavigationAlphaProgressOfNormalMode()
            return (value, 1.0)
        }
    }
    
    func calcNavigationAlphaProgressOfPullDrawerMode() -> CGFloat {
        guard let card = self.component?.getCard() else {
            return 0.0
        }
        
        let lunboY = card.getLayoutInfo().y
        
        guard let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView else {
            return 0.0
        }
        let topInset = scrollView.contentInset.top
        
        let cardTopRatio = bigCardMaxHeight > 0 ? (CONSTANT.LUNBO_BIGCARD_EXTEND_TOP/bigCardMaxHeight) : 0.0
        let st:CGFloat = lunboY // -->0.0
        
        //向上滚动临界点
        var end1:CGFloat = st + bigCardMaxHeight * (0.5 - cardTopRatio) // -->0.5
        var end2:CGFloat = st + bigCardMaxHeight * (0.7 - cardTopRatio) // -->1.0
        
        //向下滚动临界点
        var end3:CGFloat = st - 50.0 // -->0.5
        var end4:CGFloat = st - 75.0 // -->1.0
        
        let offset = scrollView.contentOffset.y + topInset

        var progress = 0.0
        
        if offset == 0 {
            progress = 1.0
        } else if offset <= end4 {
            progress = 1.0
        } else if offset > end4, offset < end3 {
            progress = calcInterpolationValue(p1: end4, p1Value: 1.0, p2: end3, p2Value: 0.5, x: offset)
        } else if offset >= end3, offset <= st {
            progress = calcInterpolationValue(p1: end3, p1Value: 0.5, p2: st, p2Value: 0.0, x: offset)
        } else if offset > st, offset <= end1 {
            progress = calcInterpolationValue(p1: st, p1Value: 0.0, p2: end1, p2Value: 0.5, x: offset)
        } else if offset > end1, offset < end2 {
            progress = calcInterpolationValue(p1: end1, p1Value: 0.5, p2: end2, p2Value: 1.0, x: offset)
        } else {
            progress = 1.0
        }
        
        return progress
    }

//    func calcNavigationAlphaProgressOfTopMovieMode() -> (CGFloat, CGFloat) {
//        guard let card = self.component?.getCard() else {
//            return (0.0, 1.0)
//        }
//        guard let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView else {
//            return (0.0, 1.0)
//        }
//        
//        let lunboY = card.getLayoutInfo().y
//        let topInset = scrollView.contentInset.top
//        
//        let cardTopRatio = bigCardMaxHeight > 0 ? (CONSTANT.LUNBO_BIGCARD_EXTEND_TOP/bigCardMaxHeight) : 0.0
//        let st:CGFloat = lunboY // -->0.0
//        
//        //向上滚动临界点
//        var end1:CGFloat = st + bigCardMaxHeight * (0.5 - cardTopRatio) // -->0.5
//        var end2:CGFloat = st + bigCardMaxHeight * (0.7 - cardTopRatio) // -->1.0
//        
//        //向下滚动临界点（整个顶导的透明度）
//        var end3:CGFloat = st - TOP_CENEMA_OFFSET_NAV_TRANSPARENT // -->0.0
//        var end4:CGFloat = end3 // -->0.0
//        
//        let offset = scrollView.contentOffset.y + topInset
//
//        var progress = 0.0
//        var navAlpha: CGFloat = 1.0
//        
//        if offset <= end4 {
//            navAlpha = 0.0
//        } else if offset > end4, offset < end3 {
//            navAlpha = 0.0
//        } else if offset >= end3, offset <= st {
//            navAlpha = calcInterpolationValue(p1: end3, p1Value: 0.0, p2: st, p2Value: 1.0, x: offset)
//        } else if offset > st, offset <= end1 {
//            progress = calcInterpolationValue(p1: st, p1Value: 0.0, p2: end1, p2Value: 0.5, x: offset)
//        } else if offset > end1, offset < end2 {
//            progress = calcInterpolationValue(p1: end1, p1Value: 0.5, p2: end2, p2Value: 1.0, x: offset)
//        } else {
//            progress = 1.0
//        }
//        
//        print("calcNavigationAlphaProgressOfTopMovieMode \(progress) \(navAlpha)")
//        
//        return (progress, navAlpha)
//    }
    
    
    func calcNavigationAlphaProgressOfTopAnimationADMode() -> (CGFloat, CGFloat) {
        guard let card = self.component?.getCard() else {
            return (0.0, 0.0)
        }
        
        var lunboY = card.getLayoutInfo().y
        if SelectionTopAnimationADManager.shareInstance().canDisplayGuide(self.component?.getPage()) {
            let guideHeight = SelectionTopAnimationADManager.guideViewHeight
            let guideViewTop = lunboY - guideHeight
            lunboY = guideViewTop
        }

        guard let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView else {
            return (0.0, 0.0)
        }
        let topInset = scrollView.contentInset.top
        
        let cardTopRatio = bigCardMaxHeight > 0 ? (CONSTANT.LUNBO_BIGCARD_EXTEND_TOP/bigCardMaxHeight) : 0.0
        let st:CGFloat = lunboY // -->0.0
        
        //向上滚动临界点
        var end1:CGFloat = st + bigCardMaxHeight * (0.5 - cardTopRatio) // -->0.5
        var end2:CGFloat = st + bigCardMaxHeight * (0.7 - cardTopRatio) // -->1.0
        
        //向下滚动临界点
        var end3:CGFloat = st - 50.0 // -->0.5
        var end4:CGFloat = st - 75.0 // -->1.0
        
        let offset = scrollView.contentOffset.y + topInset

        var progress = 0.0
        var naviProgress = 0.0
        if offset <= end4 {
            progress = 1.0
            naviProgress = 0.0
        } else if offset > end4, offset < end3 {
            progress = calcInterpolationValue(p1: end4, p1Value: 1.0, p2: end3, p2Value: 0.5, x: offset)
            naviProgress = 0.0
        } else if offset >= end3, offset <= st {
            progress = calcInterpolationValue(p1: end3, p1Value: 0.5, p2: st, p2Value: 0.0, x: offset)
            naviProgress = 0.0
        } else if offset > st, offset <= end1 {
            progress = calcInterpolationValue(p1: st, p1Value: 0.0, p2: end1, p2Value: 0.5, x: offset)
            naviProgress = progress
        } else if offset > end1, offset < end2 {
            progress = calcInterpolationValue(p1: end1, p1Value: 0.5, p2: end2, p2Value: 1.0, x: offset)
            naviProgress = progress
        } else {
            progress = 1.0
            naviProgress = progress
        }
        
        return (progress, naviProgress)
    }
    
    
    func calcNavigationAlphaProgressOfLunboAppleCNYMode() -> (CGFloat, CGFloat) {
        guard let card = self.component?.getCard() else {
            return (0.0, 0.0)
        }
        
        var lunboY = card.getLayoutInfo().y

        if SelectionLunboAppleCNYADManager.shareInstance().isLunboAppleCNYADMode(self.component?.getPage()) {
            if let cards = card.getPage()?.getCards() {
                for card in cards {
                    if let cardType = card.cardModel?.type, cardType == "15040" {
                        lunboY = card.getLayoutInfo().y
                    }
                }
            }
        }
        guard let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView else {
            return (0.0, 0.0)
        }
        let topInset = scrollView.contentInset.top
        
        let cardTopRatio = bigCardMaxHeight > 0 ? (CONSTANT.LUNBO_BIGCARD_EXTEND_TOP/bigCardMaxHeight) : 0.0
        let st:CGFloat = lunboY // -->0.0
        
        //向上滚动临界点
        var end1:CGFloat = st + 40 // -->0.5
        var end2:CGFloat = st + 80 // -->1.0
        
        //向下滚动临界点
        var end3:CGFloat = st - 20.0 // -->0.5
        var end4:CGFloat = st - 45.0 // -->1.0
        
        let offset = scrollView.contentOffset.y + topInset

        var progress = 0.0
        var naviProgress = 0.0
        if offset <= end4 {
            progress = 1.0
            naviProgress = 0.0
        } else if offset > end4, offset < end3 {
            progress = calcInterpolationValue(p1: end4, p1Value: 1.0, p2: end3, p2Value: 0.5, x: offset)
            naviProgress = 0.0
        } else if offset >= end3, offset <= st {
            progress = calcInterpolationValue(p1: end3, p1Value: 0.5, p2: st, p2Value: 0.0, x: offset)
            naviProgress = 0.0
        } else if offset > st, offset <= end1 {
            progress = calcInterpolationValue(p1: st, p1Value: 0.0, p2: end1, p2Value: 0.5, x: offset)
            naviProgress = progress
        } else if offset > end1, offset < end2 {
            progress = calcInterpolationValue(p1: end1, p1Value: 0.5, p2: end2, p2Value: 1.0, x: offset)
            naviProgress = progress
        } else {
            progress = 1.0
            naviProgress = progress
        }
        
        return (progress, naviProgress)
    }
    
    func calcNavigationAlphaProgressOfPullDrawerModeLoaing() -> CGFloat {
        guard let card = self.component?.getCard() else {
            return 0.0
        }
        
        let lunboY = card.getLayoutInfo().y
        
        guard let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView else {
            return 0.0
        }
        let topInset = scrollView.contentInset.top
        
        let cardTopRatio = bigCardMaxHeight > 0 ? (CONSTANT.LUNBO_BIGCARD_EXTEND_TOP/bigCardMaxHeight) : 0.0
        let st:CGFloat = lunboY // -->0.0
        
        //向上滚动临界点
        var end1:CGFloat = st + bigCardMaxHeight * (0.5 - cardTopRatio) // -->0.5
        var end2:CGFloat = st + bigCardMaxHeight * (0.7 - cardTopRatio) // -->1.0
        
        //向下滚动临界点
        var end3:CGFloat = st - 50.0 // -->0.5
        var end4:CGFloat = st - LOADING_OFFSET // -->1.0
        
        let offset = scrollView.contentOffset.y + topInset

        var progress = 0.0
        
        if offset <= end4 {
            progress = 0.0
        } else if offset > end4, offset < end3 {
            progress = 0.0
        } else if offset >= end3, offset <= st {
            progress = 0.0
        } else if offset > st, offset <= end1 {
            progress = calcInterpolationValue(p1: st, p1Value: 0.0, p2: end1, p2Value: 0.5, x: offset)
        } else if offset > end1, offset < end2 {
            progress = calcInterpolationValue(p1: end1, p1Value: 0.5, p2: end2, p2Value: 1.0, x: offset)
        } else {
            progress = 1.0
        }
        
        if progress > 0.9 {
            print("progress \(progress)")
        }
        
        return progress
    }
    
    
    func calcNavigationAlphaProgressOfTopAnimationLoaing() -> (CGFloat, CGFloat) {
        guard let card = self.component?.getCard() else {
            return (0.0, 0.0)
        }
        
        var lunboY = card.getLayoutInfo().y
        if SelectionTopAnimationADManager.shareInstance().canDisplayGuide(self.component?.getPage()) {
            let guideHeight = SelectionTopAnimationADManager.guideViewHeight
            let guideViewTop = lunboY - guideHeight
            lunboY = guideViewTop
        }
        
        guard let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView else {
            return (0.0, 0.0)
        }
        let topInset = scrollView.contentInset.top
        
        let cardTopRatio = bigCardMaxHeight > 0 ? (CONSTANT.LUNBO_BIGCARD_EXTEND_TOP/bigCardMaxHeight) : 0.0
        let st:CGFloat = lunboY // -->0.0
        
        //向上滚动临界点
        var end1:CGFloat = st + bigCardMaxHeight * (0.5 - cardTopRatio) // -->0.5
        var end2:CGFloat = st + bigCardMaxHeight * (0.7 - cardTopRatio) // -->1.0
        
        //向下滚动临界点
        var end3:CGFloat = st - 50.0 // -->0.5
        var end4:CGFloat = st - LOADING_OFFSET // -->1.0
        
        let offset = scrollView.contentOffset.y + topInset

        var progress = 0.0
        var naviProgress = 0.0

        if offset <= end4 {
            progress = 0.0
            naviProgress = 0.0
        } else if offset > end4, offset < end3 {
            progress = 0.0
            naviProgress = 0.0
        } else if offset >= end3, offset <= st {
            progress = 0.0
            naviProgress = 0.0
        } else if offset > st, offset <= end1 {
            progress = calcInterpolationValue(p1: st, p1Value: 0.0, p2: end1, p2Value: 0.5, x: offset)
            naviProgress = progress
        } else if offset > end1, offset < end2 {
            progress = calcInterpolationValue(p1: end1, p1Value: 0.5, p2: end2, p2Value: 1.0, x: offset)
            naviProgress = progress
        } else {
            progress = 1.0
            naviProgress = progress
        }
        
        if progress > 0.9 {
            print("progress \(progress)")
        }
        
        return (progress, naviProgress)
    }
    
    func calcNavigationAlphaProgressOfAppleCNYADLoaing() -> (CGFloat, CGFloat) {
        guard let card = self.component?.getCard() else {
            return (0.0, 0.0)
        }
        
        var lunboY = card.getLayoutInfo().y
        if SelectionLunboAppleCNYADManager.shareInstance().isLunboAppleCNYADMode(self.component?.getPage()) {
            if let cards = card.getPage()?.getCards() {
                for card in cards {
                    if let cardType = card.cardModel?.type, cardType == "15040" {
                        lunboY = card.getLayoutInfo().y
                    }
                }
            }
        }
        
        guard let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView else {
            return (0.0, 0.0)
        }
        let topInset = scrollView.contentInset.top
        
        let cardTopRatio = bigCardMaxHeight > 0 ? (CONSTANT.LUNBO_BIGCARD_EXTEND_TOP/bigCardMaxHeight) : 0.0
        let st:CGFloat = lunboY // -->0.0
        
        //向上滚动临界点
        var end1:CGFloat = st + bigCardMaxHeight * (0.5 - cardTopRatio) // -->0.5
        var end2:CGFloat = st + bigCardMaxHeight * (0.7 - cardTopRatio) // -->1.0
        
        //向下滚动临界点
        var end3:CGFloat = st - 50.0 // -->0.5
        var end4:CGFloat = st - LOADING_OFFSET // -->1.0
        
        let offset = scrollView.contentOffset.y + topInset

        var progress = 0.0
        var naviProgress = 0.0

        if offset <= end4 {
            progress = 0.0
            naviProgress = 0.0
        } else if offset > end4, offset < end3 {
            progress = 0.0
            naviProgress = 0.0
        } else if offset >= end3, offset <= st {
            progress = 0.0
            naviProgress = 0.0
        } else if offset > st, offset <= end1 {
            progress = calcInterpolationValue(p1: st, p1Value: 0.0, p2: end1, p2Value: 0.5, x: offset)
            naviProgress = progress
        } else if offset > end1, offset < end2 {
            progress = calcInterpolationValue(p1: end1, p1Value: 0.5, p2: end2, p2Value: 1.0, x: offset)
            naviProgress = progress
        } else {
            progress = 1.0
            naviProgress = progress
        }
        
        if progress > 0.9 {
            print("progress \(progress)")
        }
        
        return (progress, naviProgress)
    }
    
    func calcNavigationAlphaProgressOfNormalMode() -> CGFloat {
        guard let card = self.component?.getCard() else {
            return 0.0
        }
        
        let lunboY = card.getLayoutInfo().y
        
        guard let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView else {
            return 0.0
        }
        let topInset = scrollView.contentInset.top
        
        let cardTopRatio = bigCardMaxHeight > 0 ? (CONSTANT.LUNBO_BIGCARD_EXTEND_TOP/bigCardMaxHeight) : 0.0
        let st:CGFloat = lunboY // -->0.0
        
        //向上滚动临界点
        var end1:CGFloat = st + bigCardMaxHeight * (0.5 - cardTopRatio) // -->0.5
        var end2:CGFloat = st + bigCardMaxHeight * (0.7 - cardTopRatio) // -->1.0
        
        //向下滚动临界点
        var end3:CGFloat = st //- 50.0 // -->0.5
        var end4:CGFloat = st //- 75.0 // -->1.0
        
        let offset = scrollView.contentOffset.y + topInset

        var progress = 0.0
        
        if offset <= end4 {
            progress = 0.0
        } else if offset > end4, offset < end3 {
            progress = 0.0
        } else if offset >= end3, offset <= st {
            progress = 0.0
        } else if offset > st, offset <= end1 {
            progress = calcInterpolationValue(p1: st, p1Value: 0.0, p2: end1, p2Value: 0.5, x: offset)
        } else if offset > end1, offset < end2 {
            progress = calcInterpolationValue(p1: end1, p1Value: 0.5, p2: end2, p2Value: 1.0, x: offset)
        } else {
            progress = 1.0
        }
        
        return progress
    }
    
    func calcLunboItemRatio() -> CGFloat {
        guard let card = self.component?.getCard() else {
            return 0.0
        }
        if self.isThemeMode {
            return 0.0
        }
        if self.hasAppleAdv {
            return 0.0
        }
        
        let lunboY = card.getLayoutInfo().y
        
        guard let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView else {
            return 0.0
        }
        let topInset = scrollView.contentInset.top
        
        print("[jbp] lunbo y \(lunboY), offset \(scrollView.contentOffset.y) topInset\(topInset)")

        var st:CGFloat = lunboY // -->0.0
        var end:CGFloat = 0 // -->1.0
        
        if isPullDrawerMode, !isInRefreshingOfHomeIcon {
            end = 0.0
        }
//        else if isTopCinemaMode, !isInRefreshingOfHomeIcon {
//            end = lunboY - TOP_CENEMA_OFFSET_SMALLCARD
//        }
        else if isTopAnimationADMode, !isInRefreshingOfHomeIcon {
            end = 0.0
        }  else {
            end = lunboY - LOADING_OFFSET //下拉刷新位置
        }

        if abs(st - end) < 0.000001 {
            return 1.0
        }

        let offset = scrollView.contentOffset.y + topInset
        var ratio = calcInterpolationValue(p1: st, p1Value: 1.0, p2: end, p2Value: 0.0, x: offset)
        
        if ratio < 0 {
            ratio = 0.0
        }
        if ratio > 1.0 {
            ratio = 1.0
        }
        return ratio
    }
    
//    func topCinemaCompChangeProgress() -> CGFloat {
//        guard let card = self.component?.getCard() else {
//            return 0.0
//        }
//        guard let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView else {
//            return 0.0
//        }
//        if !isTopCinemaMode {
//            return 0.0
//        }
//        
//        let lunboY = card.getLayoutInfo().y
//        
//        let topInset = scrollView.contentInset.top
//        
//        print("[jbp] lunbo y \(lunboY), offset \(scrollView.contentOffset.y) topInset\(topInset)")
//
//        var st:CGFloat = lunboY // -->0.0
//        var end:CGFloat = 0 // -->1.0
//        
//        if !isInRefreshingOfHomeIcon {
//            end = lunboY - TOP_CENEMA_OFFSET_SMALLCARD
//        } else {
//            end = lunboY - LOADING_OFFSET //下拉刷新位置
//        }
//
//        if abs(st - end) < 0.000001 {
//            return 1.0
//        }
//
//        let offset = scrollView.contentOffset.y + topInset
//        var ratio = calcInterpolationValue(p1: st, p1Value: 1.0, p2: end, p2Value: 0.0, x: offset)
//        
//        if ratio < 0 {
//            ratio = 0.0
//        }
//        if ratio > 1.0 {
//            ratio = 1.0
//        }
//        return ratio
//    }
    
//    func topAnimationADChangeProgress() -> CGFloat {
//        guard let card = self.component?.getCard() else {
//            return 0.0
//        }
//        guard let scrollView = self.component?.pageContext?.getContainerView() as? UIScrollView else {
//            return 0.0
//        }
//        if !isTopAnimationADMode {
//            return 0.0
//        }
//        
//        var lunboY = card.getLayoutInfo().y
//        if SelectionTopAnimationADManager.shareInstance().canDisplayGuide(self.component?.getPage()) {
//            let guideHeight = SelectionTopAnimationADManager.guideViewHeight
//            let guideViewTop = lunboY - guideHeight
//            lunboY = guideViewTop
//        }
//        
//        let topInset = scrollView.contentInset.top
//        
//        print("[jbp] lunbo y \(lunboY), offset \(scrollView.contentOffset.y) topInset\(topInset)")
//
//        var st:CGFloat = lunboY // -->0.0
//        var end:CGFloat = 0 // -->1.0
//        
//        if !isInRefreshingOfHomeIcon {
//            end = lunboY - TOP_CENEMA_OFFSET_SMALLCARD
//        } else {
//            end = lunboY - LOADING_OFFSET //下拉刷新位置
//        }
//
//        if abs(st - end) < 0.000001 {
//            return 1.0
//        }
//
//        let offset = scrollView.contentOffset.y + topInset
//        var ratio = calcInterpolationValue(p1: st, p1Value: 1.0, p2: end, p2Value: 0.0, x: offset)
//        
//        if ratio < 0 {
//            ratio = 0.0
//        }
//        if ratio > 1.0 {
//            ratio = 1.0
//        }
//        return ratio
//    }
    
    @objc private func receiveAdaptorEvent(_ notification: Notification) {
        guard let userInfo = notification.userInfo else {
            return
        }
        guard let event = userInfo["event"] as? String else {
            return
        }
        if event == "firstPageRequestDidSucceed" {
            self.isInRefreshingOfHomeIcon = false
        }
        if event == "firstPageRequestDidFail" {
            self.isInRefreshingOfHomeIcon = false
        }
    }
    
    @objc private func triggerRefreshByIcon() {
        self.isInRefreshingOfHomeIcon = true
    }
}
