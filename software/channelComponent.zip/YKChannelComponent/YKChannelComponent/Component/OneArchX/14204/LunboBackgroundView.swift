//
//  LunboBackgroundView.swift
//  YKChannelComponent
//
//  Created by better on 2022/11/9.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import SwiftUI
import YoukuResource
import YKChannelPage
import YKHome

class LunboBackgroundBaseView: UIView {
    
    var lunboY: CGFloat = 0.0
    var lunboHeight: CGFloat = 0.0
    var containerPaddingTop: CGFloat = 0.0
    weak var currentLunboDelegate: AnyObject?
    weak var component:IComponent?
    lazy var gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 1.0, y: 0.0)
        self.layer.addSublayer(layer)
        layer.frame = self.bounds
        return layer
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .clear
        self.isUserInteractionEnabled = false
        self.clipsToBounds = true
        
        NotificationCenter.default.addObserver(self, selector: #selector(refreshTheme), name: Notification.Name(rawValue: "YKNThemeDidChangeNotification"), object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func reuse(_ component: IComponent?) {
        self.component = component
        guard let component = component else {
            return
        }
        guard let container = component.pageContext?.getContainerView() as? UICollectionView else {
            return
        }
        guard let layoutConfig = component.getComponentDelegate()?.layoutConfig() else {
            return
        }
        guard let pageDelegate = component.getPage()?.getPageDelegate() else {
            return
        }
        let layoutInfo = component.getLayoutInfo()

        self.containerPaddingTop = pageDelegate.layoutConfig().containerPadding.top
        self.lunboY = layoutInfo.y
        self.lunboHeight = layoutInfo.height - layoutConfig.padding.bottom
        
        let bgFrame = CGRect.init(x: 0, y: container.contentOffset.y, width: container.width, height: backgroundHeight())
        self.frame = bgFrame
        self.gradientLayer.frame = self.bounds
        container.sendSubviewToBack(self)
    }
    
    func backgroundHeight() -> CGFloat {
        return self.containerPaddingTop + lunboHeight + CONSTANT.LUNBO_BIGCARD_EXTEND_BOTTOM
    }
    
    func updateBackgroundPosition(_ scrollView: UIScrollView) {
        self.top = scrollView.contentOffset.y

        let offset = self.containerPaddingTop + scrollView.contentOffset.y
        if offset > lunboY {
            self.height = backgroundHeight() - (offset - lunboY)
        } else {
            self.height = backgroundHeight()
        }
    }
    
    func updateGradientColor( fromColor: UIColor?, toColor: UIColor?, progress: CGFloat) {
        guard let fromColor = fromColor else {
            return
        }
        guard let toColor = toColor else {
            return
        }
        CATransaction.begin()
        CATransaction.setDisableActions(true)

        if progress < 0.5 {
            self.gradientLayer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 2 * progress)]
        } else {
            self.gradientLayer.locations = [NSNumber.init(value: (2 * progress - 1.0)), NSNumber.init(value: 1)]
        }
        self.gradientLayer.colors = [fromColor.cgColor, toColor.cgColor]
    
        CATransaction.commit()
    }
    
    @objc func refreshTheme() {
        
    }
}

class LunboBackgroundTopView: LunboBackgroundBaseView {
    static let TAG = 2022110987
    
    override func backgroundHeight() -> CGFloat {
        return self.containerPaddingTop - CONSTANT.LUNBO_BIGCARD_EXTEND_TOP
    }
    
    static func config(_ component: IComponent?) -> LunboBackgroundTopView? {
        guard let component = component else {
            return nil
        }
        guard let container = component.pageContext?.getContainerView() as? UICollectionView else {
            return nil
        }
        var bgView = container.viewWithTag(TAG) as? LunboBackgroundTopView
        if bgView == nil {
            let tmpView = LunboBackgroundTopView()
            tmpView.tag = TAG
            tmpView.layer.zPosition = 1000
            container.addSubview(tmpView)
            bgView = tmpView
        }
        bgView?.reuse(component)
        return bgView
    }
}

class LunboBackgroundView: LunboBackgroundBaseView {

    static let TAG = 2022110986

    static var currentLunboIs14204 = false
    
    var isThemeMode: Bool = false
    weak var topView: LunboBackgroundTopView?
        
    lazy var whiteGradientLayerView: UIView = {
        let view = UIView.init()
        self.addSubview(view)
        view.backgroundColor = UIColor.clear
        view.frame = self.bounds
        view.isUserInteractionEnabled = false
        return view
    }()

    lazy var whiteGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 0.4), NSNumber.init(value: 1.0)]
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)

        self.whiteGradientLayerView.layer.insertSublayer(layer, at: 0)
        layer.colors = gradientColors()
        layer.frame = self.whiteGradientLayerView.bounds
        return layer
    }()
    
    lazy var adDefaultBgView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        self.addSubview(view)
        return view
    }()

    static func config(_ component: IComponent?, isThemeMode: Bool) -> LunboBackgroundView? {
        guard let component = component else {
            return nil
        }
        guard let container = component.pageContext?.getContainerView() as? UICollectionView else {
            return nil
        }
        let tag = TAG
        var bgView = container.viewWithTag(tag) as? LunboBackgroundView
        if bgView == nil {
            let tmpView = LunboBlurBackgroundView()
            tmpView.tag = tag
            tmpView.layer.zPosition = -1000
            container.addSubview(tmpView)
            bgView = tmpView
        }
        bgView?.reuse(component)
        bgView?.isThemeMode = isThemeMode
        bgView?.isHidden = isThemeMode
        return bgView
    }
    
    static func removeLunboBackground(_ component: IComponent?) {
        guard let component = component else {
            return
        }
        guard let container = component.pageContext?.getContainerView() as? UICollectionView else {
            return
        }
        var bgView = container.viewWithTag(TAG) as? LunboBackgroundView
        bgView?.removeFromSuperview()
    }
    
    override func reuse(_ component: IComponent?) {
        super.reuse(component)
        
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        self.whiteGradientLayerView.frame = self.bounds
        self.whiteGradientLayer.frame = self.bounds

        let height = self.containerPaddingTop + lunboHeight + CONSTANT.LUNBO_BIGCARD_EXTEND_BOTTOM
        let topLoc = (self.containerPaddingTop - CONSTANT.LUNBO_BIGCARD_EXTEND_TOP) / height
        let midLoc = self.containerPaddingTop / height
        self.whiteGradientLayer.locations = [NSNumber.init(value: topLoc), NSNumber.init(value: midLoc), NSNumber.init(value: 1.0)]
        CATransaction.commit()

//        self.topView = LunboBackgroundTopView.config(component)
        
        self.adDefaultBgView.frame = CGRect.init(x: 0.0, y: 0.0, width: self.width, height: self.containerPaddingTop)
        ///初始值是134 怀疑是顶导高度
        var standartHeight = homeContainerPaddingTop()
        if standartHeight < 10 {
            standartHeight = 134.0
        }
        let h = self.width * standartHeight / 375.0
        if h > self.containerPaddingTop {
            self.adDefaultBgView.top = -(h - self.containerPaddingTop)
            self.adDefaultBgView.height = h
        }

        let url =
        "https://img.alicdn.com/imgextra/i1/O1CN01gdqixh1poSKNC9CEJ_!!6000000005407-2-tps-375-134.png"
        //"https://img.alicdn.com/imgextra/i4/O1CN01xVll5u1N5I1RjZsHq_!!6000000001518-2-tps-375-134.png"
        self.adDefaultBgView.ykn_setImage(withURLString: url, module: nil, imageSize: .zero, parameters: nil, completed: nil)
    }
    
    override func updateBackgroundPosition(_ scrollView: UIScrollView) {
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        super.updateBackgroundPosition(scrollView)
        self.topView?.updateBackgroundPosition(scrollView)
        self.whiteGradientLayer.bottom = self.height
        CATransaction.commit()
    }
    
    func updateGradientColor(allDatas:[Any],
                             fromIndex: Int,
                             fromColor: UIColor?,
                             fromImgUrl: String?,
                             toIndex:Int,
                             toColor: UIColor?,
                             toImgurl: String?,
                             progress: CGFloat,
                             fromIsAdv:Bool,
                             toIsAdv:Bool) {
        self.updateGradientColor(fromColor: fromColor, fromImgUrl:fromImgUrl, toColor: toColor, toImgurl: toImgurl, progress: progress, fromIsAdv: fromIsAdv, toIsAdv: toIsAdv)
    }
    
    func updateGradientColor(fromColor: UIColor?, fromImgUrl: String?, toColor: UIColor?, toImgurl: String?, progress: CGFloat, fromIsAdv:Bool, toIsAdv:Bool) {
        self.updateGradientColor(fromColor: fromColor, toColor: toColor, progress: progress)
        if fromIsAdv, toIsAdv {
            self.adDefaultBgView.alpha = 1.0
        } else if fromIsAdv {
            self.adDefaultBgView.alpha = progress
        } else if toIsAdv {
            self.adDefaultBgView.alpha = 1.0 - progress
        } else {
            self.adDefaultBgView.alpha = 0.0
        }
    }
    
    override func updateGradientColor(fromColor: UIColor?, toColor: UIColor?, progress: CGFloat) {
        super.updateGradientColor(fromColor: fromColor, toColor: toColor, progress: progress)
        self.topView?.updateGradientColor(fromColor: fromColor, toColor: toColor, progress: progress)
    }

    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        self.whiteGradientLayer.colors = gradientColors()
    }

    @objc override func refreshTheme() {
        super.refreshTheme()
        self.whiteGradientLayer.colors = gradientColors()
    }
    
    func gradientColors() -> [CGColor] {
        let clr1 = UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0).cgColor
        let clr2 = UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0.1).cgColor
        let clr3 = UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(1).cgColor

        let clr11 = UIColor.white.withAlphaComponent(0).cgColor
        let clr12 = UIColor.white.withAlphaComponent(0.1).cgColor
        let clr13 = UIColor.white.withAlphaComponent(1).cgColor
        return isDark() ? [clr1, clr2, clr3] : [clr11, clr12, clr13]
    }
    
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
}

//class TopMovieLunboBackgroundView: LunboBackgroundView {
//    static let TopMovieTag = 20230518
//    var curMaxScale: CGFloat = 1.0
//    var isTopMovieMode = true
//
//    static func configTopMovie(_ component: IComponent?, isThemeMode: Bool) -> TopMovieLunboBackgroundView? {
//        guard let component = component else {
//            return nil
//        }
//        guard let container = component.pageContext?.getContainerView() as? UICollectionView else {
//            return nil
//        }
//        
//        let tag = TopMovieTag
//        var bgView = container.viewWithTag(tag) as? TopMovieLunboBackgroundView
//        if bgView == nil {
//            let tmpView = TopMovieLunboBackgroundView()
//            tmpView.tag = tag
//            tmpView.layer.zPosition = -1000
//            container.addSubview(tmpView)
//            bgView = tmpView
//        }
//        bgView?.isTopMovieMode = true
//        bgView?.reuse(component)
//        bgView?.isThemeMode = isThemeMode
//        bgView?.isHidden = isThemeMode
//        return bgView
//    }
//    
//    override func reuse(_ component: IComponent?) {
//        super.reuse(component)
//        guard let container = self.component?.pageContext?.getContainerView() as? UICollectionView else {
//            return
//        }
//        //将原始背景移到底部
//        if isTopMovieMode {
//            if let bgView = container.viewWithTag(LunboBackgroundView.TAG) as? LunboBackgroundView {
//                container.sendSubviewToBack(bgView)
//            }
//        }
//    }
//    
//    func updateTopMovieMode(_ isTopMovieMode: Bool) {
//        self.isTopMovieMode = isTopMovieMode
//        if !isTopMovieMode {
//            self.removeFromSuperview()
//            removeQuadCurveMask()
//        }
//    }
//    
//    func removeQuadCurveMask() {
//        self.layer.mask = nil
//    }
//    
//    func updateMaxScale(maxScale: CGFloat, lunboHeight: CGFloat) {
//        guard let component = component else {
//            return
//        }
//        guard let container = component.pageContext?.getContainerView() as? UICollectionView else {
//            return
//        }
//        if !isTopMovieMode {
//            return
//        }
//        self.curMaxScale = maxScale
//        if maxScale >= 1.0 {
//            self.isHidden = true
//            return
//        }
//        self.isHidden = false
//        
//        let extend = heightExtend(maxScale: maxScale)
//        var y = self.lunboY - extend
//        var offset = 30 * (1 - maxScale)
//        y -= offset
//        var height =  lunboHeight + extend + offset
//        if maxScale >= 0.95 && maxScale < 1.0 {
//            y = container.contentOffset.y
//            offset = 0.0
//            height = backgroundHeight()
//        }
//        CATransaction.begin()
//        CATransaction.setDisableActions(true)
//        let bgFrame = CGRect.init(x: 0, y: y, width: container.width, height: height)
//        self.frame = bgFrame
//        self.whiteGradientLayerView.frame = self.bounds
//        self.whiteGradientLayer.frame = self.bounds
//        self.gradientLayer.frame = self.bounds
//        CATransaction.commit()
//    }
//    
//    func heightExtend(maxScale: CGFloat) -> CGFloat {
//        let topExtend = 75.0 //CONSTANT.LUNBO_BIGCARD_EXTEND_TOP
//        let heightExtend = (topExtend - 15) * maxScale + 15
//        return heightExtend
//    }
//    
//    override func updateBackgroundPosition(_ scrollView: UIScrollView) {
//        CATransaction.begin()
//        CATransaction.setDisableActions(true)
//        if curMaxScale >= 0.95 {
//            super.updateBackgroundPosition(scrollView)
//            self.topView?.updateBackgroundPosition(scrollView)
//            self.whiteGradientLayer.bottom = self.height
//        }
//        CATransaction.commit()
//    }
//    
//    static func removeTopMovieLunboBackground(_ component: IComponent?) {
//        guard let component = component else {
//            return
//        }
//        guard let container = component.pageContext?.getContainerView() as? UICollectionView else {
//            return
//        }
//        var bgView = container.viewWithTag(TopMovieLunboBackgroundView.TopMovieTag) as? TopMovieLunboBackgroundView
//        bgView?.removeFromSuperview()
//    }
//}
