//
//  Item14204Delegate.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/4/17.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport4Youku

class Item14204Delegate : Item14016Delegate {
    
    override func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14204Model.self as? T.Type
    }

}
