//
//  ItemJsonExtractor14016.swift
//  YKChannelComponent
//
//  Created by better on 2023/2/23.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch

class ItemJsonExtractor14204: DefaultItemJsonExtracter {
    // MARK: - ItemJsonExtracter

    public override func getItemsJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error> {
        guard var itemsJson = componentJson?["nodes"] as? [[String: Any]] else {
            return .success([[String : Any]]()) //允许没有坑位列表
        }

        //轮播只有一个坑位时预防空白
        if itemsJson.count == 1 {
            var data = itemsJson[0]["data"] as? [String:Any]
            data?["onlyOneItemFromServer"] = true
            itemsJson[0]["data"] = data
            itemsJson.append(itemsJson[0])
        }
    
        return .success(itemsJson)
    }
}
