//
//  Component14038Model.swift
//  YKChannelComponent
//
//  Created by better on 2023/5/17.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku

/*
字段：level2->data->
title //组件头标题
titleImg //组件头图片标题（优于title展示，端上自适应宽度）
subtitle //副标题
reserve //预约
trackShow //加追 (展示优于reserve)
bgImg //组件头背景
borderColor //边框色
titleColor //标题&副标题色
*/

class Component14308Model: BaseComponentModel {
    
    var titleColor: UIColor?
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
    
        if let titleColor = dataInfo["titleColor"] as? String {
            self.titleColor = UIColor.createColorWithHexRGB(colorStr: titleColor)
        }
    }

}
