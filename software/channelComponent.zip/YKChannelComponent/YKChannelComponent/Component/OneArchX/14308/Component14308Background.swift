//
//  Component14038Background.swift
//  YKChannelComponent
//
//  Created by better on 2023/5/17.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Component14308Background:NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
        
    func itemDidInit() {

    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0.0
    }

    func createView(_ itemSize: CGSize) -> UIView {
        let view = Component14308BackgroundView.init(frame: CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return view
    }

    func reuseView(itemView: UIView) {
        guard let view = itemView as? Component14308BackgroundView else {
            return
        }
        view.fillData(component: self.item?.getComponent())
    }

    func loadEventHandlers() -> [ItemEventHandler]? {
       return nil
    }
}
