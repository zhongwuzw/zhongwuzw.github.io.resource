//
//  Component14308.swift
//  YKChannelComponent
//
//  Created by better on 2023/5/17.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku

class Component14308: NSObject, ComponentDelegate {
   
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {
        if let componentModel = self.component?.model as? BaseComponentModel {
            componentModel.extraExtend["aspectRatio"] = 1.78
        }
    }

    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Component14308Model.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }

    func isShowBackground() -> Bool {
        return true
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 69, left: YKNGap.youku_margin_left() + YKNGap.youku_column_spacing(), bottom: YKNGap.youku_comp_margin_bottom() + 12, right: YKNGap.youku_margin_right() + YKNGap.youku_column_spacing())
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_comp_margin_bottom()
        config.backgroundLeftMarginOffset = -YKNGap.youku_column_spacing()
        config.backgroundRightMarginOffset = -YKNGap.youku_column_spacing()
        config.backgroundBottomMargin = YKNGap.youku_comp_margin_bottom() - 9
        config.footerTopMargin = -9.0
        config.footerBottomMargin = YKNGap.youku_comp_margin_bottom()
        return config
    }

    func columnCount() -> CGFloat {
        return 2
    }

    /// 是否展示组件尾
    func isShowFooter() -> Bool {
        guard let componentModel = self.component?.model as? BaseComponentModel else {
            return false
        }
        if let change = componentModel.change, change.changeOnDrawer == true {
            return false
        }
        if componentModel.enter != nil || componentModel.change != nil {
            return true
        }
        return false
    }

    func footerTag() -> String? {
        return "comp.generic.footer"
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
