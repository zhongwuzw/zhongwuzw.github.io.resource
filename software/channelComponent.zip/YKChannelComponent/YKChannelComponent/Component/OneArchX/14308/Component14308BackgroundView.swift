//
//  Component14308BackgroundView.swift
//  YKChannelComponent
//
//  Created by better on 2023/5/17.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Component14308ReserveButton: ReserveButton {
    
    weak var backgroundView: Component14308BackgroundView?
    
    var refreshStatusBlock:((Bool) -> Void)?
    
    override func refreshButtonStatus() {
        super.refreshButtonStatus()
        
        guard let reserveModel = reserveModel else {
            return
        }
        let reserved = reserveModel.isReserve
        if !reserved {
            self.titleLabel.textColor = .ykn_brandInfo
        } else {
            self.titleLabel.textColor = .ykn_cg_2
        }
        self.layer.borderWidth = 0.5
        self.backgroundColor = UIColor.white.withAlphaComponent(0.9)
        self.layer.borderColor = UIColor.createColorWithHexRGB(colorStr: "#cccccc").withAlphaComponent(0.8).cgColor

        self.backgroundView?.layoutAfterRefreshReserveStatus()
        self.refreshStatusBlock?(reserved)
    }
}

class Component14308BackgroundView: AccessibilityView {

    weak var component: IComponent?
    
    lazy var titleLabel:UILabel = {
        let label = UILabel(frame: CGRect.init(x: YKNGap.dim_7(), y: YKNGap.dim_8(), width: 150, height: 22))
        label.backgroundColor = .clear
        label.textAlignment = .left
        label.lineBreakMode = .byTruncatingTail
        label.font = UIFont.systemFont(ofSize: 16, weight: .medium)
        label.textColor = UIColor.ykn_primaryInfo
        return label
    }()
    
    lazy var titleImg: UIImageGIFView = {
        let view = UIImageGIFView.init(frame: CGRect.init(x: self.titleLabel.left, y: 7, width:100, height: 34))
        view.isUserInteractionEnabled = true
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel(frame: CGRect(x: self.titleLabel.left, y: self.titleLabel.bottom + YKNGap.dim_4(), width: self.titleLabel.width, height:17))
        view.font = UIFont.systemFont(ofSize: 12)
        view.lineBreakMode = .byTruncatingTail
        view.textColor = .ykn_tertiaryInfo
        view.backgroundColor = .clear
        return view
    }()
    
    lazy var backgroundImg: UIImageGIFView = {
        let view = UIImageGIFView.init(frame: CGRect.init(x: 0, y: 0, width:self.width, height: 122))
        view.isUserInteractionEnabled = true
        return view
    }()
    
    lazy var favorBtn: YKTrackShowView = {
        let view = YKTrackShowView.init(frame: CGRect.init(x: 0, y: 20, width: 60, height: 30))
        view.right = self.width - YKNGap.dim_7()
        view.whenTapped {
            self.favorAction()
        }
        return view
    }()
    
    lazy var reserveButton:ReserveButton = {
        let button = Component14308ReserveButton()
        button.backgroundView = self
        button.refreshStatusBlock = { [self] isReserved in
//            refreshShaderView()
        }
        return button
    }()
    
//    lazy var shaderView:UIView = {
//        let view = UIView.init()
//        view.layer.cornerRadius = 15
//        view.backgroundColor = UIColor.init(white: 245/255.0, alpha: 0.5)
//
//        // 添加阴影
//        view.layer.shadowColor = UIColor.black.cgColor
//        view.layer.shadowOpacity = 0.5;
//        view.layer.shadowRadius = 16.0
//        view.layer.shadowOffset = CGSize.init(width: 0, height: 2)
//        return view
//    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        self.layer.borderWidth = 1.0
        self.layer.borderColor = UIColor.red.cgColor
        self.clipsToBounds = true
        
        self.addSubview(self.backgroundImg)
        self.addSubview(self.titleLabel)
        self.addSubview(self.subtitleLabel)
        self.addSubview(self.titleImg)
//        self.addSubview(self.shaderView)
        self.addSubview(self.favorBtn)
        self.addSubview(self.reserveButton)
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddCollectSuccessNotication), name: NSNotification.Name.init("kBSAddCollectSuccess"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelCollectSuccessNotication), name: NSNotification.Name.init("kBSCancelCollectSuccess"), object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(component: IComponent?) {
        guard let model = component?.model as? Component14308Model else {
            return
        }
        self.component = component

        Service.action.bind(model.action, self)

        self.titleLabel.text = model.title
        self.subtitleLabel.text = model.subtitle
        self.titleLabel.textColor = model.titleColor ?? UIColor.ykn_primaryInfo
        self.subtitleLabel.textColor = model.titleColor ?? UIColor.ykn_secondaryInfo
        self.backgroundImg.sd_setImage(with: URL(string: model.bgImg ?? ""))
        self.layer.borderColor = (model.borderColor?.withAlphaComponent(0.3) ?? UIColor.clear).cgColor
        
        if let titleImg = model.titleImg, titleImg.count > 0 {
            self.titleImg.isHidden = false
            self.titleLabel.isHidden = true
            self.titleImg.image = nil
            downloadImage(url: model.titleImg) { image in
                self.titleImg.image = image
                if let image = image, image.size.height > 0 {
                    let imgWidth = image.size.width / image.size.height * self.titleImg.height
                    self.titleImg.width = imgWidth
                }
            }
        } else {
            self.titleImg.isHidden = true
            self.titleLabel.isHidden = false
        }
                
        //favor
        self.favorBtnLayout(model.trackShow?.isFavor ?? false)
        bindStatisticsService()
        
        //reserve
        if let reserveModel = model.reserveModel {
            self.reserveButton.refresh(reserveModel: reserveModel, scene: nil)
        }
        
        self.layoutAfterRefreshReserveStatus()
        
//        self.refreshShaderView()
    }
    
    func layoutAfterRefreshReserveStatus() {
        guard let model = component?.model as? Component14308Model else {
            return
        }

        self.reserveButton.right = self.favorBtn.right
        self.reserveButton.centerY = self.favorBtn.centerY
        self.reserveButton.isHidden = (model.reserveModel == nil)
        self.favorBtn.isHidden = !(self.reserveButton.isHidden && model.trackShow != nil)
        
        var left = self.width
        if self.reserveButton.isHidden == false {
            left = self.reserveButton.left
        } else if self.favorBtn.isHidden == false {
            left = self.favorBtn.left
        }
        self.titleLabel.width = left - 20 - self.titleLabel.left
        self.subtitleLabel.width = self.titleLabel.width
    }
    
    func favorBtnLayout(_ isFavor: Bool) {
        guard let model = component?.model as? Component14308Model else {
            return
        }
        if model.trackShow == nil {
            return
        }

        favorBtn.selectTextColor = .ykn_cg_2
        favorBtn.selectBgColor = UIColor.white.withAlphaComponent(0.9)
        favorBtn.selectBorderWidth = 0.5
        favorBtn.selectBorderColor = UIColor.createColorWithHexRGB(colorStr: "#cccccc").withAlphaComponent(0.8)

        favorBtn.unselectTextColor = .ykn_brandInfo
        favorBtn.unselectBgColor = UIColor.white.withAlphaComponent(0.9)
        favorBtn.unselectBorderWidth = 0.5
        favorBtn.unselectBorderColor = UIColor.createColorWithHexRGB(colorStr: "#cccccc").withAlphaComponent(0.8)
        favorBtn.update(isFavor)
        
//        refreshShaderView()
    }
    
//    func refreshShaderView() {
//        self.shaderView.isHidden = true
//        if self.reserveButton.isHidden == false {
//            if let model = self.reserveButton.reserveModel, !model.isReserve {
//                self.shaderView.isHidden = false
//                self.shaderView.frame = self.reserveButton.frame
//            }
//        } else if self.favorBtn.isHidden == false {
//            if let model = component?.model as? Component14308Model, let favor = model.trackShow {
//                self.shaderView.frame = self.favorBtn.frame
//                self.shaderView.isHidden = (favor.isFavor ?? false) ? true : false
//            }
//        }
//    }
    
    func bindStatisticsService() {
        guard let model = component?.model as? Component14308Model else {
            return
        }

        guard let trackShow = model.trackShow else {
            return
        }
        
        if let isFavor = trackShow.isFavor, isFavor == true {
            let actionModel =  model.extraExtend["uncollectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        } else {
            let actionModel = model.extraExtend["collectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        }
    }
    
    func favorAction() {
        guard let model = component?.model as? Component14308Model else {
            return
        }
    
        guard let favor = model.trackShow,
              let isFavor = favor.isFavor
        else {
            return
        }
        
        var params = [String : Any]()
        params["isFavor"] = isFavor
        params["id"] = favor.favorId ?? ""
        
        print("[LJ] 3 favorAction:", params)
    
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channel.function.adaptor.zhuiju"), object: nil, userInfo: params)
    }
    
    @objc func handleAddCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: true)
    }
    
    @objc func handleCancelCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: false)
    }
    
    func handleNotication(notification: Notification, favored: Bool) {
        guard let userInfo = notification.userInfo,
              let targetId = userInfo["targetId"] as? String
        else {
            return
        }
        
        print("[LJ] 3 userInfo:", userInfo)
        
        guard let model = component?.model as? Component14308Model else {
            return
        }
        
        guard let favor = model.trackShow,
              let currentId = favor.favorId,
              let isFavor = favor.isFavor
        else {
            return

        }
        
        guard currentId == targetId else {
            return
        }
        favor.isFavor = favored
        favorBtnLayout(favor.isFavor ?? false)
        bindStatisticsService()
    }
}
