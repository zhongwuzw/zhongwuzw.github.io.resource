//
//  Item14203ContentView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/9/6.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import YoukuResource
import SDWebImage
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent
import UIKit

class Item14203ContentView: AccessibilityView {

    //MARK: Property
    lazy var bgView: UIView = {
        return UIView(frame: .zero)
    }()
    
    lazy var topItemView: Item14203SubItemView = {
        return Item14203SubItemView(frame: .zero)
    }()
    
    lazy var centerItemView: Item14203SubItemView = {
        return Item14203SubItemView(frame: .zero)
    }()
    
    lazy var bottomItemView: Item14203SubItemView = {
        return Item14203SubItemView(frame: .zero)
    }()

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(bgView)
        bgView.addSubview(self.topItemView)
        bgView.addSubview(self.centerItemView)
        bgView.addSubview(self.bottomItemView)
        
        bgView.layer.masksToBounds = true
        bgView.layer.cornerRadius = 3
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(_ items:[BaseItemModel]) {
        self.layoutCustomViews()

        var index = Int(0)
        if index < items.count {
            let item = items[index]
            self.topItemView.fillData(item)
        }
        
        index += 1
        if index < items.count {
            let item = items[index]
            self.centerItemView.fillData(item)
        }
        
        index += 1
        if index < items.count {
            let item = items[index]
            self.bottomItemView.fillData(item)
        }
        
    }
    
    func layoutCustomViews() {
        var top = CGFloat(0)
        let subItemViewHeight = Item14203ContentView.subItemViewHeight(self.width)
        self.bgView.frame = CGRect.init(x: 0.0, y: 0.0, width: self.width, height: subItemViewHeight * 3)
        
        self.topItemView.frame = CGRect.init(x: 0, y: top, width: self.width, height: subItemViewHeight)
        
        top = self.topItemView.bottom + 1
        self.centerItemView.frame = CGRect.init(x: 0, y: top, width: self.width, height: subItemViewHeight)
        
        top = self.centerItemView.bottom + 1
        self.bottomItemView.frame = CGRect.init(x: 0, y: top, width: self.width, height: subItemViewHeight)
    }

    static func itemContentHeight(_ itemWidth: CGFloat) -> CGFloat{
        return self.subItemViewHeight(itemWidth) * 3
    }
    
    static func subItemViewHeight(_ itemWidth: CGFloat) -> CGFloat{
        return 68
    }
    
    
    ///MARK:Dark Mode
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        if #available(iOS 13.0, *) {
            if self.traitCollection.hasDifferentColorAppearance(comparedTo: previousTraitCollection) {
                handleDarkMode()
            }
        }
    }
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
    }
    
    func isThemeDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
    
    func handleThemeDarkMode() {
        if isThemeDark() {
            refreshDarkUI()
        } else {
            refreshLightUI()
        }
    }

    func handleDarkMode() {
        if #available(iOS 13.0, *) {
            let isDark = self.traitCollection.userInterfaceStyle == .dark
            if isDark {
                refreshDarkUI()
            } else {
                refreshLightUI()
            }
        }
    }
    
    func refreshDarkUI() {
        topItemView.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#25252B")
        centerItemView.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#25252B")
        bottomItemView.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#25252B")
    }
    func refreshLightUI() {
        topItemView.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#FFFFFF")
        centerItemView.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#FFFFFF")
        bottomItemView.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#FFFFFF")
    }

}
