//
//  Component14203ContentView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/9/6.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import YoukuResource
import YKUIComponent
import YKModeConfigFramework
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import UIKit

class Component14203ContentView: AccessibilityView, SliderViewDelegate {
    lazy var topView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.isUserInteractionEnabled = true
        return view
    }()
    lazy var topTitleView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        view.isUserInteractionEnabled = true
        return view
    }()
    lazy var topIconView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        view.isUserInteractionEnabled = true
        return view
    }()
    public lazy var sliderView: SliderView = {
        let sliderView = SliderView.init(frame: CGRect.init(x: 6, y: self.topView.bottom, width: self.getSliderWidth(), height:self.getSliderHeight()), delegate: self)
        if ykrl_isResponsiveLayout() { //把子视图加上
            sliderView.addSubViews()
        }
        sliderView.enableCustomMode = false
        sliderView.collectionView.isPagingEnabled = true
        sliderView.pageView.isHidden = false
        sliderView.pageView.alpha = 1
        sliderView.pageView.selectedPageWidth = 9
        sliderView.pageView.unSelectedPageWidthHeight = 4
        sliderView.pageView.selectedPageColor = UIColor.createColorWithHexRGB(colorStr: "#494CFF")
        sliderView.pageView.unselectedPageColor = UIColor.createColorWithHexRGB(colorStr: "#C9C9C9")
        sliderView.pageView.centerX = sliderView.width / 2.0
        
        sliderView.diableHandleAppAd = true
        sliderView.diableHandDragging = false
        return sliderView
    }()
    ///数据源
    var compModel:SportsComponentModel?
    var items: [BaseItemModel]?
    var dataSource: [Any]?
    var ratio: CGFloat = 0
    
    ///定时刷新
    var slideTimer: Timer?
    var timeInterval:Double = 60
    var isDisplay:Bool = false
    var active:Bool = false

    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.layer.cornerRadius = 12.0
        self.layer.masksToBounds = true
        setupSubViews()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    deinit {
        self.clearTimer()
    }
    
    func setupSubViews() {
        addSubview(topView)
        topView.addSubview(topIconView)
        topView.addSubview(topTitleView)
        
        addSubview(sliderView)
        
        layer.borderColor = UIColor.ykn_hideAbleSeparator.cgColor
        layer.borderWidth = 0.5
        layer.cornerRadius = YKNCorner.radius_secondary_medium()
        layer.masksToBounds = true
    }
    
    
    
    func fillData(_ items: [BaseItemModel]?, compModel:SportsComponentModel, pageActive:Bool) {
        self.items = items
        self.compModel = compModel
        guard let items = items else {
            return
        }

        guard let dataSource = self.splitItems(items) else {
            return
        }
        self.dataSource = dataSource
        
        var timeInterval: Int = 6
        if let _scrollInterval = compModel.scrollInterval as? Int, _scrollInterval > 0 {
            timeInterval = _scrollInterval
        }
        
        ///Layout
        self.layoutCustomViews()
        
        sliderView.active = pageActive
        sliderView.reloadData(datas: dataSource, centerIndex: 0, delegate: self, interval:Double(timeInterval))

        sliderView.pageView.centerX = sliderView.width / 2.0
        sliderView.pageView.centerY = sliderView.height - 9

        topView.ykn_setImage(withURLString: compModel.bgImgUrl ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        topIconView.ykn_setImage(withURLString: compModel.iconImgUrl ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        topTitleView.ykn_setImage(withURLString: compModel.titleImgUrl ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        Service.action.bind(compModel.action, topIconView)
        
        self.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#F2F3FA")
        handleDarkMode()
    }
    
    func layoutCustomViews() {
        self.topView.frame = CGRect.init(x: 0, y: 0, width: self.width, height: self.height)
        
        //左上角 尺寸390x99
        let titleViewHeight = 28.0
        let titleViewWidth = 3.9 * titleViewHeight
        self.topTitleView.frame = CGRect.init(x: 6, y: 3, width: titleViewWidth, height: titleViewHeight)
//        topIconView.centerY = topView.height / 2.0
        
        //右上角
        let iconHeight = 12.0
        let iconWidth = iconHeight * 5
        self.topIconView.frame = CGRect.init(x: topView.width - iconWidth - 6, y: 0, width: iconWidth, height: iconHeight)
        topIconView.centerY = topTitleView.centerY
        
        self.sliderView.frame = CGRect.init(x: 6, y: 36, width: self.getSliderWidth(), height:self.getSliderHeight())
        self.sliderView.pageView.centerX = sliderView.width / 2.0
        self.sliderView.pageView.centerY = sliderView.height - 9
    }
    
    ///MARK:Timer
    ///request
    @objc func refreshComponentData() {
        let date = NSDate.init().timeIntervalSince1970
        weak var weakSelf = self

        let isDisplay = weakSelf?.isDisplay ?? false
        let active = weakSelf?.active ?? false

//        if !isDisplay {
//            return
//        }
//        if !active {
//            return
//        }
        Component14203RequestUtil.loadPageData({[weak self] (cmsInfo:[String:Any]?) in
            //更新数据源
            if let compInfo = Component14203RequestUtil.compInfoFromParsePageJson(cmsInfo) {
                weakSelf?.compModel?.setup(compInfo)
            }
            let items = Component14203RequestUtil.itemModelsFromParsePageJson(cmsInfo)
            if let compModel = weakSelf?.compModel {
                weakSelf?.items = items
                weakSelf?.fillData(weakSelf?.items, compModel: compModel, pageActive: active)
            }
        }, failure: nil)
    }

    func initSlideTimer(interval: Double) {
        self.timeInterval = interval
        if self.slideTimer != nil {
//            print("cc 14203 slideToNextPage: clearTimer:(\(slideTimer)")
            self.slideTimer?.invalidate()
            self.slideTimer = nil
        }
        if interval > 0 {
            weak var weakSelf = self
            let timer = Timer.scheduledTimer(timeInterval: interval, target: self, selector: #selector(refreshComponentData), userInfo: nil, repeats: true)
            RunLoop.main.add(timer, forMode: RunLoop.Mode.common)
//            print("cc 14203 slideToNextPage: initSliderTimer:(\(timer)")
            self.slideTimer = timer
            pauseTimer()
        }
    }
    
    func resumeTimer() {
//        if !active {
//            return
//        }
        if let timer = self.slideTimer, timer.isValid {
            timer.fireDate = Date.init(timeIntervalSinceNow: timeInterval)
        } else {
            initSlideTimer(interval: self.timeInterval)
            slideTimer?.fireDate = Date.init(timeIntervalSinceNow: timeInterval)
        }
    }

    func pauseTimer() {
        guard let timer = self.slideTimer else {
            return
        }
        if timer.isValid {
            timer.fireDate = NSDate.distantFuture
        }
    }
    
    func clearTimer() {
//        print("cc 14203 slideToNextPage: clearTimer:(\(slideTimer)")
        self.slideTimer?.invalidate()
        self.slideTimer = nil
    }

    
    override func removeFromSuperview() {
        super.removeFromSuperview()
        self.clearTimer()
    }
    
    ///MARK:Dark Mode
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        if #available(iOS 13.0, *) {
            if self.traitCollection.hasDifferentColorAppearance(comparedTo: previousTraitCollection) {
                handleDarkMode()
            }
        }
    }

    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
    }
    
    func isThemeDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
    
    func handleThemeDarkMode() {
        if isThemeDark() {
            refreshDarkUI()
        } else {
            refreshLightUI()
        }
    }
    
    func handleDarkMode() {
        if #available(iOS 13.0, *) {
            let isDark = self.traitCollection.userInterfaceStyle == .dark
            if isDark {
                refreshDarkUI()
            } else {
                refreshLightUI()
            }
        } else {
            refreshLightUI()
        }
    }
    
    func refreshDarkUI() {
        backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#16161A")
        topView.ykn_setImage(withURLString: compModel?.darkBgImg ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
    }
    func refreshLightUI() {
        self.backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#F2F3FA")
        topView.ykn_setImage(withURLString: compModel?.normalBgImg ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
    }
    ///MARK:Slider Delegate
    func getSliderWidth() -> CGFloat {
        return self.width - 12
    }
    func getSliderItemHeight() -> CGFloat {
        return Item14203ContentView.itemContentHeight(self.getSliderWidth())
    }
    func getSliderHeight() -> CGFloat {
        return self.getSliderItemHeight() + 20
    }
    func splitItems(_ items: [BaseItemModel]) -> [[BaseItemModel]]? {
        var index = 0
        var count = 0
        var datas = [[BaseItemModel]]()
        var tempElement = [BaseItemModel]()
        for item in items {
            tempElement.append(item)
            count += 1
            if count >= 3 || count >= items.count {
                count = 0
                datas.append(tempElement)
                tempElement = [BaseItemModel]()
                index += 1
            }
        }
        return datas
    }
    
    ///MARK: SliderViewDelegate
    
    func itemSpacing() -> CGFloat {
        return 0
    }
    
    func leftMargin() -> CGFloat {
        return 0
    }
    
    func rightMargin() -> CGFloat {
        return 0
    }
    
    func topMargin() -> CGFloat {
        return 0
    }
    
    func itemSideMargin() -> CGFloat {
        return 0
    }
    
    func containerSideExtend() -> CGFloat {
        return 0
    }
    
    func isEnableCustomMode() -> Bool {
        return ykrl_isResponsiveLayout()
    }
    
    func itemContentMargin(index: Int, originItemSize: CGSize) -> CGFloat {
        return 0.0
    }
    
    func containerCornerRadius() -> CGFloat {
        return 0
    }
    
    func itemIdentifier(index: Int) -> String {
        return "slider.mulitem.identifier.v2"
    }
    
    func itemWidth(containerWidth: CGFloat, containerHeight: CGFloat) -> CGFloat {
        return self.getSliderWidth()
    }
    
    func createItemView(index: Int, itemSize: CGSize) -> UIView {
        let itemView = Item14203ContentView(frame: CGRect.init(x: 0, y: 0, width: self.getSliderWidth(), height: self.getSliderHeight()))
        return itemView
    }
    
    func reuseItemView(index: Int, itemView: UIView) {
        guard let itemView = itemView as? Item14203ContentView,
                let dataSource = self.dataSource,
                dataSource.count > index else {
            return
        }
        
        guard let items = dataSource[index] as? [BaseItemModel] else {
            return
        }
        
        itemView.fillData(items)
    }
    
    func centerIndexChanged(index: Int) {
        
    }
    
    func centerViewChangedWhenDidEndScroll(index: Int, itemView: UIView) {
    }
}

