//
//  SportsMatchStatusView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/9/7.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import SDWebImage
import OneArchSupport
import OneArchSupport4Youku
import YKProtocolSDK
import YoukuResource

protocol SportsMatchStatusViewDelegate:NSObjectProtocol {
    func needUpdateStatusView(_ statusView:SportsMatchStatusView)
}

class SportsMatchStatusView: AccessibilityView {
    
    weak var delegate: SportsMatchStatusViewDelegate?
    var sportModel: SportsCompetitionModel?
    var itemModel: HomeItemModel?
    var isReserve: Bool = false
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.init(_colorLiteralRed: 34, green: 34, blue: 34, alpha: 1)
        view.font = UIFont.init(name: "PingFangSC-Regular", size: 9)
        view.numberOfLines = 0
        return view
    }()
    lazy var iconView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(titleLabel)
        self.addSubview(iconView)
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddReserveSuccessNotication), name: NSNotification.Name.init("kAddReserveSuccessNotification"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelReserveSuccessNotication), name: NSNotification.Name.init("kCancelReserveSuccessNotification"), object: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(_ sportModel: SportsCompetitionModel?) {
        guard let sportModel = sportModel else { return  }
        self.sportModel = sportModel
        self.titleLabel.isHidden = true
        self.iconView.isHidden = true
        if let matchStatus = sportModel.matchStatus,
           let matchStatusName = sportModel.matchStatusName {

            let status = sportModel.reservationStatus
            if status == 1 {
                self.isReserve = true
            } else {
                self.isReserve = false
            }
        
            self.titleLabel.isHidden = false
            self.iconView.isHidden = false
            
            self.titleLabel.text = matchStatusName
            
            //清空埋点
            Service.statistics.bind(nil, self, .OnlyClick)
            self.whenTapped {
                
            }
            // 比赛状态（0-预约；1-直播中；2-结束）
            self.layer.cornerRadius = 1.0
            if matchStatus == "0" {
                if self.isReserve  {
                    self.titleLabel.text = "已预约"
                    self.sportModel?.matchStatusName = "已预约"
                } else {
                    self.titleLabel.text = "预约"
                    self.sportModel?.matchStatusName = "预约"
                }
                self.titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#597FFE")
                self.iconView.image = UIImage.init(named: "sportMatchStatus_reserve")
                self.layer.borderWidth = 0.5
                self.layer.borderColor = UIColor.createColorWithHexRGB(colorStr: "#597FFE").withAlphaComponent(0.5).cgColor
                weak var weakSelf = self
                self.whenTapped {
                    weakSelf?.reserveAction()
                }
                bindStatisticsService()
            } else if matchStatus == "1" {
                self.titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#FF347F")
                self.iconView.image = UIImage.init(named: "sportMatchStatus_live")
                self.layer.borderWidth = 0.5
                self.layer.borderColor = UIColor.createColorWithHexRGB(colorStr: "#FF347F").withAlphaComponent(0.5).cgColor
            } else if matchStatus == "2" {
                self.titleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#597FFE")
                self.iconView.image = UIImage.init(named: "sportMatchStatus_playback")
                self.layer.borderWidth = 0.5
                self.layer.borderColor = UIColor.createColorWithHexRGB(colorStr: "#597FFE").withAlphaComponent(0.5).cgColor
            }

            self.layoutCustomViews()
        }
        
    }
    
    func layoutCustomViews() {
        self.frame = CGRect.init(origin: CGPoint.zero, size: SportsMatchStatusView.getSize(sportModel))
        let textSize = SportsMatchStatusView.getTextSize(sportModel)
        let x = (self.width - 10 - 2 - textSize.width) / 2.0
        iconView.frame = CGRect.init(x: x, y: 0, width: 10, height: 10)
        iconView.centerY = self.height / 2.0
        titleLabel.frame = CGRect.init(x: iconView.right + 2, y: 0, width: textSize.width, height: 12)
        titleLabel.centerY = self.height / 2.0
    }
    
    @objc func handleAddReserveSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, isReserved: true)
    }

    @objc func handleCancelReserveSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, isReserved: false)
    }

    func handleNotication(notification: Notification, isReserved: Bool) {

        guard let reserveId = notification.object as? String else {
            return
        }

        guard let currentId = sportModel?.liveId else {
            return
        }
        guard currentId == reserveId else {
            return
        }
        self.isReserve = isReserved
        if isReserved  {
            self.sportModel?.matchStatusName = "已预约"
            self.titleLabel.text = "已预约"
        } else {
            self.sportModel?.matchStatusName = "预约"
            self.titleLabel.text = "预约"
        }
        self.layoutCustomViews()
        self.delegate?.needUpdateStatusView(self)
//        refreshSubscribeLabel()
        bindStatisticsService()
    }

    func bindStatisticsService() {
        guard let itemModel = itemModel else {
            return
        }

        let reserveActionModel = ActionFactoryV2(itemModel, spmDExt: "_appointmentlive")
        let unReserveActionModel = ActionFactoryV2(itemModel, spmDExt: "_cancelappointmentlive")
        if isReserve {
            Service.statistics.bind(unReserveActionModel?.report, self, .OnlyClick)
        } else {
            Service.statistics.bind(reserveActionModel?.report, self, .OnlyClick)
        }
    }

    func reserveAction() {

        guard let dingyueSDK = DYKServiceManager.sharedInstance().service(forProtocolName: "YKDingYueProtocol") as? YKDingYueProtocol else {
            return
        }

        var params = [String:Any]()
        params["bizId"] = "540"
        if let reservationId = sportModel?.liveId {
            params["reservationId"] = reservationId
        }
        params["reservationType"] = "LIVE"
        params["deviceType"] = "IPHONE"
        params["src"] = "687398"
        if let itemModel = itemModel {
            let reserveActionModel = ActionFactoryV2(itemModel, spmDExt: "_appointmentlive")
            if let spm = reserveActionModel?.report?.spm {
                params["src"] = spm
            }
        }

        if isReserve {
            dingyueSDK.help_cancelReservation?(params) { _, _, _ in

            }
        } else {
            dingyueSDK.help_addReservation?(params) { _, _, _ in

            }
        }
    }

    
    static func getTextSize(_ sportModel: SportsCompetitionModel?) -> CGSize {
        if let matchStatusName = sportModel?.matchStatusName {
            let size = calcStringSize(matchStatusName, font: UIFont.init(name: "PingFangSC-Regular", size: 9), size: CGSize.init(width: 300, height: 19))
            let titleWidth = size.width
            return CGSize.init(width: titleWidth, height: 10)
        }
        return CGSize.zero
    }
    static func getSize(_ sportModel: SportsCompetitionModel?) -> CGSize {
        if let matchStatusName = sportModel?.matchStatusName {
            let titleWidth = self.getTextSize(sportModel).width
            let iconWidth = 10
            var itemWidth = 10 + titleWidth + 2 + 10
            itemWidth = max(itemWidth, 60)
            return CGSize.init(width: itemWidth, height: 16)
        }
        return CGSize.zero
    }
}
