//
//  Component14203Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/9/6.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import YoukuResource
import YKHome
import YKSCService
import YKResponsiveLayout
import OneArchSupport4Youku
import DYKNetwork_YK

open class Component14203Delegate: NSObject, ComponentDelegate,ComponentLifeCycleDelegate {

    var isDisplay:Bool = false
    
    weak var itemView:Component14203ContentView?
    lazy var lifeCycleEventHandler:ComponentLifeCycleEventHandler = {
        let handler = ComponentLifeCycleEventHandler()
        handler.delegate = self
        return handler
    }()
    
    public var componentWrapper: ComponentWrapper?
    var compModel:SportsComponentModel? {
        get {
            return self.component?.compModel as? SportsComponentModel
        }
    }
    var itemModels = [BaseItemModel]()
    
    public func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom() + 9, right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = 0.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        return config
    }
    
    public func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    public func columnCount() -> CGFloat {
        return 1
    }
    
    public func getModelClass<T>() -> T.Type? where T : NodeModel {
        return SportsComponentModel.self as? T.Type
    }
    
    // MARK: - event
    public func loadEventHandlers() -> [ComponentEventHandler]? {
        return [self.lifeCycleEventHandler]
    }
    
    public func componentDidInit() {

    }
    
    public func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let itemHeight:CGFloat = 259.0
        return itemHeight
    }
    
    public func createView(_ itemSize: CGSize) -> UIView {
        let itemWidth = Double(itemSize.width)
        let itemHeight = Double(itemSize.height)
        let itemView = Component14203ContentView.init(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight))
        return itemView
    }
    
    public func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Component14203ContentView else {
            return
        }
        guard let compModel = compModel else {
            return
        }

        self.itemView = itemView
        
        itemView.alpha = 1
        
        var itemModels = [BaseItemModel]()
        if let items = self.component?.getItems() {
            for item in items {
                if let model = item.itemModel {
                    itemModels.append(model)
                }
            }
        }
        itemView.timeInterval = Double(self.compModel?.refreshTime ?? 60)
        itemView.fillData(itemModels, compModel: compModel, pageActive: isPageInActive())
        itemView.initSlideTimer(interval: itemView.timeInterval)
    }
    
    public func enterDisplayArea(itemView: UIView?) {
        isDisplay = true
        self.itemView?.active = true
        self.itemView?.sliderView.active = true
        self.itemView?.resumeTimer()
    }
    public func exitDisplayArea(itemView: UIView?) {
        isDisplay = false
        self.itemView?.active = false
        self.itemView?.sliderView.active = false
        self.itemView?.pauseTimer()
        self.itemView?.clearTimer()
    }
    public func didActivate() {
        if isDisplay,isPageInActive() {
            self.itemView?.active = true
            self.itemView?.sliderView.active = true
            self.itemView?.resumeTimer()
        } else {
            self.itemView?.active = false
            self.itemView?.sliderView.active = false
        }
    }
    public func didDeactivate() {
        self.itemView?.active = false
        self.itemView?.sliderView.active = false
        self.itemView?.pauseTimer()
        self.itemView?.clearTimer()
    }


    func isPageInActive() -> Bool {
        if let page = self.component?.getPage() {
            if let state = page.activeState, state == true {
                return true
            }
        }
        return false
    }
}
