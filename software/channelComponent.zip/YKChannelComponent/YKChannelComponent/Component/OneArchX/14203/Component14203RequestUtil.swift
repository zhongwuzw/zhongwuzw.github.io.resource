//
//  File.swift
//  YKChannelComponent
//
//  Created by CC on 2022/10/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import DYKNetwork_YK
import YoukuResource
import OneArch
import OneArchSupport4Youku

public typealias CloseHandler = () -> Void
public typealias SuccessHandler = (_ cmsInfo:[String: Any]?) -> Void
public typealias FailureHandler = (_ error:Error?) -> Void

open class Component14203RequestUtil: NSObject {
    public static func loadPageData(_ success:SuccessHandler?, failure:FailureHandler?) {
        
        var parameters = [String: Any]()
        parameters["api_version"] = "1.0"
        parameters["nodekey"] = "SPORTSGROUP_DRAWERSCHEDULE"
        parameters["query"] = "{}"
        
        var params = [String: Any]()
        params["nodekey"] = "SPORTSGROUP_DRAWERSCHEDULE"

        if let paramsJson = try? JSONSerialization.data(withJSONObject: params, options: .prettyPrinted) {
            let jsonString = String.init(data: paramsJson, encoding: String.Encoding.utf8)
            parameters["params"] = jsonString
            params["query"] = jsonString
            parameters["query"] = jsonString
        }

        
        let requestModel = DYKHttpRequestModel()
        requestModel.enableMtop = true
        requestModel.requestURL = "mtop.columbus.channel.unifiedquery.executequery"
        requestModel.paramDict = parameters
        
        YKJSONClient.sharedMtop().request(withHttpModel: requestModel) { (task:YKResponseTask?, response:Any?) in
            if let response = response as? [String: Any],
               let data = response["data"] as? [String: Any] {
                if let success = success {
                    DispatchQueue.main.async {
                        success(data)
                    }
                }

                
            }
            
        } failure: { (task:YKResponseTask?, error:Error?)  in
            if let failure = failure {
                DispatchQueue.main.async {
                    failure(error)
                }
            }
        }

    }
    
    public static func compInfoFromParsePageJson(_ cmsInfo:[String: Any]?) -> [String: Any]? {
        
        var realData = cmsInfo?["data"] as? [String: Any]
        let levelF1Data = realData?["data"] as? [String: Any]
        
        let level0Nodes = levelF1Data?["nodes"] as? [Any]
        let level0Node = level0Nodes?.first as? [String: Any]

        let level1Nodes = level0Node?["nodes"] as? [Any]
        let level1Node = level1Nodes?.first as? [String: Any]

        let level2Nodes = level1Node?["nodes"] as? [Any]
        let level2Node = level2Nodes?.first as? [String: Any]

        return level2Node
    }
    
    public static func itemModelsFromParsePageJson(_ cmsInfo:[String: Any]?) -> [BaseItemModel] {
        
        let level2Node = self.compInfoFromParsePageJson(cmsInfo)

        let level3Nodes = level2Node?["nodes"] as? [[String: Any]]
        let level3Node = level3Nodes?.first as? [String: Any]
        
        var itemModels = [BaseItemModel]()
        if let level3Nodes = level3Nodes {
            for level3Node in level3Nodes {
                let itemModel = HomeItemModel()
                itemModel.setup(level3Node)
                itemModels.append(itemModel)
            }
        }

        return itemModels
    }
}
