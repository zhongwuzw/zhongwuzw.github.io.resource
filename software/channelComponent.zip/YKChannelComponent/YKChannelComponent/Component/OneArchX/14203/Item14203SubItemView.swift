//
//  Item14203SubItemView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/10/10.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import YoukuResource
import SDWebImage
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent
import UIKit

class Item14203SubItemView: AccessibilityView,SportsMatchStatusViewDelegate {
    weak var sportModel: SportsCompetitionModel?
    var isAgainst: Bool = false
    var sportMatchStatusIsVs = false
    
    //MARK: Property
    lazy var displayTitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222").withAlphaComponent(0.3)
        view.font = UIFont.init(name: "PingFangSC-Regular", size: 10)
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        view.textAlignment = .center
        return view
    }()
    
    lazy var startTimeTitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222").withAlphaComponent(0.3)
        view.font = UIFont.init(name: "PingFangSC-Regular", size: 10)
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        view.textAlignment = .center
        return view
    }()
    
    lazy var delayTimeTitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.createColorWithHexRGB(colorStr: "#FF347F").withAlphaComponent(0.3)
        view.font = UIFont.init(name: "PingFangSC-Regular", size: 10)
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        view.textAlignment = .center
        return view
    }()
    
    lazy var matchNameLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
        view.font = UIFont.init(name: "PingFangSC-Regular", size: 13)
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        view.textAlignment = .center
        return view
    }()
    
    //主队
    lazy var homeBodyView: UIView = {
        return UIView(frame: .zero)
    }()
    lazy var homeBodyNameLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
        view.font = UIFont.init(name: "PingFangSC-Regular", size: 13)
        view.numberOfLines = 2
        view.textAlignment = .right
        return view
    }()
    lazy var homeBodyBadgeView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.layer.borderWidth = 0.5
        view.layer.borderColor = UIColor.createColorWithHexRGB(colorStr: "#CFD5E2").withAlphaComponent(0.5).cgColor
        return view
    }()
    lazy var homeBodyScoreLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
        view.font = YKNFont.akrobatExtraBoldFont(ofSize: 16)
        view.numberOfLines = 0
        view.textAlignment = .center
        return view
    }()
    
    //客队
    lazy var guestBodyView: UIView = {
        return UIView(frame: .zero)
    }()
    lazy var guestBodyNameLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
        view.font = UIFont.init(name: "PingFangSC-Regular", size: 13)
        view.numberOfLines = 2
        view.textAlignment = .left
        return view
    }()
    lazy var guestBodyBadgeView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.layer.borderWidth = 0.5
        view.layer.borderColor = UIColor.createColorWithHexRGB(colorStr: "#CFD5E2").withAlphaComponent(0.5).cgColor

        return view
    }()
    lazy var guestBodyScoreLabel: UILabel = {
        let view = UILabel()
        view.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
        
        view.font = YKNFont.akrobatExtraBoldFont(ofSize: 16)
        view.numberOfLines = 0
        view.textAlignment = .center
        return view
    }()
    
    lazy var centerVSView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.image = UIImage.init(named: "sportMatchStatus_vs")
//        view.clipsToBounds = false
        return view
    }()
    
    lazy var scoreSeperateView: UIView = {
        let view = UIView.init(frame:CGRect.init(x: 0, y: 0, width: 8, height: 3))
        view.isUserInteractionEnabled = true
        return view
    }()
    
    lazy var gradientView: CAGradientLayer = {
        let titleShadow = CAGradientLayer()
        titleShadow.colors = [UIColor.createColorWithHexRGB(colorStr: "#9499B3").withAlphaComponent(0.5).cgColor, UIColor.createColorWithHexRGB(colorStr: "#A4B3CD").withAlphaComponent(0.5).cgColor]
        titleShadow.locations = [NSNumber.init(value: 0), NSNumber.init(value: 1.0)]
        titleShadow.startPoint = CGPoint(x: 0, y: 0)
        titleShadow.endPoint = CGPoint(x: 1.0, y: 0)
        
        return titleShadow
    }()
    
    lazy var matchStatusView: SportsMatchStatusView = {
        let view = SportsMatchStatusView(frame: .zero)
        view.delegate = self
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(displayTitleLabel)
        self.addSubview(matchNameLabel)
        
        self.addSubview(homeBodyView)
        homeBodyView.addSubview(homeBodyNameLabel)
        homeBodyView.addSubview(homeBodyBadgeView)
        homeBodyView.addSubview(homeBodyScoreLabel)

        self.addSubview(guestBodyView)
        guestBodyView.addSubview(guestBodyNameLabel)
        guestBodyView.addSubview(guestBodyBadgeView)
        guestBodyView.addSubview(guestBodyScoreLabel)

        self.addSubview(scoreSeperateView)
        scoreSeperateView.layer.addSublayer(gradientView)
        self.addSubview(centerVSView)
        
        self.addSubview(matchStatusView)
        
        self.backgroundColor = .white
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(_ item:BaseItemModel) {
        guard let item = item as? HomeItemModel else {
            return
        }
        self.sportModel = item.sportsCompetition
        matchStatusView.itemModel = item
        
        Service.action.bind(item.action, self)
        
        self.isAgainst = sportModel?.isAgainst ?? false
        if isAgainst {
            //isAginst
            homeBodyView.isHidden = false
            guestBodyView.isHidden = false
            
            //not Aginst
            matchNameLabel.isHidden = true
        } else {
            homeBodyView.isHidden = true
            guestBodyView.isHidden = true
            
            matchNameLabel.isHidden = false
        }
        centerVSView.isHidden = true
        scoreSeperateView.isHidden = true

        displayTitleLabel.isHidden = false
        matchStatusView.isHidden = false
        startTimeTitleLabel.isHidden = true
        delayTimeTitleLabel.isHidden = true
        
        displayTitleLabel.text = sportModel?.displayTitle
        matchNameLabel.text = sportModel?.matchName
        
        self.updateDisplayTitle()
        
        homeBodyNameLabel.text = sportModel?.homeBodyName
        homeBodyScoreLabel.text = sportModel?.homeBodyScore
        homeBodyBadgeView.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20)
        homeBodyBadgeView.ykn_setImage(withURLString: sportModel?.homeBodyBadge ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        guestBodyNameLabel.text = sportModel?.guestBodyName
        guestBodyScoreLabel.text = sportModel?.guestBodyScore
        guestBodyBadgeView.frame = CGRect.init(x: 0, y: 0, width: 20, height: 20)
        guestBodyBadgeView.ykn_setImage(withURLString: sportModel?.guestBodyBadge ?? "",
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)

        homeBodyScoreLabel.isHidden = true
        guestBodyScoreLabel.isHidden = true
        sportMatchStatusIsVs = true
        if let matchStatus = sportModel?.matchStatus {
            if matchStatus == "1" || matchStatus == "2" {
                homeBodyScoreLabel.isHidden = false
                guestBodyScoreLabel.isHidden = false
                sportMatchStatusIsVs = false
            }
        }
        if isAgainst {
            if sportMatchStatusIsVs {
                self.centerVSView.isHidden = false
                self.scoreSeperateView.isHidden = true
            } else {
                self.centerVSView.isHidden = true
                self.scoreSeperateView.isHidden = false
            }
        } else {
            self.centerVSView.isHidden = true
            self.scoreSeperateView.isHidden = true
        }

        
        self.matchStatusView.fillData(sportModel)
        self.layoutCustomViews()
        self.handleDarkMode()
    }
    
    func updateDisplayTitle() {
 
        ///MARK:需按照aone拼接
        var preTitle = ""
        if let startTime = sportModel?.startTime {
            preTitle = startTime + " "
        }
        let isDelay = sportModel?.isDelay ?? false
        if isDelay, let delayName = sportModel?.delayName {
            preTitle = delayName + " "
        }
        if let displayTitle = sportModel?.displayTitle {
            let font: UIFont = displayTitleLabel.font
            let allText = "\(preTitle)\(displayTitle)"
            let attrString = NSMutableAttributedString.init(string: allText)
            let part1Range = NSRange.init(allText.range(of: preTitle)!, in: allText)
            let part2Range = NSRange.init(allText.range(of: "\(displayTitle)")!, in: allText)
            
            var preTitleColor = UIColor.ykn_tertiaryInfo
            if isDelay {
                preTitleColor = UIColor.createColorWithHexRGB(colorStr: "#FF347F")
            } else {
                preTitleColor = UIColor.ykn_tertiaryInfo
            }
            let titleColor = UIColor.ykn_tertiaryInfo
            
            attrString.addAttributes([.foregroundColor: preTitleColor,
                                      .font: font
                                     ],
                                     range: part1Range)

            attrString.addAttributes([.foregroundColor: titleColor,
                                      .font: font
                                     ],
                                     range: part2Range)
            displayTitleLabel.attributedText = attrString
        }
    }
    
    func layoutCustomViews() {
        let paddingLeft = 12.0

        displayTitleLabel.frame = CGRect.init(x: paddingLeft, y: 3, width: self.width - paddingLeft * 2, height: 14)
        
        matchNameLabel.frame = CGRect.init(x: paddingLeft, y: displayTitleLabel.bottom, width: self.width - paddingLeft * 2, height: 24)
        matchNameLabel.centerY = self.height / 2.0 - 5
        
        let vsWidth = CGFloat(20)
        let bodyHeight = 40.0
        let bodyPadding = paddingLeft
        var bodyWidth = (self.width - vsWidth - bodyPadding * 2) * 0.5
        if sportMatchStatusIsVs {
            bodyWidth -= 0
        } else {
            bodyWidth -= 0
        }
        let bodyTop = displayTitleLabel.bottom + 2
        homeBodyView.frame = CGRect.init(x: bodyPadding, y: bodyTop, width: bodyWidth, height: bodyHeight)
        homeBodyView.centerY = self.height / 2.0
        let badgeWidth = 20.0
        var homeBadgeX = homeBodyView.width - badgeWidth - 30
        if !homeBodyScoreLabel.isHidden {
            let homeScoreWidth = 30.0
            homeBodyScoreLabel.frame = CGRect.init(x: homeBodyView.width - homeScoreWidth, y: 0.0, width: homeScoreWidth, height: 24.0)
            homeBodyScoreLabel.centerY = homeBodyView.height * 0.5
//            homeBadgeX = homeBodyScoreLabel.left - 4 - badgeWidth
        }
        homeBodyBadgeView.frame = CGRect.init(x: homeBadgeX, y: 0, width: badgeWidth, height: badgeWidth)
        homeBodyBadgeView.centerY = homeBodyView.height * 0.5
        homeBodyNameLabel.frame = CGRect.init(x: 0, y: 0, width: homeBodyView.width - badgeWidth - 4, height: homeBodyView.height)
        homeBodyNameLabel.width = homeBodyBadgeView.left - 4
        homeBodyNameLabel.right = homeBodyBadgeView.left - 4
        
        guestBodyView.frame = CGRect.init(x: self.width - bodyPadding - bodyWidth, y: bodyTop, width: bodyWidth, height: bodyHeight)
        guestBodyView.centerY = self.height / 2.0
        var guestBadgeX = CGFloat(30)
        if !guestBodyScoreLabel.isHidden {
            let homeScoreWidth = 30.0
            guestBodyScoreLabel.frame = CGRect.init(x: 0, y: 0.0, width: homeScoreWidth, height: 24.0)
            guestBodyScoreLabel.centerY = guestBodyView.height * 0.5
//            guestBadgeX = guestBodyScoreLabel.right + 4
        }
        guestBodyBadgeView.frame = CGRect.init(x: guestBadgeX, y: 0, width: badgeWidth, height: badgeWidth)
        guestBodyBadgeView.centerY = guestBodyView.height * 0.5
        guestBodyNameLabel.frame = CGRect.init(x: badgeWidth + 2, y: 0, width: guestBodyView.width - badgeWidth - 4, height: guestBodyView.height)
        guestBodyNameLabel.width = guestBodyView.width - guestBodyBadgeView.right - 4
        guestBodyNameLabel.left = guestBodyBadgeView.right + 4
        
        centerVSView.frame = CGRect.init(x: 0, y: 0, width: vsWidth, height: vsWidth)
        centerVSView.centerX = self.width / 2.0
        centerVSView.centerY = self.homeBodyView.centerY
        
        scoreSeperateView.frame = CGRect.init(x: 0, y: 0, width: 8, height: 3)
        scoreSeperateView.centerX = self.width / 2.0
        scoreSeperateView.centerY = self.homeBodyView.centerY
        gradientView.frame = scoreSeperateView.bounds
        
        layoutStatusView()
        
    }
    
    public func needUpdateStatusView(_ statusView:SportsMatchStatusView) {
        sportModel?.matchStatusName = statusView.sportModel?.matchStatusName

        matchStatusView.centerX = self.width / 2.0
        matchStatusView.bottom = self.height - 6
    }
    
    func layoutStatusView() {
        let statusSize = SportsMatchStatusView.getSize(sportModel)
        matchStatusView.frame = CGRect.init(x: 0, y: 0, width: statusSize.width, height: statusSize.height)
        matchStatusView.centerX = self.width / 2.0
        matchStatusView.bottom = self.height - 6
    }
    
    ///MARK:Dark Mode
    override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        if #available(iOS 13.0, *) {
            if self.traitCollection.hasDifferentColorAppearance(comparedTo: previousTraitCollection) {
                handleDarkMode()
            }
        }
    }
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
    }
    
    func isThemeDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
    
    func handleThemeDarkMode() {
        if isThemeDark() {
            refreshDarkUI()
        } else {
            refreshLightUI()
        }
        updateDisplayTitle()
    }

    func handleDarkMode() {
        if #available(iOS 13.0, *) {
            let isDark = self.traitCollection.userInterfaceStyle == .dark
            if isDark {
                refreshDarkUI()
            } else {
                refreshLightUI()
            }
            updateDisplayTitle()
        }
    }
    
    func refreshDarkUI() {
        backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#25252B")
        displayTitleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#FFFFFF").withAlphaComponent(0.3)
        matchNameLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#FFFFFF")
        homeBodyNameLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#FFFFFF")
        guestBodyNameLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#FFFFFF")
        homeBodyScoreLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#FFFFFF")
        guestBodyScoreLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#FFFFFF")
        if let sportModel = sportModel, let matchStatus = sportModel.matchStatus, matchStatus == "1" {
            homeBodyScoreLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#FF347F")
            guestBodyScoreLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#FF347F")
        }
    }
    func refreshLightUI() {
        backgroundColor = UIColor.createColorWithHexRGB(colorStr: "#FFFFFF")
        displayTitleLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222").withAlphaComponent(0.3)
        matchNameLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
        homeBodyNameLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
        guestBodyNameLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
        homeBodyScoreLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
        guestBodyScoreLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
        if let sportModel = sportModel, let matchStatus = sportModel.matchStatus, matchStatus == "1" {
            homeBodyScoreLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#FF347F")
            guestBodyScoreLabel.textColor = UIColor.createColorWithHexRGB(colorStr: "#FF347F")
        }
    }
}
