//
//  SportsComponentModel.swift
//  YKChannelComponent
//
//  Created by CC on 2022/9/8.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku
import YoukuResource

open class SportsComponentModel: BaseComponentModel {


    public var refreshTime:Int = Int(60)
    public var iconImgUrl:String?
    public var titleImgUrl:String?
    public var bgImgUrl:String?
    public var normalBgImg:String?
    public var darkBgImg:String?

    
    public required init() {
        
    }
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        
//        guard let type = cmsInfo?["type"] as? Int else {
//            return
//        }
        
        if let value = dataInfo["refreshTime"] as? Int {
            refreshTime = value
        } else if let value = dataInfo["refreshTime"] as? String {
            refreshTime = Int(value) ?? 60
        }
        if let value = dataInfo["icon"] as? String {
            iconImgUrl = value
        }
        if let value = dataInfo["title"] as? String {
            titleImgUrl = value
        }
        if let value = dataInfo["normalBgImg"] as? String {
            normalBgImg = value
        }
        if let value = dataInfo["darkBgImg"] as? String {
            darkBgImg = value
        }
        bgImgUrl = normalBgImg
    }
    
    
}
