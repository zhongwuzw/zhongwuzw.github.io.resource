//
//  Item14203Delegate.swift
//  YKChannelComponent
//
//  Created by CC on 2022/9/6.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item14203Delegate: NSObject, ItemDelegate {
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView()
    }
    
    func reuseView(itemView: UIView) {
        
    }
    
    var itemWrapper: ItemWrapper?
    
    static func create() -> ItemDelegate {
        return Item14203Delegate.init()
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func itemDidInit() {

    }
    
    required override init() {
        
    }

}
