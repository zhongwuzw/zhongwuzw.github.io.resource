//
//  Item14145.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

class Item14145: NSObject, ItemDelegate {
    func itemDidInit() {
        
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    var itemWrapper: ItemWrapper?
    
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let imageHeight = itemWidth / 1.78
        let textAreaH = Double(ceil(textAreaHeight(itemWidth:itemWidth)))
        let itemHeight = textAreaH + imageHeight
        
        preCaculateLayout(CGSize.init(width: itemWidth, height: itemHeight), self.item)
        return itemHeight
    }

    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14145ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14145ContentView else {
            return
        }
        itemView.fillData(item: self.item, ratio: getImageAspectRatio())
    }
    
    func reuseId() -> String? {
        return "Item14145"
    }
    
    //MARK: - private
    
     func getImageAspectRatio() -> CGFloat {
        return 1.78
    }
    
    func videoImageHeight(_ itemWidth: CGFloat) -> CGFloat {
        return  itemWidth / getImageAspectRatio()
    }
    
    /// 文本区域高度（含spacing）
    func textAreaHeight(itemWidth: CGFloat) -> CGFloat {
        let titleAreaHeight: CGFloat = YKNFont.height(with: YKNFont.posteritem_maintitle_weight(.semibold), lineNumber: 2) + 6 + 3
        let subTitleHeight: CGFloat = YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)
        return titleAreaHeight + subTitleHeight
    }
    
     func preCaculateLayout(_ itemSize: CGSize, _ item: IItem?) {
        guard let tempItemModel = item?.itemModel else {
            return
        }

        let itemWidth = itemSize.width
        let imageSize = CGSize.init(width: itemWidth, height: videoImageHeight(itemWidth))

        //cache
        if let mark = tempItemModel.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: imageSize)
            item?.layout?.mark = layout
        }

        if let summary = tempItemModel.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize:imageSize)
            item?.layout?.summary = layout
        }

        if let lbTexts = tempItemModel.lbTexts {
            let layout = Service.lbTexts.estimatedLayout(lbTexts, toViewSize:imageSize)
            item?.layout?.lbTexts = layout
        }
        //主标题
        let titleLayout = TextLayoutModel.init()
        let titleY = imageSize.height + 6
        let titleH = calStringLimitedLineHeight(tempItemModel.iconFontTitle, font: YKNFont.posteritem_maintitle(), limitWidth: itemWidth, limitLine: 2)
        titleLayout.renderRect = CGRect.init(x: 0,
                                             y: titleY,
                                             width: itemWidth,
                                             height: titleH)
        item?.layout?.title = titleLayout
    }
}
