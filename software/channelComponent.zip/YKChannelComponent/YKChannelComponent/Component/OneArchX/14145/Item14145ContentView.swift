//
//  Item14145ContentView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import SDWebImage
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent

class Item14145ContentView: AccessibilityView {
    //MARK: Property
    lazy var videoImageView: BaseVideoImageView = {
        return BaseVideoImageView(frame: .zero)
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.numberOfLines = 2
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    var subInfoView: DoubleFeedSubInfoBaseView?

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(videoImageView)
        self.addSubview(titleLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(item:IItem?, ratio:CGFloat) {
        guard let itemModel = item?.model as? BaseItemModel else {
            return
        }
        
        // image
        self.videoImageView.size = CGSize.init(width: self.width, height: self.width / ratio)
        self.videoImageView.fillData(item: item)

        //title
        self.titleLabel.frame = item?.layout?.title?.renderRect ?? CGRect.zero
        self.titleLabel.text = itemModel.iconFontTitle

        //subinfo
        if subInfoView != nil {
            subInfoView?.removeFromSuperview()
        }
        
        let subInfoType = DoubleFeedSubInfoViewFactory.getSubInfoType(item)
        if subInfoType != "" {
            let frame = CGRect.init(x: 0, y: self.titleLabel.bottom + 3, width: self.width, height: YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1))
            let view = DoubleFeedSubInfoViewFactory.createSubinfoViewWithType(subInfoType, frame)
            view?.fillData(item)
            if view != nil {
                addSubview(view!)
            }
            self.subInfoView = view
        }

        //氛围
        let scene = itemModel.scene
        self.backgroundColor = .clear //sceneUtil(.clear, sceneColor: scene?.sceneBgColor())
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: scene?.sceneTitleColor())
        
        //绑定事件
        Service.action.bind(itemModel.action, self)
    }
    
    func createIconFont(_ fontSize: CGFloat) -> UIFont {
        return YKNIconFont.sharedInstance().font(withSize: fontSize)
    }
}
