//
//  TransitionSwitch.swift
//  YKChannelComponent
//
//  Created by Kenneth on 2023/1/10.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku
import OneTransition
import OneTransitionCore
import orange
import YKResponsiveLayout
import YoukuCore
import OneServiceSwift

class TransitionSwitch {
    class func enablePlayerTransition(model: BaseItemModel?) {
        var extraExtend = model?.playerModel?.extraExtend
        if extraExtend == nil {
            extraExtend = [String: Any]()
        }
        
        var userInfo = extraExtend?["userInfo"] as? [String : Any] ?? [String : Any]()
        userInfo["ot_enableTransition"] = true
        extraExtend?["userInfo"] = userInfo
        model?.playerModel?.extraExtend = extraExtend
    }
    
    class func disablePlayerTransition(model: BaseItemModel?) {
        var extraExtend = model?.playerModel?.extraExtend
        if extraExtend == nil {
            extraExtend = [String: Any]()
        }
        
        var userInfo = extraExtend?["userInfo"] as? [String : Any] ?? [String : Any]()
        userInfo["ot_enableTransition"] = false
        extraExtend?["userInfo"] = userInfo
        model?.playerModel?.extraExtend = extraExtend
    }
}

// 12075
extension TransitionSwitch {
    class func enable12075Transition(model: BaseItemModel) -> Bool {
        let disableTransition = Orange.getConfigByGroupName("OneTransition", key: "disablePageToLongVideoTransition", defaultConfig: "0", isDefault: nil) as? String ?? "0"
        if disableTransition == "1" {
            return false
        }
        
        guard let item = model.domainObject as? IItem else { return false }
        // 指定页面走无缝
        let pageName = item.getPage()?.pageModel?.pvModel?.pageName ?? ""
        let extraExtend = model.data?["extraExtend"] as? [String : Any]
        let enablePlayPageTransition = extraExtend?["enablePlayPageTransition"] as? Bool ?? false
        let pageNameWhiteList = get12075PageNameWhiteList()
        if pageNameWhiteList.contains(pageName) && enablePlayPageTransition {
            return true
        }
        
        // 端侧实验港剧场打开无缝
        let bucket = OneService.nobelInvoker.hitAB("1956").result
        print("bucket::\(bucket)")
        if bucket == "4775" && pageName == "page_guidenode_hongkong_jingxuan" {
            return true
        }
        return false
    }
    
    class func enable12075DifferentPlayIdTransition(model: BaseItemModel?) -> Bool {
        guard let model = model else { return false }
        if !enable12075Transition(model: model) {
           return false
        }
        
        let disable = Orange.getConfigByGroupName("OneTransition", key: "disable12075DifferentPlayId", defaultConfig: "0", isDefault: nil) as? String ?? "0"
        if disable == "1" {
            return false
        }
        
        let isVip = User.isLogin() ? (User.current()?.isMember == true) : false
        if !isVip {
            return false
        }
        
        if let hotPoint = model.preview?["hotPoint"] as? NSNumber, hotPoint.intValue > 0 {
            return true
        }
        return false
    }

    private class func get12075PageNameWhiteList() -> [String] {
        guard let config = Orange.getConfigByGroupName("OneTransition", key: "homePageToLongVideoPageNameWhiteList", defaultConfig: nil, isDefault: nil) as? String,
              config.count > 0
        else {
            return default12075PageNameWhiteList()
        }
        
        var list = [String]()
        let subStrs = config.split(separator: ",")
        for subStr in subStrs {
            list.append(String(subStr))
        }
        return list
    }
    
    private class func default12075PageNameWhiteList() -> [String] {
        return ["page_homeselect", "page_guidenode_hongkong_jingxuan"]
    }
}

// 12076
extension TransitionSwitch {
    class func enable12076AddAccurateStart(model: BaseItemModel?) -> Bool {
        let enable = Orange.getConfigByGroupName("OneTransition", key: "enable12076AddAccurateStart", defaultConfig: "1", isDefault: nil) as? String
        if enable == "0" {
            return false
        }
        
        let url = model?.action?.routeUrl
        let svScheme = "ykshortvideo://video_play"
        let jumpToSV = url?.contains(svScheme) ?? false
        if jumpToSV {
            return true
        }
        return false
    }
    
    class func enable12076Transition(model: BaseItemModel?) -> Bool {
        if ykrl_isResponsiveLayout() {
            return false
        }

        let url = model?.action?.routeUrl
        let scheme = OTRouterModel.scheme(from: url)
        let params = model?.action?.routeParams
        // 跳播放页，只针对pugv打开
        if scheme == "youku://play" {
            let playMode = params?["playMode"] as? String ?? ""
            if playMode == "pugv" {
               return true
           } else {
               return false
           }
        }
        return false
    }
}

// 12094
extension TransitionSwitch {
    class func enable12094Transition(model: BaseItemModel?) -> Bool {
        let data = model?.data as? [String : Any]
        let dataExtraExtend = data?["extraExtend"] as? [String : Any]
        let enableTransition = dataExtraExtend?.yk_bool("enableSvPageTransition") ?? false
        return enableTransition
    }
    
    class func enable12094TransitionBack(model: BaseItemModel?) -> Bool {
        let data = model?.data as? [String : Any]
        let dataExtraExtend = data?["extraExtend"] as? [String : Any]
        let enableTransition = dataExtraExtend?.yk_bool("enableSvPageTransitionBack") ?? false
        return enableTransition
    }
}
