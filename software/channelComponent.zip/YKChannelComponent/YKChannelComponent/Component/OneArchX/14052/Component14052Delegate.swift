//
//  Component14052Delegate.swift
//  YKChannelComponent
//
//  Created by better on 2023/2/16.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import UIKit
import OneArch
import YoukuResource
import YKHome
import YKSCService
import YKResponsiveLayout
import OneArchSupport4Youku
import OneArchSupport

@objcMembers
class Component14052Delegate:Component14016Delegate {
    override func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: 9, right: 0)
        config.preferredCardSpacingTop = 9.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        return config
    }
    
    override func componentDidInit() {
        (self.component?.compModel as? HomeComponentModel)?.compHwRatio = CGFloat(0.5)
        self.component?.compModel?.extraExtend["yksc.data.comp.slider.isFullWidthMode"] = false
        super.componentDidInit()
    }

    override func sliderViewBottomBannerHeight() -> CGFloat {
        return 0.0
    }
    
    override func sliderViewTopMarign() -> CGFloat {
        return topMargin()
    }
    
    override public func topMargin() -> CGFloat {
        return SCREEN_WIDTH * 116 / 375.0
    }
     
    override func reuseView(itemView: UIView) {
        super.reuseView(itemView: itemView)
        guard let itemView = itemView as? SliderView else {
            return
        }
        guard let extraExtend = self.component?.compModel?.extraExtend as? [String : Any] else {
            return
        }
        if let url = extraExtend.stringForKey("coverImg") {
            var colors = [UIColor.init(white: 0, alpha: 0), UIColor.init(white: 0, alpha: 0.4)];
            if let topColorStr = extraExtend["galleryGradientTopColor"] as? String,
               let topColor = UIColor.init(hexRGB: topColorStr),
               let bottomColorStr = extraExtend["galleryGradientBottomColor"] as? String,
               let bottomColor = UIColor.init(hexRGB: bottomColorStr) {
                colors = [topColor, bottomColor]
            }
            itemView.backgroundView.refreshColor(bgImg: url, gradientColors: colors)
        }
    }
    
    // MARK: - apple AD
    override func createAppleADAdapter() -> NewComponentAppleADSliderAdapter {
        return NewComponent14049AppleADSliderAdapter.init()
    }
}
