//
//  Item14325.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/11/10.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Item14325:NSObject, ItemDelegate  {

    var itemWrapper: ItemWrapper?
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    func columnCount() -> CGFloat {
        return 2.0
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {

        self.receiveEstimatedLayout(Double(itemWidth))
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func itemDidInit() {
        
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14325ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14325ContentView else {
            return
        }
        guard let itemModel = self.item?.itemModel else {
            return
        }
        let layout = self.item?.itemModel?.layout
        Service.action.bind(itemModel.action, itemView)
        Service.summary.attach(itemModel.summary, toView: itemView.videoImageView, layout: layout?.summary)
        Service.lbTexts.attach(itemModel.lbTexts, toView: itemView.videoImageView, layouts: layout?.lbTexts)
        Service.mark.attach(itemModel.mark, toView: itemView.videoImageView, layout: layout?.mark)
        //是否是二楼组件
        if let cardType = self.item?.getCard()?.cardModel?.type, cardType == "15038" {
            itemView.isSecondFloorComponent = true
        } else {
            itemView.isSecondFloorComponent = false
        }
        itemView.pageIsThemeMode = isPageInThemeMode(self.item?.getPage())
        
        itemView.fillData(itemModel)
    }
    
    
    func receiveEstimatedLayout(_ itemWidth: Double) {

        let titleH = YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
        let subtitleH = YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)

        var bottomHeight = 6.0 + 3.0 + titleH + subtitleH
        let itemHeight = ceil(itemWidth * RATIO_9_16) + bottomHeight
        item?.layout?.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)
                
        let width = itemWidth
        let height = width * 9.0 / 16.0
        let videoImageViewSize = CGSize.init(width: width, height: height)
        if let mark = item?.itemModel?.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: videoImageViewSize)
            item?.layout?.mark = layout
        }
        
        if let lbTexts = item?.itemModel?.lbTexts {
            let layout = Service.lbTexts.estimatedLayout(lbTexts, toViewSize: videoImageViewSize)
            item?.layout?.lbTexts = layout
        }
        
        if let summary = item?.itemModel?.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize: videoImageViewSize)
            item?.layout?.summary = layout
        }
    }
}
