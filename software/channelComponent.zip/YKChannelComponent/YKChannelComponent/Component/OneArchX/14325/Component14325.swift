//
//  Component14325.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/11/10.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Component14325: NSObject, ComponentDelegate {
    var componentWrapper: OneArch.ComponentWrapper?

    func componentDidInit() {
        TopAnimationADGuideView.preloadLottieUrl(self.component?.compModel as? Comp14325Model)
    }
    public func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Comp14325Model.self as? T.Type
    }
    
    func layoutType() -> OneArch.ComponentLayoutType {
        return .columnAverage
    }
    
    func loadEventHandlers() -> [OneArch.ComponentEventHandler]? {
        return nil
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: YKNGap.youku_comp_margin_top(), left: YKNGap.youku_margin_left(), bottom: 0, right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_comp_margin_bottom()
        config.footerBottomMargin = 18.0
        return config
    }
    func columnCount() -> CGFloat {
        return 2
    }
}
