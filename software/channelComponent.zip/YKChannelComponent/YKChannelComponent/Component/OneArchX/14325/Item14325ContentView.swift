//
//  Item14325ContentView.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/11/10.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Item14325ContentView: ItemBaseAlphaContentView {
    //MARK: Property
    lazy var bgView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.clipsToBounds = true
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .white
        view.font = YKNFont.posteritem_maintitle()
        view.numberOfLines = 0
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .white.withAlphaComponent(0.75)
        view.font = YKNFont.posteritem_subhead()
        view.textAlignment = .left
        return view
    }()
    
    lazy var descLabel: UILabel = {
        let view = UILabel()
        view.textColor = .white
        view.font = YKNFont.posteritem_subhead()
        view.textAlignment = .center
        view.layer.masksToBounds = true
        view.layer.borderColor = UIColor.white.withAlphaComponent(0.75).cgColor
        view.layer.borderWidth = 0.5
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    func initSubviews() {
        self.addSubview(bgView)
        bgView.addSubview(videoImageView)
        bgView.addSubview(titleLabel)
        bgView.addSubview(subtitleLabel)
        bgView.addSubview(descLabel)
    }
    
    func fillData(_ model: BaseItemModel) {

        if isSecondFloorComponent {
            self.alpha = self.alphaProgress * self.getNavBackgroundAlpha()
        } else {
            self.alpha = 1.0
        }
        titleLabel.text = model.title

        subtitleLabel.text = model.subtitle
        //test
//        model.desc = "购买"
        //
        if let desc = model.desc {
            descLabel.text = desc
            descLabel.isHidden = false
        } else {
            descLabel.isHidden = true
        }
        videoImageView.frame = self.imageViewFrame()
        videoImageView.ykn_setImage(withURLString: XCDNSTRING(model.img),
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        
        relayoutSubviews()
        
        self.subtitleLabel.isHidden = model.hideSubtitle
    }
    
    func relayoutSubviews() {
        bgView.frame = self.bounds
        
        let w = self.imageViewFrame().size.width
        videoImageView.frame = self.imageViewFrame()

        let y = CGFloat(videoImageView.frame.maxY) + 6.0
        
        var descW = 56.0
        let descH = 30.0
        if descLabel.isHidden {
            descW = 0.0
        }
        descLabel.frame = CGRect.init(x: w - descW, y: 6.0, width: descW, height: descH)
        descLabel.layer.cornerRadius = descH / 2.0
        
        titleLabel.frame = CGRect.init(x: 0.0, y: y, width: w - descW - 6.0, height: YKNFont.height(with: titleLabel.font, lineNumber: 1))

        subtitleLabel.frame = CGRect.init(x: 0.0, y: titleLabel.frame.maxY + 3.0, width: w - descW - 6.0, height: YKNFont.height(with: subtitleLabel.font, lineNumber: 1))
        
        descLabel.centerY = titleLabel.bottom
    }
    
    func imageViewFrame() -> CGRect {
        let w = self.frame.size.width
        let h = ceil(w * 9.0/16.0)
        return CGRect.init(x: 0, y: 0, width: w, height: h)
    }
}
