//
//  Comp14325Model.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/11/13.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku
import YoukuResource

open class Comp14325Model : BaseComponentModel {
    var guideImg:String?
    var guideText:String?
    
    ///local url
    var localTopBgLottieUrl:String?
    var localGuideLottieUrl:String?

    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        guard let data = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        if let value = data["guideImg"] as? String {
            guideImg = value
        }
        if let value = data["guideText"] as? String {
            guideText = value
        }
    }
}
