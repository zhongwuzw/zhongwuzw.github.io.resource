//
//  Component14306.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/5/23.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import YoukuResource

class Component14306: Component14195 {

    override func autoSelectedEnabled() -> Bool {
        return false
    }
    
    override public func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Component14196Model.self as? T.Type
    }

    override func layoutConfig() -> ComponentLayoutConfig {
        var config = super.layoutConfig()
        
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        config.headerBottomMargin = 9.0
        
        return config
    }

    /// 是否展示组件头
    override func isShowHeader() -> Bool {
        guard let model = component?.model as? Component14196Model else {
            return false
        }
        if model.title?.count ?? 0 > 0 {
            return true
        }
        return false
    }
    
    /// 业务自定义tag
    override func headerTag() -> String? {
        return "comp.14196.header"
    }
}
