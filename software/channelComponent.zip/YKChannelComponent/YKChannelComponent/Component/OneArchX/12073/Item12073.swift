//
//  Item12073.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/13.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout
import YKChannelPage
import YoukuAnalytics

class Item12073:NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
    
    static func create() -> ItemDelegate {
        return Item12073.init()
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }

    
    func columnCount() -> CGFloat {
        return 2.0
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        if ykrl_isResponsiveLayout() {
            if let components = self.item?.getCard()?.getComponents() {
                for comp in components {
                    if let tag = comp.model?.type, (tag == "14035" || tag == "14196" || tag == "14306") {
                        return 0
                    }
                }
            }
        }

        self.receiveEstimatedLayout(Double(itemWidth))
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler(),
                ItemPlayerProgressEventHandler(),
                LongPressPreviewItemEventHandler()]
    }
    
    func itemDidInit() {
        if let reasons = item?.itemModel?.reasons {
            for (index, reason) in reasons.enumerated() {
                if index == 1, let img = reason.img, img.isEmpty == false {
                    item?.itemModel?.reasons?[index].imgEnabled = true
                }
            }
            
            //靠下对齐布局，需要统一高度，恢复所有推荐理由的垂直边距
            item?.itemModel?.reasons = reasons.map({
                var newReason = $0
                newReason.isNeedVerticalPaddingAtYK11 = true
                return newReason
            })
        }
        SelectionCardFeedAdUtil.bindAdGrayIdIfNeeded(item)
    }
    
    /// 渲染复用ID
    func reuseId() -> String? {
        if isPullDrawler() {
            return "15029." + (self.item?.model?.type ?? "12073")
        }
        if is15038PullDrawler() {
            return "15038." + (self.item?.model?.type ?? "12073")
        }
        return (self.item?.model?.type ?? "12073")
    }
    
    func isPullDrawler() -> Bool {
        if let card = self.item?.getCard(), let tag = card.model?.type, tag == "15029" {
            return true
        }
        return false
    }
    func is15038PullDrawler() -> Bool {
        if let card = self.item?.getCard(), let tag = card.model?.type, tag == "15038" {
            return true
        }
        return false
    }
    
    func receiveEstimatedLayout(_ itemWidth: Double) {
        var bottomHeight = 30 + ceil(38.0 * Double(YKNSize.yk_icon_size_scale()))
        if self.item?.itemModel?.hideSubtitle == true {
            bottomHeight = 27 + ceil(23.0 * Double(YKNSize.yk_icon_size_scale()))
        }
        
        bottomHeight = updateBottomHeight(bottomHeight)
        
        let itemHeight = ceil(itemWidth * RATIO_9_16) + bottomHeight
        item?.layout?.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)
        
        let width = itemWidth
        let height = width * 9.0 / 16.0
        let videoImageViewSize = CGSize.init(width: width, height: height)
        if let mark = item?.itemModel?.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: videoImageViewSize)
            item?.layout?.mark = layout
        }
        
        if let lbTexts = item?.itemModel?.lbTexts {
            let layout = Service.lbTexts.estimatedLayout(lbTexts, toViewSize: videoImageViewSize)
            item?.layout?.lbTexts = layout
        }
        
        if let summary = item?.itemModel?.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize: videoImageViewSize)
            item?.layout?.summary = layout
        }
        
        if let reasons = item?.itemModel?.reasons {
            let h: Double = ceil(18.0 * Double((YKNSize.yk_icon_size_scale() - 1.0) / 2.0 + 1.0))
            
            var boundingwidth: CGFloat = 0.0
            if let oneArchPageScene = self.item?.getPage()?.pageContext?.concurrentDataMap["OneArchPageScene"] as? String, oneArchPageScene == "Detail" {
                if self.item?.itemModel?.feedbackModel != nil {
                    boundingwidth = width - 20
                } else {
                    boundingwidth = width //通投到播放页时不下发负反馈按钮则不显示，无需空出负反馈按钮宽度
                }
            } else {
                boundingwidth = width - 20
            }
            let layout = Service.reasons.estimatedLayout(reasons,
                                                         position: CGPoint.init(x: 0.0, y: itemHeight - h),
                                                         boundingSize: CGSize.init(width: boundingwidth, height: h))
            item?.layout?.reasons = layout
        }
    }
    
    func updateBottomHeight(_ height: CGFloat) -> CGFloat {
        return height
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
            let itemView = ItemPlugin12073ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            itemView.tag = 10012073
            return itemView
    }

    func reuseView(itemView: UIView) {
        print("[小阁楼] 抽屉状态变化 reuseView")
        self.item?.itemModel?.dataCenterMap["dataIsBinded"] = true
    
        guard let itemModel = self.item?.itemModel else {
            return
        }
        let layout = self.item?.itemModel?.layout

        weak var weakItem = self.item
        
        itemModel.feedbackModel?.supportUndoMask = true
        //player
        var isSecondFloorComp = false
        if let itemViewNative = itemView as? ItemPlugin12073ContentView {
            Service.player.attach(itemModel.playerModel, toView: itemViewNative.videoImageView, displayFrame: itemViewNative.imageViewFrame())
            
            //是否是二楼组件
            if let cardType = self.item?.getCard()?.cardModel?.type {
                itemViewNative.isSecondFloorComponent = !disableSecondFloorCompChange() ? ((cardType == "15029") && isSelectionPagePullDrawerMode()) : (cardType == "15029")
                if cardType == "15038", isHomeTopAnimationADMode(self.item?.getPage()) {
                    itemViewNative.isSecondFloorComponent = true
                }
                itemViewNative.pageIsThemeMode = isPageInThemeMode(self.item?.getPage())
                isSecondFloorComp = true
            } else {
                itemViewNative.isSecondFloorComponent = false
            }
            
            itemViewNative.fillData(itemModel)
            Service.summary.attach(itemModel.summary, toView: itemViewNative.videoImageView, layout: layout?.summary)
            Service.lbTexts.attach(itemModel.lbTexts, toView: itemViewNative.videoImageView, layouts: layout?.lbTexts)
            Service.reasons.attach(itemModel.reasons, toView: itemViewNative, layouts: layout?.reasons)
            
            //角标
            Service.mark.attach(itemModel.mark, toView: itemViewNative.videoImageView, layout: layout?.mark)
        }

        let exposeType:StatisType = isSecondFloorComp ? .OnlyClick : .Defalut //小阁楼曝光特殊处理，下拉拽下来再发曝光
        if isSecondFloorComp {
            registExposeObserver()
        } else {
            unregistExposeObserver()
        }
        
        if currentPullDrawerHasShow(self.item?.getPage()) {
            sendManualExpose()
        }
        
        Service.action.bind(itemModel.action, itemView, exposeType) {
            print("12073 will action")
        } didAction: {
            print("12073 did action")
            weakItem?.sendEventMessage("yksc.event.item.rec.tap", params: nil)
        }
        
        sendCustomLog()
    }
    
    func sendCustomLog() {
        guard let type = self.item?.getCard()?.cardModel?.type, type == "10004" else {
            return
        }
        
        if let map = self.item?.getPage()?.pageContext?.concurrentDataMap,
            let first_request_time = map["first_request_time"] as? Double,
            let from_home_data_parse_time = map["from_home_data_parse_time"] as? Double {
            let now = CFAbsoluteTimeGetCurrent()
            
            let args = ["from_home_req_time" : Int64((now - first_request_time) * 1000),
                        "from_home_data_parse_time" : Int64((now - from_home_data_parse_time) * 1000)]
            print("[expose] time:\(args)")
            YoukuAnalytics.sharedInstance()?.collectALiCustomEvent(withEventID: "19999",
                                                                     pageName: "home_feed_card",
                                                                     arg1: "first_render_time",
                                                                     arg2: nil,
                                                                     arg3: nil,
                                                                     args: args)
            map["first_request_time"] = nil
            map["from_home_data_parse_time"] = nil
        }
    }
    
    var hasRegistExposeObserver = false
    func registExposeObserver() {
        if !hasRegistExposeObserver {
            NotificationCenter.default.addObserver(self, selector: #selector(pullDrawerStateChanged(_:)), name: Notification.Name(rawValue: "home.pullDrawer.stateChanged"), object: nil)
            hasRegistExposeObserver = true
        }
    }
    
    func unregistExposeObserver() {
        if hasRegistExposeObserver {
            hasRegistExposeObserver = false
            NotificationCenter.default.removeObserver(self, name: Notification.Name(rawValue: "home.pullDrawer.stateChanged"), object: nil)
        }
    }
    
    @objc func pullDrawerStateChanged(_ noti: Notification?) {
        guard let pullDrawerHasShow = noti?.userInfo?["pullDrawerHasShow"] as? Bool else {
            return
        }
        
        print("[小阁楼] 抽屉状态变化 收到通知:\(pullDrawerHasShow)")
        if pullDrawerHasShow {
            sendManualExpose()
        }
    }
    
    func sendManualExpose() {
        if let report = self.item?.itemModel?.action?.report {
            YoukuAnalytics.sharedInstance()?.collectALiCustomEvent(withEventID: "2201",
                                                                   pageName: report.pageName,
                                                                   arg1: nil,
                                                                   arg2: nil,
                                                                   args:report.args)
            print("[小阁楼] 抽屉状态变化 发手动曝光")
        }
    }
}
