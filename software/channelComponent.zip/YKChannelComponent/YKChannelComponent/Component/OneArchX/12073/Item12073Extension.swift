//
//  Item12073ContentViewExtension.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/20.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArchSupport
import OneArchSupport4Youku

extension ItemPlugin12073ContentView {
    func fillData(_ model: BaseItemModel) {

        let is14347 = model.type == "14347"
        
        if isSecondFloorComponent {
            self.alpha = self.alphaProgress * self.getNavBackgroundAlpha()
        } else {
            self.alpha = 1.0
        }
        titleLabel.text = model.title

        subTitleLabel.text = model.subtitle
        
        videoImageView.frame = self.imageViewFrame()
        videoImageView.ykn_setImage(withURLString: XCDNSTRING(model.img),
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
        

//        Service.action.bind(model.action, self) {
//            print("12073 will action")
//        } didAction: {
//            print("12073 did action")
////            itemContext.scFireEvent("yksc.event.item.rec.tap", params: nil)
//        }

        

        relayoutSubviews()

        //color
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: model.scene?.sceneTitleColor() )
        self.subTitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: model.scene?.sceneSubTitleColor())
//        self.backgroundColor = sceneUtil(UIColor.clear, sceneColor: model.scene?.sceneBgColor())
        
        self.subTitleLabel.isHidden = model.hideSubtitle
        if is14347, !self.subTitleLabel.isHidden { //14347副标题显示，解绑推荐理由（fix-复用问题）
            Service.reasons.detach(fromView: self)
        }
    }
}
