//
//  ItemPlugin12073ContentView.swift
//  YKChannelComponent
//
//  Created by wustlj on 2021/4/2.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import YKSCBase
import Lottie
//import YKChannelBase

class ItemPlugin12073ContentView: ItemBaseAlphaContentView {
        
    //MARK: Property
    lazy var bgView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.clipsToBounds = true
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.numberOfLines = 0
        return view
    }()
    
    lazy var subTitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = YKNFont.posteritem_subhead()
        view.textAlignment = .left
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
//        self.backgroundColor = UIColor.ykn_primaryBackground
        
        self.addSubview(bgView)
        bgView.addSubview(videoImageView)
        bgView.addSubview(titleLabel)
        bgView.addSubview(subTitleLabel)
    }
        
//    override func fillData(itemContext: YKSCItemContext) {
//        
//        super.fillData(itemContext: itemContext)
//        
//        let model = itemContext.model
//        
//        print("[jbp] 12073 fillData")
//
//        titleLabel.text = model.title
//
//        subTitleLabel.text = model.subtitle
//        subTitleLabel.isHidden = model.hideSubtitle
//        
//        videoImageView.frame = self.imageViewFrame()
//        videoImageView.ykn_setImage(withURLString: XCDNSTRING(model.img),
//                                    module: "home",
//                                    imageSize: CGSize.zero,
//                                    parameters: nil,
//                                    completed: nil)
//        
////        self.yk_addBorderAndShadow()
//
//        Service.action.bind(model.action, self) {
//            print("12073 will action")
//        } didAction: {
//            print("12073 did action")
////            itemContext.scFireEvent("yksc.event.item.rec.tap", params: nil)
//        }
//
//        Service.mark.attach(model.mark, toView: videoImageView, layout: itemContext.layoutModel.mark)
//        Service.summary.attach(model.summary, toView: videoImageView, layout: itemContext.layoutModel.summary)
//        Service.lbTexts.attach(model.lbTexts, toView: videoImageView, layouts: itemContext.layoutModel.lbTexts)
//        Service.reasons.attach(model.reasons, toView: self, layouts: itemContext.layoutModel.reasons)
//        relayoutSubviews()
//
//        //color
//        self.titleLabel.textColor = YKChannelBase.sceneUtil(.ykn_primaryInfo, sceneColor: itemContext.sceneTitleColor())
//        self.subTitleLabel.textColor = YKChannelBase.sceneUtil(.ykn_tertiaryInfo, sceneColor: itemContext.sceneSubTitleColor())
////        self.backgroundColor = YKChannelBase.sceneUtil(UIColor.clear, sceneColor: itemContext.sceneBgColor())
//    }
    
    
    func relayoutSubviews() {
        bgView.frame = self.bounds
        
        let w = self.imageViewFrame().size.width
        videoImageView.frame = self.imageViewFrame()

        let y = CGFloat(videoImageView.frame.maxY) + YKNGap.youku_picture_title_spacing()
        titleLabel.frame = CGRect.init(x: 0, y: y, width: w, height: YKNFont.height(with: titleLabel.font, lineNumber: 1))

        subTitleLabel.frame = CGRect.init(x: 0, y: titleLabel.frame.maxY + 3, width: w, height: YKNFont.height(with: subTitleLabel.font, lineNumber: 1))
    }
    
    func imageViewFrame() -> CGRect {
        let w = self.frame.size.width
        let h = ceil(w * 9.0/16.0)
        return CGRect.init(x: 0, y: 0, width: w, height: h)
    }
}
