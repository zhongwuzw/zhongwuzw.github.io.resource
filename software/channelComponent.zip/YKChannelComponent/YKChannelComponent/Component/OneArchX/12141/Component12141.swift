//
//  Component12141.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/1/18.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Component12141: NSObject, ComponentDelegate {
    var componentWrapper: ComponentWrapper?
    
    var item:IItem? {
        return self.component?.getItems()?.first
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.dim_6()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_column_spacing(), right: YKNGap.youku_margin_right())
//        config.preferredCardSpacingTop = 9.0
//        config.headerBottomMargin = 9.0
        return config
    }
    
    func columnCount() -> CGFloat {
        return 2
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [
            PlayerScrollEndCompEventHandler(),
            ComponentClientAIEventHandler()
        ]
    }
    
    func componentDidInit() {
        
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        guard let item = self.item , let itemDelegate = item.getItemDelegate() else { return 0 }
        return itemDelegate.itemHeight(itemWidth: itemWidth)
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item12141ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        self.item?.getItemDelegate()?.reuseView(itemView: itemView)
    }
}

class Component12161: Component12141 {
    
    override func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item12161ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    override func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.dim_6()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_line_spacing(), right: YKNGap.youku_margin_right())
//        config.preferredCardSpacingTop = 9.0
//        config.headerBottomMargin = 9.0
        return config
    }
}
