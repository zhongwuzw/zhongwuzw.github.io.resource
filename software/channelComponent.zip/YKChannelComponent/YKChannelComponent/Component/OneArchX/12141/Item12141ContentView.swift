//
//  Item12141ContentView.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/1/18.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import Lottie
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item12141ContentView: UIView {
        
    weak var itemModel: HomeItemModel?
    
    //MARK: Property
    lazy var bgView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.clipsToBounds = true
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView(frame: .zero)
        view.clipsToBounds = true
        view.contentMode = .scaleAspectFill
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.font = YKNFont.posteritem_maintitle_weight(.medium)
        view.textColor = .ykn_primaryInfo
        view.numberOfLines = 2
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var lineView: UIView = {
        let view = UIView.init(frame: .zero)
        view.backgroundColor = .ykn_separator
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel.init(frame: .zero)
        view.textColor = .ykn_primaryInfo
        view.font = YKNIconFont.sharedInstance().font(withSize: 12)
        view.lineBreakMode = .byTruncatingMiddle
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        self.addSubview(bgView)
        bgView.addSubview(videoImageView)
        bgView.addSubview(titleLabel)
//        bgView.addSubview(lineView)
        bgView.addSubview(subtitleLabel)
        
        self.backgroundColor = UIColor.ykn_primaryBackground
        self.clipsToBounds = true
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
    }
    
    func fillData(_ model: HomeItemModel) {
        self.itemModel = model
        titleLabel.text = model.title

        if let subtitle = model.subtitle, !subtitle.isEmpty {
            subtitleLabel.text = "\u{e71f}" + subtitle + "\u{e720}"
            subtitleLabel.isHidden = false
        } else {
            subtitleLabel.isHidden = true
        }
        
        videoImageView.frame = self.imageViewFrame()
        videoImageView.ykn_setImage(withURLString: XCDNSTRING(model.materialImg?.img),
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)

        relayoutSubviews()

        //color
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: model.scene?.sceneTitleColor() )
        self.subtitleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: model.scene?.sceneSubTitleColor())
        self.backgroundColor = sceneUtil(UIColor.ykn_elevatedPrimaryBackground, sceneColor: model.scene?.sceneCardFooterBgColor())
    }
    
    
    func relayoutSubviews() {
        bgView.frame = self.bounds
        
        let w = self.imageViewFrame().size.width
        videoImageView.frame = self.imageViewFrame()

        let y = CGFloat(videoImageView.frame.maxY) + YKNGap.youku_picture_title_spacing()
        let titleHeight = self.itemModel?.layout.title?.renderRect.height ?? YKNFont.height(with: titleLabel.font, lineNumber: 1)
        titleLabel.frame = CGRect.init(x: 9, y: y, width: w - 18.0, height: titleHeight)
//        lineView.frame = CGRect.init(x: 9, y: titleLabel.bottom + 6.0, width: self.width - 18, height: 1.0 / UIScreen.main.scale)
        subtitleLabel.frame = CGRect.init(x: 11, y: titleLabel.bottom + 9.0, width: w - 18.0, height: YKNFont.height(with: subtitleLabel.font, lineNumber: 1) + 5)
    }
    
    func imageViewFrame() -> CGRect {
        let w = self.frame.size.width
        let h = Item12141ContentView.imageViewHeight(itemWidth: w, ration: self.itemModel?.materialImg?.ratio)

        return CGRect.init(x: 0, y: 0, width: w, height: h)
    }
    
    
    static func imageViewHeight(itemWidth: CGFloat, ration: Int?) -> CGFloat {
        var ration = ration ?? 0
        if ration == 0 {
            ration = 177
        }
        let height = ceil(itemWidth * 100.0 / CGFloat(ration))
        return height
    }
}

class Item12161ContentView: Item12141ContentView {
    
    override func fillData(_ model: HomeItemModel) {
        super.fillData(model)
        self.backgroundColor = sceneUtil(UIColor.clear, sceneColor: model.scene?.sceneCardFooterBgColor())
    }
    
    override func relayoutSubviews() {
        bgView.frame = self.bounds
        
        let w = self.imageViewFrame().size.width
        videoImageView.frame = self.imageViewFrame()
        videoImageView.layer.cornerRadius = YKNCorner.radius_secondary_medium()

        let y = CGFloat(videoImageView.frame.maxY) + YKNGap.youku_picture_title_spacing()
        let titleHeight = self.itemModel?.layout.title?.renderRect.height ?? YKNFont.height(with: titleLabel.font, lineNumber: 1)
        titleLabel.frame = CGRect.init(x: 2.0, y: y, width: w - 4.0, height: titleHeight)

        subtitleLabel.frame = CGRect.init(x: 2.0, y: titleLabel.bottom + 9.0, width: w - 4.0, height: YKNFont.height(with: subtitleLabel.font, lineNumber: 1))
        subtitleLabel.textColor = UIColor.ykn_secondaryInfo
    }
}
