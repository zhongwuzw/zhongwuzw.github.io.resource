//
//  Item12141.swift
//  YKChannelComponent
//
//  Created by chao chen on 2024/1/18.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout

class Item12141:NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    
    func columnCount() -> CGFloat {
        return 2.0
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.receiveEstimatedLayout(Double(itemWidth))
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler(),
                ItemPlayerProgressEventHandler(),
                LongPressPreviewItemEventHandler()]
    }
    
    func itemDidInit() {
        if let reasons = item?.itemModel?.reasons {
            for (index, reason) in reasons.enumerated() {
                if index == 1, let img = reason.img, img.isEmpty == false {
                    item?.itemModel?.reasons?[index].imgEnabled = true
                }
            }
            
            //靠下对齐布局，需要统一高度，恢复所有推荐理由的垂直边距
            item?.itemModel?.reasons = reasons.map({
                var newReason = $0
                newReason.isNeedVerticalPaddingAtYK11 = true
                return newReason
            })
        }
    }
    
    func imageViewHeight(itemWidth:Double, ratio:Double) {
        
    }
    
    func receiveEstimatedLayout(_ itemWidth: Double) {

        var bottomHeight:Double = 6.0
        
        ///title
        let titleWidth = itemWidth - 18.0
        let titleHeight = calStringLimitedLineHeight(self.item?.itemModel?.title, font: YKNFont.posteritem_maintitle_weight(.medium), limitWidth: itemWidth - 18, limitLine: 2)
        let titleLayout = TextLayoutModel()
        titleLayout.renderRect = CGRect(x: 9, y: 0, width: titleWidth, height: titleHeight)
        item?.layout?.title = titleLayout
        
        bottomHeight += titleHeight
        
        let bottomPadding =  9.0
        bottomHeight += bottomPadding
        
        if let subtitle = item?.itemModel?.subtitle {
            let subtitleHeight = YKNFont.height(with: YKNFont.secondry_auxiliary_text(), lineNumber: 1)
            bottomHeight += subtitleHeight
            bottomHeight += 1.0
        }
        
        ///reason+上下
//        bottomHeight += 3.0 + 12.0 + 17.0
        
        let itemModel = self.item?.itemModel as? HomeItemModel
        let imgWidth = itemWidth
        let imgHeight = Item12141ContentView.imageViewHeight(itemWidth: imgWidth, ration: itemModel?.materialImg?.ratio)
 
        var itemHeight = imgHeight + bottomHeight
        item?.layout?.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)
        
        let videoImageViewSize = CGSize.init(width: imgWidth, height: imgHeight)
        if let mark = item?.itemModel?.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: videoImageViewSize)
            item?.layout?.mark = layout
        }
        
        if let lbTexts = item?.itemModel?.lbTexts {
            let layout = Service.lbTexts.estimatedLayout(lbTexts, toViewSize: videoImageViewSize)
            item?.layout?.lbTexts = layout
        }
        
        if let summary = item?.itemModel?.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize: videoImageViewSize)
            item?.layout?.summary = layout
        }
        if let reasons = item?.itemModel?.reasons {
            let x = 9.0
            let boundingwidth = itemWidth - x - 25
            let boundingSize = CGSize.init(width: boundingwidth, height: CGFloat.greatestFiniteMagnitude)
            var layout = Service.reasons.estimatedLayout(reasons, boundingSize: boundingSize)
            
            let bottomPadding = 12.0
            let reasonHeight = Double(layout.first?.renderRect.size.height ?? 0)
            itemHeight = itemHeight + bottomPadding + reasonHeight
            item?.layout?.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)

            let position = CGPoint.init(x: x, y: itemHeight - reasonHeight - bottomPadding)
            layout = Service.reasons.estimatedLayout(reasons, position: position, boundingSize: boundingSize)
            item?.layout?.reasons = layout
        }
    }
    
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item12141ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            return itemView
    }

    func reuseView(itemView: UIView) {
       
        guard let itemView = itemView as? Item12141ContentView else {
            return
        }
        guard let itemModel = self.item?.itemModel as? HomeItemModel else {
            return
        }
        
        itemView.fillData(itemModel)

        let layout = self.item?.itemModel?.layout

        //埋点
        Service.action.bind(self.item?.itemModel?.action, itemView)

        //负反馈
        weak var weakComponent = self.item?.getComponent()

        itemModel.feedbackModel?.feedbackFinished = {
            if let component = weakComponent {
                deleteComponentWithAnimation(component)
            }
        }
        
        Service.player.attach(itemModel.playerModel, toView: itemView.videoImageView, displayFrame: itemView.imageViewFrame())
                
        Service.summary.attach(itemModel.summary, toView: itemView.videoImageView, layout: layout?.summary)
//        Service.lbTexts.attach(itemModel.lbTexts, toView: itemView.videoImageView, layouts: layout?.lbTexts)
        Service.reasons.attach(itemModel.reasons, toView: itemView, layouts: layout?.reasons)
        Service.mark.attach(itemModel.mark, toView: itemView.videoImageView, layout: layout?.mark)
    }
}

class Item12161:Item12141 {
    
    override func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item12161ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
            return itemView
    }
    override func receiveEstimatedLayout(_ itemWidth: Double) {
        
        var bottomHeight:Double = 6.0
        
        ///title
        let titleWidth = itemWidth - 4.0
        let titleHeight = calStringLimitedLineHeight(self.item?.itemModel?.title, font: YKNFont.posteritem_maintitle_weight(.medium), limitWidth: titleWidth, limitLine: 2)
        let titleLayout = TextLayoutModel()
        titleLayout.renderRect = CGRect(x: 2.0, y: 0, width: titleWidth, height: titleHeight)
        item?.layout?.title = titleLayout
        
        bottomHeight += titleHeight
        
        let bottomPadding =  6.0
        bottomHeight += bottomPadding
        
        if let subtitle = item?.itemModel?.subtitle {
            if item?.itemModel?.hideSubtitle == false {
                let subtitleHeight = YKNFont.height(with: YKNFont.secondry_auxiliary_text(), lineNumber: 1)
                bottomHeight += subtitleHeight
                bottomHeight += 1.0
            }
        }
        
        ///reason+上下
//        bottomHeight += 3.0 + 12.0 + 17.0
        
        let itemModel = self.item?.itemModel as? HomeItemModel
        let imgWidth = itemWidth
        let imgHeight = Item12141ContentView.imageViewHeight(itemWidth: imgWidth, ration: itemModel?.materialImg?.ratio)
 
        var itemHeight = imgHeight + bottomHeight
        item?.layout?.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)
        
        let videoImageViewSize = CGSize.init(width: imgWidth, height: imgHeight)
        if let mark = item?.itemModel?.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: videoImageViewSize)
            item?.layout?.mark = layout
        }
        
        if let lbTexts = item?.itemModel?.lbTexts {
            let layout = Service.lbTexts.estimatedLayout(lbTexts, toViewSize: videoImageViewSize)
            item?.layout?.lbTexts = layout
        }
        
        if let summary = item?.itemModel?.summary {
            let layout = Service.summary.estimatedLayout(summary, toViewSize: videoImageViewSize)
            item?.layout?.summary = layout
        }
        if let reasons = item?.itemModel?.reasons {
            let x = 2.0
            let boundingwidth = itemWidth - x - 25
            let boundingSize = CGSize.init(width: boundingwidth, height: CGFloat.greatestFiniteMagnitude)
            var layout = Service.reasons.estimatedLayout(reasons, boundingSize: boundingSize)
            
            let reasonHeight = Double(layout.first?.renderRect.size.height ?? 0)
            itemHeight = itemHeight + reasonHeight
            item?.layout?.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)

            let position = CGPoint.init(x: x, y: itemHeight - reasonHeight)
            layout = Service.reasons.estimatedLayout(reasons, position: position, boundingSize: boundingSize)
            item?.layout?.reasons = layout
        }
    }
    
}
