//
//  Item14300.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/10/19.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item14300 : NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() { //子线程
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14299Model.self as? T.Type
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        guard let _ = self.item?.model as? PadBaseItemModel else {
            return 0.0
        }
        
        return calItemHeight(itemWidth)
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemFrame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
        return PadContentView.init(frame: itemFrame)
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? PadContentView else {
            return
        }
        
        itemView.fillData(item)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [LongPressPreviewItemEventHandler()]
    }
    
    // MARK: - cal layout
    
    func calItemHeight(_ itemWidth: CGFloat) -> CGFloat {
        guard let item = item , let model = item.model as? PadBaseItemModel else {
            return 0
        }
        
        PadContentViewLayoutService.calItemLayout(item, itemWidth: itemWidth) //计算layout
        
        var itemHeight: CGFloat = 0
        
        let itemIndex: Int = item.index
        if itemIndex == 0 { //第一坑位计算高度
            item.getComponent()?.compModel?.extraExtend["calBottomTotalHeight"] = model.bottomViewTotalHeight //缓存bottom高度
            
            itemHeight = PadContentView.calHeightWithWidth(itemWidth, item)
            item.getComponent()?.compModel?.extraExtend["calItemHeight"] = itemHeight //缓存坑位高度
        } else { //其他坑位使用缓存总高度、bottom高度
            if let cacheBottomHeight = item.getComponent()?.compModel?.extraExtend["calBottomTotalHeight"] as? CGFloat { //使用缓存bottom高度
                model.bottomViewTotalHeight = cacheBottomHeight
            }
            
            if let cacheItemHeight = item.getComponent()?.compModel?.extraExtend["calItemHeight"] as? CGFloat {
                itemHeight = cacheItemHeight
            }
        }
        print("[响应式 new] 14300 index:\(itemIndex) 计算高度:\(itemHeight)")
        return itemHeight
    }
}
