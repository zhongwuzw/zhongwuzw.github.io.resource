//
//  Component14300.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/10/19.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku

class Component14300: Component14001 {
    override func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: PAD_NEW_HOME_MarginLeft, bottom: YKNGap.youku_column_spacing() - YKNGap.dim_6(), right: PAD_NEW_HOME_MarginLeft)
        config.preferredCardSpacingTop = 0 //组件头设置了一个YKNGap.dim_6()，上方bottom已经设置了总高度，需减掉
        config.columnSpacing = PAD_NEW_HOME_ColumnSpacing
        config.rowSpacing = PAD_NEW_HOME_LineSpacing
        return config
    }
}
