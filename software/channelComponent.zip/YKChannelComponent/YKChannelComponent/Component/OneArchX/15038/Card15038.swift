//
//  Card15038.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/11/2.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuResource

class Card15038: BaseCardDelegate {
    override func layoutConfig() -> CardLayoutConfig {
        var config = super.layoutConfig()
        config.padding = UIEdgeInsets.init(top: 0.0, left: 0.0, bottom: 0.0, right: 0.0)
        return config
    }
    override func isShowHeader() -> Bool {
        return true
    }
}


class Card15038Header:NSObject, ComponentDelegate {
    var componentWrapper: OneArch.ComponentWrapper?

    func layoutType() -> OneArch.ComponentLayoutType {
        .custom
    }
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 100, bottom: 0, right: 100)
        return config
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let height = (110.0 / 375.0) * YKRLScreenWidth() - YKNGap.youku_comp_margin_top()
        return height
    }
    
    func reuseId() -> String? {
        let identifier = "card.header.Card15038Header"
        return identifier
    }

    /// 初始化item view
    func createView(_ itemSize: CGSize) -> UIView {
        let frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
        return UIView.init(frame: frame)
    }

    /// 复用
    func reuseView(itemView: UIView) {
        itemView.backgroundColor = .clear
        itemView.isUserInteractionEnabled = false
        itemView.superview?.isUserInteractionEnabled = false
    }
    
    
    func componentDidInit() {

    }
    
    func hasSubtitle() -> Bool {
        return false
    }
}
