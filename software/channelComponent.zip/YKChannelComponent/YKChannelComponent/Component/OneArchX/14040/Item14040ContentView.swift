//
//  Item14040ContentView.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/28.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Item14040ContentView: AccessibilityView {

    //MARK: Property
    lazy var imageView:UIImageGIFView = {
        let view = UIImageGIFView()
        view.backgroundColor = .clear
        view.contentMode = .scaleAspectFit
        view.layer.cornerRadius = YKNCorner.radius_medium()
        view.clipsToBounds = true
        return view
    }()
    
    lazy var titleLabel:UILabel = {
        let label = UILabel()
        label.backgroundColor = .clear
        label.textAlignment = .center
        let isMac = YKRLLayoutManager.sharedInstance().currentPlatform == YKRLLayoutPlatform.mac
        label.font = isMac ? YKNFont.secondry_auxiliary_text() : YKNFont.tertiary_auxiliary_text()
        label.textColor = UIColor.ykn_primaryInfo
        return label
    }()
    
    lazy var bubbleBtn:UIButton = {
        let button = UIButton()
        button.titleLabel?.font = UIFont.systemFont(ofSize: 8)
        button.titleLabel?.lineBreakMode = .byTruncatingTail
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = UIColor.ykn_cr_1
        button.isUserInteractionEnabled = false
        return button
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.imageView)
        self.addSubview(self.titleLabel)
        self.addSubview(self.bubbleBtn)
        self.bubbleBtn.isHidden = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(itemModel: BaseItemModel) {
        self.backgroundColor = .clear
      
        Service.action.bind(itemModel.action, self)

        self.titleLabel.text = itemModel.title
        
        var icon = itemModel.gifImg
        if icon == nil {
            icon = itemModel.img
        }
        let scale = 1.0 //YKNSize.yk_icon_size_scale()
        let w:CGFloat = 15 + 42 * scale
        let h:CGFloat = 42 * scale
        self.imageView.size = SCREEN_WIDTH < 375 ? CGSize.init(width: 49, height: 37) : CGSize.init(width: w, height: h)

        self.imageView.ykn_setImage(withURLString: icon, module: "home", imageSize: .zero, parameters: nil, completed: nil)
        self.bubbleBtn.setTitle(itemModel.mark?.text, for: .normal)
        
        layoutUI(itemModel)

        //氛围
        titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor:itemModel.scene?.sceneTitleColor())
    }
    
    func layoutUI(_ itemModel: BaseItemModel) {
        self.imageView.origin = CGPoint.init(x: (self.width - self.imageView.width)/2, y: 3)
        
        let isMac = YKRLLayoutManager.sharedInstance().currentPlatform == YKRLLayoutPlatform.mac
        
        let font = isMac ? YKNFont.secondry_auxiliary_text() : YKNFont.tertiary_auxiliary_text()
        let titleHeight:CGFloat = YKNFont.height(with: font, lineNumber: 1)
        
        self.titleLabel.frame = CGRect.init(x: 0, y: self.imageView.bottom + YKNGap.youku_picture_title_spacing(), width: self.width, height: titleHeight)
        
        let text = itemModel.mark?.text ?? ""
        if text.count > 0, let font = self.bubbleBtn.titleLabel?.font {
            self.bubbleBtn.isHidden = false
            var width = text.boundingRect(with: CGSize.init(width: Double(MAXFLOAT), height: 28.0), options: .usesLineFragmentOrigin, attributes: [.font:font], context: nil).size.width + 8
            if (width > self.width) {
                width = self.width;
            }
            self.bubbleBtn.frame = CGRect.init(x: self.width - width, y: 0, width: width, height: 14)
            self.bubbleBtn.layer.cornerRadius = 7
            self.bubbleBtn.layer.masksToBounds = true
        }else{
            self.bubbleBtn.isHidden = true
        }
    }
}
