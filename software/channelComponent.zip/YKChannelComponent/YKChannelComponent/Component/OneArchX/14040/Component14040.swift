//
//  Component14040.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/28.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout

class Component14040: NSObject, ComponentDelegate {
    
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeComponentModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .horizontalScroll
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        let columnSpacing = getColumnSpacing()
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        config.preferredCardSpacingTop = YKNGap.youku_module_margin_top()
        config.headerBottomMargin = 0.0
        config.rowSpacing = 0.0
        config.columnSpacing = columnSpacing
        config.footerTopMargin = 0.0
        config.preferredRowHeight = 0.0
        let paddingLeft = getPadding(columnSpacing).0
        let paddingRight = getPadding(columnSpacing).1
        config.horizontalPaddingLeft = paddingLeft
        config.horizontalPaddingRight = paddingRight
        config.backgroundLeftMarginOffset = 0
        config.backgroundRightMarginOffset = 0
        config.headerLeftMarginOffset = 0
        config.headerRightMarginOffset = 0
        config.backgroundTopMargin = 0
        return config
    }
    
    func getColumnSpacing() -> CGFloat {
        if ykrl_isResponsiveLayout() {
            return 18 // 20221129版本 目标值18，标注见 https://work.aone.alibaba-inc.com/issue/46241807
        }
        let itemCount = self.component?.getItems()?.count ?? 0
        if itemCount == 0 {
            return YKNGap.youku_column_spacing()
        }
        
        let containerWidth = self.component?.pageContext?.getContainerView()?.width ?? YKRLScreenWidth()
        
        let itemWidth:CGFloat = 57
        var spacing:CGFloat = YKNGap.dim_7()
        
        if itemCount <= 5 {
            let n:CGFloat = CGFloat(max(itemCount - 1, 1))
            spacing = (containerWidth - YKNGap.youku_margin_left() - YKNGap.youku_margin_right() - CGFloat(itemCount) * itemWidth) * 1.0 / n
        } else {
            spacing = (containerWidth - YKNGap.margin_l() - 5.3 * itemWidth)/5
        }
        
        if spacing > 54 {
            spacing = 54
        }
        return spacing
    }

    func getPadding(_ columnSpacing: CGFloat) -> (CGFloat,CGFloat) {
        var paddingLeft = YKNGap.youku_margin_left()
        var paddingRight = YKNGap.youku_margin_right()
        if ykrl_isResponsiveLayout() {
            let itemCount = CGFloat(self.component?.homeCompModel?.itemsCount ?? 1)
            let containerWidth = self.component?.pageContext?.getContainerView()?.width ?? YKRLScreenWidth()
            let itemWidth = CGFloat(15 + 42)
            let itemMaxWidth = itemWidth * itemCount + columnSpacing * max(itemCount - 1, 0)
            if (paddingLeft + paddingRight + itemMaxWidth) < containerWidth {
                paddingLeft = (containerWidth - itemMaxWidth) / 2.0
                paddingRight = paddingLeft
            }
        }
        return (paddingLeft, paddingRight)
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        if let collectionView = itemView.subviews.first as? UICollectionView {
            collectionView.contentOffset = CGPoint.init(x: -collectionView.contentInset.left, y: 0)
        }
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
