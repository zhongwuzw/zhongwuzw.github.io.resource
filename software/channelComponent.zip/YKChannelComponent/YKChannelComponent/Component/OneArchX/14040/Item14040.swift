//
//  Item14040.swift
//  YKChannelComponent
//
//  Created by better on 2021/12/28.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item14040: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    func itemDidInit() {
        
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func itemWidth() -> CGFloat {
        return Item14040.calItemWidth(self.item)
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let scale:CGFloat = 1.0 //YKNSize.yk_icon_size_scale()
        let height:CGFloat = 3 + 42 * scale
        let titleHeight:CGFloat = YKNFont.height(with: YKNFont.tertiary_auxiliary_text(), lineNumber: 1)
        let titleSpacing:CGFloat = YKNGap.youku_picture_title_spacing()
        let itemHeight = height + titleHeight + titleSpacing
        return itemHeight
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14040ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14040ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        itemView.fillData(itemModel: itemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    static func calItemWidth(_ item: IItem?) -> CGFloat {
        let scale:CGFloat = 1.0 // YKNSize.yk_icon_size_scale()
        var width = 15 + ceil(42 * scale)
        if ykrl_isResponsiveLayout() {
            let font = YKNFont.tertiary_auxiliary_text()
            if let title = item?.itemModel?.title, title.isEmpty == false {
                let labelWidth = calcStringSize(title, font: font, size: .zero).width
                if labelWidth > width {
                    if labelWidth >= width * 1.5 {
                        width = width * 1.5
                    } else {
                        width = labelWidth
                    }
                }
            }
        }
        return width
    }

}
