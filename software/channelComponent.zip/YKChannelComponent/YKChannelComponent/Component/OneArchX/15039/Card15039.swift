//
//  Card15039.swift
//  YKChannelComponent
//
//  Created by zhangjc on 2023/11/27.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuAppAlarm
import YKResponsiveLayout
import OneArchSupport4Youku

class Card15039: BaseCardDelegate {

    override func layoutConfig() -> CardLayoutConfig {
        var config = super.layoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        return config
    }

    override func getComponentJsonExtracter() -> ComponentJsonExtracter? {
        return Card15039ComponentJsonExtracter.init()
    }
    
    override func getModelClass<T>() -> T.Type? where T : NodeModel {
        return ChannelBaseCardModel.self as? T.Type
    }
}

class Card15039ComponentJsonExtracter: DefaultComponentJsonExtracter {

    // MARK: - 原始数据加工
    override public func getComponentsJson(cardJson: [String : Any]?, card: ICard?) -> Result<[[String : Any]], Error> {
        guard let components = cardJson?["nodes"] as? [[String: Any]] else {
            return .success([[String : Any]]()) //允许没有组件列表
        }
        
        //递归处理组件和坑位居
        let result = handleNodes(nodes: components)
//        if let index = card?.index, index == 0 {
//            let result = handleNodes(nodes: components)
//        }
        
        //feed空数据上报预警
        if result.count == 0 {
            if let cardModel = card?.model as? BaseCardModel {
                let errorMsg = "current_page=\(cardModel.curPageIndex)"
                print("[15039] \(errorMsg)")
                YoukuAppAlarm.alarm(withBizType: "responsive_feed_empty", bizChannelKey: "15030", traceId: "", errorCode: "", errorMsg: errorMsg, needAlarm: true)
            }
        }

        return .success(result)
    }
    
    
    private func handleNodes(nodes: [[String:Any]]) -> [[String:Any]] {
        var result = [[String:Any]]()
        for i in 0..<nodes.count { //14327 || 14329
            var node = nodes[i]
            let type = node["type"] as? Int ?? 0
            if type == 14327, i < 3, !ykrl_isResponsiveLayout() { //角色榜
                node["type"] = type + 1
                if let subNodes = node["nodes"] as? [[String:Any]] {
                    node["nodes"] = handleNodes(nodes: subNodes)
                }
                result.append(node)
            } else if type == 14329, i < 1, !ykrl_isResponsiveLayout() { //CP榜
                node["type"] = type + 1
                if let subNodes = node["nodes"] as? [[String:Any]] {
                    node["nodes"] = handleNodes(nodes: subNodes)
                }
                result.append(node)

            } else {
                result.append(node)
            }
        }

        return result
    }
}
