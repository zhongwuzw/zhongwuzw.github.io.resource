//
//  Component14110.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/25.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Component14110:NSObject, ComponentDelegate {

    var componentWrapper: ComponentWrapper?

    func componentDidInit() {}

    func layoutType() -> ComponentLayoutType {
        return .itemFlow
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_column_spacing()
        config.footerBottomMargin = YKNGap.youku_comp_margin_bottom()
        return config
    }

    func columnCount() -> CGFloat {
        return 2.0
    }

    /// 加载事件处理器
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

    /// item高度（custom布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }

    /// 初始化item view（custom布局使用）
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView.init()
    }

    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
       
    }
}
