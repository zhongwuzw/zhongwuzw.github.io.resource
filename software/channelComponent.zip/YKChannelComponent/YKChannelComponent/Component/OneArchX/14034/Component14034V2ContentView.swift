//
//  Component14034V2ContentView.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/1.
//  Copyright © 2023 Youku. All rights reserved.
//

import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKCMSComponent
import OnePlayer

class Component14034V2ContentView : AccessibilityView, ReserveButtonDelegate, Component14034V2MenuViewDelegate, ChannelSliderPlayerDelegate {

    weak var component: IComponent?
    weak var model: BaseComponentModel?
    weak var itemModel: HomeItemModel?
    
    static var isMute = true
    
    var _visable = false
    var _disableVV = true

    var delayPlayTimer:Timer?
    var player: ChannelSliderPlayer?

    lazy var contentView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.ykn_tertiaryInfo
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.layer.masksToBounds = true
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFit
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
        return view
    }()
    
    lazy var playIcon: UIImageView = {
        let view = UIImageView.init(image:UIImage.init(named: "st_player_plugin_icon_play"))
        return view
    }()
    
    lazy var muteButton: UIButton = {
        let button = UIButton.init(type: .custom)
        button.setImage(UIImage.init(named: "st_player_plugin_icon_silent_on"), for: .normal)
        button.setImage(UIImage.init(named: "st_player_plugin_icon_silent_off"), for: .selected)
        button.frame = CGRect.init(x: 0, y: 0, width: 50, height: 50)
        button.addTarget(self, action: #selector(didClickMuteButton), for: UIControl.Event.touchUpInside)
        button.isSelected = !Component14034V2ContentView.isMute
        return button
    }()
    
    lazy var gradientView: UIView = {
        let view = UIView.init()
        view.isUserInteractionEnabled = false
        return view
    }()
    
    lazy var menuView: Component14034V2MenuView = {
        let menuViewWidth: CGFloat = self.bounds.width
        let menuViewHeight: CGFloat = Component14034V2ContentView.getMenuViewHeight()
        
        let view = Component14034V2MenuView.init(frame: CGRect.init(origin: .zero, size: CGSize.init(width: menuViewWidth, height: menuViewHeight)))
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .white
        view.font = Component14034V2ContentView.getTitleFont()
        view.numberOfLines = 1
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .white
        view.font = Component14034V2ContentView.getSubtitleFont()
        view.numberOfLines = 1
        return view
    }()
    
    lazy var reserveButton: Component14034V2ReserveButton = {
        let view = Component14034V2ReserveButton()
        view.delegate = self
        view.isHidden = true
        return view
    }()
    
    //MARK: -
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
//        NotificationCenter.default.addObserver(self, selector: #selector(handleAddReserveSuccessNotication), name: NSNotification.Name.init("kAddReserveSuccessNotification"), object: nil)
//        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelReserveSuccessNotication), name: NSNotification.Name.init("kCancelReserveSuccessNotification"), object: nil)
        
        addSubview(contentView)
        contentView.frame = self.bounds
        
        //封面图
        contentView.addSubview(videoImageView)
        let width = Double(self.frame.size.width)
        let height = Double(ceil(width * 9.0/16.0))
        videoImageView.frame = CGRect.init(x: 0, y: 0, width: width, height: height)
        
        //播放按钮
        videoImageView.addSubview(playIcon)
        playIcon.frame = CGRect.init(x: 0, y: 0, width: 45, height: 45)
        playIcon.center = CGPoint.init(x: videoImageView.width/2.0, y: videoImageView.height/2.0)
                
        //播放器
        self.player = self.newPlayer()
        
        let padding: CGFloat = YKNGap.dim_6()
        let textWidth: CGFloat = width - 2 * padding
        
        //渐变阴影区
        addSubview(gradientView)
        let gradientViewHeight: CGFloat = Component14034V2ContentView.getPlayerBottomGradientHeight()
        let gradientViewWidth: CGFloat = videoImageView.bounds.size.width
        let gradientViewY: CGFloat = videoImageView.frame.maxY - gradientViewHeight
        let gradientViewX: CGFloat = 0
        gradientView.frame = CGRect.init(x: gradientViewX, y: gradientViewY, width: gradientViewWidth, height: gradientViewHeight)
        
        //横滑视图
        addSubview(menuView) //使得menuView 不被实时添加的视图（播放器等）遮挡
        let menuViewSize: CGSize = menuView.bounds.size
        let menuViewY: CGFloat = videoImageView.frame.maxY - Component14034V2ContentView.getMenuViewYOffset()
        menuView.frame = CGRect.init(x: 0, y: menuViewY, width: menuViewSize.width, height: menuViewSize.height)
        
        //静音按钮
        addSubview(muteButton) //使得静音按钮热区不被遮挡
        let muteButtonSize: CGSize = muteButton.size
        let x: CGFloat = videoImageView.frame.maxX - muteButtonSize.width
        let y: CGFloat = videoImageView.frame.maxY - muteButtonSize.height - 10
        muteButton.frame = CGRect.init(x: x, y: y, width: muteButtonSize.width, height: muteButtonSize.height)
        
        //主标题
        contentView.addSubview(titleLabel)
        let titleY: CGFloat = menuView.frame.maxY + Component14034V2ContentView.getTitleTopGap()
        let titleHeight: CGFloat = YKNFont.height(with: Component14034V2ContentView.getTitleFont(), lineNumber: 1)
        titleLabel.frame = CGRect(x: padding, y: titleY, width: textWidth, height: titleHeight)
        
        //副标题
        contentView.addSubview(subtitleLabel)
        let subtitleY: CGFloat = titleLabel.frame.maxY + Component14034V2ContentView.getBetweenTitleAndSubtitleGap()
        let subtitleHeight: CGFloat = YKNFont.height(with: Component14034V2ContentView.getSubtitleFont(), lineNumber: 1)
        subtitleLabel.frame = CGRect(x: padding, y: subtitleY, width: textWidth, height: subtitleHeight)
        
        //预约按钮
        contentView.addSubview(reserveButton)
        let buttonWidth: CGFloat = 60
        let buttonHeight: CGFloat = 30
        let buttonX: CGFloat = titleLabel.frame.maxX - buttonWidth
        let buttonY: CGFloat = menuView.frame.maxY + YKNGap.dim_8()
        reserveButton.frame = CGRect.init(x: buttonX, y: buttonY, width: buttonWidth, height: buttonHeight)
        reserveButton.layer.cornerRadius = buttonHeight / 2.0
    }
    
    static func getHeight(_ givenWidth: CGFloat) -> CGFloat {
        var height: CGFloat = 0
        
        let playerHeight = Double(ceil(givenWidth * 9.0/16.0))
        height += playerHeight
        
        let menuView = getMenuViewHeight()
        let getMenuViewYOffset = getMenuViewYOffset()
        height += (menuView - getMenuViewYOffset)
        
        let titleTopGap = getTitleTopGap()
        height += titleTopGap
        
        let titleHeight = YKNFont.height(with: self.getTitleFont(), lineNumber: 1)
        height += titleHeight
        
        let gap = getBetweenTitleAndSubtitleGap()
        height += gap
        
        let subtitleHeight = YKNFont.height(with: self.getSubtitleFont(), lineNumber: 1)
        height += subtitleHeight
        
        let bottomPadding = getBottomPadding()
        height += bottomPadding
        
        return height
    }
    
    static func getPlayerBottomGradientHeight() -> CGFloat {
        return 40
    }
    
    static func getMenuViewYOffset() -> CGFloat {
        return 50.0
    }
    
    static func getMenuViewHeight() -> CGFloat {
        return 92.0
    }
    
    static func getTitleTopGap() -> CGFloat {
        return YKNGap.dim_6()
    }
    
    static func getTitleFont() -> UIFont {
        return YKNFont.module_headline_weight(.semibold)
    }
    
    static func getBetweenTitleAndSubtitleGap() -> CGFloat {
        return YKNGap.dim_2()
    }
    
    static func getSubtitleFont() -> UIFont {
        return YKNFont.module_headline_linktext()
    }
    
    static func getBottomPadding() -> CGFloat {
        return YKNGap.dim_7()
    }
    
    func fillData(_ componentModel: BaseComponentModel, component: IComponent) {
        self.model = componentModel
        self.component = component
        
        // 横滑视图
        menuView.delegate = self
        menuView.fillData(component)
    }
    
    func fillData(_ itemModel: HomeItemModel, animated: Bool = false) {
        if itemModel == self.itemModel {
            return // 忽略重复数据
        }
        
        self.itemModel = itemModel
        
        // 标题
        titleLabel.text = itemModel.title
                
        // 子标题
        fillSubtitle(itemModel)
        
        // 背景色
        if let color = itemModel.extraExtend["imageAvgColor"] as? UIColor {
            if animated {
                UIView.animate(withDuration: 0.2) {
                    self.contentView.backgroundColor = color
                }
            } else {
                self.contentView.backgroundColor = color
            }
        }
        
        // 封面图
        if let videoImage = itemModel.poster?.img as? String {
            videoImageView.ykn_setImage(withURLString: XCDNSTRING(videoImage),
                                        module: "home",
                                        imageSize: CGSize.zero,
                                        parameters: nil) { [weak self] (image, error, userInfo) in
                if let image = image {
                   
                    image.yk_averageColor(withSaturationMin: 0.2 * 1.2, max: 0.45 * 1.2, lightnessMin: 0.35 * 0.7, max: 0.5 * 0.7) { color in
                        itemModel.extraExtend["imageAvgColor"] = color
                        self?.fillGradient(itemModel)
                        
                        if animated {
                            UIView.animate(withDuration: 0.2) {
                                self?.contentView.backgroundColor = color ?? UIColor.ykn_tertiaryInfo
                            }
                        } else {
                            self?.contentView.backgroundColor = color ?? UIColor.ykn_tertiaryInfo
                        }
                    }
                }
            }
        } else {
            videoImageView.image = nil
            contentView.backgroundColor = UIColor.ykn_tertiaryInfo
        }
        
        // 播放
        fillPlayer(itemModel)
        
        // 预约按钮
        if let reserveModel = itemModel.reserveModel {
            reserveButton.isHidden = false
            reserveButton.refresh(reserveModel: reserveModel, scene: nil)
        } else {
            reserveButton.isHidden = true
        }
        
        // 角标
        if itemModel.layout.mark == nil, let mark = itemModel.mark {
            let marklayout = Service.mark.estimatedLayout(mark, toViewSize: self.videoImageView.size)
            itemModel.layout.mark = marklayout
        }
        Service.mark.attach(itemModel.mark, toView: self.videoImageView, layout: itemModel.layout.mark)

        // 点击&埋点
        Service.action.bind(itemModel.action, self.contentView)
    }
    
    func fillSubtitle(_ itemModel: HomeItemModel) {
        var subtext = itemModel.desc ?? ""
        if let reserveModel = itemModel.reserveModel {
            if reserveModel.needShowCount {
                if !subtext.isEmpty {
                    subtext.append(" | ")
                }
                
                let countText = "\(reserveModel.formatCountText)已预约"
                subtext.append(countText)
            }
        }
        subtitleLabel.text = subtext
    }
    
    //MARK: Notification
//    @objc func handleAddReserveSuccessNotication(notification: Notification) {
//        handleNotication(notification: notification, isReserved: true)
//    }
//
//    @objc func handleCancelReserveSuccessNotication(notification: Notification) {
//        handleNotication(notification: notification, isReserved: false)
//    }
//
//    func handleNotication(notification: Notification, isReserved: Bool) {
//        guard let reserveId = notification.object as? String else {
//            return
//        }
//        guard let itemModel = itemModel else {
//            return
//        }
//        guard let reserveModel = itemModel.reserveModel, let currentId = reserveModel.rid else {
//            return
//        }
//        guard currentId == reserveId else {
//            return
//        }
//
//        reserveModel.isReserve = isReserved
//
//        // 更新预约人数
//        var count = isReserved ? reserveModel.count + 1 : reserveModel.count - 1
//        count = max(0, count)
//        reserveModel.count = count
//        itemModel.reserveModel = reserveModel
//
//        fillSubtitle(itemModel)
//    }
    
    func fillPlayer(_ itemModel: HomeItemModel) {
        if let cardModel = self.component?.getCard()?.model as? BaseCardModel {
            _disableVV = (cardModel.extraExtend["notSendVV"] as? Bool) ?? true
        }
        self.playIcon.isHidden = UtilityHelper.isWifi()
        bindMuteButtonReport()
        play(false)
    }
    
    func getItemModel() -> BaseItemModel? {
        guard let items = self.component?.getItems() else {
            return nil
        }

        let itemModels = items.compactMap({ $0.itemModel })
        for aItemModel in itemModels {
            if let value = aItemModel.extraExtend["isHighlighted"] as? Bool, value == true {
                return aItemModel
            }
        }
        
        return nil
    }
    
    func getPreviewId() -> String? {
        guard let itemModel = getItemModel() else {
            return nil
        }
        let preview = itemModel.preview
        var previewVid:String?
        if let vid = preview?["vid"] as? NSNumber {
            previewVid = vid.stringValue
        } else if let vid = preview?["vid"] as? String {
            previewVid = vid
        }
        return previewVid
    }
    
    func getConfig(key: String) -> Bool {
        if key.isEmpty {
            return false
        }
        
        guard let card = component?.getCard(),
              let cardModel = card.cardModel
        else {
            return false
        }
        
        let value = cardModel.extend[key] as? String ?? ""
        if value == "1" {
            return true
        }
        return false
    }
    
    func fillGradient(_ itemModel: HomeItemModel) {
        var color = UIColor.ykn_tertiaryInfo
        if let tintColor = itemModel.extraExtend["imageAvgColor"] as? UIColor {
            color = tintColor
        }
        
        Service.viewInnerGradient.attach(.bottom,
                                         toView: gradientView,
                                         scope: gradientView.height,
                                         startColor: color.withAlphaComponent(0.01),
                                         endColor: color)
    }
    
    // MARK: - ReserveButtonDelegate
    func didUpdateReserveButtonFrame() {
        let buttonWidth: CGFloat = reserveButton.width
        let buttonHeight: CGFloat = reserveButton.height
        let buttonX: CGFloat = titleLabel.frame.maxX - buttonWidth
        let buttonY: CGFloat = menuView.frame.maxY + YKNGap.dim_8()
        reserveButton.frame = CGRect.init(x: buttonX, y: buttonY, width: buttonWidth, height: buttonHeight)
        reserveButton.layer.cornerRadius = buttonHeight / 2.0
        
        guard let itemModel = itemModel else {
            return
        }
        guard let reserveModel = itemModel.reserveModel else {
            return
        }
        //reserveModel.count = Int(reserveButton.reserveCountString) ?? reserveModel.count
        fillSubtitle(itemModel)
    }
    
    // MARK: - Component14034V2MenuViewDelegate
    func menuView(_ menuView: Component14034V2MenuView, shouldSelect itemModel: HomeItemModel) -> Bool {
        if let isHighlighted = itemModel.extraExtend["isHighlighted"] as? Bool, isHighlighted {
            Service.action.doAction(itemModel.action, extendRouteParams: nil, willAction: nil, didAction: nil)
            return false //重复选择，跳转到播放页
        }
        
        return true //允许选择
    }
    
    func menuView(_ menuView: Component14034V2MenuView, willSelect itemModel: HomeItemModel) {
        
    }
    
    func menuView(_ menuView: Component14034V2MenuView, didSelect itemModel: HomeItemModel) {
        if menuView != self.menuView {
            return
        }
        
        fillData(itemModel, animated: true)
    }
    
    // MARK: - Player
    func newPlayer() -> ChannelSliderPlayer? {
        let vc = self.component?.pageContext?.getViewController()
        let player = ChannelSliderPlayer.init(controller: vc)
        player?.delegate = self
        player?.isSlientMode = Component14034V2ContentView.isMute
        player?.setupFrame(self.videoImageView.bounds)
        //添加起播互斥插件
        player?.registerPlugin(withPluginID: "startPlayMutex", params: mutextParams())
        return player
    }
    
    func mutextParams() -> [String:Any] {
        return ["name":"YKCStartPlayMutexPlugin",
                "initlevel":10,
                "enabled":true,
                "classname":"YKCStartPlayMutexPlugin",
                "layers":["layerid":"ad", "level":1000]
        ]
    }
    
    func startPlayer() {
        if UtilityHelper.isPlayerInValidArea(playerView: videoImageView) {
            // 正在播放
            if let player = self.player, let previewVid = getPreviewId(),
               player.isPlaying && previewVid == player.playingVid {
                return
            }
            syncSilentMode()
            startDelayPlayTimer()
        }
    }
 
    func stopPlayer() {
        NSObject.cancelPreviousPerformRequests(withTarget: self)
        stopDelayPlayTimer()
        self.muteButton.isHidden = true
        self.player?.stopVideo()
        self.player?.embedPlayerView().removeFromSuperview()
    }
    
    func startDelayPlayTimer() {
        stopDelayPlayTimer()
        delayPlayTimer = Timer.scheduledTimer(timeInterval: 0.55, target: self, selector: #selector(handleDelayPlayTimerTimeUp), userInfo: nil, repeats: false)
    }

    func stopDelayPlayTimer() {
        if self.delayPlayTimer?.isValid == true {
            self.delayPlayTimer?.invalidate()
        }
        self.delayPlayTimer = nil
    }
    
    @objc func handleDelayPlayTimerTimeUp() {
        play(true)
    }

    func play(_ isExpoPlay: Bool) {
        self.player?.embedPlayerView().isHidden = true
        self.muteButton.isHidden = true
        self.player?.stopVideo()
        
        //只有 WIFI 下才能播放
        if !UtilityHelper.isWifi() {
            return
        }
        
        if getConfig(key: "scrollAutoPlay") == false {
            return //未配置曝光播放，终止起播
        }
        
        let previewVid = getPreviewId()
        if _visable, isPageInActive(), !isStringEmpty(previewVid) {
            let params = NSMutableDictionary()
            if isExpoPlay {
                if _disableVV {
                    params["play_style"] = "1"
                    params["disableVV"] = true
                } else {
                    params["play_style"] = "1"
                    params["playtrigger"] = "2"
                    params["disableVV"] = false
                }
            } else {
                if _disableVV {
                    params["play_style"] = "1"
                    params["disableVV"] = true
                } else {
                    params["play_style"] = "1"
                    params["playtrigger"] = "1"
                    params["disableVV"] = false
                }
            }
            NSObject.cancelPreviousPerformRequests(withTarget: self)
            self.perform(#selector(delayPalyWithParas(_:)), with: params, afterDelay: 0.5)
        }
    }
    
    @objc func delayPalyWithParas(_ params: NSMutableDictionary) {
        guard _visable, isPageInActive(),
            let previewId = getPreviewId(),
            let vc = self.component?.pageContext?.getViewController(),
            let params = params as? [String:Any] else {
                return
        }
        self.player?.playVideo(withVid: previewId, params: params, controller: vc)
    }
    
    func isPageInActive() -> Bool {
        return self.component?.pageContext?.isPageActive() ?? false
    }
    
    /// 判断是否合法的sid
    /// - Parameter sid: 给定的sid
    /// - Returns: true表示合法的sid
    func isValidShowId(_ sid: String) -> Bool {
        var validLength = false
        if sid.count == 20 {
            validLength = true
        }
        if !validLength {
            return false
        }
        
        let pattern = "^[a-f0-9]{20}$"
        if let regx = try? NSRegularExpression(pattern: pattern, options: [.caseInsensitive, .anchorsMatchLines]) {
           let result = regx.matches(in: sid.lowercased(), options: [.reportCompletion], range: NSMakeRange(0, sid.count))
            var validShowId = false
            if let firstMatch = result.first {
                let matchLen = firstMatch.range.length
                validShowId = (matchLen == 20)
                return validShowId
            }
        }
        
        return false
    }
    
    // MARK: ChannelSliderPlayerDelegate
    /// 开始播放
    func didStartPlayVideo(in player: ChannelSliderPlayer) {
        // 兜底播放sid会暂停现象
        let previewVid = getPreviewId() ?? ""
        let playingSid = player.playingSid ?? ""
        let playingVid = player.playingVid ?? ""
        if (!playingSid.isEmpty || !playingVid.isEmpty) && !previewVid.isEmpty {
            let isSid = isValidShowId(previewVid)
            if (isSid && playingSid == previewVid) || (!isSid && playingVid == previewVid) {
                // do nothing
            } else {
                stopPlayer()
                play(false)
                return
            }
        }
        
        player.gravity = OPVideoGravity.resizeAspect.rawValue
        
        if _visable, isPageInActive() {
            player.embedPlayerView().isHidden = false
            self.muteButton.isHidden = false
            if let embedPlayerView = player.embedPlayerView(), embedPlayerView.superview != self {
                contentView.insertSubview(embedPlayerView, aboveSubview: videoImageView)
            }
        } else {
            stopPlayer()
        }
    }

    /// 播放错误
    func player(_ player: ChannelSliderPlayer, playError errorCode: Int32) {
        self.player?.embedPlayerView()?.removeFromSuperview()
    }
    
    /// 播放完成
    func didFinishPositiveVideo(in player: ChannelSliderPlayer) {
        self.menuView.focusNextItem(animated: true)
    }

    @objc func didClickMuteButton() {
        Component14034V2ContentView.isMute = !Component14034V2ContentView.isMute
        self.player?.isSlientMode = Component14034V2ContentView.isMute
        self.muteButton.isSelected = !self.muteButton.isSelected
        bindMuteButtonReport()
    }
    
    func syncSilentMode() {
        self.player?.isSlientMode = Component14034V2ContentView.isMute
        self.muteButton.isSelected = !Component14034V2ContentView.isMute
    }

    func bindMuteButtonReport() {
        guard let itemModel = getItemModel() else {
            return
        }
        if Component14034V2ContentView.isMute {
            Service.statistics.bind(itemModel.preview?["report_volumeon"] as? ReportModel, muteButton, .OnlyClick)
        } else {
            Service.statistics.bind(itemModel.preview?["report_volumeoff"] as? ReportModel, muteButton, .OnlyClick)
        }
    }
    
    func didActivate() {
        if _visable {
            startPlayer()
        }
    }
    
    func didDeactivate() {
        stopPlayer()
    }
    
    func enterDisplay() {
        _visable = true
    }
    
    func exitDisplay() {
        _visable = false
    }
    
    //MARK: 事件回调
    func containerDidScrolled() {
        if UtilityHelper.isPlayerInValidArea(playerView: videoImageView) {
            startPlayer()
        } else {
            stopPlayer()
        }
    }
}
