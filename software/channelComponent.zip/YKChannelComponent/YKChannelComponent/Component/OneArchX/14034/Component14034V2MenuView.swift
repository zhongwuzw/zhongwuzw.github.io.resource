//
//  Component14034V2MenuView.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/1.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

protocol Component14034V2MenuViewDelegate: NSObjectProtocol {
    
    func menuView(_ menuView: Component14034V2MenuView, shouldSelect itemModel: HomeItemModel) -> Bool
    
    func menuView(_ menuView: Component14034V2MenuView, willSelect itemModel: HomeItemModel)
    
    func menuView(_ menuView: Component14034V2MenuView, didSelect itemModel: HomeItemModel)
    
}

class Component14034V2MenuView: UIView, UICollectionViewDelegate, UICollectionViewDataSource {

    var component: IComponent?
    var collectionView : UICollectionView?
    
    weak var delegate: Component14034V2MenuViewDelegate?
    
    /// 原始数据源
    var originalDataSource = [HomeItemModel]()
    
    /// 原始数据源放大倍数，注意：必须是2的倍数
    let groupCount: Int = 100
    
    /// 高亮坑位偏移量： 1 表示原坑我的右手边第一个
    var highlightedOffset: Int = 1
    
    /// 下标：CellIndexPath.item， value: 原始数据源对应下标
    var originalIndexMap = [Int]()
    
    var isDragging: Bool = false
    
    var prevSelectIndexPath: IndexPath?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        setupCollectionView()
    }
    
    func setupCollectionView() {
        let gap: CGFloat = 6
        let itemWidth: CGFloat = 70
        let itemHeight: CGFloat = 92
        
        let layout = Component14034V2MenuViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.minimumLineSpacing = gap
        layout.minimumInteritemSpacing = gap
        layout.sectionInset = UIEdgeInsets.zero
        layout.itemSize = CGSize(width: itemWidth, height: itemHeight)
        layout.highlightedOffset = self.highlightedOffset
        
        // 往左偏移一个坑位的距离，总宽度为原来1.8倍，使得左右两侧cell正常显示。
        let x: CGFloat = -itemWidth + 3.0
        let y: CGFloat = 0.0
        let width: CGFloat = self.width - 2 * x
        let height: CGFloat = self.height
        
        let collectionView = UICollectionView(frame: CGRect(x: x, y: y, width: width * 1.8, height: height), collectionViewLayout: layout)
        collectionView.layer.masksToBounds = false
        collectionView.backgroundColor = UIColor.clear
        collectionView.collectionViewLayout = layout
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.register(Component14034V2MenuViewCell.self,
                                forCellWithReuseIdentifier: NSStringFromClass(Component14034V2MenuViewCell.self))
        addSubview(collectionView)
        
        self.collectionView = collectionView
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(_ component: IComponent?) {
        guard let component = component else {
            return
        }
        
        guard let items = component.getItems(), !items.isEmpty else {
            return
        }
        
        if shouldResetDataSource(component) {
            self.component = component
            
            let itemModels = items.compactMap({ $0.homeItemModel })
            
            // 设置数据源
            originalDataSource = itemModels
            for _ in 0 ..< groupCount {
                for j in 0 ..< originalDataSource.count {
                    originalIndexMap.append(j)
                }
            }
            
            collectionView?.reloadData()
            
            // 定位到中间的一组数据源
            DispatchQueue.main.async {
                let itemIndex = Int(0.5 * Double(self.groupCount)) * self.originalDataSource.count - self.highlightedOffset
                let midIndexPath = IndexPath(item: itemIndex, section: 0)
                self.focusOn(indexPath: midIndexPath, animated: false)
            }
        } else if !originalDataSource.isEmpty {
            var selectedIndex = 0
            for (i, item) in originalDataSource.enumerated() {
                if let value = item.extraExtend["isHighlighted"] as? Bool, value == true {
                    selectedIndex = i - highlightedOffset
                    break
                }
            }
            
            let itemIndex = Int(0.5 * Double(self.groupCount)) * self.originalDataSource.count + selectedIndex
            let selectedIndexPath = IndexPath(item: itemIndex, section: 0)
            self.focusOn(indexPath: selectedIndexPath, animated: false)
        }
    }
    
    func shouldResetDataSource(_ component: IComponent?) -> Bool {
        if self.component == nil {
            return true
        }
        
        if self.component?.compModel == nil {
            return true
        }
        
        if let prevComponentModel = self.component?.compModel,
           let currentComponentModel = component?.compModel,
           prevComponentModel != currentComponentModel {
            return true
        }
            
        return false
    }
    
    func scrollViewWillBeginDragging(_ scrollView: UIScrollView) {
        isDragging = true
    }
    
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if isDragging {
            isDragging = false
            
            guard let collectionView = collectionView else {
                return
            }
            
            guard let collectionViewLayout = collectionView.collectionViewLayout as? Component14034V2MenuViewFlowLayout else {
                return
            }
            
            let point = collectionView.contentOffset
            var indexPath = IndexPath(item: 0, section: 0)
            indexPath.row = Int(round(point.x) / collectionViewLayout.stepSpace())
            
            //修正高亮偏移量
            var highlightedIndexPath = indexPath
            highlightedIndexPath.row = indexPath.row + highlightedOffset
            
            guard highlightedIndexPath.row < originalIndexMap.count else {
                return  // 防越界
            }
            let highlightedIndex = originalIndexMap[highlightedIndexPath.row]
            
            guard highlightedIndex < originalDataSource.count else {
                return  // 防越界
            }
            let highlightedItemModel = originalDataSource[highlightedIndex]
            
            self.delegate?.menuView(self, willSelect: highlightedItemModel)
            for (i, item) in originalDataSource.enumerated() {
                if i == highlightedIndex {
                    item.extraExtend["isHighlighted"] = true
                } else {
                    item.extraExtend["isHighlighted"] = false
                }
            }
            self.prevSelectIndexPath = highlightedIndexPath
            self.delegate?.menuView(self, didSelect: highlightedItemModel)
        }
    }
    
    // MARK: - UICollectionViewDataSource & UICollectionViewDelegate
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return originalIndexMap.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: NSStringFromClass(Component14034V2MenuViewCell.self),
                                                      for: indexPath)
        
        guard let cell = cell as? Component14034V2MenuViewCell else {
            return cell
        }
        
        guard indexPath.row < originalIndexMap.count else {
            return cell // 防越界
        }
        let index = originalIndexMap[indexPath.row]
        
        guard index < originalDataSource.count else {
            return cell // 防越界
        }
        let itemModel = originalDataSource[index]
        
        if let imageURLString = itemModel.img {
            cell.posterImageView.ykn_setImage(withURLString: XCDNSTRING(imageURLString),
                                              module: "home",
                                              imageSize: CGSize.zero,
                                              parameters: nil,
                                              completed: nil)
        } else {
            cell.posterImageView.image = nil
        }
        
        // 横滑封面图只需要绑定点击
        Service.statistics.bind(itemModel.action?.report, cell, .OnlyClick)
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        guard indexPath.row < originalIndexMap.count else {
            return // 防越界
        }
        
        // 修正高亮位置
        var targetIndexPath = indexPath
        targetIndexPath.row = indexPath.row - highlightedOffset
        
        // 区分点击路径
        var isDiffIndexPathRepeatSelect = false
        if let prevSelectIndexPath = prevSelectIndexPath {
            if prevSelectIndexPath != indexPath {
                isDiffIndexPathRepeatSelect = isSameData(indexPath, prevSelectIndexPath)
            }
        }
        
        let source = isDiffIndexPathRepeatSelect ? "diffIndexPathRepeatSelect" : "didSelect"
        focusOn(indexPath: targetIndexPath, animated: true, source: source)
    }
    
    func focusNextItem(animated: Bool) {
        guard let collectionView = collectionView else {
            return
        }
        
        guard let collectionViewLayout = collectionView.collectionViewLayout as? Component14034V2MenuViewFlowLayout else {
            return
        }
        
        var targetIndexPath = IndexPath()
        
        //推算当前IndexPath
        let point = collectionView.contentOffset
        var currentIndexPath = IndexPath(item: 0, section: 0)
        currentIndexPath.row = Int(round(point.x) / collectionViewLayout.stepSpace())
        
        //求下一IndexPath
        let nextItem = currentIndexPath.item + 1
        if nextItem < originalIndexMap.count { //防越界
            targetIndexPath = IndexPath(item: nextItem, section: 0)
        }
        
        //越界兜底，回到起始的最中心一项
        if targetIndexPath.isEmpty {
            let itemIndex = Int(0.5 * Double(self.groupCount)) * self.originalDataSource.count
            let midIndexPath = IndexPath(item: itemIndex, section: 0)
            targetIndexPath = midIndexPath
        }
        
        self.focusOn(indexPath: targetIndexPath, animated: true)
    }
    
    func focusOn(indexPath: IndexPath, animated: Bool, source: String = "auto") {
        guard let collectionView = collectionView else {
            return
        }
        
        guard let layout = collectionView.collectionViewLayout as? Component14034V2MenuViewFlowLayout else {
            return
        }
        
        var highlightedIndexPath = indexPath
        highlightedIndexPath.row = indexPath.row + highlightedOffset
        
        guard highlightedIndexPath.row < originalIndexMap.count else {
            return  // 防越界
        }
        let highlightedIndex = originalIndexMap[highlightedIndexPath.row]
        
        guard highlightedIndex < originalDataSource.count else {
            return // 防越界
        }
        let highlightedItemModel = originalDataSource[highlightedIndex]
        
        if source == "didSelect" {
            let shouldFocus = self.delegate?.menuView(self, shouldSelect: highlightedItemModel) ?? false
            if shouldFocus == false  {
                return // 中断
            }
        }
        
        self.delegate?.menuView(self, willSelect: highlightedItemModel)
        
        var targetRect = CGRect.init()
        targetRect.size = collectionView.bounds.size
        targetRect.origin.x = CGFloat(indexPath.item) * (layout.itemSize.width + layout.minimumLineSpacing)
        collectionView.scrollRectToVisible(targetRect, animated: animated)
        layout.lastStepPoint = targetRect.origin
        
        for (i, item) in originalDataSource.enumerated() {
            if i == highlightedIndex {
                item.extraExtend["isHighlighted"] = true
            } else {
                item.extraExtend["isHighlighted"] = false
            }
        }
        
        self.prevSelectIndexPath = highlightedIndexPath
        self.delegate?.menuView(self, didSelect: highlightedItemModel)
    }
    
    func isSameData(_ lhs: IndexPath, _ rhs: IndexPath) -> Bool {
        guard let lhsItemModel = modelAt(indexPath: lhs), let rhsItemModel = modelAt(indexPath: rhs) else {
            return false
        }
        
        return lhsItemModel == rhsItemModel
    }
    
    func modelAt(indexPath : IndexPath) -> BaseItemModel? {
        guard indexPath.row < originalIndexMap.count else {
            return nil // 防越界
        }
        let index = originalIndexMap[indexPath.row]
        
        guard index < originalDataSource.count else {
            return nil // 防越界
        }
        
        let itemModel = originalDataSource[index]
        return itemModel
    }
}
