//
//  Item14034V2.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/1.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku

class Item14034V2: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {
        
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        //暂不参与列表渲染
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        //暂不参与列表渲染
        return UIView.init()
    }
    
    func reuseView(itemView: UIView) {
        //暂不参与列表渲染
        
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return HomeItemModel.self as? T.Type
    }
}

