//
//  Component14034V2ReserveButton.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/1.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import OneArchSupport
import OneArchSupport4Youku

///描边按钮样式,只有样式 不处理逻辑
class Component14034V2ReserveButton: ReserveButton {
    
    override init() {
        super.init()
        
        self.backgroundColor = .clear
        self.clipsToBounds = true
        self.setTitleFont(YKNFont.posteritem_subhead())
        self.isUserInteractionEnabled = true
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func refresh(reserveModel: ReserveModel?, scene: SceneModel?) {
        self.reserveModel = reserveModel
        self.scene = scene
        
        // 预约有礼icon
        if let icon = reserveModel?.icon, let url = URL.init(string: icon) {
            self.imageView.sd_setImage(with: url, completed: {[weak self] img, error, type, url in
                self?.imageView.image = self?.imageView.image?.withRenderingMode(.alwaysTemplate)
                self?.imageView.tintColor = .white
            })
        }
        
        refreshButtonStatus()
        weak var weakself = self
        self.whenTapped {
            UtilityHelper.doReservation(reserveModel: weakself?.reserveModel)
        }
    }
    
    override func refreshButtonFrame() {
        super.refreshButtonFrame()
    }
    
    override func refreshButtonStatus() {
        guard let reserveModel = reserveModel else {
            return
        }
        
        //icon默认隐藏
        self.imageView.isHidden = true
        let reserved = reserveModel.isReserve
        
        if !reserved {
            let titleColor = UIColor.white
            
            if let title = reserveModel.text {
                self.setTitle(title)
                if let icon = reserveModel.icon, let _ = URL.init(string: icon) {
                    self.imageView.isHidden = false
                    self.imageView.tintColor = titleColor
                }
            } else {
                self.setTitle("预约")
            }

            self.backgroundColor = UIColor.white.withAlphaComponent(0.2)
            self.setTitleColor(UIColor.white)
        } else {
            self.setTitle("已预约")
            self.backgroundColor = UIColor.white.withAlphaComponent(0.08)
            self.setTitleColor(UIColor.white.withAlphaComponent(0.6))
        }
        
        bindStatisticsService()
        refreshButtonFrame()
    }
    
    public override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        //暗黑切换无UI变化
    }
    
}

