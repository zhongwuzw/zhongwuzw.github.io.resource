//
//  Component14034V2.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/1.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Component14034V2 : ComponentEventHandler, ComponentDelegate {
    
    var componentWrapper: ComponentWrapper?
    
    weak var itemView: Component14034V2ContentView?
    
    var compPaddingTop: CGFloat = 0
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_line_spacing() /* 不能用token YKNGap.youku_comp_margin_bottom() */, right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.youku_module_margin_bottom()
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0
        config.responsiveAdjustableMinColumnCount = 1
        config.responsiveMinColumnCount = 2
        config.responsiveMaxColumnCount = 3
        return config
        
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return [
            self
        ]
    }
    
    func componentDidInit() {
        guard let component = component,
              let items = component.getItems(),
              let firstItem = items.first
        else {
            return
        }
        
        firstItem.itemModel?.extraExtend["isHighlighted"] = true
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let height: CGFloat = Component14034V2ContentView.getHeight(itemWidth)
        return height
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let view = Component14034V2ContentView.init(frame: .init(origin: .zero, size: itemSize))
        return view
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Component14034V2ContentView else {
            return
        }
        
        guard let component = component,
              let componentModel = component.compModel else {
            return
        }

        self.itemView = itemView
        return itemView.fillData(componentModel, component: component)
    }
    
    func isValidEvent() -> Bool {
        guard let viewComp = self.itemView?.component else {
            return false
        }
        
        guard let component = self.component else {
            return false
        }
        
        let ptr1 = Unmanaged<AnyObject>.passUnretained(viewComp).toOpaque()
        let ptr2 = Unmanaged<AnyObject>.passUnretained(component).toOpaque()
        if ptr1 == ptr2 {
            return true
        }
        
        return false
    }
}

extension Component14034V2: IPageLifeCycleEventHandler {
    
    /// 页面视图初始化
    func viewDidLoad() {
        
    }

    /// 页面将激活
    func willActivate() {
        
    }

    /// 页面已激活
    func didActivate() {
        guard isValidEvent() else {
            return
        }
        
        self.itemView?.didActivate()
    }

    /// 页面将失活
    func willDeactivate() {

    }

    /// 页面已失活
    func didDeactivate() {
        guard isValidEvent() else {
            return
        }
        
        self.itemView?.didDeactivate()
    }

    /// 页面销毁
    func pageDealloc() {
        
    }
    
    /// 应用进入激活状态
    func appDidBecomeActive() {
        guard isValidEvent() else {
            return
        }
    
        self.itemView?.didActivate()
    }
    
    /// 应用即将进入失活状态
    func appWillResignActive() {
        guard isValidEvent() else {
            return
        }
        
        self.itemView?.didDeactivate()
    }
    
}

extension Component14034V2: IComponentLifeCycleEventHandler {
    
    func enterDisplayArea(itemView: UIView?) {
        guard isValidEvent() else {
            return
        }
        
        self.itemView?.enterDisplay()
    }
    
    func exitDisplayArea(itemView: UIView?) {
        guard isValidEvent() else {
            return
        }
        
        self.itemView?.exitDisplay()
    }
    
    func visibleViewDidScroll(itemView: UIView?) {
        guard isValidEvent() else {
            return
        }
        
        self.itemView?.containerDidScrolled()
    }
    
    func visibleViewDidEndScroll(itemView: UIView?) {
        
    }
    
    func visibleViewsDidEndScroll() {
        
    }
    
}
