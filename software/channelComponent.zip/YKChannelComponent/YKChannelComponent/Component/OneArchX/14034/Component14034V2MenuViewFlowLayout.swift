//
//  Component14034V2MenuViewFlowLayout.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/1.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit

class Component14034V2MenuViewFlowLayout: UICollectionViewFlowLayout {
    
    /// 高亮坑位偏移量
    var highlightedOffset: Int = 0
    
    var lastStepPoint: CGPoint = .zero
    
    override func prepare() {
        super.prepare()
        self.collectionView?.decelerationRate = .normal
    }
    
    override func targetContentOffset(forProposedContentOffset proposedContentOffset: CGPoint, withScrollingVelocity velocity: CGPoint) -> CGPoint {
        guard let collectionView = collectionView else {
            return super.targetContentOffset(forProposedContentOffset: proposedContentOffset, withScrollingVelocity: velocity)
        }
        
        // 分页的 width
        let pageSpace = self.stepSpace()
        let offsetMax: CGFloat = collectionView.contentSize.width - (pageSpace + self.sectionInset.right + self.minimumLineSpacing)
        let offsetMin: CGFloat = 0

        // 修改之前记录的位置，如果小于最小的contentsize或者最大的contentsize则重置值
        if lastStepPoint.x < offsetMin {
            lastStepPoint.x = offsetMin
        } else if lastStepPoint.x > offsetMax {
            lastStepPoint.x = offsetMax
        }

        // 目标位移点距离当前点距离的绝对值
        let offsetForCurrentPointX: CGFloat = abs(proposedContentOffset.x - lastStepPoint.x)
        let velocityX = velocity.x

        // 判断当前滑动方向，向左 true, 向右 false
        let direction: Bool = (proposedContentOffset.x - lastStepPoint.x) > 0

        // 左向阈值判定
        var overLeftDirectionThreshold: Bool = false
        if direction {
            if offsetForCurrentPointX > 0.0 {
                overLeftDirectionThreshold = true
            }
        }
        
        // 右向阈值判定
        var overRightDirectionThreshold: Bool = false
        if !direction {
            if offsetForCurrentPointX > 0.0 {
                overRightDirectionThreshold = true
            }
        }
        
        var newProposedContentOffset: CGPoint = CGPoint.zero
        if (overLeftDirectionThreshold || overRightDirectionThreshold) && (lastStepPoint.x >= offsetMin) && (lastStepPoint.x <= offsetMax) {
            // 分页因子，用于计算滑过的cell数量
            var pageFactor: Int = 0
            if velocityX != 0 {
                // 滑动
                // 速率越快，cell 滑过的数量越多
                pageFactor = abs(Int(round(velocityX)))
            } else {
                // 拖动
                // 备注：通过阈值判断后，至少拖动一页， 超过一页后适用四舍五入
                pageFactor = abs(Int(round(max(offsetForCurrentPointX, pageSpace) / pageSpace)))
            }

            /*
             //设置 pageFactor 的上限为2，（大于3页滑2页，其余滑1页）
             pageFactor = pageFactor < 1 ? 1 : (pageFactor < 3 ? 1 : 2)
             
             //设置 pageFactor 的上限为1。（总是滑一页）
             pageFactor = 1
            */

            let pageOffsetX: CGFloat = pageSpace * CGFloat(pageFactor)
            newProposedContentOffset = CGPoint(x: lastStepPoint.x + (direction ? pageOffsetX : -pageOffsetX), y: proposedContentOffset.y)
        } else {
            // 滚动距离小于阈值，则不进行翻页
            newProposedContentOffset = CGPoint(x: lastStepPoint.x, y: lastStepPoint.y)
        }

        lastStepPoint.x = newProposedContentOffset.x
        return newProposedContentOffset
    }
    
    // 每滑动一页的间距
    public func stepSpace() -> CGFloat {
        return self.itemSize.width + self.minimumLineSpacing
    }
    
    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        guard let collectionView = collectionView else {
            return super.layoutAttributesForElements(in: rect)
        }
        
        guard let array = super.layoutAttributesForElements(in: rect) else {
            return super.layoutAttributesForElements(in: rect)
        }
    
        var visibleRect = CGRect()
        visibleRect.origin = collectionView.contentOffset
        visibleRect.size = collectionView.bounds.size
        
        // 收拢基准线
        let baseline = visibleRect.minX + CGFloat(highlightedOffset) * stepSpace()
        
        for attributes in array {
            let distance = baseline - attributes.frame.minX
            let direction = distance > 0 // true 左边, false 右边
            
            let progressLength: CGFloat = stepSpace()
            
            let scale: CGFloat = 42.0 / 70.0 // 0.6
            
            // progress 取值范围 [0, 1]
            let progress: CGFloat = (progressLength - max(0, min(progressLength, abs(distance)))) / progressLength
            let cnt = distance / stepSpace()
            
            // zoom 取值范围 [0.6, 1]
            let zoomRangeLength = 1 - scale
            let zoom = (1 - zoomRangeLength) + (progress * zoomRangeLength)
            
            /*
             使用原位置推算新位置
             图示：
                     较远距离
                     |   临界距离
                     ↓   ↓ ↓
                 ... o o O o o ...
                         |
                         ↑
                     收拢基准线
             */
            if distance > progressLength {
                //基准线左侧 较远距离
                let oldFrame = attributes.frame
                let width: CGFloat = oldFrame.width * zoom
                let height: CGFloat = oldFrame.height * zoom
                let x: CGFloat = oldFrame.maxX - width + (abs((cnt)) - 1) * (oldFrame.width * (1 - zoom))
                let y: CGFloat = oldFrame.maxY - height
                attributes.frame = CGRect.init(x: x, y: y, width: width, height: height)
            } else if distance < (-progressLength) {
                //基准线右侧 较远距离
                let oldFrame = attributes.frame
                let width: CGFloat = oldFrame.width * zoom
                let height: CGFloat = oldFrame.height * zoom
                let x: CGFloat = oldFrame.minX - (abs((cnt)) - 1) * (oldFrame.width * (1 - zoom))
                let y: CGFloat = oldFrame.maxY - height
                attributes.frame = CGRect.init(x: x, y: y, width: width, height: height)
            } else if direction == false {
                //基准线右侧 临界距离
                let oldFrame = attributes.frame
                let width: CGFloat = oldFrame.width * zoom
                let height: CGFloat = oldFrame.height * zoom
                let x: CGFloat = oldFrame.minX
                let y: CGFloat = oldFrame.maxY - height
                attributes.frame = CGRect.init(x: x, y: y, width: width, height: height)
            } else if direction == true {
                //基准线左侧 临界距离
                let oldFrame = attributes.frame
                let width: CGFloat = oldFrame.width * zoom
                let height: CGFloat = oldFrame.height * zoom
                let x: CGFloat = oldFrame.maxX - width
                let y: CGFloat = oldFrame.maxY - height
                attributes.frame = CGRect.init(x: x, y: y, width: width, height: height)
            }
        }
        
        return array
    }
    
    override func shouldInvalidateLayout(forBoundsChange newBounds: CGRect) -> Bool {
        //滑动放大缩小  需要实时刷新layout
        return true
    }
}
