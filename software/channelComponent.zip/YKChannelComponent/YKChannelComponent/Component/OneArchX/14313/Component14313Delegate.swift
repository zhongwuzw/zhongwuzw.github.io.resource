//
//  Component14313Delegate.swift
//  YKChannelComponent
//
//  Created by better on 2023/6/9.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKHome
import YKSCService
import YKResponsiveLayout
import OneArchSupport
import OneArchSupport4Youku
import YKChannelPage
import YKModeConfigFramework
import YoukuAnalytics
import YKChannel
import NovelAdSDK

let kLocaleHomeConfigEnableClientAdInsertkey = "YKChannelComponent.home.config.enableClientAdInsert"

@objcMembers
class Component14313Delegate: Component14204Delegate, BatchNovelAdsHandlerDelegate {
    
    var itemVews = [String: UIView]()
    var itemContentMargins = [Int: Float]()
    
    var bathAdsHandler: BatchNovelAdsHandler?
    var topADScrollInterval:Int = 0
    var topADStartTimeInterval:CGFloat = 0
    var topADTimer:Timer?
    var topADGuideTextSize:CGSize?
    
    lazy var itemJsonExtracter: Comp14313ItemJsonExtracter = {
        let extracter = Comp14313ItemJsonExtracter()
        var serverFlag = false
        if let dataState = self.component?.getPage()?.pageModel?.dataState, dataState == .network {
            serverFlag = self.component?.getPage()?.pageModel?.config.getBoolValue("enableClientAdInsert") ?? false
            UserDefaults.standard.set(serverFlag, forKey: kLocaleHomeConfigEnableClientAdInsertkey)
        }
        extracter.enableClientAdInsert = serverFlag
        return extracter
    } ()
    
    required init() {
        super.init()
        NotificationCenter.default.addObserver(self, selector: #selector(receiveTopADCardShowEvent(_:)), name: NSNotification.Name.init(rawValue: "yk.topAnimationMode.ADCard.hasShow"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(receiveTopADCardHideEvent(_:)), name: NSNotification.Name.init(rawValue: "yk.topAnimationMode.ADCard.hasHide"), object: nil)
                
        print("[XAdSDKCarousel] remove data")
        
    }
    
    override func componentDidInit() {
        super.componentDidInit()
        let topADComp = getTopAnimatioADComponent(self.component?.getPage())
        if let topADModel = topADComp?.compModel as? Comp14325Model {
            self.topADScrollInterval = topADModel.scrollInterval
        }
//        #if DEBUG
//        ///test
//        self.topADScrollInterval = 25
//        #endif
    }
    
    override func layoutConfig() -> ComponentLayoutConfig {
        var config = super.layoutConfig()
        if isHomeTopAnimationADMode(self.component?.getPage()) {
            config.preferredCardSpacingTop = 18.0
        }
        if isHomeLunboAppleCNYADMode(self.component?.getPage()) {
            config.preferredCardSpacingTop = 0.0
        }
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        return config
    }
    
    override func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Comp14313Model.self as? T.Type
    }
    
    override func itemHeight(itemWidth: CGFloat) -> CGFloat {
        var itemHeight = super.itemHeight(itemWidth: itemWidth)
        //
        SelectionTopAnimationADManager.shareInstance().resetLunboIndex()
        
        SelectionLunboAppleCNYADManager.shareInstance().resetLunboIndex()
        
        self.estimatedLayoutTopADGuide()
        
        return itemHeight
    }
    
    override func isEnableCustomMode() -> Bool {
        return true
    }
    
    override public func itemSpacing() -> CGFloat {
        return YKNGap.youku_column_spacing()
    }
    
    override public func itemSideMargin() -> CGFloat {
        return YKNGap.youku_margin_left()
    }
    
    override public func containerSideExtend() -> CGFloat {
        return 20
    }
    
    override func clipContainer(_ ratio: CGFloat) {
        //do nothing
    }
    
    override func createView(_ itemSize: CGSize) -> UIView {
        let itemView = super.createView(itemSize)
        if let sliderView = itemView as? SliderView {
            sliderView.itemContentBorderMargin = 0.0    //item内边距去掉
        }
        return itemView
    }
    
    public override func getItemJsonExtracter() -> ItemJsonExtracter? {
        return self.itemJsonExtracter
    }
    
    override func itemContentMargin(index: Int, originItemSize: CGSize) -> CGFloat {
        var margin = 0.0
        var defaultRatio = 0.0
        var contentRatio = 0.0
        var materialSizeDic: [String: Any]?
        var contentType = "show"
        if isAdvertItem(index: index) { //case2: 坑7广告
            materialSizeDic = self.adService.adContext?.getAdMaterialSize() as? [String: Any]
            defaultRatio = 16.0 / 8.0
            contentType = "loop ad"
        } else if index >= 0, index < self.allDatas.count, let item = self.allDatas[index] as? IItem, //case3: 服务端下发1-2广告 type=14314
                  let model = item.itemModel as? Item14314Model, model.type == "14314", let adDict = model.adDict {
            let w = adDict["W"] as? CGFloat ?? 0.0
            let h = adDict["H"] as? CGFloat ?? 0.0
            if w > 0.0, h > 0.0 {
                var dic = [String:Any]()
                dic["width"] = w
                dic["height"] = h
                materialSizeDic = dic
            }
            defaultRatio = 16.0 / 9.0
            contentType = "14314 1-2 ad"
        }
        
        if let width = materialSizeDic?["width"] as? CGFloat, width > 0, let height = materialSizeDic?["height"] as? CGFloat, height > 0 {
            let ratio: CGFloat = width / height
            if ratio > 0.0 {
                contentRatio = ratio
            }
        }
        
        if contentRatio > 0 {
            contentRatio = convertSupportRatio(contentRatio)
            let adWidth = ceil(originItemSize.height * contentRatio)
            if adWidth < originItemSize.width {
                margin = ceil((originItemSize.width - adWidth) / 2)
            }
        } else if defaultRatio > 0.0 {
            let adWidth = ceil(originItemSize.height * defaultRatio)
            if adWidth < originItemSize.width {
                margin = ceil((originItemSize.width - adWidth) / 2)
            }
        }
        
        let string = "[14313] index:\(index) magin:\(margin) ratio: \(String(format: "%.2f", contentRatio)) defaultRatio:\(String(format: "%.2f", defaultRatio)) dic: \(materialSizeDic ?? [:]) type: \(contentType)"
        YKSCScreenLogUtil.printLog(string, color: .green)
        print(string)
        
        itemContentMargins[index] = Float(margin)
        return margin
    }
    
    func convertSupportRatio(_ ratio: CGFloat) -> CGFloat {
        let ratio16_8 = 16.0 / 8.0
        let ratio16_9 = 16.0 / 9.0
        if fabs(ratio - ratio16_8) < fabs(ratio - ratio16_9) {
            return ratio16_8
        } else {
            return ratio16_9
        }
    }
    
    override func reuseItemView(index: Int, itemView: UIView) {
        _reuseItemView(index: index, itemView: itemView)
        
        if is14313Lunbo() {
            for k in itemVews.keys {
                if let view = itemVews[k] {
                    if isSameobject(object1: itemView, object2: view) {
                        itemVews[k] = nil
                    }
                }
            }
            
            var section = 0
            if let view = itemView.superview as? SliderCollectionViewCell {
                section = view.indexPath.section
            }
            itemVews["\(section)-\(index)"] = itemView
        }
        
        if isLunboAppleCNYADMode {
            NotificationCenter.default.post(name: NSNotification.Name.init("kHomePageLunboReuseItemView.AppleCNYMode"), object: nil, userInfo: ["index":index, "itemViewSize":itemView.size])
        }
    }
    
    override func indexChanging(fromIndex: Int, fromSection: Int, toIndex: Int, progress: CGFloat) {
        super.indexChanging(fromIndex: fromIndex, fromSection:fromSection, toIndex: toIndex, progress: progress)
        
        guard is14313Lunbo(), fromIndex < self.allDatas.count, toIndex < self.allDatas.count else {
            return
        }
        
        var index1Section = fromSection
        let index2Section = fromSection
        var index3Section = fromSection
        var index4Section = fromSection
        
        print("[14313] indexching \(fromIndex) \(toIndex) \(progress)")
        var index1 = fromIndex - 1
        if index1 < 0 {
            index1 = self.allDatas.count - 1
            index1Section = fromSection - 1
        }
        let index2 = fromIndex
        var index3 = toIndex
        if fromIndex > toIndex {
            index3Section = fromSection + 1
        }
        if index3 == index2 {
            index3 += 1
            if index3 >= self.allDatas.count {
                index3 = 0
                index3Section = fromSection + 1
            }
        }
        var index4 = index3 + 1
        index4Section = index3Section
        if index4 >= self.allDatas.count {
            index4 = 0
            index4Section = index3Section + 1
        }
        print("[14313] indexes \(index1) \(index2) \(index3) \(index4) fs \(fromSection)")
        
        let v1 = itemVews["\(index1Section)-\(index1)"]
        let v2 = itemVews["\(index2Section)-\(index2)"]
        let v3 = itemVews["\(index3Section)-\(index3)"]
        let v4 = itemVews["\(index4Section)-\(index4)"]
        
        print("[14313] views \(v1) \(v2) \(v3) \(v4)")
        print("[14313] keys \(index1Section)-\(index1) \(index2Section)-\(index2) \(index3Section)-\(index3) \(index4Section)-\(index4)")
        
        let D1 = itemContentMargins[index1] ?? 0.0
        let D2 = itemContentMargins[index2] ?? 0.0
        let D3 = itemContentMargins[index3] ?? 0.0
        //let D4 = itemContentMargins[index4] ?? 0.0
        //print("[14313] ds \(D1) \(D2) \(D3) \(D4)")
        
        v1?.left = calcInterpolationValue(p1:1.0 , p1Value: CGFloat(2*D1 + D2), p2:0.0 , p2Value: CGFloat(2*D1 + 2*D2+D3), x: progress)
        v2?.left = calcInterpolationValue(p1:1.0 , p1Value: CGFloat(D2), p2:0.0, p2Value: CGFloat(2*D2+D3), x: progress)
        v3?.left = calcInterpolationValue(p1:1.0 , p1Value: CGFloat(-D2), p2:0.0, p2Value: CGFloat(D3), x: progress)
        v4?.left = calcInterpolationValue(p1:1.0 , p1Value: CGFloat(-2*D3 - D2), p2:0.0 , p2Value: CGFloat(-D3), x: progress)
    }
    
    func is14313Lunbo() -> Bool {
        return true
    }
    
    override func loadEventHandlers() -> [ComponentEventHandler]? {
        var array = super.loadEventHandlers()
        let batchAdsHandler = BatchNovelAdsHandler.init()
        batchAdsHandler.delegate = self
        self.bathAdsHandler = batchAdsHandler
        array?.append(batchAdsHandler)
        
        if is14313Lunbo() { //新轮播不需要老cpm曝光逻辑
            let stasticHanlder = ContentAdStasticsHandler()
            array?.append(stasticHanlder)
            self.cententAdStatisHandler = stasticHanlder
        }
        
        return array
    }
    
    override func setupPluginConfigs() {
        var allDatas = [Any]()
        
        if let items = self.component?.getItems() {
            for context in items {
                allDatas.append(context)
            }
        }
        
        // 焦7配置
        if is14313Lunbo(), let adConfig = self.adConfig  {
            if adConfig.enabled, adConfig.adRequestSuccessed {
                
                var adIndex = adConfig.index
                let jsonExtracter = self.itemJsonExtracter
                let changedIndex = jsonExtracter.advertConfigChangedIndex
                if jsonExtracter.enableClientAdInsert, changedIndex > jsonExtracter.advertConfigIndex, changedIndex > 0, changedIndex <= allDatas.count {
                    adIndex = changedIndex
                    print("[首焦广告替换] 组装数据 焦7位置变化 原:\(jsonExtracter.advertConfigIndex) 新:\(changedIndex)")
                }
                
                if adConfig.mode == .Replace { // 替换
                    if adIndex >= 1, adIndex <= allDatas.count {
                        allDatas[adIndex-1] = "advert"
                    }
                } else if adConfig.mode == .Insert { // 插到index位置后面
                    if adIndex >= 0, adIndex <= allDatas.count {
                        allDatas.insert("advert", at: adIndex)
                    }
                }
            }
        }
        
        self.allDatas = allDatas
    }
    
    var itemViewSize = CGSize.zero
    override func reuseView(itemView: UIView) {
        super.reuseView(itemView: itemView)
        
        if is14313Lunbo() {
            self.sliderView?.pageView.alpha = 0
        }
        self.itemViewSize = itemView.size
        self.addTopADGuideView()
    }
    
    public func addTopADGuideView() {
        let container = self.component?.pageContext?.getContainerView()
        let tag = SelectionTopAnimationADManager.guideViewTag
        var topAniView = container?.viewWithTag(tag) as? TopAnimationADGuideView
        if !SelectionTopAnimationADManager.shareInstance().isTopAnimationADMode(self.component?.getPage()) {
            topAniView?.removeFromSuperview()
            topAniView = nil
            return
        }
        let comp14325Model = getTopAnimatioADComponent(self.component?.getPage())?.compModel as? Comp14325Model
        if SelectionTopAnimationADManager.shareInstance().canDisplayGuide(self.component?.getPage()), let lunboY = self.component?.getCard()?.getLayoutInfo().y, comp14325Model?.guideText != nil, !YKAppleADManager.sharedInstance().hasAppleAD {
            
            let height = SelectionTopAnimationADManager.guideViewHeight
            if topAniView == nil {
                topAniView = TopAnimationADGuideView.init(frame: CGRect(x: 0.0, y: 0.0, width: itemViewSize.width, height: height))
                topAniView?.tag = tag
                topAniView?.backgroundColor = .clear
                if let topAniView = topAniView {
                    container?.addSubview(topAniView)
                }
            }
            topAniView?.isHidden = false
            topAniView?.alpha = 1.0
            topAniView?.frame = CGRect(x: 0.0, y: lunboY - height , width: itemViewSize.width, height: height)
            topAniView?.textSize = self.topADGuideTextSize
            topAniView?.fillData(comp14325Model)
            if let bgColor = themeBgColors?.first {
                showTopGuideViewBgColor(true)
            } else {
                showTopGuideViewBgColor(false)
            }
        } else {
            topAniView?.isHidden = true
            topAniView?.alpha = 0.0
        }
   
    }

    override func itemIdentifier(index: Int) -> String {
        var identifier = ""
        if index < self.allDatas.count {
            let data = self.allDatas[index]
            if isAdvertItem(index: index) { //保留焦7广告逻辑
                identifier = "14016.item.ad" + String(index)
            } else if let item = data as? IItem , let type = item.model?.type, type.isEmpty == false {
                identifier = "\(type).item.content.swift.\(String(index))"
            } else if let str = data as? String, str.hasPrefix("batchNovelAd_") { //批量替换ad
                identifier = "batchNovelAd.item.content.swift.\(String(index))"
            }
        }
        
        if identifier == "" {
            identifier = super.itemIdentifier(index: index)
        }
        print("[批量广告] itemIdentifier index:\(index)")
        return identifier
    }
    
    override func createItemView(index: Int, itemSize: CGSize) -> UIView {
        let frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
        var itemView: UIView?
        if index < self.allDatas.count {
            let data = self.allDatas[index]
            if let item = data as? IItem {
                if item.model?.type == "14314" { //广告卡
                    itemView = Item14314AdContentView(frame: frame)
//                    YKSCScreenLogUtil.printLog("[批量广告] life createItemView 14314:\(itemView) index:\(index)", color: .red)
                }  else if item.model?.type == "14313" || item.model?.type == "14336" { //内容卡，等待广告替换
                    itemView = Comp14204ContentView(frame: frame)
                }
            } else if isBatchNovelAdItem(index: index) { // 替换内容卡
                itemView = Item14313AdContentView.init(frame: frame)
//                YKSCScreenLogUtil.printLog("[批量广告] life createItemView 14313:\(itemView) index:\(index)", color: .red)
            }
        }
        if let itemView = itemView {
            itemView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
            itemView.clipsToBounds = true
            return itemView
        } else {
            return super.createItemView(index: index, itemSize: itemSize)
        }
    }

    func _reuseItemView(index: Int, itemView: UIView) {
        if let itemView = itemView as? Item14314AdContentView { //广告内容卡
            if index < self.allDatas.count, let item = self.allDatas[index] as? IItem {
                if let adView = self.bathAdsHandler?.adCreateViewDict?[index] {
                    itemView.fillAdView(adView, index)
                } else { // 没有则创建
                    if let c = self.bathAdsHandler?.createAdView(item, index) {
                        itemView.fillAdView(c, index)
                    }
                }
                itemView.adCotentView?.feedbackProtocol = self.bathAdsHandler
            }
        } else {
            super.reuseItemView(index: index, itemView: itemView)
        }
    }
    
    override func content14204ViewTitleRightMagin(_ itemCount: Int) -> CGFloat {
        return CGFloat(12)
    }
    
    func isBatchNovelAdItem(index: Int) -> Bool {
        if index > 0, index < self.allDatas.count, let itemData = self.allDatas[index] as? String {
            return itemData.hasPrefix("batchNovelAd_")
        }
        return false
    }
    
    func isLunboAdItem(index: Int) -> Bool {
        if isBatchNovelAdItem(index: index) {
            return true
        } else if isAdvertItem(index: index) {
            return true
        } else if index >= 0, index < self.allDatas.count, let item = self.allDatas[index] as? IItem,
                    let model = item.model, model.type == "14314" {
            return true
        }
        
        return false
    }
    
    //用作顶部背景
    override func isAdvertItemFor14204(index: Int) -> Bool {
        if isLunboAdItem(index: index) {
            if let t = getNovelAdColors(index), t.0 != nil {
                return false
            }
            return true
        } else if let item = self.allDatas[index] as? IItem, let model = item.itemModel as? HomeItemModel {
            if is14313Lunbo(), model.isBigCard == false, model.absorbColor == nil {
                return true
            }
        }
        return false
    }
    
    weak var preItemView: UIView?
    override func centerViewChangedWhenDidEndScroll(index: Int, itemView: UIView) {
        let preIndex = self.sliderViewPreviousPageIndex
        super.centerViewChangedWhenDidEndScroll(index: index, itemView: itemView)
        
        guard preIndex != index else {
            return
        }
        
        if SelectionTopAnimationADManager.shareInstance().isTopAnimationADMode(self.component?.getPage()) {
            SelectionTopAnimationADManager.shareInstance().lunboPreIndex = preIndex
            SelectionTopAnimationADManager.shareInstance().lunboIndex = index
            self.component?.getPage()?.sendEventMessage("yk.selection.topAnimationADMode.scrolltoRealLunboY", params: nil)
            self.component?.getPage()?.sendEventMessage("yk.selection.topAnimationADMode.lunboIndexChange.hideTopView", params: nil)
        } else if SelectionLunboAppleCNYADManager.shareInstance().isLunboAppleCNYADMode(self.component?.getPage()) {
            SelectionLunboAppleCNYADManager.shareInstance().lunboPreIndex = preIndex
            SelectionLunboAppleCNYADManager.shareInstance().lunboIndex = index
            self.component?.getPage()?.sendEventMessage("yk.selection.lunboAppleCNYADMode.scrolltoRealLunboY", params: nil)
//            self.notifyNavigatinBar()
        }
        YKSCScreenLogUtil.printLog("[新轮播] index切换 f:\(preIndex) t:\(index) ", color: .red)
        
        self.bathAdsHandler?.itemOut(index: preIndex, itemView: preItemView)
        self.bathAdsHandler?.itemIn(index: index, itemView: itemView)
        
        self.cententAdStatisHandler?.itemIn(index)
        self.preItemView = itemView
    }

    override func itemAbsorbColor(index: Int) -> (UIColor, String?) {
        let DEFAULT_COLOR = UIColor.createColorWithHexRGB(colorStr: "#463B5D")
        
        var color = DEFAULT_COLOR
        var imgUrl: String?
        
        if index >= 0, index < self.allDatas.count {
            if isLunboAdItem(index: index) {
                if let t = getNovelAdColors(index), let tColor = t.0 {
                    color = tColor
                    imgUrl = t.1
                }
            } else if let item = self.allDatas[index] as? IItem {
                if let absorbColor = item.homeItemModel?.absorbColor {
                    color = absorbColor
                }
                imgUrl = item.homeItemModel?.img
            }
        }
        return (color, imgUrl)
    }
    
    func getNovelAdColors(_ index: Int) -> (UIColor?, String?)? {
        var color: UIColor? = nil
        var imgUrl: String?
        
        if !is14313Lunbo() { //新轮播从model取值
            if let model = oadModelAtIndex(index) {
                if let dict = model.getBackGroundColorAndImage() as? [String: String] {
                    if let colorStr = dict["bgColor"], colorStr.isEmpty == false {
                        color = UIColor.createColorWithHexRGB(colorStr: colorStr)
                    }
                    
                    imgUrl = dict["bgImage"]
//                    YKSCScreenLogUtil.printLog(("[新轮播] 广告返回颜色:\(dict["bgColor"]) url:\(imgUrl)"), color: .red)
                    return (color, imgUrl)
                }
            }
        } else if let adView = self.adViewAtIndex(index) as? Comp14314NadView,
            let dict = adView.getBackGroundColorAndImage() as? [String: String] {
            if let colorStr = dict["bgColor"], colorStr.isEmpty == false {
                color = UIColor.createColorWithHexRGB(colorStr: colorStr)
            }
            
            imgUrl = dict["bgImage"]
//            YKSCScreenLogUtil.printLog(("[批量广告] itemAbsorbColor:\(dict["bgColor"]) url:\(imgUrl)"), color: .red)
            return (color, imgUrl)
        }
        
        return nil
    }
    
    func adViewAtIndex(_ index: Int) -> UIView? {
        return self.bathAdsHandler?.adViewAtIndex(index)
    }
    
    func oadModelAtIndex(_ index: Int) -> OADModel? {
        if index < self.allDatas.count {
            if let item = self.allDatas[index] as? IItem, let itemModel = item.itemModel as? Item14314Model {
                return itemModel.adModel
            }
        }
        return nil
    }
    
    override func containerDidScroll(_ scrollView: UIScrollView) {
        super.containerDidScroll(scrollView)
        if isTopAnimationADMode {
            
        }
    }
    
    override func refreshSliderBackground() {
        super.refreshSliderBackground()
        if isLunboAppleCNYADMode {
            var themeColors = self.themeBgColors
            if !forceShowThemeBgColor  {
                themeColors = nil
            }
            var userInfo = [String:Any]()
            if let themeColors = themeColors {
                userInfo["themeColors"] = themeColors
            }
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yksc.event.comp.lunbo.14333.refreshTheme"), object: nil, userInfo: userInfo)
        }
    }
    
    // MARK: - ComponentAddPageLifeEventHandlerDelegate
    
    override func appDidBecomeActive() {
        super.appDidBecomeActive()
        self.bathAdsHandler?.appDidBecomeActive()
        if topADCardIsShow {
            if self.topADScrollInterval > 0 {
                ///1.轮播滚动暂停
                pauseSlider()
                ///2.对小阁楼展示时间计时,到时间后小阁楼收起 轮播恢复滚动
                resumeTopADTimer()
            }
        }
    }
    
    override func appWillResignActive() {
        super.appWillResignActive()
        self.bathAdsHandler?.appWillResignActive()
        self.pauseTopADTimer()
    }
    
    override func didActivate() {
        super.didActivate()
        self.bathAdsHandler?.didActivate()
        if topADCardIsShow {
            if self.topADScrollInterval > 0 {
                ///1.轮播滚动暂停
                pauseSlider()
                ///2.对小阁楼展示时间计时,到时间后小阁楼收起 轮播恢复滚动
                resumeTopADTimer()
            }
        }
    }
    
    override func didDeactivate() {
        super.didDeactivate()
        self.bathAdsHandler?.didDeactivate()
        self.pauseTopADTimer()
    }
    
    override func canResumeSlider() -> Bool {
        let isADPlaying = bathAdsHandler?.isPlaying ?? false
        if isADPlaying {
            return false
        }
        return true
    }
    
    // MARK: BatchNovelAdsHandlerDelegate
    public func getEnableReumeSlider() -> Bool {
        if !isTopAnimationADMode {
            return true
        } else {
            if !topADCardIsShow {
                return true
            } else {
                if self.topADScrollInterval < 1 {
                    return true
                }
            }
        }
        return false
    }
    
    public func appleAdClosedEvent() {
        self.addTopADGuideView()
        if isTopAnimationADMode {
            self.component?.getPage()?.sendEventMessage("yk.selection.topAnimationADMode.appleAD.closed", params: nil)
        } else if isLunboAppleCNYADMode {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yksc.event.comp.lunbo.14333.vb.close"), object: nil, userInfo: nil)
        }
    }
    
    ///slider
    override func resumeSlider() {
        if getEnableReumeSlider() {
            super.resumeSlider()
        }
    }
    func firstItemIs14314Ad() -> Bool {
        if let model = self.component?.getItems()?.first?.itemModel as? Item14314Model, model.type == "14314", let adDict = model.adDict {
            return true
        }
        return false
    }
    ///小阁楼展示
    @objc func receiveTopADCardShowEvent(_ noti:Notification) {
        if !topADCardIsShow {
            topADCardIsShow = true
            self.topAnimationADLunboBackgroundView?.senceAnimationPlay()
            if self.topADScrollInterval > 0 {
                ///1.轮播滚动暂停
                pauseSlider()
                ///2.对小阁楼展示时间计时,到时间后小阁楼收起 轮播恢复滚动
                resumeTopADTimer()
            }
        }
    }
    ///小阁楼消失
    @objc func receiveTopADCardHideEvent(_ noti:Notification) {
        if topADCardIsShow {
            topADCardIsShow = false
            self.topAnimationADLunboBackgroundView?.senceAnimationStop()
            ///1.停止小阁楼的timer
            pauseTopADTimer()
            
            let curTimeInterval = Date().timeIntervalSince1970
            let showTime = curTimeInterval - topADStartTimeInterval
            //判断有无焦1广告
            if bathAdsHandler == nil, !self.firstItemIs14314Ad() {
                if showTime >= self.timeInterval {
                    slideToNextPage()
                    resumeSlider()
                } else {
                    resumeSlider()
                }
            } else {
                let isADPlaying = bathAdsHandler?.isPlaying ?? false
                let hasToNextPage = bathAdsHandler?.hasToNextPage ?? false
                if !isADPlaying, hasToNextPage {
                    slideToNextPage()
                    resumeSlider()
                } else {
//                    resumeSlider()
                }
            }
        }
    }
    @objc func resumeTopADTimer() {
        restartTopAdTimerAfterTimeInterval(TimeInterval(self.topADScrollInterval))
    }
    @objc func pauseTopADTimer() {
        guard let timer = self.topADTimer else {
            return
        }
        if timer.isValid {
            timer.fireDate = NSDate.distantFuture
        }
    }
    func restartTopAdTimerAfterTimeInterval(_ interval: TimeInterval) {
        if interval <= 0 {
            return
        }
        if let timer = self.topADTimer, timer.isValid {
            timer.fireDate = Date.init(timeIntervalSinceNow: interval)
            self.topADStartTimeInterval = Date().timeIntervalSince1970
        } else {
            initTopADTimer(interval: interval)
            resumeTopADTimer()
        }
    }
    // MARK: timer control
    func initTopADTimer(interval: TimeInterval) {
        if self.topADTimer != nil {
            self.topADTimer?.invalidate()
            self.topADTimer = nil
        }
        if interval > 0 {
            let timer = Timer.init(timeInterval: interval, target: self, selector: #selector(topADTimerEvent), userInfo: nil, repeats: false)
            RunLoop.main.add(timer, forMode: RunLoop.Mode.common)
            self.topADTimer = timer
            pauseTopADTimer()
        }
    }
    
    ///小阁楼计时结束
    @objc func topADTimerEvent() {
        self.component?.getPage()?.sendEventMessage("yk.selection.topAnimationADMode.force.hideTopView", params: nil)

//        let curTimeInterval = Date().timeIntervalSince1970
//        let showTime = curTimeInterval - topADStartTimeInterval
//        //判断有无焦1广告
//        if bathAdsHandler == nil, !self.firstItemIs14314Ad() {
//            if showTime >= self.timeInterval {
//                slideToNextPage()
//            }
//        } else {
//            let isADPlaying = bathAdsHandler?.isPlaying ?? false
//            let hasToNextPage = bathAdsHandler?.hasToNextPage ?? false
//            if !isADPlaying, hasToNextPage {
//                slideToNextPage()
//            }
//        }
//        resumeSlider()
    }
    
    func estimatedLayoutTopADGuide() {
        if !SelectionTopAnimationADManager.shareInstance().isTopAnimationADMode(self.component?.getPage()) {
            return
        }
        if let comp14325Model = getTopAnimatioADComponent(self.component?.getPage())?.compModel as? Comp14325Model, let guideText = comp14325Model.guideText {
            SelectionTopAnimationADManager.shareInstance().guideText = guideText
            let realText = guideText + " " + "\u{e707}"
            let width: CGFloat = ceil(calcStringSize(realText, font: YKNIconFont.sharedInstance().font(withSize: 12.0), size: CGSize.init(width: Int.max, height: Int.max)).width)
            let height = YKNFont.height(with: UIFont.systemFont(ofSize: 12), lineNumber: 1) + 2.0
            self.topADGuideTextSize = CGSizeMake(width, height)
        } else {
            SelectionTopAnimationADManager.shareInstance().guideText = nil
        }
    }
    
    
    var cententAdStatisHandler: ContentAdStasticsHandler?
}
