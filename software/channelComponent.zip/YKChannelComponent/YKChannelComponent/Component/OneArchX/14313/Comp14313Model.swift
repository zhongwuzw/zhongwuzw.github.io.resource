//
//  Comp14313Model.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/6/20.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Comp14313Model: Comp14204Model {

    var advertConfigs: [Comp14313ConfigModel]?
    
    var requestAdListStr: String = ""
    var adPostionDict: [String: Comp14313ConfigModel] = [String : Comp14313ConfigModel]() //广告位对应model
    var adIndexDict: [Int: Comp14313ConfigModel] = [Int : Comp14313ConfigModel]() //index对应model
    
    override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        // 下线老焦2代码
        self.nadConfig = nil
        
//        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
//            return
//        }
        
        // 强制下线3-6代码
//        if let advertConfigs = dataInfo["advertConfigs"] as? [[String : Any]], advertConfigs.count > 0 {
//            var tempConfigs = [Comp14313ConfigModel]()
//            for advertConfig in advertConfigs {
//                let config = Comp14313ConfigModel.init()
//                config.setup(advertConfig)
//
//                if config.p != -1 && config.index != -1 {
//                    tempConfigs.append(config)
//                }
//            }
//            self.advertConfigs = tempConfigs
//
//            var pArr = [String]()
//            for tempConfig in tempConfigs {
//                let saveK = "\(tempConfig.p)"
//                pArr.append("\(tempConfig.p)")
//                self.adPostionDict[saveK] = tempConfig
//                self.adIndexDict[tempConfig.index] = tempConfig
//            }
//
//            let string = pArr.joined(separator: "_")
//            print("14313 请求广告 \(string)")
//            self.requestAdListStr = string
//
//            print("14313 请求广告位:\(requestAdListStr)")
//        }
    }
}

class Comp14313ConfigModel {
    var index: Int = -1
    var p: Int = -1
    var cmsJson: [String: Any]?
    
    func setup(_ cmsInfo: [String : Any]) {
        if let adParams = cmsInfo["adParams"] as? [String : Any], let p = getTypeIntValue(adParams["p"]) {
            self.p = p
        }
        
        if let index = getTypeIntValue(cmsInfo["index"]), index >= 1 {
            self.index = (index - 1)
        }
    }
}
