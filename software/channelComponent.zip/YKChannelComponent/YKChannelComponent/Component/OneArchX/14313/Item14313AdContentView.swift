//
//  Item14313AdContentView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/6/20.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import NovelAdSDK

class Item14313AdContentView: AccessibilityView , Item14313AdViewDelegate {
    weak var adCotentView: Comp14314NadView?
    var index: Int = 0
    
    func fillAdView(_ view: Comp14314NadView, _ index: Int) {
        self.adCotentView?.removeFromSuperview()
        
        if view.superview != nil {
            view.removeFromSuperview()
        }
        self.index = index
        self.adCotentView = view
        view.frame = self.bounds
        self.addSubview(view)
    }
    
    deinit {
        print("[批量广告] life 14313 deinit")
    }
}

class Item14314AdContentView: AccessibilityView , Item14313AdViewDelegate {
    weak var adCotentView: Comp14314NadView?
    var index: Int = 0
    weak var item: IItem?
    
    lazy var adAPI: NadAPI = {
        return NadAPI()
    } ()
    
    func fillAdView(_ view: Comp14314NadView, _ index: Int) {
        self.adCotentView?.removeFromSuperview()
        
        self.index = index
        
        if view.superview != nil {
            view.removeFromSuperview()
        }
        self.adCotentView = view
        view.frame = self.bounds
        view.layer.cornerRadius = 0
        self.addSubview(view)
    }

    deinit {
        print("[批量广告] life 14314 deinit")
    }
}

class Item14314NewAdContentView: AccessibilityView , Item14313AdViewDelegate {
    weak var adCotentView: Comp14314NadView?
    var index: Int = 0
    weak var item: IItem?
    
    func fillData(_ item: IItem?) {
        guard let item = item, let model = item.model as? Item14314Model, let oadModel = model.adModel else {
            return
        }
        
        self.index = item.index
        
        if self.adCotentView == nil ,
           let adView = model.adAPI.getAdView(oadModel) as? Comp14314NadView {
            print("[新轮播] adAPI getAdView")
            adView.frame = self.bounds
            self.addSubview(adView)
            self.adCotentView = adView
        } else {
            print("[新轮播] adAPI new_fillData")
            self.adCotentView?.new_fillData(oadModel, api: model.adAPI)
        }
    }

    deinit {
        print("[新轮播] Item14314AdContentView deinit")
    }
}

protocol Item14313AdViewDelegate {
    var adCotentView: Comp14314NadView? { get set }
}

