//
//  BatchNovelAdsHandler.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/6/20.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKChannel
import YKResponsiveLayout
import YKSCConst
import YKSCService
import NovelAdSDK
import orange
import UIKit

class BatchNovelAdsHandler: ComponentEventHandler, IComponentLifeCycleEventHandler, LunboAdHandlerDelayDelegate, Comp14314NadViewDelegate, OADFeedbackProtocol {
    
    weak var delegate: BatchNovelAdsHandlerDelegate?
    var adCreateViewDict: [Int: Comp14314NadView]? //广告创建视图(通过传入json创建，type = 14014使用)
    var isPlaying:Bool = false
    var hasToNextPage:Bool = false

    var disableExposeOpt: Bool = false //广告补发曝光优化逻辑开关
    lazy var adAPI: NadAPI = {
        return NadAPI()
    } ()
    
    required init() {
        super.init()
        
        self.disableExposeOpt = judgeDisableExposeOpt()
    }
    
    override func listeningEventObservers() -> [EventObserver]? {
        return [
                EventObserver("yksc.event.comp.lunbo.componentDidInit"),
                EventObserver("yksc.event.comp.lunbo.willDisplayItemView"),
                EventObserver("yksc.event.comp.lunbo.didEndDisplayingItemView"),
                EventObserver("yksc.event.comp.appleAD.resumeSlider"), //vb广告播放结束
        ]
    }
    
    override func onEvent(_ event: OEvent) {
        if event.name == "yksc.event.comp.lunbo.componentDidInit" { //组件初始化事件
            handleComponentDidInit()
        } else if event.name == "yksc.event.comp.lunbo.willDisplayItemView" {
            willDisplayItemView(event.params["itemView"] as? UIView)
        } else if event.name == "yksc.event.comp.lunbo.didEndDisplayingItemView" {
            didEndDisplayingItemView(event.params["itemView"] as? UIView)
        } else if event.name == "yksc.event.comp.appleAD.resumeSlider" {
            handleByAppleAdClosed(event.params)
            delegate?.appleAdClosedEvent()
        }
    }
    
    func handleComponentDidInit() {
        self.adCreateViewDict = [Int: Comp14314NadView]()
        
        delayWrapper = NewNovelADHandlerWrapper.init()
        delayWrapper?.handler = self
        
        NotificationCenter.default.addObserver(self, selector: #selector(receiveSplashViewRemovedNotification(_:)), name: Notification.Name(rawValue: "splashviewremoved"), object: nil)
    }
    
    func handleByAppleAdClosed(_ params: [String: Any]?) {
        let _itemView = currentItemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(self.currentIndex)
        guard let nadView = nadView else {
            return
        }
        
        if let isSlideFocus = params?["isSlideFocus"] as? Bool, isSlideFocus == true {
            if self.canPlay() {
                playAd(true)
            }
        }

        print("[新轮播] handleByAppleAdClosed")
        if self.currentIndex == 0 && !isPageInPreload {
            isItemIn = true
            nadView.adViewVisibleFull()
        }
    }
    
    func willDisplayItemView(_ itemView: UIView?) {
        print("[新轮播] willDisplayItemView")
        
    }
    
    func didEndDisplayingItemView(_ itemView: UIView?) {

    }
    
    var receiveSplashViewRemovedNoti: Bool = false
    @objc func receiveSplashViewRemovedNotification(_ notif: Notification?) {
        print("[新轮播] 开屏消失通知")
        guard !receiveSplashViewRemovedNoti else { //只处理一次开屏消失通知
            return
        }
        receiveSplashViewRemovedNoti = true
        
        if self.canPlay() {
            playAd(true)
        }
    }
    
    func playAd(_ isItemIn: Bool) {
        let _itemView = currentItemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(currentIndex)
        guard let nadView = nadView else {
            return
        }
        
        print("[新轮播] 开始播放视频 index:\(self.currentIndex)")
        
        nadView.playVideo()
        
        // 进入时发一次曝光
        if isItemIn && !isPageInPreload {
            nadView.adViewVisibleFull()
        }
    }
    
    // MARK: - 状态
    weak var page: IPage? {
        return component?.getPage()
    }
    
    var isPageInPreload: Bool {
        return page?.pageModel?.dataState != .network
    }
    
    var isPageInActive: Bool {
        return component?.getPage()?.activeState ?? false
    }
    
    var isItemIn: Bool = false
    var isPlayFinished:Bool = false
    
    var delayWrapper: NewNovelADHandlerWrapper?
    var isSplashRemoved: Bool {
        let superVC = YKHomeModeManager.sharedInstance().homeViewController
        let isSplashViewRemoved = superVC?.isSplashViewRemoved as? Bool ?? true
        return isSplashViewRemoved

    }
    
    func canPlay(_ isWillDisplay: Bool = false) -> Bool {
        let a = disableExposeOpt ? isItemIn : true
        let b = !isWillDisplay ? isDisplaying() : true
        let c = isPageInActive
        let d = !YKAppleADManager.sharedInstance().hasAppleAD
        let e = self.isSplashRemoved
        print("[新轮播] [14016] canPlay = (\(String(a)) | \(String(b))| \(String(c)) | \(String(d)) | \(String(e))")
        
        return a && b && c && d && e
    }
    
    func isDisplaying() -> Bool {
        return delegate?.isNovelADCompVisible() ?? false
    }
    
    // MARK: -
    
    var isNewSlider = false
    
    var currentIndex: Int = 0
    var preIndex: Int = 0
    
    weak var currentItemView: UIView?
    weak var preItemView: UIView?
    
//    func currentIsPlaying() -> Bool {
//        return isPlaying && !isPlayFinished
//    }
    
    func resetState() {
        isItemIn = false
        isPlaying = false
        isPlayFinished = false
        hasToNextPage = false
        
        currentIndex = -1
        preIndex = -1
        
        currentItemView = nil
        preItemView = nil
        
        self.delayWrapper?.cancelDelayDo()
    }
    
    func itemIn(index: Int, itemView: UIView) {
        self.preIndex = self.currentIndex
        self.currentIndex = index
        self.currentItemView = itemView
        self.delayWrapper?.cancelDelayDo() //滚入index，停止延时
        
        let _itemView = itemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(index)
        
        if !disableExposeOpt {
            isItemIn = true
            isPlayFinished = false
            print("[新轮播] itemIn index:\(index)")
        }
        
        guard let nadView = nadView, isPageInActive && !YKAppleADManager.sharedInstance().hasAppleAD else {
            if nadView == nil , let _ = itemView as? Comp14204ContentView { //fix-滚动到内容坑轮播图不能自动滑问题
                if self.isSplashRemoved && isPageInActive && !YKAppleADManager.sharedInstance().hasAppleAD && judgeContentItemInResumeOpt() {
                    delegate?.tryResumeSlider()
                }
            }
            return
        }
        
        if disableExposeOpt {
            isItemIn = true
            isPlayFinished = false
            print("[新轮播] itemIn index:\(index)")
        }

        if self.isSplashRemoved {
            self.playAd(true)
            
            // 修复视频起播后，直接滑走导致图片未轮播
            if nadView.isVideoType() == false, judgeItemInResumeOpt() {
                if isPageInActive {
                    delegate?.tryResumeSlider()
                }
            }
        }
    }

    func itemOut(index: Int, itemView: UIView?) {
        let _itemView = itemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(index)
        
        if !disableExposeOpt {
            print("[新轮播] itemOut index:\(index)")
            isItemIn = false
            isPlayFinished = true
        }
        
        guard let nadView = nadView   else {
            return
        }
        
        if disableExposeOpt {
            print("[新轮播] itemOut index:\(index)")
            isItemIn = false
            isPlayFinished = true
        }

        nadView.stopVideo()
    }

    func willDisplay() {
        let _itemView = currentItemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(self.currentIndex)
        guard let nadView = nadView else {
            return
        }

        print("[新轮播] willDisplay")
        if canPlay(true) && !isPlayFinished {
            nadView.playVideo()
            
            if !disableExposeOpt {
                print("[新轮播] willDisplay 补发一次曝光")
                nadView.adViewVisibleFull()
            }
        }
    }

    func endDisplay() {
        let _itemView = currentItemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(self.currentIndex)
        guard let nadView = nadView else {
            return
        }

        print("[新轮播] endDisplay")
        nadView.pauseVideo()
    }

    func didActivate() {
        let _itemView = currentItemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(self.currentIndex)
        guard let nadView = nadView else {
            return
        }

        print("[新轮播] didActivate")
        if canPlay() && !isPlayFinished {
            nadView.playVideo()
            
            if !disableExposeOpt {
                print("[新轮播] didActivate 补发一次曝光")
                nadView.adViewVisibleFull()
            }
        }
    }

    func didDeactivate() {
        let _itemView = currentItemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(self.currentIndex)
        guard let nadView = nadView else {
            return
        }

        print("[新轮播] didDeactivate")
        nadView.pauseVideo()
    }

    func appDidBecomeActive() {
        let _itemView = currentItemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(self.currentIndex)
        guard let nadView = nadView else {
            return
        }

        print("[新轮播] appDidBecomeActive")
        if canPlay() && !isPlayFinished {
            
            weak var weakSelf = self
            DispatchQueue.main.async {
                nadView.playVideo()
                
                if !(weakSelf?.disableExposeOpt ?? false) {
                    print("[新轮播] 进入前台 补发一次曝光")
                    nadView.adViewVisibleFull()
                }
            }
        }
    }

    func appWillResignActive() {
        let _itemView = currentItemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(self.currentIndex)
        guard let nadView = nadView else {
            return
        }

        print("[新轮播] appWillResignActive")
        nadView.pauseVideo()
    }
    
    /// item进入可视区域
    func enterDisplayArea(itemView: UIView?) {
        print("[新轮播] enterDisplayArea")
        willDisplay()
    }

    /// item离开可视区域
    func exitDisplayArea(itemView: UIView?) {
        print("[新轮播] exitDisplayArea")
        endDisplay()
    }

    /// 可见组件-容器滚动
    func visibleViewDidScroll(itemView: UIView?) {
        
    }

    /// 可见组件-容器停止滚动（以cell为单位回调多次）
    func visibleViewDidEndScroll(itemView: UIView?) {
        
    }

    /// 可见组件-容器停止滚动（回调一次）
    func visibleViewsDidEndScroll() {
        
    }
    
    // MARK: - Comp14314NadViewDelegate
    
    func didStartPlay(_ view: Comp14314NadView) {
        let _itemView = currentItemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(self.currentIndex)
        guard let adView = nadView, adView == view else {
            view.stopVideo()
            return
        }
        YKSCScreenLogUtil.printLog(("[新轮播] didStartPlay"), color: .red)
        
        isPlaying = true
        hasToNextPage = false
        isPlayFinished = false
        
        delegate?.pauseSlider()
        delayWrapper?.cancelDelayDo()
    }
    
    func didEndPlay(_ view: Comp14314NadView, error: Error?, isTimeout: Bool, delayTime: Double) {
        YKSCScreenLogUtil.printLog(("[新轮播] didEndPlay error:\(error) isTimeOut:\(isTimeout) delayTime:\(delayTime)"), color: .red)
        
        isPlaying = false
        isPlayFinished = true
        
        if OADFeedbackService.sharedInstance().isAttaching() == false {
            delayWrapper?.delayTimeDo(delayTime)
        }
    }
    
    func didEndPlay() {
        delegate?.resumeSlider()
    }
    
    func isItemVisible(_ view: Comp14314NadView) -> Bool {
        return canPlay()
    }
    
    func playTimeDidChange(_ time: Int32) {
        if judgeDisablePlayTimeDidChangedOpt() {
            return
        }
        
        isPlaying = true
    }
    
    func currentIsPlaying() -> Bool {
        let _itemView = currentItemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(self.currentIndex)
        guard let adView = nadView else {
            return false
        }
        
        return adView.isVideoPlaying()
    }
    
    // MARK: OADFeedbackProtocol
    
    func didAttachAdFeedback() {
        print("[NAD] [14313] didAttachAdFeedback")
        
        delegate?.pauseSlider()
        delayWrapper?.cancelDelayDo()
    }
    
    func didDetachAdFeedback() {
        print("[NAD] [14313] didDetachAdFeedback")
        
        if isVideoType() {
            if isPlayFinished {
                delayWrapper?.delayTimeDo(delayTime())
            }
        } else {
            delegate?.resumeSlider()
        }
    }
    
    func didSuccessAdFeedback() {
        
    }
    
    func delayTime() -> Double {
        let t = Orange.getConfigByGroupName("NovelAdSDK-iOS", key: "lunbo2_performance_max_wait_duration_ms", defaultConfig: 1000.0, isDefault: nil) as? Double ?? 1000.0
        return t/1000.0
    }
    
    // MARK: - LunboAdHandlerDelayDelegate
    
    func delayResumeSlider() {
        if isPageInActive {
            hasToNextPage = true
        }
        let enableResume = delegate?.getEnableReumeSlider() ?? true
        if isPageInActive, enableResume {
            delegate?.slideToNextPage()
            delegate?.resumeSlider()
        }
    }
    
    // MARK: - private
    
    /// 创建广告视图
    func createAdView(_ item: IItem?, _ index: Int) -> Comp14314NadView? {
        guard let item = item, let model = item.itemModel as? Item14314Model, var adDict = model.adDict else {
            return nil
        }
        adDict["isNewSlider"] = self.component?.model?.type == "14336"
        let v = self.adAPI.createAdView(withJSON: adDict) as? Comp14314NadView
        v?.delegate = self
        self.adCreateViewDict?[index] = v
        YKSCScreenLogUtil.printLog(("[新轮播] life createAdView:\(v) index:\(index)"), color: .red)
        return v
    }
    
    func adViewAtIndex(_ index: Int) -> Comp14314NadView? {
        if let view = self.adCreateViewDict?[index] {
            return view
        }
        
        return nil
    }
    
    func isVideoType() -> Bool {
        let _itemView = currentItemView as? Item14314NewAdContentView
        let nadView = isNewSlider ? _itemView?.adCotentView : adViewAtIndex(self.currentIndex)
        guard let nadView = nadView else {
            return false
        }
        
        return nadView.isVideoType()
    }
    
    deinit {
        print("[新轮播] life deinit:\(self)")
        
        if let adCreateViewDict = self.adCreateViewDict { // 释放业务创建广告view
            if Thread.isMainThread {
                for (_, v) in adCreateViewDict {
                    v.removeFromSuperview()
                }
            } else {
                DispatchQueue.main.async {
                    for (_, v) in adCreateViewDict {
                        v.removeFromSuperview()
                    }
                }
            }
        }
    }
    
    func judgeItemInResumeOpt() -> Bool {
        let orangeInfo = Orange.getGroupConfig(byGroupName: "yksc_config")
        return YKCCUtil.getBoolValue(orangeInfo?["homeSliderItemInResumeOpt"]) ?? true
    }
    
    func judgeDisableExposeOpt() -> Bool {
        let orangeInfo = Orange.getGroupConfig(byGroupName: "yksc_config")
        return YKCCUtil.getBoolValue(orangeInfo?["homeSliderDisableExposeOpt"]) ?? false
    }
    
    func judgeDisablePlayTimeDidChangedOpt() -> Bool {
        let orangeInfo = Orange.getGroupConfig(byGroupName: "yksc_config")
        return YKCCUtil.getBoolValue(orangeInfo?["adPlayTimeDidChangedOpt"]) ?? false
    }
    
    func judgeContentItemInResumeOpt() -> Bool {
        let orangeInfo = Orange.getGroupConfig(byGroupName: "yksc_config")
        return YKCCUtil.getBoolValue(orangeInfo?["homeSliderContentItemInResumeOpt"]) ?? true
    }
}

protocol BatchNovelAdsHandlerDelegate : NewNovelADHandlerDelegate {
    func getEnableReumeSlider() -> Bool
    func appleAdClosedEvent()
}

class ContentAdStasticsHandler: ComponentEventHandler {
    weak var page: IPage? {
        return component?.getPage()
    }
    
    var isPageInActive: Bool {
        return component?.getPage()?.activeState ?? false
    }
    
    var isPageInPreload: Bool {
        return page?.pageModel?.dataState != .network
    }
    
    override func listeningEventObservers() -> [EventObserver]? {
        return [
                EventObserver("yksc.event.comp.appleAD.resumeSlider"), //vb广告播放结束
        ]
    }
    
    override func onEvent(_ event: OEvent) {
        if event.name == "yksc.event.comp.appleAD.resumeSlider" {
            contentAdExposeIfNeeded(0)
        }
    }
    
    func itemIn(_ index: Int) {
        guard isPageInActive && !YKAppleADManager.sharedInstance().hasAppleAD else {
            return
        }
        
        // 发曝光
        contentAdExposeIfNeeded(index)
    }
    
    // MARK: - 首焦1接cpm投放，补发曝光
    
    func contentAdExposeIfNeeded(_ index: Int) {
        guard !isPageInPreload, let items = self.component?.getItems(), index >= 0,  index < items.count else {
            return
        }
        
        let item = items[index]
        
        guard let model = item.model as? Item14204Model, model.type == "14313" else {
            return
        }
        
        // 主线程解析广告模型OADModel
        model.parseContentAdDataIfNeeded()
        
        if model.contentHasSendAdExposed == false,
            let oadModel = model.contentOadModel, let api = model.nadApi {
            print("[广告补发埋点] 曝光model:\(oadModel)")
            model.contentHasSendAdExposed = true
            api.adExposure(oadModel)
        }
    }
}
