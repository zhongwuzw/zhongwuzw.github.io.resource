//
//  Comp14313ItemJsonExtracter.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2023/9/12.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation
import OneArch
import XAdSDK
import YKSCService

@objcMembers
class Comp14313ItemJsonExtracter: ItemJsonExtracter {
    let itemJsonExtracter = DefaultItemJsonExtracter.init()
    var enableClientAdInsert: Bool = false
    
    var advertConfigIndex: Int = -1
    var advertConfigChangedIndex: Int = -1
    // MARK: - ItemJsonExtracter
    
    func getItemsJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error> {
        if enableClientAdInsert {
            return self.getInsertedJson(componentJson: componentJson, component: component)
        }
        
        return itemJsonExtracter.getItemsJson(componentJson: componentJson, component: component)
    }
    
    func getItemTag(itemJson: [String: Any]?, component: IComponent?) -> String? {
        return itemJsonExtracter.getItemTag(itemJson: itemJson, component: component)
    }
    
    func getItemSubcomponentsJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error> {
        return itemJsonExtracter.getItemSubcomponentsJson(componentJson: componentJson, component: component)
    }
    
    func getSubitemsJson(itemJson: [String : Any]?, item: IItem?) -> Result<[[String : Any]], Error> {
        return itemJsonExtracter.getSubitemsJson(itemJson: itemJson, item: item)
    }
    
    public func getInsertedJson(componentJson: [String: Any]?, component: IComponent?) -> Result<[[String: Any]], Error> {
        guard let originItemsJson = componentJson?["nodes"] as? [[String: Any]], originItemsJson.count > 0 else {
            return .success([[String : Any]]()) //允许没有坑位列表
        }
        
        var itemsJson = originItemsJson

        // 记录坑7位置
        if let data = componentJson?["data"] as? [String: Any], let advertConfig = data["advertConfig"] as? [String: Any],
            let index = YKCCUtil.getIntValue(advertConfig["index"]), index >= 0 {
            advertConfigIndex = index
            advertConfigChangedIndex = index
        }
        
        // 组装原始数据
        var arr = [XAdCarouselModel]()
        for i in 0..<2 {
            if itemsJson.count > i {
                let itemJson = itemsJson[i]
                if !self.itemIsFix(itemJson: itemJson) { // 定坑不处理
                    if let m = buildAParamModel(itemJson: itemJson, index: i) {
                        arr.append(m)
                    }
                }
            }
        }
        
        // 特殊case，12都是定坑，直接return
        if arr.count == 0 {
            YKSCScreenLogUtil.printLog("[首焦广告替换] 焦1-2都是定坑，直接返回", color: .red)
            return .success(originItemsJson)
        }
        
        // 拿替换数据
        var oriResult = XAdCarouselManger.sharedInstance().replaceCarouselAd(arr)
//        oriResult = buildMockModel()
        
        // index排序
        if oriResult.count > 0 {
            oriResult = sortedResultArr(oriResult)
        }
        
        // 校验ad数据合法
        var result = [XAdCarouselModel]()
        for model in oriResult {
            let adJson = model.adJson
            if model.isReplaced && adJson.isEmpty == false {
                result.append(model)
            }
        }
        
        YKSCScreenLogUtil.printLog("[首焦广告替换] 广告数据信息 原始:\(arr) 返回:\(oriResult) 可用:\(result)", color: .red)
        if result.count > 0 {
            var fixIndexs = [Int]() // 定坑位置
            var changedFixIndexs = [Int]()
            var fixIndexHasChanged = false
            
            var replaceAdIndexs = [Int]() // 广告替换位置
            var changedReplaceAdIndexs = [Int]()
            var replaceIndexHasChanged = false
            
            for i in 0..<itemsJson.count {
                let itemJson = itemsJson[i]
                if self.itemIsFix(itemJson: itemJson) {
                    fixIndexs.append(i)
                } else if i < 2 && self.adIsReplace(itemJson: itemJson) && self.adSDKNotReplace(index: i, oriResult: oriResult) { //焦1、2广告不替换当定坑处理
                    YKSCScreenLogUtil.printLog("[首焦广告替换] 广告不替换 index:\(i)", color: .green)
                    fixIndexs.append(i)
                }
            }
            changedFixIndexs = fixIndexs
            YKSCScreenLogUtil.printLog("[首焦广告替换] 定坑位置: \(fixIndexs)", color: .green)
            
            // 处理替换
            for model in result {
                if model.index >= 0, model.index < 2, !fixIndexs.contains(model.index) {
                    let itemJson = originItemsJson[model.index]
                    let isReplace = self.adIsReplace(itemJson: itemJson)
                    if isReplace {
                        let replaceJson = self.buildNewItemJson(model: model)
                        itemsJson[model.index] = replaceJson
                        
                        replaceAdIndexs.append(model.index)
                        YKSCScreenLogUtil.printLog("[首焦广告替换] 替换 index:\(model.index)", color: .green)
                    }
                }
            }
            changedReplaceAdIndexs = replaceAdIndexs
            
            // 处理插入
            for model in result {
                if model.index >= 0, model.index < 2, !fixIndexs.contains(model.index) {
                    let itemJson = originItemsJson[model.index]
                    let isReplace = self.adIsReplace(itemJson: itemJson)
                    if !isReplace {
                        let insertJson = self.buildNewItemJson(model: model)
                        itemsJson.insert(insertJson, at: model.index)
                        
                        YKSCScreenLogUtil.printLog("[首焦广告替换] 插入 index:\(model.index)", color: .cyan)
                        
                        // 记录广告位置变化
                        let tempReplaceIndexs = changedReplaceAdIndexs
                        for i in 0..<tempReplaceIndexs.count {
                            let index = tempReplaceIndexs[i]
                            if index >= model.index {
                                replaceIndexHasChanged = true
                                changedReplaceAdIndexs[i] = index + 1
                            }
                        }
                        YKSCScreenLogUtil.printLog("[首焦广告替换] 替换位置变化 原:\(replaceAdIndexs) 新:\(changedReplaceAdIndexs)", color: .cyan)
                        
                        // 记录定坑位置变化
                        let tempFixIndexs = changedFixIndexs
                        for i in 0..<tempFixIndexs.count {
                            let index = tempFixIndexs[i]
                            if index >= model.index {
                                fixIndexHasChanged = true
                                changedFixIndexs[i] = index + 1
                            }
                        }
                        YKSCScreenLogUtil.printLog("[首焦广告替换] 定坑位置变化 原:\(fixIndexs) 新:\(changedFixIndexs)", color: .cyan)
                        
                        // 处理焦7广告位置变化
                        if advertConfigIndex != -1 && advertConfigIndex >= model.index {
                            advertConfigChangedIndex += 1
                            YKSCScreenLogUtil.printLog("[首焦广告替换] 焦7位置变化 原:\(advertConfigIndex) 新:\(advertConfigChangedIndex)", color: .cyan)
                        }
                    }
                }
            }
            
            // 处理广告位置变化
            if replaceIndexHasChanged {
                YKSCScreenLogUtil.printLog("[首焦广告替换] 广告位置：\(replaceAdIndexs) 当前位置：\(changedReplaceAdIndexs)", color: .orange)
                for i in 0..<changedReplaceAdIndexs.count {
                    let index = changedReplaceAdIndexs[i]
                    let shouldIndex = replaceAdIndexs[i]
                    if shouldIndex < index {
                        let item = itemsJson.remove(at: index)
                        itemsJson.insert(item, at: shouldIndex)
                    }
                }
            } else {
                YKSCScreenLogUtil.printLog("[首焦广告替换] 广告位置：\(changedReplaceAdIndexs) 无需替换", color: .orange)
            }
            
            // 处理定坑位置变化
            if fixIndexHasChanged {
                YKSCScreenLogUtil.printLog("[首焦广告替换] 定坑位置：\(fixIndexs) 当前位置：\(changedFixIndexs)", color: .orange)
                for i in 0..<changedFixIndexs.count {
                    let index = changedFixIndexs[i]
                    let shouldIndex = fixIndexs[i]
                    if shouldIndex < index {
                        let item = itemsJson.remove(at: index)
                        itemsJson.insert(item, at: shouldIndex)
                    }
                }
            } else {
                YKSCScreenLogUtil.printLog("[首焦广告替换] 定坑位置：\(fixIndexs) 无需替换", color: .orange)
            }
            
            // 更新spmD (数据位置：data.action.report.spmD)
            if itemsJson.count > originItemsJson.count {
                var replaceDItemsJson = [[String: Any]]()
                var spmDHasChanged = false
                
                for i in 0..<itemsJson.count {
                    var item = itemsJson[i]
                    if item["ad"] == nil,
                       var data = item["data"] as? [String: Any],
                        var action = data["action"] as? [String: Any],
                        var report = action["report"] as? [String: Any],
                        var trackInfo = report["trackInfo"] as? [String: Any],
                        let oSpmD = report["spmD"] as? String, oSpmD.isEmpty == false {
                        if let lastCharacter = oSpmD.last, let lastDigit = Int(String(lastCharacter)), lastDigit > 0 , lastDigit <= itemsJson.count {
                            if lastDigit != (i + 1) {
                                var spmD = oSpmD
                                spmD.removeLast()
                                spmD = spmD + "\(i + 1)"
                                YKSCScreenLogUtil.printLog("[首焦广告替换] 更新spmD o:\(oSpmD) n:\(spmD)", color: .purple)
                                report["spmD"] = spmD
                                trackInfo["originalSpmD"] = oSpmD
                                report["trackInfo"] = trackInfo
                                action["report"] = report
                                data["action"] = action
                                item["data"] = data
                                replaceDItemsJson.append(item)
                                
                                spmDHasChanged = true
                                continue
                            }
                        }
                    }
                    
                    replaceDItemsJson.append(item)
                }
                
                if spmDHasChanged {
                    itemsJson = replaceDItemsJson
                }
            }
        }
        
        return .success(itemsJson)
    }
    
    public func buildAParamModel(itemJson: [String: Any], index: Int) -> XAdCarouselModel? {
        if let data = itemJson["data"] as? [String: Any] {
            let m1 = XAdCarouselModel.init()
            m1.isReplaced = false
            m1.index = index
            
            if let ad = data["ad"] as? [String: Any] {
                m1.adJson = ad
            }
            
            if let extend = data["extend"] as? [String: Any] {
                m1.extraInfo = extend
            }
            return m1
        }
        
        return nil
    }
    
    public func buildNewItemJson(model: XAdCarouselModel) -> [String: Any] {
        var itemJson = [String: Any]()
        itemJson["type"] = 14314
        
        var data = [String: Any]()
        data["ad"] = model.adJson
        data["extend"] = model.extraInfo
        itemJson["data"] = data
        return itemJson
    }

    public func adIsReplace(itemJson: [String: Any]) -> Bool {
        if let data = itemJson["data"] as? [String: Any], let _ = data["ad"] as? [String: Any] {
            return true
        }
        
        return false
    }
    
    public func adSDKNotReplace(index: Int, oriResult: [XAdCarouselModel]) -> Bool {
        for model in oriResult {
            if model.isReplaced == false && model.index == index {
                return true
            }
        }
        
        return false
    }
    
    public func itemIsFix(itemJson: [String: Any]) -> Bool {
        if let data = itemJson["data"] as? [String: Any], let fix = YKCCUtil.getBoolValue(data["fix"]) , fix == true {
            return true
        }
        
        return false
    }
    
    public func sortedResultArr(_ oriArr: [XAdCarouselModel]) -> [XAdCarouselModel] {
        let resultArr = oriArr.sorted { m1, m2 in
            return m1.index <= m2.index
        }
        
        return resultArr
    }
    
//    private func buildMockModel() -> [XAdCarouselModel] {
//        var replaceArr = [XAdCarouselModel]()
//        if let datas = self.readFromLocalFile("replaceAd"), let dataArr = datas["ads"] as? [[String: Any]], dataArr.count > 0 {
//            for i in 0..<dataArr.count {
//                let m = XAdCarouselModel()
//                m.isReplaced = true
//                m.adJson = dataArr[i]
//                m.index = i
//                replaceArr.append(m)
//            }
//        }
////        print("[首焦广告替换] 数据:\(replaceArr)")
//        return replaceArr
//    }
//
//    private func readFromLocalFile(_ fileName:String) -> [String:Any]? {
//        if let path = Bundle.main.path(forResource: fileName, ofType: "json") {
//            let data = NSData.init(contentsOfFile: path)
//            let dict = try? JSONSerialization.jsonObject(with: data! as Data,
//                                                            options: .mutableContainers) as? [String: Any]
//            return dict
//        }
//        return nil
//    }
}

// 如果定坑1,1不替换，插入2
// 如果定坑2，插入1，焦1移动到第3位
