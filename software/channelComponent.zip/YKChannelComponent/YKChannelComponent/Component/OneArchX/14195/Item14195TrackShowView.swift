//
//  Item14195TrackShowView.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/3/7.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item14195TrackShowView: UIView{
    
    var needShowCount: Bool = true
    var trackShowCountString: String = ""
    weak var favorModel: FavorModel?
    var itemModel: Item14195Model?
    
    lazy var titleLabel: UILabel = {
        let label = UILabel.init(frame: CGRect.zero)
        label.frame = self.bounds
        label.textAlignment = .center
        label.font = YKNFont.tertiary_auxiliary_text()
        label.isUserInteractionEnabled = true
        return label
    }()

    override init(frame: CGRect) {
        super.init(frame: CGRect(x: 0.0, y: 0.0, width: Item14195TrackShowView.buttonWidth(), height: 25.0))
        
        layer.masksToBounds = true
        layer.cornerRadius = YKNCorner.radius_small()

        addSubview(titleLabel)
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddCollectSuccessNotication), name: NSNotification.Name.init("kBSAddCollectSuccess"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelCollectSuccessNotication), name: NSNotification.Name.init("kBSCancelCollectSuccess"), object: nil)
        
        whenTapped {
            self.favorAction()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    public class func buttonWidth() -> CGFloat {
        var base: CGFloat = 99.0
        if ykrl_isResponsiveLayout() {
            base = 159.0
        }
        return base
    }
    
    func fillModel(_ model: HomeItemModel){
        self.itemModel = model as? Item14195Model
        self.favorModel = itemModel?.trackShow
        
        bindStatisticsService()
        layoutSubviewsIfNeeded()
    }
    
    func layoutSubviewsIfNeeded() {
        guard let favorModel = favorModel else {
            return
        }

        if favorModel.count > 0 {
            self.trackShowCountString = favorModel.formatCountText
            self.needShowCount = favorModel.needShowCount
        }
        
        refreshButtonStatus()
    }
    
    func refreshButtonStatus() {
        guard let favorModel = self.favorModel else {
            return
        }
        
        let isFavor = favorModel.isFavor
        self.titleLabel.attributedText = nil
        self.titleLabel.text = nil
        self.titleLabel.textAlignment = .center
        if let isFavor = isFavor{
            if !isFavor{
                self.titleLabel.attributedText = attributeTitleContent(countString: self.trackShowCountString, title: "+追", titleColor: UIColor.white, favored: isFavor)
                self.backgroundColor = UIColor.white.withAlphaComponent(0.2)
            }else {
                self.titleLabel.attributedText = attributeTitleContent(countString: self.trackShowCountString, title: "在追", titleColor: UIColor.white.withAlphaComponent(0.6), favored: isFavor)
                self.backgroundColor = UIColor.white.withAlphaComponent(0.08)
            }
        }
    }

    @objc func handleAddCollectSuccessNotication(notification: Notification) {
            handleNotication(notification: notification, favored: true)
        }

    @objc func handleCancelCollectSuccessNotication(notification: Notification) {
            handleNotication(notification: notification, favored: false)
        }

    func handleNotication(notification: Notification, favored: Bool) {
        guard let userInfo = notification.userInfo,
              let targetId = userInfo["targetId"] as? String
        else {
            return
        }
        
        guard let currentId = favorModel?.favorId else { return }
        
        guard currentId == targetId else { return }
        
        self.favorModel?.isFavor = favored
        
        if let count = favorModel?.count, let isFavor = favorModel?.isFavor{
            var newCount = isFavor ? count + 1 : count - 1
            newCount = max(0, newCount)
            favorModel?.count = newCount
        }
        
        layoutSubviewsIfNeeded()
        bindStatisticsService()
    }

    func favorAction() {

        var params = [String : Any]()
        params["isFavor"] = favorModel?.isFavor
        params["id"] = favorModel?.favorId ?? ""

        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channel.function.adaptor.zhuiju"), object: nil, userInfo: params)
    }
    
    func attributeTitleContent(countString: String, title: String, titleColor: UIColor, favored: Bool) -> NSAttributedString {
        
        let attriString = NSMutableAttributedString.init()
        let countFont = YKNFont.tertiary_auxiliary_text()
        let intervalFont = YKNFont.posteritem_subhead_weight(.light)
        let intervalColor = UIColor.white.withAlphaComponent(0.3)
        let titleFont = YKNFont.posteritem_subhead_weight(.medium)
        if countString.count > 0 && self.needShowCount{
            attriString.append(NSMutableAttributedString.init(string: "\(countString)", attributes: [.font: countFont, .foregroundColor: titleColor]))
            attriString.append(NSMutableAttributedString.init(string: " | ", attributes: [.font: intervalFont, .foregroundColor: intervalColor]))
        }
        let tmpString = NSMutableAttributedString.init(string: title, attributes: [.font: titleFont, .foregroundColor: titleColor])
        attriString.append(tmpString)
        return attriString
    }
    
    func bindStatisticsService() {
        guard let favorModel = self.favorModel else {
            return
        }
        
        if let isFavor = favorModel.isFavor, isFavor {
            let actionModel = self.itemModel?.extraExtend["uncollectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self, .OnlyClick)
        } else {
            let actionModel = self.itemModel?.extraExtend["collectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self, .OnlyClick)
        }
    }
    
}
