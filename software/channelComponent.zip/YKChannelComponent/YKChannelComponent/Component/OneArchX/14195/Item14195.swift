//
//  Item14195.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/3/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Item14195: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    var model: BaseItemModel?
    
    func itemDidInit() {
        if let itemModel = item?.itemModel {
            self.model = itemModel
            
            let followActionModel = ActionFactoryV2(itemModel, spmDExt: "_watching")
            
            let unfollowActionModel = ActionFactoryV2(itemModel, spmDExt: "_unwatching")
            
            if followActionModel != nil {
                itemModel.extraExtend["collectActionModel"] = followActionModel
            }
            
            if unfollowActionModel != nil {
                itemModel.extraExtend["uncollectActionModel"] = unfollowActionModel
            }
        }
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14195Model.self as? T.Type
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let width: CGFloat = itemWidth
        var height: CGFloat = width * (4.0 / 3.0)
        height += YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1) + YKNGap.dim_6() + 2.0 //标题延伸
        
        if let model = self.model, let _ = model.trackShow{
            height -= YKNGap.dim_6()
            height += YKNGap.dim_5()
            //标题延伸+3.0间距
            height += 5.0
            height += 25.0
        }

        estimatedLayout(CGSize.init(width: width, height: height))
        return height
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14195ContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14195ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? HomeItemModel else {
            return
        }
        guard let layout = self.item?.layout else {
            return
        }

        itemView.fillModel(itemModel, layout: layout)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func estimatedLayout(_ size: CGSize) {
        guard let itemModel = self.item?.model as? Item14195Model else {
            return
        }
        
        let tagFont = YKNFont.qyDigitalSemiBoldFont(ofSize: 12 * YKNSize.yk_icon_size_scale())
        let tagSize = calcStringSize(itemModel.tagTitle, font: tagFont, size: .zero)
        itemModel.tagTitleSize = tagSize
        itemModel.tagFont = tagFont
        //14306读mark字段
        if let type = itemModel.type, type == "14306" {
            let tagSize = calcStringSize(itemModel.mark?.text, font: tagFont, size: .zero)
            itemModel.tagTitleSize = tagSize
        }
        item?.layout?.extendExtra = [String: Any]()
        
        if let dateString = itemModel.desc {
            let padding = YKNGap.dim_6()
            let limitSize = CGSize.init(width: max(0, (size.width - padding * 2)), height: max(0, (size.height - padding * 2)))
            
            let font = Item14195TextView.dateLabelFont()
            let dateTextSize = calcStringSize(dateString, font: font, size: limitSize)
            
            let layout = TextLayoutModel.init()
            layout.boundingSize = size
            layout.renderRect = CGRect.init(x: padding, y: padding, width: dateTextSize.width, height: dateTextSize.height)
            
            item?.layout?.extendExtra?["dateLabel"] = layout
        }
        
        if itemModel.updateTime > 0 {
            let padding = YKNGap.dim_6()
            var textX: CGFloat = 0
            if let dateLabelLayout = item?.layout?.extendExtra?["dateLabel"] as? TextLayoutModel {
                let dateWidth = dateLabelLayout.renderRect.size.width
                if dateWidth > 0 {
                    textX = dateLabelLayout.renderRect.maxX + YKNGap.dim_4()
                }
            }
            let limitSize = CGSize.init(width: max(0, (size.width - textX - padding)), height: max(0, (size.height - padding * 2)))
            
            let HHss = Item14192ContentView.getDateFormatString(timeStamp: itemModel.updateTime)
            let font = Item14195TextView.timeLabelFont()
            let HHssTextSize = calcStringSize(HHss, font: font, size: limitSize)
            let layout = TextLayoutModel.init()
            layout.boundingSize = size
            layout.renderRect = CGRect.init(x: textX, y: padding, width: HHssTextSize.width, height: HHssTextSize.height)
            
            item?.layout?.extendExtra?["timeLabel"] = layout
        }
        
        if let summary = itemModel.summary?.text, !summary.isEmpty {
            let padding = YKNGap.dim_6()
            var textX: CGFloat = padding
            if let timeLabelLayout = item?.layout?.extendExtra?["timeLabel"] as? TextLayoutModel {
                let timeWidth = timeLabelLayout.renderRect.size.width
                if timeWidth > 0 {
                    textX = timeLabelLayout.renderRect.maxX + YKNGap.dim_4()
                }
            } else if let dateLabelLayout = item?.layout?.extendExtra?["dateLabel"] as? TextLayoutModel {
                let dateWidth = dateLabelLayout.renderRect.size.width
                if dateWidth > 0 {
                    textX = dateLabelLayout.renderRect.maxX + YKNGap.dim_4()
                }
            }
            let limitSize = CGSize.init(width: max(0, (size.width - textX - padding)), height: max(0, (size.height - padding * 2)))
            
            let font = Item14195TextView.summaryLabelFont()
            let summaryTextSize = calcStringSize(summary, font: font, size: limitSize)
            let layout = TextLayoutModel.init()
            layout.boundingSize = size
            layout.renderRect = CGRect.init(x: max(0, size.width - padding - summaryTextSize.width),
                                            y: padding,
                                            width: summaryTextSize.width,
                                            height: summaryTextSize.height)
            
            item?.layout?.extendExtra?["summaryLabel"] = layout
        }
    }

}
