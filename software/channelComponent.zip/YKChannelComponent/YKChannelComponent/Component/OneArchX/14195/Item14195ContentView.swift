//
//  Item14195ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/3/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku
//import YKChannelBase
import YKUIComponent
import YKSCBase

protocol Item14195TextViewProtocol: UIView {
    //2.0 接口
    func fillModel(_ itemModel: HomeItemModel, layout: OneArchSupport4Youku.LayoutModel)
    
    //1.0 接口
    //func fillItemContext(_ itemContext: YKSCItemContext)
    
    func timeString() -> String?
}

class Item14195ImageView: UIImageGIFView{
    var identifier: String = ""
}

class Item14195ContentView: UIView, Item14195TrackShowButtonDelegate{
    
    //MARK: - Property
    lazy var imageView: Item14195ImageView = {
        let imageView = Item14195ImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .ykn_primaryFill
        imageView.clipsToBounds = true
        imageView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        imageView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return imageView
    }()

    lazy var bottomView: UIView = {
        let view = UIView.init()
        return view
    }()
    
    lazy var textView: Item14195TextViewProtocol = {
        let view = createTextView()
        return view
    }()
    
    lazy var titleLabel:CalendarTitleLabel = {
        let view = CalendarTitleLabel.init(frame: CGRect.init(x: 0, y: 0, width: 57, height: 23))
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        layer.cornerRadius = YKNCorner.radius_secondary_medium()
        layer.masksToBounds = true
        
        addSubview(imageView)
        addSubview(bottomView)
        addSubview(textView)
        addSubview(titleLabel)
        
        let imageViewHeight: CGFloat = width * (4.0 / 3.0)
        imageView.frame = CGRect.init(x: 0, y: 5, width: width, height: imageViewHeight)

        let bottomViewHeight: CGFloat = YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1) + YKNGap.dim_5() + 1.0
        bottomView.frame = CGRect.init(x: 0, y: height - bottomViewHeight, width: width, height: bottomViewHeight)
    }
    
    func trackShowButtonRenderSizeDidChange() {
        let bottomViewHeight: CGFloat = YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1) + YKNGap.dim_5() + 3.0 + 25.0
        bottomView.frame = CGRect.init(x: 0, y: height - bottomViewHeight, width: width, height: bottomViewHeight)
        self.textView.frame = self.bounds
    }
    
    func fillModel(_ itemModel: HomeItemModel, layout: OneArchSupport4Youku.LayoutModel) {
        guard let model = itemModel as? Item14195Model else {
            return
        }
        //填充背景图
        var imgPath = itemModel.gifImg
        if imgPath == nil {
            imgPath = itemModel.img
        }
        fillImage(imgPath)
        
        //填充文字
        textView.fillModel(itemModel, layout: layout)

        //title
        let text = textView.timeString() ?? ""
        titleLabel.isHidden = text.isEmpty
        titleLabel.setData(title: text)
        titleLabel.setTitleSize(model.tagTitleSize)
        titleLabel.label.font = model.tagFont
        
        if let type = model.type, type == "14306" {
            if let title = itemModel.mark?.text {
                titleLabel.setData(title: title)
            } else {
                titleLabel.isHidden = true
            }
        }
        //绑定跳转、埋点
        OneArchSupport.Service.action.bind(itemModel.action, self)
    }
    
//    func fillItemContext(_ itemContext: YKSCItemContext) {
//        //填充背景图
//        let imgPath = itemContext.scString(forKey: YKSCItemDataImagePath)
//        fillImage(imgPath)
//
//        //填充文字
//        textView.fillItemContext(itemContext)
//
//        //绑定跳转、埋点
//        Service.action.bind(itemContext.model.action, self)
//    }
    
    func fillImage(_ imgPath: String?) {
        fillThemeColor(UIColor.black.withAlphaComponent(0.6))
        imageView.identifier = imgPath ?? ""
        imageView.ykn_setImage(withURLString: imgPath,
                               module: "nodepage",
                               imageSize: .zero,
                               parameters: [String: Any]()) { (image, error, info) in
            guard let image = image else {
                return
            }
            
            image.yk_averageColor(withSaturationMin: 0.2 * 1.2, max: 0.45 * 1.2, lightnessMin: 0.35 * 0.7, max: 0.5 * 0.7) { color in
                guard let color = color else {
                    return
                }
                
                if imgPath == self.imageView.identifier {
                    self.fillThemeColor(color)
                }
            }
        }
    }
    
    func fillThemeColor(_ color: UIColor) {
        self.bottomView.backgroundColor = color
//        YKChannelBase.Service.viewInnerGradient.attach(.top,
//                                                       toView: imageView,
//                                                       scope: 40,
//                                                       startColor: color.withAlphaComponent(0.0),
//                                                       endColor: color)
        
        
        OneArchSupport.Service.viewInnerGradient.attach(ViewInnerGradientSide.bottom, toView: imageView, scope: 40, startColor: color.withAlphaComponent(0.0), endColor: color)
        
        if let view = imageView.viewWithTag(19000310 + 2) {
            view.bottom = imageView.height
        }

        titleLabel.setColor(color: color)
    }
    
    func createTextView() -> Item14195TextViewProtocol {
        let view = Item14195TextView.init(frame: self.bounds)
        view.delegate = self
        return view
    }
}

