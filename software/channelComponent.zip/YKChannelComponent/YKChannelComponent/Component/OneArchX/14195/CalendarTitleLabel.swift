//
//  CalendarTitleLabel.swift
//  YKChannelComponent
//
//  Created by better on 2023/2/3.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource

class CalendarTitleRightView: UIView {
    
    var leftView: UIView?
    var circleView: UIView?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.clipsToBounds = true
        
        let w: CGFloat = self.width
        let h: CGFloat = self.height
        
        let circle = UIView.init(frame: CGRect(x: 0, y: 0, width: w, height: w))
        circle.layer.cornerRadius = w / 2.0
        circle.clipsToBounds = true
        circle.backgroundColor = .red
        circle.alpha = 0.4
        self.addSubview(circle)

        let lv = UIView.init(frame: CGRect.init(x: 0, y: 0, width: h, height: h))
        lv.backgroundColor = .blue
        let layer = CAShapeLayer()
        let cornerRect = CGRect(x: 0, y: 0, width: w, height: w)
        let path = UIBezierPath(roundedRect: cornerRect, cornerRadius:0)
        let rpath = UIBezierPath(roundedRect: cornerRect, cornerRadius: w/2.0).reversing()
        path.append(rpath)
        layer.path = path.cgPath
        lv.layer.mask = layer
        self.addSubview(lv)
        
        self.leftView = lv
        self.circleView = circle
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

class CalendarTitleLabel: UIView {

    lazy var label: UILabel = {
        let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 47, height: 23))
        label.layer.cornerRadius = 7
        label.clipsToBounds = true
        label.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMaxYCorner]
        label.textAlignment = .center
        label.font = YKNFont.qyDigitalSemiBoldFont(ofSize: 18 * YKNSize.yk_icon_size_scale())
        YKNFont.module_headline_linktext_weight(.semibold)
        label.textColor = .white
        return label
    }()
    
    lazy var rightView: CalendarTitleRightView = {
        let view = CalendarTitleRightView.init(frame: CGRect.init(x: self.label.right, y: 0, width: 10, height: 5))
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(label)
        self.addSubview(rightView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setData(title: String?) {
        self.label.text = title
        self.isHidden = (title?.count ?? 0 > 0) ? false: true
    }
    
    func setColor(color: UIColor?) {
        self.label.backgroundColor = color
        self.rightView.leftView?.backgroundColor = color
        self.rightView.circleView?.backgroundColor = color
    }
    
    func setTitleSize(_ size: CGSize) {
        self.width = YKNGap.dim_5() * 2 + size.width + 10
        self.height = max(23, size.height + YKNGap.dim_4())
        self.label.width = self.width - 10
        self.label.height = self.height
        self.rightView.left = self.label.right
    }
    
}
