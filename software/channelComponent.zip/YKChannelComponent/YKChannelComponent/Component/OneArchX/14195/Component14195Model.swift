//
//  Component14195Model.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/7/25.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku

class Component14195Model: BaseComponentModel {

    var disableAutomaticTimeAnchor :Bool = false
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        
        if let disableAutomaticTimeAnchor = dataInfo["disableAutomaticTimeAnchor"] as? Int, disableAutomaticTimeAnchor == 1 {
            self.disableAutomaticTimeAnchor = true
        } else if let disableAutomaticTimeAnchor = dataInfo["disableAutomaticTimeAnchor"] as? Bool, disableAutomaticTimeAnchor == true {
            self.disableAutomaticTimeAnchor = true
        } else if let disableAutomaticTimeAnchor = dataInfo["disableAutomaticTimeAnchor"] as? String, disableAutomaticTimeAnchor == "1" {
            self.disableAutomaticTimeAnchor = true
        }
    }
}
