//
//  Item14195Model.swift
//  YKChannelComponent
//
//  Created by better on 2023/2/6.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Item14195Model: HomeItemModel {

    public var tagTitle: String?
    public var tagTitleSize: CGSize = .zero
    public var tagFont: UIFont?
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
    
        let time = Item14192ContentView.getDateFormatString(timeStamp: self.updateTime)
        if let date = self.desc {
            self.tagTitle = "\(date)\(time)"
        } else {
            self.tagTitle = time
        }
    }
}
