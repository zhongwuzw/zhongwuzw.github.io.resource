//
//  Item14195TextView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/3/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArchSupport4Youku
import YKModeConfigFramework
//import YKChannelBase

protocol Item14195TrackShowButtonDelegate: UIView {
    
    func trackShowButtonRenderSizeDidChange()
}

class Item14195TextView: UIView, Item14195TextViewProtocol{
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = UIColor.white
        view.font = YKNFont.posteritem_maintitle_weight(.semibold)
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = UIColor.white.withAlphaComponent(0.8)
        view.font = YKNFont.posteritem_subhead()
        view.textAlignment = .left
        return view
    }()

    lazy var dateLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = UIColor.white
        view.font = Item14195TextView.dateLabelFont()
        return view
    }()
     
    lazy var timeLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = UIColor.white
        view.font = Item14195TextView.timeLabelFont()
        return view
    }()
    
    lazy var summaryLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = UIColor.white.withAlphaComponent(0.8)
        view.font = Item14195TextView.summaryLabelFont()
        view.textAlignment = .right
        return view
    }()
    
    lazy var trackShowView: Item14195TrackShowView = {
        let view = Item14195TrackShowView.init()
        return view
    }()
    
    var hasTrackShowView: Bool = false
    
    weak var delegate: Item14195TrackShowButtonDelegate?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    class func dateLabelFont() -> UIFont {
        let font = YKNFont.posteritem_maintitle_weight(.semibold)
        
        //内容拥挤，设置极限放大倍数，但底层SDK不支持，业务上层尽可能地兼容
        let fullScale = YKFontModeManager.sharedInstance().getFontScale()
        let maxFullScale: CGFloat = 1.2
        if fullScale > 1.1 {
            let newPointSize = CGFloat(floor(font.pointSize / fullScale * maxFullScale))
            return UIFont.systemFont(ofSize: newPointSize, weight: .semibold)
        } else {
            return font
        }
    }
    
    class func timeLabelFont() -> UIFont {
        let font = YKNFont.akrobatExtraBoldFont(ofSize: YKNFont.display_s().pointSize)
        
        //内容拥挤，设置极限放大倍数，但底层SDK不支持，业务上层尽可能地兼容
        let fullScale = YKFontModeManager.sharedInstance().getFontScale()
        let maxFullScale: CGFloat = 1.2
        if fullScale > 1.1 {
            let newPointSize = CGFloat(floor(font.pointSize / fullScale * maxFullScale))
            return YKNFont.akrobatExtraBoldFont(ofSize: newPointSize)
        } else {
            return font
        }
    }
    
    class func summaryLabelFont() -> UIFont {
        let font = YKNFont.module_headline_linktext()
        
        //内容拥挤，设置极限放大倍数，但底层SDK不支持，业务上层尽可能地兼容
        let fullScale = YKFontModeManager.sharedInstance().getFontScale()
        let maxFullScale: CGFloat = 1.2
        if fullScale > 1.1 {
            let newPointSize = CGFloat(floor(font.pointSize / fullScale * maxFullScale))
            return UIFont.systemFont(ofSize: newPointSize, weight: .regular)
        } else {
            return font
        }
    }
    
    func setupSubviews() {
        addSubview(titleLabel)
        addSubview(subtitleLabel)
        addSubview(trackShowView)
        //addSubview(dateLabel)
        //addSubview(timeLabel)
        //addSubview(summaryLabel)
    }
    
    func setupSubviewsIfNeeded() {
        let textLeftPadding: CGFloat = YKNGap.dim_5()
        let textRightPadding: CGFloat = textLeftPadding
        let textWidth: CGFloat = self.width - textLeftPadding - textRightPadding
        
        //subtitle
        let subtitleHeight: CGFloat = YKNFont.height(with: subtitleLabel.font, lineNumber: 1)
        var subtitleY: CGFloat = self.height - YKNGap.dim_6() - subtitleHeight
        if hasTrackShowView{
            subtitleY = subtitleY - 25.0
        }
        subtitleLabel.frame = CGRect.init(x: textLeftPadding, y: subtitleY, width: textWidth, height: subtitleHeight)
        
        //title
        let titleHeight: CGFloat = YKNFont.height(with: titleLabel.font, lineNumber: 1)
        let titleY: CGFloat = subtitleLabel.frame.minY - YKNGap.youku_maintitle_subtitle_spacing() - titleHeight
        titleLabel.frame = CGRect.init(x: textLeftPadding, y: titleY, width: textWidth, height: titleHeight)
        
        //date
        let dateHeight: CGFloat = YKNFont.height(with: dateLabel.font, lineNumber: 1)
        let dateY: CGFloat = YKNGap.dim_5()
        dateLabel.frame = CGRect.init(x: textLeftPadding, y: dateY, width: textWidth, height: dateHeight)
        
        //time
        let timeHeight: CGFloat = YKNFont.height(with: dateLabel.font, lineNumber: 1)
        let timeY: CGFloat = YKNGap.dim_5()
        timeLabel.frame = CGRect.init(x: textLeftPadding + 50, y: timeY, width: textWidth, height: timeHeight)
        
        //summary
        let summaryHeight: CGFloat = YKNFont.height(with: summaryLabel.font, lineNumber: 1)
        let summaryY: CGFloat = YKNGap.dim_5()
        summaryLabel.frame = CGRect.init(x: textLeftPadding, y: summaryY, width: textWidth, height: summaryHeight)
    }
    
    func timeString() -> String? {
        return itemModel?.tagTitle
    }
    
    var itemModel: Item14195Model?
    
    func fillModel(_ itemModel: HomeItemModel, layout: OneArchSupport4Youku.LayoutModel) {
        self.itemModel = itemModel as? Item14195Model
    
        titleLabel.text = itemModel.title
        subtitleLabel.text = itemModel.subtitle
        dateLabel.text = itemModel.desc
        timeLabel.text = Item14192ContentView.getDateFormatString(timeStamp: itemModel.updateTime)
        summaryLabel.text = itemModel.summary?.text ?? ""
        
        if let dateLayout = layout.extendExtra?["dateLabel"] as? OneArchSupport4Youku.TextLayoutModel {
            dateLabel.frame = dateLayout.renderRect
        } else {
            dateLabel.frame = .zero
        }
        if let timeLayout = layout.extendExtra?["timeLabel"] as? OneArchSupport4Youku.TextLayoutModel {
            timeLabel.frame = timeLayout.renderRect
            timeLabel.centerY = dateLabel.centerY + 1 //日期与时间水平对齐
        } else {
            timeLabel.frame = .zero
        }
        if let summaryLayout = layout.extendExtra?["summaryLabel"] as? OneArchSupport4Youku.TextLayoutModel {
            summaryLabel.frame = summaryLayout.renderRect
        } else {
            summaryLabel.frame = .zero
        }
        
        self.subtitleLabel.text = itemModel.summary?.text ?? ""
        if let type = self.itemModel?.type, type == "14306" {
            self.subtitleLabel.text = itemModel.subtitle
        }
        
        setupSubviewsIfNeeded()
        self.trackShowView.isHidden = true
        if let itemModel = self.itemModel{
            if let _ = itemModel.trackShow{
                self.trackShowView.isHidden = false
                hasTrackShowView = true
                self.trackShowView.fillModel(itemModel)
                self.delegate?.trackShowButtonRenderSizeDidChange()
                setupSubviewsIfNeeded()
                layoutTrackShowView()
            }
        }
    }
    
    func layoutTrackShowView() {
        let textLeftPadding: CGFloat = YKNGap.dim_5()
        let textRightPadding: CGFloat = textLeftPadding
        //trackShowView
        let trackShowViewY: CGFloat = subtitleLabel.frame.maxY + YKNGap.youku_maintitle_subtitle_spacing()
        trackShowView.frame = CGRect.init(x: textLeftPadding, y: trackShowViewY, width: self.width - textLeftPadding - textRightPadding, height: 25)
        trackShowView.titleLabel.frame = trackShowView.bounds
    }

//    func fillItemContext(_ itemContext: YKSCItemContext) {
//        let itemModel = itemContext.model
//        titleLabel.text = itemModel.title
//        subtitleLabel.text = itemModel.subtitle
//        dateLabel.text = itemModel.desc
//
//        let updateTime = itemModel.homeModel?.updateTime ?? 0
//        timeLabel.text = Item14192ContentView.getDateFormatString(timeStamp: updateTime)
//        summaryLabel.text = itemModel.summary?.text ?? ""
//
//        let layout = itemContext.layoutModel
//        if let dateLayout = layout.extendExtra?["dateLabel"] as? YKChannelBase.TextLayoutModel {
//            dateLabel.frame = dateLayout.renderRect
//        } else {
//            dateLabel.frame = .zero
//        }
//        if let timeLayout = layout.extendExtra?["timeLabel"] as? YKChannelBase.TextLayoutModel {
//            timeLabel.frame = timeLayout.renderRect
//            timeLabel.centerY = dateLabel.centerY + 1 //日期与时间水平对齐
//        } else {
//            timeLabel.frame = .zero
//        }
//        if let summaryLayout = layout.extendExtra?["summaryLabel"] as? YKChannelBase.TextLayoutModel {
//            summaryLabel.frame = summaryLayout.renderRect
//        } else {
//            summaryLabel.frame = .zero
//        }
//    }
}
