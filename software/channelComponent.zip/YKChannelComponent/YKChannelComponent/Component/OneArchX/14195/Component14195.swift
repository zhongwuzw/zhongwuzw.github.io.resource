//
//  Component14195.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/3/28.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource

class Component14195: NSObject, ComponentDelegate {

    var componentWrapper: ComponentWrapper?
    
    var autoSelectedOnceFlag = false
    
    public func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Component14195Model.self as? T.Type
    }

    func componentDidInit() {
        
    }
    
    func isShowHeader() -> Bool {
        return false
    }
    
    func headerTag() -> String? {
        return nil
    }
    
    func layoutType() -> ComponentLayoutType {
        return .horizontalScroll
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom(), right: 0)
        config.preferredCardSpacingTop = 0.0
        config.headerBottomMargin = 0.0
        config.rowSpacing = 0.0
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.footerTopMargin = 0.0
        config.preferredRowHeight = 0.0
        config.horizontalPaddingLeft = YKNGap.youku_margin_left()
        config.horizontalPaddingRight = YKNGap.youku_margin_right()
        config.backgroundLeftMarginOffset = 0
        config.backgroundRightMarginOffset = 0
        config.headerLeftMarginOffset = 0
        config.headerRightMarginOffset = 0
        config.backgroundTopMargin = 0
        return config
    }
    
    func columnCount() -> CGFloat {
        return 3
    }
    
    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        guard autoSelectedEnabled() else {
            return
        }
        
        guard autoSelectedOnceFlag == false else {
            return
        }
        
        let itemsCount = component?.getItems()?.count ?? 0
        guard itemsCount > 2 else {
            return
        }
        
        let autoSelectedIndex = autoSelectedIndex()
        guard autoSelectedIndex > 0 && autoSelectedIndex < itemsCount else {
            return
        }
        
        guard let selectedItem = component?.getItems()?[autoSelectedIndex] else {
            return
        }
        
        selectedItem.scrollTo(at: .left, animated: false)
        
        autoSelectedOnceFlag = true
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
    
    func autoSelectedEnabled() -> Bool {
        guard let model = self.component?.model as? Component14195Model else {
            return true
        }
        
        if model.disableAutomaticTimeAnchor {
            return false
        }
        
        return true
    }
    
    func autoSelectedIndex() -> Int {
        guard let items = component?.getItems() else {
            return -1
        }
        
        let models: [HomeItemModel] = items.map { aItem in
            aItem.homeItemModel ?? HomeItemModel()
        }
        
        var selectedIndex: Int = -1
        let nowTimestamp = Int(Date().timeIntervalSince1970)
        let nowHH = Component14195.timeIntervalToTimeString(timeInterval: nowTimestamp, "ddHH")
        for (index, aModel) in models.enumerated() {
            let currentUpdateTime = aModel.updateTime
            let currentUpdateTimeHH = Component14195.timeIntervalToTimeString(timeInterval: currentUpdateTime, "ddHH")
            if nowHH == currentUpdateTimeHH {
                selectedIndex = index
                break
            }
            
            if currentUpdateTime > nowTimestamp {
                selectedIndex = index
                break
            }
        }
        
        return selectedIndex
    }
    
    static func timeIntervalToTimeString(timeInterval: Int, _ dateFormat:String? = "yyyy-MM-dd HH:mm:ss") -> String {
        let date:Date = Date.init(timeIntervalSince1970: Double(timeInterval))
        let formatter = DateFormatter.init()
        formatter.dateFormat = dateFormat
        return formatter.string(from: date as Date)
    }
}
