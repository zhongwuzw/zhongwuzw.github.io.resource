//
//  Item14157Model.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/7/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku

class Item14157Model: BaseItemModel {
    
    var isBottomRoundCorner: Bool = false
    
    /// 是否在首页频道上的组件
    var isDisplayInChannel = false
    
    /// 剧场标
    var logo: String = ""
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        
        if let extraExtend = dataInfo["extraExtend"] as? [String: Any],
           let width = extraExtend["width"] as? CGFloat, width > 0,
           let height = extraExtend["height"] as? CGFloat, height > 0
        {
            self.imgRatio = height / width
        } else {
            self.imgRatio = 240.0 / 375.0
        }
        
        if let isBottomRoundCorner = dataInfo["isBottomRoundCorner"] as? Bool {
            self.isBottomRoundCorner = isBottomRoundCorner
        }
        
        if let logo = dataInfo["logo"] as? String {
            self.logo = logo
        }
    }
    
}
