//
//  Item14157ContentView.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/7/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import SDWebImage
import YKResponsiveLayout
import OneArch
import OneArchSupport

class Item14157GradientView: UIView {
    
    override final class var layerClass: AnyClass {
        get {
            return CAGradientLayer.self
        }
    }
    
    override var layer: CAGradientLayer {
        return super.layer as! CAGradientLayer
    }
    
    var colors: (start: UIColor, end: UIColor)? {
        didSet { updateLayer() }
    }

    private func updateLayer() {
        layer.colors = colors.map { [$0.start.cgColor, $0.end.cgColor] }
    }
    
}

class Item14157ImageView: UIImageGIFView {
    var identifier: String = ""
}

class Item14157ContentView: UIView, ItemImmersionBackgroundViewContainer {

    //MARK: - Property
    lazy var imageView: Item14157ImageView = {
        let imageView = Item14157ImageView.init(frame: CGRect.zero)
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    
    lazy var logoImageView: Item14157ImageView = {
        let imageView = Item14157ImageView.init(frame: CGRect.zero)
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .clear
        return imageView
    }()
    
    lazy var contentView: UIView = {
        let view = UIView()
        return view
    }()
        
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 30, weight: .regular)
        label.textAlignment = .left
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var subtitleLabel: UILabel = {
        let label = UILabel()
        label.font = YKNFont.posteritem_subhead()
        label.textAlignment = .left
        label.textColor = .white.withAlphaComponent(0.7)
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var descLabel: UILabel = {
        let label = UILabel()
        label.font = YKNFont.font_size_middle4()
        label.textAlignment = .left
        label.textColor = .white
        label.numberOfLines = 1
        label.lineBreakMode = .byTruncatingTail
        label.isUserInteractionEnabled = true
        return label
    }()
    
    lazy var iconImageView: UIImageGIFView = {
        let imageView = UIImageGIFView.init(frame: CGRect.zero)
        imageView.contentMode = .scaleAspectFit
        imageView.clipsToBounds = true
        return imageView
    }()
    
    lazy var gradientView: Item14157GradientView = {
        let view = Item14157GradientView()
        view.layer.locations = [0.0, 1.0]
        return view
    }()
    
    lazy var bottomRoundSpacingView: UIView = {
        let view = UIView()
        
        view.backgroundColor = UIColor.ykn_primaryBackground
        
        let maskFrame = CGRect.init(x: 0, y: 0, width: self.width, height: 50)
        let maskPath = UIBezierPath.init(roundedRect: maskFrame,
                                         byRoundingCorners: [.topLeft, .topRight],
                                         cornerRadii: CGSize.init(width: 14, height: 14))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = maskFrame
        maskLayer.path = maskPath.cgPath
        
        view.layer.mask = maskLayer
        
        return view
    }()
    
    private var imageMaskColor: UIColor?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(imageView)
        addSubview(gradientView)
        addSubview(contentView)
        
        contentView.addSubview(logoImageView)
        contentView.addSubview(iconImageView)
        contentView.addSubview(titleLabel)
        contentView.addSubview(subtitleLabel)
        contentView.addSubview(descLabel)
        contentView.addSubview(bottomRoundSpacingView)
        
        imageView.frame = self.bounds
        gradientView.frame = CGRect.init(origin: .zero, size: .init(width: self.bounds.width, height: 30))
        
        let statusBarOffset = STATUSBAR_HEIGHT - 20
        contentView.frame = CGRect.init(x: 0, y: statusBarOffset, width: self.width, height: self.height - statusBarOffset)
        
        let padding: CGFloat = YKNGap.youku_margin_left()
        titleLabel.frame = CGRect.init(x: padding, y: (64), width: self.width - 2 * padding, height: 37)
        subtitleLabel.frame = CGRect.init(x: padding, y: (100), width: self.width - 2 * padding, height: 17)
        descLabel.frame = CGRect.init(x: padding, y: (126), width: self.width - 2 * padding, height: 17)
    }
    
    func fillData(_ itemModel: Item14157Model) {
        // fill image
        fillImage(itemModel)
        
        // fill texts
        titleLabel.text = itemModel.title
        subtitleLabel.text = itemModel.subtitle
        descLabel.text = itemModel.desc
        
        // layout
        layoutWithData(itemModel)
        
        // fill logo (执行时序保证在layout之后)
        if !ykrl_isResponsiveLayout() {
            iconImageView.isHidden = false
            logoImageView.isHidden = true
        } else if !itemModel.logo.isEmpty  {
            iconImageView.isHidden = true
            logoImageView.isHidden = false
            fillLogoImage(itemModel.logo)
        } else {
            iconImageView.isHidden = true
            logoImageView.isHidden = true
        }
        
        Service.action.bind(itemModel.action, self)
    }
    
    func fillImage(_ itemModel: Item14157Model) {
        var imgPath = itemModel.gifImg ?? itemModel.img
        
        if ykrl_isResponsiveLayout(), let bgImage = itemModel.bgImg, !bgImage.isEmpty {
            imgPath = bgImage
        }
        
        if !imageView.identifier.isEmpty, imageView.identifier == imgPath {
            return //重复图片，无需重复加载，避免闪动一次白色底色。
        }
        
        imageView.identifier = imgPath ?? ""
        
        var params = [String : Any]()
        params["fade"] = true
        
        imageView.ykn_setImage(withURLString: imgPath, module: "nodepage", imageSize: .zero, parameters: params, completed: nil)
        imageView.autoresizingMask = [.flexibleHeight, .flexibleWidth]
    }
    
    func fillLogoImage(_ imgPath: String?) {
        if !logoImageView.identifier.isEmpty, logoImageView.identifier == imgPath {
            return //重复图片，无需重复加载，避免闪动一次白色底色。
        }
        
        logoImageView.identifier = imgPath ?? ""
        
        var params = [String : Any]()
        params["fade"] = true

        weak var weakSelf = self
        logoImageView.ykn_setImage(withURLString: imgPath, module: "nodepage", imageSize: .zero, parameters: params) { (image, error, info) in
            if let strongSelf = weakSelf,
               let image = image,
               image.size.height > 0 {
                
                //图片实际宽度适配，仅保留X,Y,Height
                let imageRenderHeight: CGFloat = strongSelf.logoImageView.bounds.height
                let imageRenderWidth: CGFloat = ceil(image.size.width/image.size.height * imageRenderHeight)
                let imageRenderX: CGFloat = ceil(self.bounds.size.width - imageRenderWidth) / 2
                let imageRenderY: CGFloat = YKNGap.dim_10()
                strongSelf.logoImageView.frame = CGRect.init(origin: .init(x: imageRenderX, y: imageRenderY), size: CGSize.init(width: imageRenderWidth, height: imageRenderHeight))
            }
        }
    }
    
    func layoutWithData(_ itemModel: Item14157Model) {
        if itemModel.isDisplayInChannel {
            gradientView.isHidden = false
            if let topColor = itemModel.scene?.componentGradientTopColor(),
               let bottomColor = itemModel.scene?.componentGradientBottomColor() {
                gradientView.colors = (topColor, bottomColor)
            }
        } else {
            gradientView.isHidden = true
        }
        
        let isBottomRoundCorner = itemModel.isBottomRoundCorner
        if isBottomRoundCorner {
            bottomRoundSpacingView.isHidden = false
            
            let w: CGFloat = contentView.width
            let h: CGFloat = nodePageHeaderCompoenentBottomRoundSpacingHeight()
            let x: CGFloat = 0
            let y: CGFloat = contentView.height - h
            
            bottomRoundSpacingView.frame = CGRect.init(x: x, y: y, width: w, height: h)
            bottomRoundSpacingView.backgroundColor = itemModel.scene?.sceneBgColor() ?? UIColor.ykn_primaryBackground
        } else {
            bottomRoundSpacingView.isHidden = true
        }
        
        let padding: CGFloat = YKNGap.youku_margin_left()
        
        if !itemModel.logo.isEmpty, !logoImageView.isHidden {
            // logo宽度取决于图片加载后保持宽高比例计算
            let logoSize = CGSize.init(width: logoImageView.bounds.width, height: 74)
            let logoX: CGFloat = ceil(self.bounds.size.width - logoSize.width) / 2
            let logoY: CGFloat = YKNGap.dim_10()
    
            logoImageView.frame = CGRect.init(origin: .init(x: logoX, y: logoY), size: logoSize)
        }
        
        
        let textWidth: CGFloat = self.width - 2 * padding
        
        if let iconURL = itemModel.icon, !iconURL.isEmpty, !ykrl_isResponsiveLayout(), !iconImageView.isHidden {
            titleLabel.isHidden = true
            iconImageView.isHidden = false
            
            let imageRenderHeight: CGFloat = 38
            let iconY: CGFloat = 91
            iconImageView.frame = CGRect.init(x: padding, y: iconY, width: self.width, height: imageRenderHeight)
            weak var weakSelf = self
            
            var params = [String : Any]()
            params["fade"] = true
            params["placeholderColor"] = UIColor.clear
            
            iconImageView.ykn_setImage(withURLString: iconURL, module: "nodepage", imageSize: .zero, parameters: params) { (image, error, info) in
                if let strongSelf = weakSelf,
                   let image = image,
                   image.size.height > 0 {
                    
                    //先恢复正常
                    strongSelf.iconImageView.frame = CGRect.init(x: 0, y: iconY, width: strongSelf.width, height: imageRenderHeight)
                    //再往左平移
                    let imageRenderWidth: CGFloat = image.size.width/image.size.height * imageRenderHeight
                    strongSelf.iconImageView.left = YKNGap.youku_margin_left() + (imageRenderWidth - strongSelf.width) * 0.5
                }
            }
            
            let subtitleY: CGFloat = iconImageView.frame.maxY + 3
            subtitleLabel.frame = CGRect.init(x: padding, y: subtitleY, width: textWidth, height: 17)
            
            let descY: CGFloat = subtitleLabel.frame.maxY + YKNGap.dim_7()
            descLabel.frame = CGRect.init(x: padding, y: descY, width: textWidth, height: 17)
        } else {
            titleLabel.isHidden = false
            iconImageView.isHidden = true
            
            let titleY: CGFloat = 91
            titleLabel.frame = CGRect.init(x: padding, y: titleY, width: textWidth, height: 42)
            
            let subtitleY: CGFloat = titleLabel.frame.maxY + 3
            subtitleLabel.frame = CGRect.init(x: padding, y: subtitleY, width: textWidth, height: 17)
            
            let descY: CGFloat = subtitleLabel.frame.maxY + YKNGap.dim_7()
            descLabel.frame = CGRect.init(x: padding, y: descY, width: textWidth, height: 17)
        }
    }

    // MARK: ItemImmersionBackgroundViewContainer
    func immersionBackgroundView() -> UIView {
        return imageView
    }
}
