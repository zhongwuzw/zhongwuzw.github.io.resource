//
//  Item14157.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2022/7/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Item14157: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T: NodeModel>() -> T.Type? {
        return Item14157Model.self as? T.Type
    }
    
    func itemDidInit() {
        guard let itemModel = item?.itemModel as? Item14157Model else {
            return
        }
        
        if let card = item?.getCard(), let cardModel = card.cardModel {
            if let isDisplayInChannel = cardModel.extraExtend["displayInChannel"] as? Bool {
                itemModel.isDisplayInChannel = isDisplayInChannel
                
                if isDisplayInChannel {
                    //上顶导固定宽高
                    itemModel.imgRatio = 175.0 / 375.0
                    
                    //上顶导专用图片
                    if let bgImg = itemModel.extraExtend["bgImg"] as? String {
                        itemModel.img = bgImg
                    }
                }
            }
        }
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return backgroundImageSize().height
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item14157ContentView.init(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item14157ContentView else {
            return
        }
        guard let itemModel = self.item?.model as? Item14157Model else {
            return
        }

        itemView.fillData(itemModel)
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [
            ItemImmersionBackgroundAdapterPlugin()
        ]
    }
    
    func backgroundImageSize() -> CGSize {
        if ykrl_isResponsiveLayout() {
            if let model = self.item?.model as? Item14157Model, model.isDisplayInChannel {
                return .zero
            } else {
                return .init(width: YKRLScreenWidth(), height: 110)
            }
        }
        
        var itemHeight: CGFloat = 200.0
        let statusBarOffset = YKStatusBarHeight() - 20
        itemHeight += statusBarOffset
        
        if let model = self.item?.model as? Item14157Model {
            if model.isBottomRoundCorner {
                itemHeight += nodePageHeaderCompoenentBottomRoundSpacingHeight()
            }
            
            if let ratio = model.imgRatio, ratio > 0.1 {
                itemHeight = YKRLScreenWidth() * ratio
            }
        }
        
        return .init(width: YKRLScreenWidth(), height: itemHeight)
    }

}
