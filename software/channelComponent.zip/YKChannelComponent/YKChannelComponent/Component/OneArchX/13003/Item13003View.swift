//
//  Item13003View.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import OneArchSupport4Youku

class Item13003View: AccessibilityView {
    
    lazy var bgView:UIView = {
        let view = UIView()
        view.backgroundColor = .ykn_primaryFill
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var titleLabel:UILabel = {
        let width = ykrl_isResponsiveLayout() ? 32 : 26
        let height = ykrl_isResponsiveLayout() ? 20 : 17
        let label = UILabel.init(frame:CGRect.init(x: 0, y: 0, width: width, height: height))
        label.font = YKNFont.posteritem_subhead()
        label.textAlignment = .center
        label.textColor = UIColor.ykn_tertiaryInfo
        return label
    }()
    
    lazy var moreIcon:UIImageView = {
        let icon = UIImageView.init(frame:CGRect.init(x: 0, y: 0, width: 12, height: 12))
        icon.image = UIImage.init(named: "ykn_more_btn")?.withRenderingMode(.alwaysTemplate)
        icon.tintColor = .ykn_secondaryInfo
        return icon
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.bgView)
        self.addSubview(self.titleLabel)
        self.addSubview(self.moreIcon)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(item:IItem?, ratio:CGFloat) {
        guard let itemModel = item?.model as? BaseItemModel else {
            return
        }
        self.titleLabel.text = itemModel.title ?? "更多"
        self.bgView.frame = CGRect.init(x: 0, y: 0, width: self.width, height: self.width / ratio)
        self.titleLabel.sizeToFit()
        self.titleLabel.center = CGPoint.init(x: self.bgView.width/2.0, y: self.bgView.height/2.0)
        self.moreIcon.left = self.titleLabel.right
        self.moreIcon.centerY = self.titleLabel.centerY
        //氛围
        let scene = itemModel.scene
        self.bgView.backgroundColor = sceneUtil(.ykn_secondaryBackground, sceneColor: scene?.sceneCardFooterBgColor())
        self.titleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: scene?.sceneCardFooterTitleColor())
        self.moreIcon.tintColor = sceneUtil(.ykn_secondaryInfo, sceneColor: scene?.sceneCardFooterTitleColor())
    }
}
