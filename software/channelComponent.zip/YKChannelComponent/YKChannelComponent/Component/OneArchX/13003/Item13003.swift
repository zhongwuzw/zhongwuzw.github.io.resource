//
//  Item13003.swift
//  YKChannelComponent
//
//  Created by better on 2022/1/1.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout
import YoukuAnalytics
import YoukuResource

class Item13003: NSObject, ItemDelegate {

    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {

    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }

    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let ratio = getImageAspectRatio()
        let videoImageHeight = ceil(itemWidth / ratio)
        return videoImageHeight
    }

    func getImageAspectRatio() -> CGFloat {
        guard let componentModel = self.item?.getComponent()?.model as? BaseComponentModel else {
            return 0.75
        }
        guard let aspectRatio = componentModel.extraExtend["aspectRatio"] as? Double else {
            return 0.75
        }
        return CGFloat(aspectRatio)
    }

    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item13003View(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemModel = self.item?.model as? BaseItemModel else {
            return
        }
        guard let itemView = itemView as? Item13003View else {
            return
        }
        Service.action.bind(itemModel.action, itemView)
        itemView.fillData(item:self.item, ratio:getImageAspectRatio())
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
}
