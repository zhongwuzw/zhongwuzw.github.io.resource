//
//  Item14158Model.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/9/7.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArchSupport4Youku
import YKResponsiveLayout

class Item14158Model: BaseItemModel {
    
    var cmsInfo = [String: Any]()
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let cmsInfo = cmsInfo else {
            return
        }
        
        self.cmsInfo = cmsInfo
    }
}
