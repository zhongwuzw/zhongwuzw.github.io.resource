//
//  Component14158.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/9/7.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource
import YKUIComponent

class Component14158: CompSliderLayoutDelegate {
    
    override var compModel: BaseComponentModel? {
        get {
            return self.component?.compModel
        }
    }
    
    public override func layoutConfig() -> ComponentLayoutConfig {
        var config = super.layoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: YKNGap.youku_column_spacing(), right: 0)
        return config
    }
    
    override open func itemHeight(itemWidth: CGFloat) -> CGFloat {
        var itemHeight:CGFloat = ceil(itemWidth / (375.0 / 424) + 20)
        return itemHeight
    }
    
    override public func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Component14158SliderView(frame: CGRect(origin: .zero, size: itemSize),
                                                bottomHeight: sliderViewBottomBannerHeight(),
                                                delegate: self)
        return itemView
    }
    
    public override func createItemView(index: Int, itemSize: CGSize) -> UIView {
        guard let items = self.component?.getItems() else {
            return UIView.init(frame: .zero)
        }
        
        guard index < items.count else {
            return UIView.init(frame: .zero)
        }
        
        guard let view = items[index].getItemDelegate()?.createView(itemSize) else {
            return UIView.init(frame: .zero)
        }
        
        return view
    }

    public override func reuseItemView(index: Int, itemView: UIView) {
        guard let items = self.component?.getItems() else {
            return
        }
        
        guard index < items.count else {
            return
        }
        
        items[index].getItemDelegate()?.reuseView(itemView: itemView)
    }
    
    // MARK:
    public override func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
}

class Component14158SliderView: SliderView {
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(frame: CGRect, bottomHeight: CGFloat, delegate: SliderViewDelegate) {
        super.init(frame: frame, bottomHeight: bottomHeight, delegate: delegate)
        
        pageView.selectedPageColor = UIColor.ykn_primaryInfo
        pageView.unselectedPageColor = UIColor.ykn_tertiaryInfo
    }
    
    override func resetPageView() {
        super.resetPageView()
        
        // 居中展示
        self.pageView.left = (self.width - self.pageView.width) * 0.5
    }
    
}
