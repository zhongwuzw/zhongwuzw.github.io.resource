//
//  CinemaCllectionViewFlowLayout.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit

protocol CinemaCllectionViewFlowLayoutDelegate: NSObject {
    func collectionViewScrollIndexItem(index:Int)
}

class CinemaCllectionViewFlowLayout: UICollectionViewFlowLayout {

    weak var flowLayoutDelegate: CinemaCllectionViewFlowLayoutDelegate?
    
    var index: Int = 0
    var collectionViewWidth: CGFloat = 0.0
    var collectionViewHeight: CGFloat = 0.0

    override func layoutAttributesForElements(in rect: CGRect) -> [UICollectionViewLayoutAttributes]? {
        guard let superArr = super.layoutAttributesForElements(in: rect) else {
            return nil
        }
        guard let collectionView = self.collectionView else {
            return nil
        }
        //实现相应的缩放
        for attributes in superArr {
            let center:CGFloat = collectionView.contentOffset.x + 0.5 * collectionView.width
            let offset:CGFloat = abs(attributes.center.x - center)
            let width:CGFloat = itemSize.width + 20.0
            
            let maxScale:CGFloat = 1.112
            var scale:CGFloat = 1.0
            
            scale = (1.0 - maxScale) / width * offset + maxScale
            scale = max(scale, 1.0)
            attributes.transform = CGAffineTransform.init(scaleX: scale, y: scale)
            //修改透明度
    //        attibutes.alpha = 3.59 * scale - 3.19;
    //        attibutes.alpha = 3.0 * scale - 2.5;
    //        attibutes.alpha = 2.4 * scale - 1.8;
        }
        return superArr
    }
    
    override func shouldInvalidateLayout(forBoundsChange: CGRect) -> Bool {
        guard let collectionView = self.collectionView, let parentView = collectionView.superview else {
            return false
        }
        let point = parentView.convert(collectionView.center, to: collectionView)
        guard let index = collectionView.indexPathForItem(at: point) else {
            return false
        }
        if index.row == 0 {
            if (self.scrollDirection == .horizontal) {
                if (forBoundsChange.origin.x < collectionView.width * 0.5){
                    self.index = 0
                    self.flowLayoutDelegate?.collectionViewScrollIndexItem(index: self.index)
                }
            }
        } else{
            if self.index != index.row {
                self.index = index.row
                self.flowLayoutDelegate?.collectionViewScrollIndexItem(index: self.index)
            }
        }
        super.shouldInvalidateLayout(forBoundsChange: forBoundsChange)
        return true
    }

    override func targetContentOffset(forProposedContentOffset: CGPoint, withScrollingVelocity: CGPoint) -> CGPoint {
        guard let collectionView = self.collectionView else {
            return .zero
        }
        self.collectionViewWidth = collectionView.width
        self.collectionViewHeight = collectionView.height

        /**
         *  ProposeContentOffset是本来应该停下的位子
         *  1. 先给一个字段存储最小的偏移量 那么默认就是无限大
         */
        var minOffset = CGFloat.greatestFiniteMagnitude
        
        // 2. 获取到可见区域的centerX 和centerY
        let horizontalCenter = forProposedContentOffset.x + collectionView.width / 2
        let verticalCenter = forProposedContentOffset.y + collectionView.height / 2
        
        // 3. 拿到可见区域的rect
        var visibleRect:CGRect = CGRect.zero
        if self.scrollDirection == .horizontal {
            visibleRect = CGRect.init(x: forProposedContentOffset.x, y: 0, width: self.collectionViewWidth, height: self.collectionViewHeight)
        } else {
            visibleRect = CGRect.init(x: 0, y: forProposedContentOffset.y, width: self.collectionViewWidth, height: self.collectionViewHeight)
        }
        
        // 4. 获取到所有可见区域内的item数组
        guard let visibleAttributes = super.layoutAttributesForElements(in: visibleRect) else {
            return .zero
        }

        // 5. 遍历数组，找到距离中心最近偏移量是多少 可以是垂直偏移量也可以是水平偏移量
        for atts in visibleAttributes {
            if self.scrollDirection == .horizontal {
                // 可见区域内每个item对应的中心X坐标
                let itemCenterX = atts.center.x
                
                // 比较是否有更小的，有的话赋值给minOffset
                if abs(itemCenterX - horizontalCenter) <= abs(minOffset) {
                    minOffset = itemCenterX - horizontalCenter;
                }
            } else {
                // 可见区域内每个item对应的中心X坐标
                let itemCenterY = atts.center.y
                
                // 比较是否有更小的，有的话赋值给minOffset
                if abs(itemCenterY - verticalCenter) <= abs(minOffset) {
                    minOffset = itemCenterY - verticalCenter;
                }
            }
        }
        
        /**
         *  这里需要注意的是，eg水平方向为例：
         *  上面获取到的minOffset有可能是负数，那么代表左边的item还没到中心，如果确定这种情况下左边的item是距离最近的，
         *  那么需要左边的item居中，意思就是collectionView的偏移量需要比原本更小才是，例如原先是1000的偏移，
         *  但是需要展示前一个item，所以需要1000减去某个偏移量，因此不需要更改偏移的正负
         *  eg水平方向为例 ：但是当propose小于0的时候或者大于contentSize（除掉左侧和右侧偏移以及单个cell宽度）
         *  eg水平方向为例 ： 防止当第一个或者最后一个的时候不会有居中（偏移量超过了本身的宽度），直接卡在推荐的停留位置
         */
        if self.scrollDirection == .horizontal {
            var centerOffsetX = forProposedContentOffset.x + minOffset
            if (centerOffsetX < 0)
            {
                centerOffsetX = 0
            }
            
            let insetLeft = self.sectionInset.left
            let insetRight = self.sectionInset.right
            if centerOffsetX > collectionView.contentSize.width - (insetLeft + insetRight + self.itemSize.width) {
                centerOffsetX = floor(centerOffsetX);
            }
            print("[jbp] target x \(centerOffsetX)")
            return CGPoint.init(x: centerOffsetX, y: forProposedContentOffset.y)
        }
        else
        {
            var centerOffsetY = forProposedContentOffset.y + minOffset
            if (centerOffsetY < 0)
            {
                centerOffsetY = 0
            }
            
            if (centerOffsetY > collectionView.contentSize.height - (self.sectionInset.top + self.sectionInset.bottom + self.itemSize.height))
            {
                centerOffsetY = floor(centerOffsetY)
            }
            return CGPoint.init(x: forProposedContentOffset.x, y: centerOffsetY)
        }
    }

}
