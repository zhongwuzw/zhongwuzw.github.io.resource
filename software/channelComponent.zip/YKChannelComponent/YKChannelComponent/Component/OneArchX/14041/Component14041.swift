//
//  Component14041.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/17.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import YoukuResource

class Component14041:NSObject, ComponentDelegate {

    var componentWrapper: ComponentWrapper?

    func componentDidInit() {}

    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets(top: 0, left: 0, bottom: YKNGap.youku_comp_margin_bottom() + 9, right: 0)
        return config
    }

    func columnCount() -> CGFloat {
        return 1.0
    }

    /// 加载事件处理器
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

    /// item高度（custom布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let height = Comp14041Util.itemHeight(containerWidth: itemWidth)
        return height
    }

    /// 初始化item view（custom布局使用）
    func createView(_ itemSize: CGSize) -> UIView {
        return Component14041View(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
    }

    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        guard let view = itemView as? Component14041View else {
            return
        }
        view.fillData(component: self.component)
    }

    func itemViewClicked() {
        print("[OneArch] itemViewClicked")
    }
}
