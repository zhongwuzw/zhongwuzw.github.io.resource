//
//  CinemaCollectionViewCell.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import OneArchSupport4Youku
import OneArch

class CinemaCollectionViewCell: UICollectionViewCell {
    
    //MARK: Property
    lazy var videoImageView: BaseVideoImageView = {
        let view = BaseVideoImageView(frame: self.bounds)
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(videoImageView)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func fillData(item: IItem?) {
        guard let itemModel = item?.model as? BaseItemModel,
              let compModel = item?.getComponent()?.model as? BaseComponentModel else {
            return
        }
        // image
        self.videoImageView.fillData(item: item)
    }
}
