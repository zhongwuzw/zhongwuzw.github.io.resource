//
//  Component14041View.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import OneArch

class Component14041View: UIView, CinemaCllectionViewFlowLayoutDelegate, UICollectionViewDelegateFlowLayout, UICollectionViewDataSource {
    
    var collectionViewCount = 100
    weak var component: IComponent?
    var centerIndex = 1
    
    lazy var collectionView: UICollectionView = {
        let layout = CinemaCllectionViewFlowLayout.init()
        layout.itemSize = CGSize.init(width: Comp14041Util.itemWidth(containerWidth: self.width), height: Comp14041Util.videoImgHeight(containerWidth: self.width))
        layout.minimumLineSpacing = YKNGap.dim_6()
        layout.minimumInteritemSpacing = YKNGap.dim_6()
        layout.scrollDirection = .horizontal
        layout.flowLayoutDelegate = self
        let collectionView = UICollectionView.init(frame: CGRect.init(x: 0, y: 0, width: self.width, height: layout.itemSize.height * 1.112), collectionViewLayout: layout)
        collectionView.showsHorizontalScrollIndicator = false
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.backgroundColor = .clear
        if #available(iOS 11.0, *) {
            collectionView.contentInsetAdjustmentBehavior = .never
        }
        let identifier = "CinemaCollectionViewCell"
        collectionView.register(CinemaCollectionViewCell.self, forCellWithReuseIdentifier: identifier)
        return collectionView
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = Comp14041Util.titleFont()
        view.textAlignment = .center
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_tertiaryInfo
        view.font = Comp14041Util.subtitleFont()
        view.numberOfLines = 1
        view.textAlignment = .center
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(collectionView)
        self.addSubview(self.titleLabel)
        self.addSubview(self.subtitleLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(component: IComponent?) {
        guard let compModel = component?.compModel else {
            return
        }
        self.component = component
        self.collectionView.contentOffset = CGPoint.init(x: 0, y: 0)
        _scrollFirst = true
        self.centerIndex = getCenterIndex()
        self.collectionView.reloadData()
    
        self.subtitleLabel.size = CGSize.init(width: self.width, height: Comp14041Util.subTitleHeight())
        self.subtitleLabel.bottom = self.height
        self.titleLabel.frame = CGRect.init(x: 0, y: 0, width: self.width, height: Comp14041Util.titleHeight())
        self.titleLabel.bottom = self.subtitleLabel.top - 1
        self.subtitleLabel.textColor = sceneUtil(.ykn_tertiaryInfo, sceneColor: compModel.scene?.sceneSubTitleColor())
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: compModel.scene?.sceneTitleColor())
        
        updateTitleInfo()

        bindActions()
    }
    
    func updateTitleInfo() {
        guard let component = component, let items = component.getItems() else {
            return
        }
        guard centerIndex < items.count else {
            return
        }
        let item = items[centerIndex]
        guard let itemModel = item.itemModel else {
            return
        }
        self.titleLabel.text = itemModel.title
        self.subtitleLabel.text = itemModel.subtitle
    }
    
    //MARK: UICollectionViewDelegateFlowLayout
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        let x = self.width * 0.5 - 60
        return UIEdgeInsets.init(top: 0, left: x, bottom: 0, right: x)
    }
    
    //MARK: UICollectionViewDelegate
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        guard let component = component, let items = component.getItems() else {
            return 0
        }
        return items.count * collectionViewCount
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let identifier = "CinemaCollectionViewCell"
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: identifier, for: indexPath)
        if let items = component?.getItems() {
            let index = getItemIndex(indexPath.row)
            if index < items.count {
                let item = items[index]
                if let itemview = cell as? CinemaCollectionViewCell {
                    itemview.fillData(item: item)
                    let report = item.itemModel?.action?.report
                    Service.statistics.bind(report, cell, .Defalut)
                }
//                bindAction(index: index, cell: itemview)
            }
        }
//        if let items = component?.getItems(), indexPath.row < items.count {
//            if let itemview = cell as? CinemaCollectionViewCell {
//                itemview.fillData(item: items[indexPath.row])
//                bindAction(index: indexPath.row, cell: itemview)
//            }
//        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let itemIndex = getItemIndex(indexPath.row)
        
        if let items = component?.getItems(), itemIndex < items.count {
            let item = items[itemIndex]
            
            if itemIndex == self.centerIndex {
                if let action = item.itemModel?.action {
                    Service.action.doActionWithoutStatistics(action, willAction: nil, didAction: nil)
                }
            } else {
                collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: true)
                self.centerIndex = getItemIndex(indexPath.row)
            }
        }

    }
    
    func getItemIndex(_ indexRow: Int) -> Int {
        if let items = component?.getItems() {
            if let itemCount = component?.getItems()?.count, itemCount > 0 {
                let index = indexRow % itemCount
                return index
            }
        }
        return indexRow
    }
    
    func getRealIndex(_ index: Int) -> Int {
        if let items = component?.getItems() {
            if let itemCount = component?.getItems()?.count, itemCount > 0 {
                
                return index + (collectionViewCount / 2) * itemCount
            }
        }
        return index
    }
    
    var _scrollFirst = true
    func collectionView(_ collectionView: UICollectionView, willDisplay cell: UICollectionViewCell, forItemAt indexPath: IndexPath) {
        if _scrollFirst {
            if let items = component?.getItems(), items.count > 0, self.centerIndex < items.count {
                print("[jbp] 14041 scrollto \(self.centerIndex)")
                let realIndex = getRealIndex(self.centerIndex)
                collectionView.scrollToItem(at: IndexPath.init(row: realIndex, section: 0), at: .centeredHorizontally, animated: false)
                print("[jbp] 14041 scrollto end \(self.centerIndex)")
                bindActions()
            }
            _scrollFirst = false
        }
    }
    
    //MARK: CinemaCllectionViewFlowLayoutDelegate
    func collectionViewScrollIndexItem(index: Int) {
        if _scrollFirst {
            return
        }
        let itemIndex = getItemIndex(index)
        print("[jbp] 14041 collectionViewScrollIndexItem \(itemIndex)")
        setCenterIndex(index: itemIndex)
        updateTitleInfo()
        bindActions()
    }

    func getCenterIndex() -> Int {
        guard let compModel = self.component?.compModel else {
            return 1
        }
        if let index = compModel.extraExtend["selCenterIndex"] as? Int {
            return index
        }
        return 1
    }

    func setCenterIndex(index: Int) {
        guard let compModel = self.component?.compModel else {
            return
        }
        self.centerIndex = index
        compModel.extraExtend["selCenterIndex"] = index
    }
    
    func bindActions() {
//        guard let items = self.component?.getItems() else {
//            return
//        }
//        print("[jbp] bindActions")
//        for i in 0..<items.count {
//            let indexPath = IndexPath.init(row: i, section: 0)
//            if let cell = self.collectionView.cellForItem(at: indexPath) {
//                bindAction(index: i, cell: cell)
//            }
//        }
    }
    
    func bindAction(index: Int, cell:UIView) {
        
//        guard let items = self.component?.getItems(), index < items.count else {
//            return
//        }
//        let itemModel = items[index].itemModel
//        if index == self.centerIndex {
//            print("[jbp] bindAction \(index)")
//            cell.clearTapHandler()
//            Service.action.bind(itemModel?.action, cell)
//        } else {
//            print("[jbp] clear Action \(index)")
//            Service.action.bind(nil, cell)
//            Service.statistics.bind(itemModel?.action?.report, cell, .Defalut)
//            weak var weakself = self
//            cell.whenTapped {
//                if let weakself = weakself {
//                    weakself.centerIndex = index
//                    weakself.collectionView.scrollToItem(at: IndexPath.init(row: weakself.centerIndex, section: 0), at: .centeredHorizontally, animated: true)
//                    weakself.bindActions()
//                }
//            }
//        }
    }
}
