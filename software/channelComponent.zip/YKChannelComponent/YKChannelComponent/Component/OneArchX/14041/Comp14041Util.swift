//
//  Comp14041Util.swift
//  YKChannelComponent
//
//  Created by better on 2022/3/18.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import OneArchSupport4Youku
import OneArch

class Comp14041Util: UIView {
    
    static func titleFont() -> UIFont {
        return YKNFont.posteritem_maintitle()
    }

    static func subtitleFont() -> UIFont {
        return YKNFont.posteritem_subhead()
    }
    
    static func titleHeight() -> CGFloat {
        return YKNFont.height(with: YKNFont.posteritem_maintitle(), lineNumber: 1)
    }
    
    static func subTitleHeight() -> CGFloat {
        return YKNFont.height(with: YKNFont.posteritem_subhead(), lineNumber: 1)
    }
    
    static func itemWidth(containerWidth:CGFloat) -> CGFloat {
        let ITEM_COUNT_3B4:CGFloat = 3
        let margin = YKNGap.youku_margin_left() * 2
        let colMargin = YKNGap.dim_6() * (ITEM_COUNT_3B4 - 1)
        let ITEM_WIDTH_3B4:CGFloat = (containerWidth - colMargin - margin) / ITEM_COUNT_3B4
        return ITEM_WIDTH_3B4
    }
    
    static func videoImgHeight(containerWidth:CGFloat) -> CGFloat {
        return itemWidth(containerWidth: containerWidth) * 4 / 3.0
    }
    
    static func itemHeight(containerWidth:CGFloat) -> CGFloat {
        let videoHeight = Comp14041Util.videoImgHeight(containerWidth: containerWidth)
        let subTitleHeight = Comp14041Util.subTitleHeight()
        let titleHeight = Comp14041Util.titleHeight()
        let itemHeight:CGFloat = videoHeight * 1.112 + YKNGap.dim_5() + subTitleHeight + titleHeight + YKNGap.dim_2() + 10
        return itemHeight
    }
}
