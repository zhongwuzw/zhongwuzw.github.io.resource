//
//  Component14135Model.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/30.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku

class Component14135Model: BaseComponentModel {

    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String: Any] else {
            return
        }
        
    }

}
