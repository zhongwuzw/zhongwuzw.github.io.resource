//
//  Item14135Model.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/30.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArchSupport4Youku

class Item14135Model: HomeItemModel {
    
    var scoreValue: Double = 0
    var scoreFormattedString: String = ""

    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo)
        
        guard let dataInfo = cmsInfo?["data"] as? [String: Any] else {
            return
        }
        
        if let trend = dataInfo["trend"] as? [String: Any], !trend.isEmpty {
            self.extraExtend["trend"] = trend
        }
        
        if let popularity = dataInfo["popularity"] as? [String: Any], !popularity.isEmpty {
            self.extraExtend["popularity"] = popularity
        }
        
        if let score = dataInfo["score"] as? [String: Any], !score.isEmpty {
            if let scoreValue = score["score"] as? String, !scoreValue.isEmpty {
                if let value = Double(scoreValue) {
                    self.scoreValue = value
                    scoreFormattedString = String(format: "%.1f", value)
                }
            } else if let scoreValue = score["score"] as? Double {
                self.scoreValue = scoreValue
                scoreFormattedString = String(format: "%.1f", scoreValue)
            }
            
            self.extraExtend["score"] = score
        }
    }

}
