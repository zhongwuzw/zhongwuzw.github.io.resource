//
//  Item14135ContentView.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/30.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKNodePage

class Item14135ContentView: UIView {
    
    var rankIndex: Int = 0
    
    lazy var imageView: UIImageGIFView = {
        let imageView = UIImageGIFView()
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .ykn_primaryFill
        imageView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        imageView.layer.masksToBounds = true
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_primaryInfo
        view.font = Item14135.titleFont()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_tertiaryInfo
        view.font = Item14135.subtitleFont()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var popularityView: YKNPPopularityView = {
        let view = YKNPPopularityView.init(frame: .init(origin: .zero, size: .init(width: self.width, height: 17)))
        view.isV2 = true
        view.titleLabel.textColor = UIColor.ykn_brandInfo
        return view
    }()
    
    lazy var starView: YKNScoreStarView = {
        let view = YKNScoreStarView.init(frame: .init(origin: .zero, size: .init(width: 63, height: 10)))
        return view
    }()
    
    lazy var scoreLabel: UILabel = {
        let height: CGFloat = YKNFont.height(with: Item14135.scoreFont(), lineNumber: 1)
        let view = UILabel.init(frame: .init(origin: .zero, size: .init(width: self.width, height: height)))
        view.font = Item14135.scoreFont()
        view.textColor = UIColor.ykn_brandInfo
        view.numberOfLines = 1
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(imageView)
        imageView.frame = CGRect.init(origin: .zero, size: Item14135.itemImageViewSize())
        
        addSubview(titleLabel)
        let titleX: CGFloat = imageView.frame.minX
        let titleY: CGFloat = imageView.frame.maxY + YKNGap.youku_picture_title_spacing()
        let titleHeight: CGFloat = ceil(YKNFont.height(with: Item14135.titleFont(), lineNumber: 1))
        titleLabel.frame = CGRect.init(x: titleX, y: titleY, width: self.width, height: titleHeight)
        
        addSubview(subtitleLabel)
        let subtitleX: CGFloat = titleLabel.frame.minX
        let subtitleY: CGFloat = titleLabel.frame.maxY + YKNGap.youku_maintitle_subtitle_spacing()
        let subtitleHeight: CGFloat = ceil(YKNFont.height(with: Item14135.subtitleFont(), lineNumber: 1))
        subtitleLabel.frame = CGRect.init(x: subtitleX, y: subtitleY, width: self.width, height: subtitleHeight)
        
        addSubview(popularityView)
        popularityView.frame = subtitleLabel.frame
        
        addSubview(starView)
        let starX: CGFloat = titleLabel.frame.minX
        let starY: CGFloat = titleLabel.frame.maxY + 5
        let starSize: CGSize = starView.bounds.size
        starView.frame = CGRect.init(origin: .init(x: starX, y: starY), size: starSize)
        
        addSubview(scoreLabel)
        let scoreX: CGFloat = starView.frame.maxX
        let scoreY: CGFloat = 0
        let scoreWidth: CGFloat = self.width - starView.frame.maxX
        let scoreHeight: CGFloat = scoreLabel.bounds.size.height
        scoreLabel.frame = CGRect(x: scoreX, y: scoreY, width: scoreWidth, height: scoreHeight)
        scoreLabel.centerY = starView.centerY
    }

    func fillModel(_ itemModel: Item14135Model) {
        Service.action.bind(itemModel.action, self)
        
        imageView.ykn_setImage(withURLString: itemModel.img, module: "nodepage", imageSize: .zero, parameters: [String: Any](), completed: nil)
        Service.rank.attach(rankIndex, toView: imageView)
        
        titleLabel.text = itemModel.title
        
        starView.isHidden = true
        scoreLabel.isHidden = true
        subtitleLabel.isHidden = true
        popularityView.isHidden = true
        
        if let trendCount = itemModel.trend?.count, !trendCount.isEmpty,
           let trendModel = itemModel.extraExtend["trend"] as? [String : Any] {
            popularityView.isHidden = false
            popularityView.setPopularityModel(trendModel)
        } else if !itemModel.scoreFormattedString.isEmpty, itemModel.scoreValue > 0 {
            scoreLabel.isHidden = false
            starView.isHidden = false
            
            scoreLabel.text = itemModel.scoreFormattedString
            starView.setReputation(CGFloat(itemModel.scoreValue))
        } else if let popularityCount = itemModel.popularity?.count, !popularityCount.isEmpty,
                  let popularityModel = itemModel.extraExtend["popularity"] as? [String : Any] {
           popularityView.isHidden = false
           popularityView.setPopularityModel(popularityModel)
        } else {
            subtitleLabel.isHidden = false
            subtitleLabel.text = itemModel.moreDesc
        }
    }
}
