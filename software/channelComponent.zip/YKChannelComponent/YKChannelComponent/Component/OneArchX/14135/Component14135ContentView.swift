//
//  Component14135ContentView.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/30.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Component14135ContentView: UIView {
    
    lazy var contentView: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var headerView: Component14135HeaderView = {
        let height: CGFloat = 45 * YKNSize.yk_icon_size_scale()
        let view = Component14135HeaderView.init(frame: .init(x: 0, y: 0, width: self.width, height: height))
        return view
    }()
    
    lazy var item1View: Item14135ContentView = {
        let view = Item14135ContentView.init(frame: CGRect.init(origin: .zero, size: Item14135.itemViewSize()))
        view.rankIndex = 1
        return view
    }()
    
    lazy var item2View: Item14135ContentView = {
        let view = Item14135ContentView.init(frame: CGRect.init(origin: .zero, size: Item14135.itemViewSize()))
        view.rankIndex = 2
        return view
    }()
    
    lazy var item3View: Item14135ContentView = {
        let view = Item14135ContentView.init(frame: CGRect.init(origin: .zero, size: Item14135.itemViewSize()))
        view.rankIndex = 3
        return view
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(headerView)
        
        var x: CGFloat = 0
        var y: CGFloat = 0
        y = headerView.frame.maxY + 3
        
        addSubview(item1View)
        item1View.left = x
        item1View.top = y
        
        addSubview(item2View)
        x = item1View.frame.maxX + YKNGap.youku_column_spacing()
        item2View.left = x
        item2View.top = y
        
        addSubview(item3View)
        x = item2View.frame.maxX + YKNGap.youku_column_spacing()
        item3View.left = x
        item3View.top = y
    }

    func fillModel(_ componentModel: Component14135Model, component: IComponent?) {
        headerView.fillModel(componentModel)
        
        if let firstItem = component?.getItems()?.first?.itemModel as? Item14135Model {
            item1View.isHidden = false
            item1View.fillModel(firstItem)
        } else {
            item1View.isHidden = true
        }
        
        if let secondItem = component?.getItems()?.dropFirst().first?.itemModel as? Item14135Model {
            item2View.isHidden = false
            item2View.fillModel(secondItem)
        } else {
            item2View.isHidden = true
        }
        
        if let thirdItem = component?.getItems()?.dropFirst(2).first?.itemModel as? Item14135Model {
            item3View.isHidden = false
            item3View.fillModel(thirdItem)
        } else {
            item3View.isHidden = true
        }
    }
}

class Component14135HeaderView: UIView {
    
    lazy var titleImageView: UIImageGIFView = {
        let imageView = UIImageGIFView.init(frame: .init(x: 0, y: 0, width: 180, height: 22))
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .ykn_primaryFill
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_primaryInfo
        view.font = Component14135.titleFont()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var subtitleLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_tertiaryInfo
        view.font = Component14135.subtitleFont()
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var keywordLabel: UILabel = {
        let view = UILabel.init()
        view.textColor = .ykn_tertiaryInfo
        view.font = Component14135.subtitleFont()
        view.textAlignment = .right
        view.numberOfLines = 1
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    lazy var arrowView: UIImageView = {
        let imageView = UIImageView.init(frame: .init(x: 0, y: 0, width: 12, height: 12))
        imageView.image = UIImage.init(named: "ykn_more_btn")?.withRenderingMode(.alwaysTemplate)
        imageView.tintColor = .ykn_tertiaryInfo
        imageView.isUserInteractionEnabled = true
        return imageView
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        setupSubviews()
    }
    
    func setupSubviews() {
        addSubview(titleImageView)
        addSubview(titleLabel)
        addSubview(subtitleLabel)
        addSubview(keywordLabel)
        addSubview(arrowView)

        let titleHeight = YKNFont.height(with: Component14135.titleFont(), lineNumber: 1)
        titleLabel.frame = CGRect.init(x: 0, y: 0, width: 150, height: titleHeight)
        
        let subtitleHeight = YKNFont.height(with: Component14135.subtitleFont(), lineNumber: 1)
        subtitleLabel.frame = CGRect.init(x: 0, y: 0, width: self.width, height: subtitleHeight)
        
        let keywordHeight = YKNFont.height(with: Component14135.subtitleFont(), lineNumber: 1)
        keywordLabel.frame = CGRect.init(x: 0, y: 0, width: 0, height: keywordHeight)
    }
    
    func fillModel(_ componentModel: Component14135Model) {
        //绑定跳转、埋点
        Service.action.bind(componentModel.action, self)
        
        if let titleImage = componentModel.titleImg, !titleImage.isEmpty {
            titleImageView.isHidden = false
            arrowView.isHidden = false
            keywordLabel.isHidden = false
            titleLabel.isHidden = true
            
            self.titleImageView.backgroundColor = UIColor.ykn_primaryFill
            weak var weakSelf = self
            titleImageView.ykn_setImage(withURLString: titleImage, module: nil, imageSize: .zero, parameters: nil) { image, error, userinfo in
                guard let self = weakSelf else {
                    return
                }
                
                if let _ = image {
                    self.titleImageView.backgroundColor = UIColor.clear
                }
            }
            
            subtitleLabel.text = componentModel.subtitle
            keywordLabel.text = componentModel.desc
            
            subtitleLabel.top = titleImageView.bottom + YKNGap.dim_4()
            arrowView.centerY = titleImageView.centerY
            arrowView.right = self.width
            keywordLabel.left = titleImageView.right
            keywordLabel.width = arrowView.left - titleImageView.right
            keywordLabel.centerY = titleImageView.centerY
            
        } else {
            titleImageView.isHidden = true
            arrowView.isHidden = false
            keywordLabel.isHidden = false
            titleLabel.isHidden = false
            
            titleLabel.text = componentModel.title
            subtitleLabel.text = componentModel.subtitle
            keywordLabel.text = componentModel.desc
            
            keywordLabel.sizeToFit()
            
            arrowView.centerY = titleLabel.centerY
            arrowView.right = self.width
            
            keywordLabel.right = arrowView.left
            keywordLabel.centerY = titleLabel.centerY
            
            titleLabel.width = keywordLabel.left - 6
            subtitleLabel.top = titleLabel.bottom + YKNGap.dim_4()
        }
    }
}
