//
//  Component14135.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/30.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku

class Component14135: NSObject, ComponentDelegate {
   
    var componentWrapper: ComponentWrapper?
    
    func getModelClass<T: NodeModel>() -> T.Type? {
        return Component14135Model.self as? T.Type
    }
    
    func componentDidInit() {
        
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_comp_margin_bottom()
        config.footerBottomMargin = YKNGap.youku_comp_margin_bottom()
        return config
    }
    
    func diverCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        estimatedLayout(itemWidth)
        return component?.compModel?.layout.renderRect.height ?? 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let view = Component14135ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return view
    }
    
    func reuseId() -> String? {
        var reuseId = "Component14135ContentView"
        if let height = self.component?.compModel?.layout.renderRect.height {
            reuseId = reuseId + "_\(height)"
        }
        return reuseId
    }

    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Component14135ContentView else {
            return
        }
        guard let componentModel = self.component?.compModel as? Component14135Model else {
            return
        }
        
        itemView.fillModel(componentModel, component: component)
    }

    func estimatedLayout(_ itemWidth: CGFloat) {
        var itemHeight: CGFloat = 0
        itemHeight += ceil(45 * YKNSize.yk_icon_size_scale())
        itemHeight += 3
        itemHeight += Item14135.itemViewSize().height
        
        let layout = LayoutModel.init()
        layout.renderRect = CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight)
        layout.boundingSize = CGSize.init(width: itemWidth, height: itemHeight)
        self.component?.compModel?.layout = layout
    }
}

extension Component14135 {
    
    class func titleFont() -> UIFont {
        return YKNFont.module_headline_weight(.semibold)
    }
    
    class func subtitleFont() -> UIFont {
        return YKNFont.posteritem_subhead()
    }
    
}
