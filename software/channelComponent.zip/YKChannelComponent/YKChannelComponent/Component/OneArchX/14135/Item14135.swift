//
//  Item14135.swift
//  YKChannelComponent
//
//  Created by DylanLai on 2023/8/30.
//  Copyright © 2023 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKProtocolSDK
import OneArchSupport
import OneArchSupport4Youku
import YKResponsiveLayout

class Item14135: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {

    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item14135Model.self as? T.Type
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView.init(frame: .zero)
    }
    
    func reuseView(itemView: UIView) {
        
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
}


extension Item14135 {
    
    class func itemImageViewSize() -> CGSize {
        var column: CGFloat = 3
        if ykrl_isResponsiveLayout() {
            column = 4
        }
        
        let marginLeft: CGFloat = YKNGap.youku_margin_left()
        let marginRight: CGFloat = YKNGap.youku_margin_right()
        let columnSpacing: CGFloat = YKNGap.youku_column_spacing()
        
        let screenWidth = min(YKRLScreenWidth(), YKRLScreenHeight()) //取屏幕宽函数在转屏时不准确，取屏幕最短边为基准计算
        let width: CGFloat = ceil((screenWidth - marginLeft - marginRight - (column - 1) * columnSpacing) / column)
        let height: CGFloat = ceil(width * 4.0 / 3.0) //封面图
        
        return CGSize.init(width: width, height: height)
    }
    
    class func titleFont() -> UIFont {
        return YKNFont.posteritem_maintitle()
    }
    
    class func subtitleFont() -> UIFont {
        return YKNFont.posteritem_subhead()
    }
    
    class func scoreFont() -> UIFont {
        return YKNFont.akrobatFont(ofSize: 13)
    }
    
    class func itemViewSize() -> CGSize {
        let width: CGFloat = itemImageViewSize().width
        var height: CGFloat = 0
        
        height += ceil(width * 4.0 / 3.0) //封面图
        height += YKNGap.youku_picture_title_spacing()
        height += ceil(YKNFont.height(with: Item14135.titleFont(), lineNumber: 1))
        height += YKNGap.youku_maintitle_subtitle_spacing()
        height += ceil(YKNFont.height(with: Item14135.subtitleFont(), lineNumber: 1))
        
        return CGSize.init(width: width, height: height)
    }
    
}
