//
//  LikeUtilV2.swift
//  YKChannelComponent
//
//  Created by CC on 2021/12/13.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import YoukuAnalytics
import DYKIOSCategory
import OneServiceSwift
import Nobel
import YKChannel
import DYKNavigator
import YKUIComponent
import OneServiceSwift
import OneArchSupport4Youku

public class LikeUtilV2 {
    
    class func didClickLike(_ model: BaseItemModel?, _ completion: ((Bool) -> Void)? = nil) {
        let isLiked = model?.like?.state ?? false
        LikeUtilV2.likeWithModel(model, isLike: !isLiked, completion)
    }
    
    class func likeWithModel(_ model: BaseItemModel?, isLike: Bool, _ completion: ((Bool) -> Void)? = nil) {
        guard let model = model as? BaseItemModel else {
            return
        }
        
        let params = LikeUtilV2.likeParamsWithModel(model)

        let mtopApi = isLike ? "mtop.youku.pgc.zpd.praise.add" : "mtop.youku.pgc.zpd.praise.cancel"
        OneService.networkInvoker.sharedMtopClient().result?.json(with: mtopApi, method: .post, parameters: params as! [String : Any], headers: [:], timeout: 10, success: { (json) in
            
            guard let jsonData = json as? [AnyHashable : Any],
                  let data = jsonData.yk_object("data") as? [String: Any],
                  data.yk_bool("result") else {
                MessageBox.sharedInstance()?.showMessage("服务器繁忙，请稍后再试!")
                return
            }
            
            let liked = isLike ? true : false
            
            if let like = model.like as? LikeModel {
                like.state = liked
                like.count += (isLike ? 1 : -1)
                like.count = max(0, like.count)
            }
            completion?(true)

        }, failure: { (error) in
            MessageBox.sharedInstance()?.showMessage("服务器繁忙，请稍后再试!")
            completion?(false)
        })
    }
    
    
    class func likeParamsWithModel(_ model: BaseItemModel?) -> NSMutableDictionary {
        let params = NSMutableDictionary()
        
        if let like = model?.like, !like.apiParams.isEmpty {
            params.addEntries(from: like.apiParams)
        } else {
            params["targetType"] = 1
            params["id"] = model?.playerModel?.playerId ?? ""
        }
        
        params.addEntries(from: YKChannelMtopConfig.defaultParams())
        return params
    }
    
    class func stringWithlikeCount(_ count:Int) -> String {
        if count == 0 {
            return "点赞"
        }
        var tempCount = Int(0)
        if (count < Int(10000)) {
            return String(count)
        } else if (count < Int(100000000)) {
            tempCount = count / 10000
            let newCount = count % 10000 / 1000
            return generateSimpleValue(tempCount, newCount) + "万";
        } else {
            tempCount = count / 100000000
            let newCount = count % 100000000 / 10000000
            return generateSimpleValue(tempCount, newCount) + "亿";
        }
    }
    
    class func generateSimpleValue(_ integer:Int, _ decimal:Int) -> String {
        return decimal == 0 ? String(integer) : String(integer) + "." + String(decimal)
    }
    
}
