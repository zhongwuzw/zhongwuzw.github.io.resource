//
//  CommonUtilV2.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/25.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKAdSDK


func deleteComponentWithAnimation(_ component: IComponent?) {
    guard let component = component else {
        return
    }
    guard let card = component.getCard() else {
        return
    }
    
    card.getComponentManager()?.removeComponent(component: component, animated: true)
}

func createUCAdFeedbackModel(_ model: BaseItemModel?) -> FeedbackModel {
    let feedbackModel: FeedbackModel = FeedbackModel()
    
    var defalutTitle = "就是不感兴趣"
    if let defaultFeedbackText = model?.defaultFeedbackText {
       defalutTitle = defaultFeedbackText
    }
    feedbackModel.reasons = [FeedbackItemModel.init(["title":defalutTitle, "reason":"I"])]
    
    feedbackModel.report = model?.action?.report
    feedbackModel.scene = model?.scene
    
    let ucAdModel = YKAdResponseModel.init()
    let seatBid = YKAdResponseSeatBid.init()
    var bidModel: YKAdResponseBid?
    if let json = model?.bid {
        bidModel = YKAdResponseBid.adResponseModel(withJSONObject: json)
    }
    if let bidModel = bidModel {
        seatBid.bid = [bidModel]
    }
    ucAdModel.seatBid = [seatBid]
    
    if let ucExtra = model?.extend["ucExtra"] as? [String:Any] {
        if let bidid = ucExtra["bidid"] as? String {
            ucAdModel.bidId = bidid
        }
        if let dmpid = ucExtra["dmpid"] as? String {
            ucAdModel.dmpId = dmpid
        }
        if let id = ucExtra["id"] as? String {
            ucAdModel.resId = id
        }
    }
    
    feedbackModel.ucAdModel = ucAdModel
    
    model?.feedbackModel = feedbackModel
    
    return feedbackModel
}

// 解析含有嵌套biz数据，可用bid 位于 bid -> seatbid[0] -> bid下
func createUCAdFeedbackModelNew(_ model: BaseItemModel?) -> FeedbackModel {
    let feedbackModel: FeedbackModel = FeedbackModel()
    
    var defalutTitle = "不感兴趣"
    if let defaultFeedbackText = model?.defaultFeedbackText {
       defalutTitle = defaultFeedbackText
    }
    feedbackModel.reasons = [FeedbackItemModel.init(["title":defalutTitle, "reason":"I"])]
    
    feedbackModel.report = model?.action?.report
    feedbackModel.scene = model?.scene
    
    let ucAdModel = YKAdResponseModel.init()
    let seatBid = YKAdResponseSeatBid.init()
    var bidModel: YKAdResponseBid?
    if let bidJson = model?.bid {
        if let seatBidJsonArr = bidJson["seatbid"] as? [[String: Any]], seatBidJsonArr.count > 0 {
            let usedBidJson = seatBidJsonArr[0]
            if let internalArr = usedBidJson["bid"] as? [[String: Any]] , internalArr.count > 0 {
                let json = internalArr[0]
                bidModel = YKAdResponseBid.adResponseModel(withJSONObject: json)
            }
        }

        if let bidid = bidJson["bidid"] as? String {
            ucAdModel.bidId = bidid
        }
        if let dmpid = bidJson["dmpid"] as? String {
            ucAdModel.dmpId = dmpid
        }
        if let id = bidJson["id"] as? String {
            ucAdModel.resId = id
        }
    }
    if let bidModel = bidModel {
        seatBid.bid = [bidModel]
    }
    ucAdModel.seatBid = [seatBid]
    
    feedbackModel.ucAdModel = ucAdModel
    
    model?.feedbackModel = feedbackModel
    
    return feedbackModel
}

//判断是否空颜色或者透明色
func isEmptyColor(_ color: UIColor?) -> Bool {
    guard let color = color else {
        return true
    }
    return color == UIColor.clear
}

func isSelectionChannel(_ page: IPage?) -> Bool {
    let nodeKey = page?.pageModel?.nodeKey
    let isSelection = nodeKey == "SELECTION" || nodeKey == "NUSELECTION" || nodeKey == "SELECTIONYOUNG"
    return isSelection
}

extension UIImage {
    
    // 图片去色
    func util_removeColor() -> UIImage? {
        let ciImage = CIImage(image: self)

        let filter = CIFilter(name: "CIColorControls")
        filter?.setValue(ciImage, forKey: kCIInputImageKey)
        filter?.setValue(0, forKey: kCIInputSaturationKey)

        let context = CIContext(options: nil)
        if let outputImage = filter?.outputImage, let cgImage = context.createCGImage(outputImage, from: (outputImage.extent)) {
            let resultImage = UIImage(cgImage: cgImage)
            return resultImage
        }
        
        return nil
    }
}
