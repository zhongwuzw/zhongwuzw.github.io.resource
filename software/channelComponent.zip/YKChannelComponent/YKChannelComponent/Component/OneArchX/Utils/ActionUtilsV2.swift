//
//  ActionUtilsV2.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/25.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport
import OneArchSupport4Youku

func ActionFactoryV2(_ model:YoukuNodeModel) -> ActionModel? {
    return ActionFactoryV2(model, spmDExt: nil)
}

func ActionFactoryV2(_ model:YoukuNodeModel, spmDExt: String?) -> ActionModel? {

    
    let action = model.action?.copy() as? ActionModel
    
    if let spmD = action?.report?.spmD, let spmDExt = spmDExt {
        action?.report?.spmD = spmD + spmDExt
    }
    if let spmAB = action?.report?.spmAB, let spmC = action?.report?.spmC, let spmD = action?.report?.spmD, let spmDExt = spmDExt {
        action?.report?.spm = spmAB + "." + spmC + "." + spmD
        if let spm = action?.report?.spm {
            action?.report?.args?["spm"] = spm
        }
    }
    return action
}

func ActionFactoryV2(_ model:YoukuNodeModel, spmDReplace: String?) -> ActionModel? {
    let action = model.action?.copy() as? ActionModel
    
    if let spmDReplace = spmDReplace {
        action?.report?.spmD = spmDReplace
    }
    if let spmAB = action?.report?.spmAB, let spmC = action?.report?.spmC, let spmD = action?.report?.spmD {
        action?.report?.spm = spmAB + "." + spmC + "." + spmD
        if let spm = action?.report?.spm {
            action?.report?.args?["spm"] = spm
        }
    }
    return action
}

