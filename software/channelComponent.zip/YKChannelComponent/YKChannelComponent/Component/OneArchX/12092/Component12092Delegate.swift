//
//  Component12092Delegate.swift
//  YKChannelComponent
//
//  Created by wustlj on 2022/6/9.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout
import OneArchSupport
import OneArchSupport4Youku

class Component12092Delegate: NSObject, ComponentDelegate, FlowScrollProtocol {
    
    var item: IItem? {
        get {
            return self.component?.getItems()?.first
        }
    }
    var itemModel: BaseItemModel? {
        get {
            return self.component?.getItems()?.first?.itemModel
        }
    }
    
    var compModel: BaseComponentModel? {
        get {
            return self.component?.model as? BaseComponentModel
        }
    }
    
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {
        if let componentModel = self.component?.model as? BaseComponentModel {
            componentModel.extraExtend["aspectRatio"] = 0.75
        }
    }

    func layoutType() -> ComponentLayoutType {
        return .custom
    }

    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = 9.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0 //100

        return config
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
        
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

    /// item高度（custom布局使用）
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        self.estimatedLayout(Double(itemWidth))
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        if (hasTopImage()) {
            return itemHeight + bgHeight() - spaceHeight() + YKNGap.dim_8()
        } else {
            return itemHeight + bgHeight() + spaceHeight()
        }
    }

    /// 初始化item view（custom布局使用）
    func createView(_ itemSize: CGSize) -> UIView {
        let itemWidth = itemSize.width
        let itemHeight = itemSize.height

        let itemView = FlowScrollContainerView.init(frame: CGRect(x: 0, y: 0, width: itemWidth, height: itemHeight), hasTopImage: hasTopImage())
        return itemView
    }
    
    func reuseId() -> String? {
        if hasTopImage() {
            return "YKChannelComponent.Comp12092.topImage"
        } else {
            return "YKChannelComponent.Comp12092"
        }
    }

    /// 复用（custom布局使用）
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? FlowScrollContainerView else {
            return
        }
        
        itemView.superview?.clipsToBounds = false
        
        itemView.delegate = self
        
        let sceneModel = compModel?.scene
        itemView.reload(sloganPath: sceneModel?.sceneSloganPath(),
                        logoTopPath: sceneModel?.sceneLogoTopPath(),
                        logoBottomPath: sceneModel?.sceneLogoBottomPath(),
                        themeSceneColor: sceneModel?.sceneThemeColor(),
                        bgSceneColor: sceneModel?.sceneCardFooterBgColor(),
                        sceneThemeColor: sceneModel?.sceneThemeColor(),
                        sceneButtonSelectBgColor: sceneModel?.sceneButtonSelectBgColor())
        
        Service.action.bind(compModel?.action, itemView.bottomImageView)

        itemView.resetScrollPosition()
    }
    
    func hasTopImage() -> Bool {
        let sceneModel = compModel?.scene
        if let path = sceneModel?.sceneLogoTopPath(), path.count > 0 {
            return true
        }
        return false
    }
    
    //MARK: help
    
    func spaceHeight() -> CGFloat {
        return YKNGap.youku_comp_margin_bottom() - 9.0
    }
    
    func bgWidth() -> CGFloat {
        var w = YKRLScreenWidth()
        if let compWidth = self.component?.getPage()?.getLayoutInfo().width, compWidth > 0 {
            w = compWidth
        }
        w -= (YKNGap.youku_margin_left() + YKNGap.youku_margin_right())
        return w
    }
    
    func bgHeight() -> CGFloat {
        let w = bgWidth()
        let bgDesignHeight = hasTopImage() ? 104.0 : 82.0
        return ceil(w * bgDesignHeight / 345.0)
    }
    
    func estimatedLayout(_ itemWidth: Double) {
        let itemWidth = ceil((itemWidth - YKNGap.dim_7() - YKNGap.dim_7() - YKNGap.youku_column_spacing() * 2)/3.0)
        var itemHeight = ceil(itemWidth / 0.75) + 44
        
        if let items = self.component?.getItems() {
            for (index, aItem) in items.enumerated() {
                if let itemDelegate = aItem.getItemDelegate() as? BaseItemDelegate {
                    let h = itemDelegate.preCaculateLayout(itemWidth, aItem)
                    if index ==  0 {
                        itemHeight = h
                    }
                }
            }
        }
        
        item?.layout?.renderRect = CGRect.init(x: 0, y: 0, width: itemWidth, height: itemHeight)
    }
    
    // MARK: FlowScrollProtocol
     
    func fsItemCount() -> Int {
        return self.component?.getItems()?.count ?? 0
    }
    
    func fsEdgeInset() -> UIEdgeInsets {
        return UIEdgeInsets.init(top: 0, left: YKNGap.dim_7(), bottom: 0, right: YKNGap.dim_7())
    }
    
    func fsItemSize() -> CGSize {
        guard let itemSize = item?.layout?.renderRect.size else {
            return CGSize.zero
        }
        return itemSize
    }
        
    func fsCreateItemView() -> UIView {
        let size = fsItemSize()
        return BaseItemContentView.init(frame: CGRect.init(x: 0, y: 0, width: size.width, height: size.height))
    }
    
    func fsReuseItemView(index: Int, itemView: UIView) {
        guard let itemView = itemView as? BaseItemContentView else {
            return
        }
                
        if let items = self.component?.getItems(), index < items.count {
            itemView.fillData(item: items[index], ratio: 0.75)
        }
    }
}
