//
//  Component12092BgView.swift
//  YKChannelComponent
//
//  Created by wustlj on 2022/6/10.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import YoukuResource
import YKChannelBase

class Component12092BgView: UIView {

    lazy var logoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.isUserInteractionEnabled = true
        return view
    }()
    
    lazy var titleImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.isUserInteractionEnabled = true
        return view
    }()
    
    lazy var actionView: YKRoundActionView = {
        let view = YKRoundActionView.init(frame: CGRect.init(x: self.width - YKNGap.dim_7() - 84, y: 48.0, width: 84, height: 30))
        return view
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        addSubview(logoImageView)
        addSubview(titleImageView)
        addSubview(actionView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
                
    }
        
    func fillScene(sloganPath: String?, logoPath: String?, themeColor: UIColor?) {
        fillData(sloganPath: sloganPath, logoPath: logoPath)
        
        actionView.refresh()
        if let sceneThemeColor = themeColor {
            actionView.layer.borderColor = sceneThemeColor.cgColor
            actionView.titleLabel.textColor = sceneThemeColor
        }
    }
    
    func fillData(sloganPath: String?, logoPath: String?) {
        titleImageView.frame = CGRect.init(x: YKNGap.dim_7(), y: 35, width: 137, height: 56)
        titleImageView.ykn_setImage(withURLString: sloganPath ?? "",
                               module: nil,
                               imageSize: .zero,
                               parameters: nil,
                               completed: nil)
        
        logoImageView.frame = self.bounds
        logoImageView.ykn_setImage(withURLString: logoPath ?? "",
                               module: nil,
                               imageSize: .zero,
                               parameters: nil,
                               completed: nil)
    }

}
