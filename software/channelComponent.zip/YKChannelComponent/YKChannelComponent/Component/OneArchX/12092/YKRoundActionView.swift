//
//  YKRoundActionView.swift
//  YKChannelComponent
//
//  Created by wustlj on 2022/6/10.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import YKUIComponent

public class YKRoundActionView : UIView {
    
    public override var isAccessibilityElement: Bool {
        get {
            return true
        }
        set {
            
        }
    }
        
    public override var accessibilityLabel: String? {
        get {
            return YKHomeAccessbilityHelperView.accessibilityLabel(with: self) + "，按钮"
        }
        set {
            
        }
    }

    private var selected: Bool = false
    
//    public var selectTextColor: UIColor = .ykn_tertiaryInfo
//    public var selectBgColor: UIColor = .ykn_seconarySeparator
//    public var selectBorderWidth: CGFloat = 0.0
//    public var selectBorderColor: UIColor = .clear

    public var unselectBgColor: UIColor = .ykn_border
    public var unselectTextColor: UIColor = .ykn_brandInfo
    public var unselectBorderWidth: CGFloat = 1.0
    public var unselectBorderColor: UIColor = .clear
    
    public var text: String = "进入剧场\u{e60f}"

    public lazy var titleLabel: UILabel = {
        let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 20, height: 20))
        label.textAlignment = .center
        label.isUserInteractionEnabled = true
        return label
    }()
    
    override init(frame: CGRect) {
        let font = YKNIconFont.sharedInstance().font(withSize: YKNFont.posteritem_subhead().pointSize)
        
        let size = calcStringSize(text, font: font, size: CGSize.init(width: 200, height: 100))                
        let fitFrame = CGRect.init(x: 0, y: 0, width: ceil(size.width + 24), height: frame.size.height)
        
        super.init(frame: fitFrame)
        
        layer.masksToBounds = true
        layer.cornerRadius = frame.size.height/2
        addSubview(titleLabel)
        titleLabel.font = font
        titleLabel.text = text
        
        refresh()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func refresh() {
//        titleLabel.text = "进入剧场\u{e60f}"
        titleLabel.text = text
        layer.borderWidth = unselectBorderWidth
        layer.borderColor = unselectBorderColor.cgColor
        backgroundColor = unselectBgColor
        titleLabel.textColor = unselectTextColor
        
        setNeedsLayout()
    }
    
    func refreshScene(_ sceneThemeColor: UIColor?) {
        if let sceneColor = sceneThemeColor {
            layer.borderColor = sceneColor.cgColor
            titleLabel.textColor = sceneColor
        } else {
            layer.borderColor = unselectBorderColor.cgColor
            titleLabel.textColor = unselectTextColor
        }
    }
    
    public override func layoutSubviews() {
        titleLabel.frame = CGRect.init(x: 0, y: 0, width: self.width, height: self.height)
    }
}
