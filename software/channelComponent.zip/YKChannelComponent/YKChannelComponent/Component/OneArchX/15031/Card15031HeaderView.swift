//
//  Card15031HeaderView.swift
//  YKChannelComponent
//
//  Created by CC on 2022/12/22.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import YKModeConfigFramework

extension CardHeaderGeneralView {
    func createFavorPopLabel() -> UILabel {
        let view = UILabel(frame: CGRect(x: 0, y: 0, width: 60.0, height: 30.0))
        view.font = YKNFont.posteritem_subhead()
        view.lineBreakMode = .byTruncatingTail
        view.textAlignment = .center
        view.textColor = .ykn_primaryButtonInfo
        view.backgroundColor = .ykn_cr_2
        view.layer.cornerRadius = 15.0
        view.layer.masksToBounds = true
        view.isHidden = true
        view.tag = 20221222
        self.addSubview(view)
        return view
    }
    func favorPopLabel() -> UILabel {
       let view = self.viewWithTag(20221222) as? UILabel ?? createFavorPopLabel()
        return view
    }
    
    func updateFavorPopData(_ component:IComponent?) {
//        super.fillData(component)
        if let card = component?.getCard(), let cardModel = card.cardModel, let trackBadgeCount = cardModel.trackBadgeCount, !trackBadgeCount.isEmpty {
            favorPopLabel().text = "更新+" + trackBadgeCount
            let size = calcStringSize(favorPopLabel().text, font: favorPopLabel().font, size: CGSize.init(width: 1000, height: 20))
            favorPopLabel().width = size.width + 18
        }
    }
    
    func showFavorPopView(_ show:Bool) {
        let favorPopLabel = favorPopLabel()
        if let text = favorPopLabel.text, !text.isEmpty {
            self.layer.masksToBounds = false
            self.superview?.layer.masksToBounds = false
            favorPopLabel.isHidden = !show
            favorPopLabel.left = self.titleLabel.right + 6
            favorPopLabel.centerY = titleLabel.centerY
        } else {
            favorPopLabel.isHidden = true
        }
    }
}
