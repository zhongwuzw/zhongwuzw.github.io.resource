//
//  Card15031.swift
//  YKChannelComponent
//
//  Created by CC on 2022/12/22.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport4Youku

class Card15031: BaseCardDelegate {

    override func layoutConfig() -> CardLayoutConfig {
        var config = super.layoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        return config
    }

    override func isShowHeader() -> Bool {
        guard let cardModel = self.card?.model as? BaseCardModel else {
            return false
        }
        
        if cardModel.noModuleTitle {
            return false
        }
        
        
        if cardModel.title != nil || cardModel.titleImg != nil {
            return true
        }
        
        return false
    }
}
