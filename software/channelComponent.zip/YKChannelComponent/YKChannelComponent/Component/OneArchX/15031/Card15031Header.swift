//
//  Card15031Header.swift
//  YKChannelComponent
//
//  Created by CC on 2022/12/22.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku
import YKResponsiveLayout
import SwiftUI
import YKSCService
import YKHome

class Card15031HeaderHandler:CardGeneraHeaderHandler {
    
    var isDisplayed: Bool {
        get {
            if let map = self.component?.getPage()?.pageContext?.concurrentDataMap,
               let flag = map["Card15031IsDisplayed"] as? Bool {
                return flag
            }
            
            return false
        }
        set(newValue) {
            if let map = self.component?.getPage()?.pageContext?.concurrentDataMap {
                map["Card15031IsDisplayed"] = newValue
            }
        }
    }
    
    override func enterDisplayArea(itemView: UIView?) {
        super.enterDisplayArea(itemView: itemView)
        if let reuseView = self.reuseView as? CardHeaderGeneralView {
            if !isDisplayed {
                isDisplayed = true
                reuseView.showFavorPopView(true)
                DispatchQueue.main.asyncAfter(deadline: .now() + 3) {
                    reuseView.showFavorPopView(false)
                }
            }
        }
    }
    
    override func exitDisplayArea(itemView: UIView?) {
        super.exitDisplayArea(itemView: itemView)
        if let reuseView = self.reuseView as? CardHeaderGeneralView {
            reuseView.showFavorPopView(false)
        }
    }
}

class Card15031Header:CardGeneralHeader {
   
    weak var handler15031:Card15031HeaderHandler?
    override func componentDidInit() {

    }
    
    override func loadEventHandlers() -> [ComponentEventHandler]? {
        let handler = Card15031HeaderHandler.init()
        self.handler15031 = handler
        return [handler]
    }
    
    override func reuseId() -> String? {
        let rightMode = CardHeaderUtil.getRightAreaMode(card: self.component?.getCard())
        let identifier = "card.header.Card15031Header." + String(describing: rightMode)
        return identifier
    }

    
    /// 初始化item view
    override func createView(_ itemSize: CGSize) -> UIView {
        let frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
        let rightMode = CardHeaderUtil.getRightAreaMode(card: self.component?.getCard())
        if rightMode == .bigImage {
            return CardBigImageTitleView.init(frame: frame)
        } else if rightMode == .scrollHotWords {
            return CardHeaderScrollKeyWordsView.init(frame: frame)
        } else if rightMode == .calendar {
            return CardHeaderCalendarWordView.init(frame: frame)
        } else {
            return CardHeaderKeyWordView.init(frame: frame)
        }
    }

    /// 复用
    override func reuseView(itemView: UIView) {
        if let itemView = itemView as? CardHeaderGeneralView {
            itemView.titleWidth = self.titleWidth
            itemView.fillData(self.component)
            self.handler15031?.reuseView = itemView
            itemView.updateFavorPopData(self.component)
            weak var weakself = self
            if CardHeaderUtil.isCalendar(card: self.component?.getCard()) {
                CalendarManager.autoShowCalendarCard(component: self.component, card:weakself?.component?.getCard(), rightView: weakself?.handler15031?.reuseView?.rightView)
            }
        } else if let itemView = itemView as? CardBigImageTitleView {
            itemView.fillData(self.component)
        }
        itemView.superview?.layer.zPosition = 101
    }
}
