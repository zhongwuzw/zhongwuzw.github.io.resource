//
//  Comp13500Model.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku
import YoukuResource

open class Comp13500Model: BaseComponentModel {

    var layoutData: [String : Any]? //保存layout字段数据
    
    open override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        guard let dataInfo = cmsInfo?["layout"] as? [String:Any] else {
            return
        }
        
        self.layoutData = dataInfo
    }
}
