//
//  Component13500.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/3/26.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import YoukuResource
import OneArchSupport4Youku

class Component13500: NSObject, ComponentDelegate {
   
    var componentWrapper: ComponentWrapper?

    func componentDidInit() {
        if let componentModel = self.component?.model as? Comp13500Model, let layoutInfo = componentModel.layoutData {
            var useRatio: Double = 0
            if let ratio = layoutInfo["ratio"] as? String  {
                useRatio = Double(ratio) ?? 1.78
            } else if let ratio = layoutInfo["ratio"] as? Double {
                useRatio = ratio
            }
            componentModel.extraExtend["aspectRatio"] = useRatio
        }
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom(), right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = YKNGap.dim_6()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_comp_margin_bottom()
        config.footerBottomMargin = YKNGap.youku_comp_margin_bottom()
        return config
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Comp13500Model.self as? T.Type
    }

    func columnCount() -> CGFloat {
        if let componentModel = self.component?.model as? Comp13500Model, let layoutInfo = componentModel.layoutData {
            if let columnNum = layoutInfo["columnNum"] as? Int {
                return CGFloat(columnNum)
            } else if let columnNum = layoutInfo["columnNum"] as? String, let intValue = Int(columnNum) {
                return CGFloat(intValue)
            }
        }
        return 2
    }

    /// 是否展示组件尾
    func isShowFooter() -> Bool {
        guard let componentModel = self.component?.model as? BaseComponentModel else {
            return false
        }
        if let change = componentModel.change, change.changeOnDrawer == true {
            return false
        }
        if componentModel.enter != nil || componentModel.change != nil {
            return true
        }
        return false
    }

    func footerTag() -> String? {
        return "comp.generic.footer"
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        return nil
    }

}
