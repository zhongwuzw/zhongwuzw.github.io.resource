//
//  Item12061.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/4/14.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Component12061: BaseDFComponentDelegate {
    override func createView(_ itemSize: CGSize) -> UIView {
        return Item12061ContentView.init(frame: CGRect.init(origin: .zero, size: itemSize))
    }
}
