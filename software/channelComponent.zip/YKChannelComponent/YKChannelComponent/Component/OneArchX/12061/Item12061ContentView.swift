//
//  Item12061ContentView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2022/4/14.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import SDWebImage
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YKSCChannel
import YoukuResource
import YKUIComponent

class Item12061ContentView: BaseDFItemContentView {
    //MARK: Property
    lazy var videoImageView: BaseVideoImageView = {
        let view = BaseVideoImageView(frame: .zero)
        view.clipsToBounds = true
        view.layer.cornerRadius = 0
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel.init(frame: CGRect.init(x: 9, y: 7, width: self.width - 18, height: 44))
        view.textColor = .ykn_primaryInfo
        view.font = YKNFont.posteritem_maintitle()
        view.numberOfLines = 2
        view.lineBreakMode = .byTruncatingTail
        return view
    }()
    
    var subInfoView: DoubleFeedSubInfoBaseView?
    weak var item: IItem?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        self.addSubview(videoImageView)
        self.addSubview(titleLabel)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func fillData(_ item: IItem?) {
        self.item = item
        super.fillData(item)
        guard let item = item, let itemModel = item.model as? BaseDFItemModel,
              let compModel = item.getComponent()?.model as? HomeComponentModel else {
            return
        }
        
        let ratio = itemModel.imgRatio ?? (compModel.imgRatio ?? 16 / 9.0)
        // image
        self.videoImageView.size = CGSize.init(width: self.width, height: self.width / ratio)
        self.videoImageView.fillData(item: item)

        //title
        self.titleLabel.text = itemModel.title

        //subInfoView
        if subInfoView != nil {
            subInfoView?.removeFromSuperview()
        }
        let subInfoType = DoubleFeedSubInfoViewFactory.getSubInfoType(item)
        if subInfoType != "" {
            let frame = CGRect.init(x: 9, y: self.titleLabel.bottom + 3, width: self.width - 9 - 30, height: 30)
            let view = DoubleFeedSubInfoViewFactory.createSubinfoViewWithType(subInfoType, frame)
            view?.fillData(item)
            if view != nil {
                addSubview(view!)
            }
            self.subInfoView = view
        }
        
        relayoutSubViews()
        
        //氛围
        updateScene(itemModel)
        
        //绑定事件
        Service.action.bind(itemModel.action, self)
        
        //负反馈
        Service.feedback.attach(itemModel.feedbackModel, toView: self, morePos: .BottomRightBorder, isSupportUndo: false) {
            item.getComponent()?.getItemManager()?.removeItem(item: item, animated: true)
        }
        
        // 预览视频
        if let playerModel = itemModel.playerModel {
            Service.player.attach(playerModel, toView: self, displayFrame: videoImageView.bounds)
        }
    }
    
    func updateScene(_ itemModel: BaseDFItemModel) {
        let scene = itemModel.scene
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: scene?.sceneTitleColor())
    }
    
    func relayoutSubViews() {
        self.titleLabel.top = self.videoImageView.bottom + 7
        self.titleLabel.height = calStringLimitedLineHeight(self.titleLabel.text, font: self.titleLabel.font, limitWidth: self.width - 9 - 20, limitLine: 2)

        self.subInfoView?.bottom = self.height - 3
    }
}
