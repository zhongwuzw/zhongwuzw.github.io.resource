//
//  Item12152.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/4/3.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout

class Item12152:NSObject, ItemDelegate {
    var itemWrapper: ItemWrapper?
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return Item12152Model.self as? T.Type
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        let imgW = itemWidth - 9 * 2
        let imgH = ceil(imgW * 203 / 152)
        return 49 + imgH + 17 + 32 + 12 + 2
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }
    
    func itemDidInit() {
       
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        return Item12152ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
    }

    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? Item12152ContentView,
            let itemModel = self.item?.itemModel as? Item12152Model else {
            return
        }
        
        itemView.fillData(itemModel)
    }
}

class Item12166: Item12152 {
    
    override func createView(_ itemSize: CGSize) -> UIView {
        return Item12166ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
    }
}

class Item12152Model: BaseItemModel {
    var moreText: String = ""
    var number: Int = 0
    
    override func setup(_ cmsInfo: [String : Any]?, source: String = "") {
        super.setup(cmsInfo, source: source)
        
        guard let dataInfo = cmsInfo?["data"] as? [String:Any] else {
            return
        }
        
        if let moreText = dataInfo["moreText"] as? String, moreText.count > 0 {
            self.moreText = moreText
        } else {
            self.moreText = "更多新片"
        }
        
        self.number = YKCCUtil.getIntValue(dataInfo["number"]) ?? 0
    }
}
