//
//  Item12152ContentView.swift
//  YKChannelComponent
//
//  Created by luofuzhong on 2024/4/3.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import Lottie
import OneArch
import OneArchSupport
import OneArchSupport4Youku

class Item12152ContentView: UIView {
        
    //MARK: Property
    
    lazy var titleContainer: UIView = {
        let view = UIView()
        return view
    }()
    
    lazy var numLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = UIFont(name: "Akrobat-ExtraBold", size: 28)
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let view = UILabel()
        view.textColor = .ykn_primaryInfo
        view.font = UIFont.systemFont(ofSize: 14, weight: .medium)
        return view
    }()
    
    lazy var videoImageView: UIImageGIFView = {
        let view = UIImageGIFView()
        let w = self.frame.size.width - 18
        let h = ceil(w * 203/152)
        view.frame = CGRect.init(x: 9, y: 49, width: w, height: h)
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        return view
    }()
    
    lazy var bgLayer1: UIView = {
        let view = UIView()
        view.clipsToBounds = true
        view.layer.cornerRadius = 3
        view.backgroundColor = .ykn_primaryFill
        return view
    }()
    
    lazy var bgLayer2: UIView = {
        let view = UIView()
        view.clipsToBounds = true
        view.layer.cornerRadius = 3
        view.backgroundColor = .ykn_primaryFill.withAlphaComponent(0.5)
        return view
    }()
    
    lazy var moreButton: UILabel = {
        let view = UILabel(frame: CGRect.init(x: videoImageView.left, y: self.height - 32 - 12, width: videoImageView.width, height: 32))
        view.textColor = .ykn_secondaryInfo
        view.font = UIFont.systemFont(ofSize: 12)
        view.layer.cornerRadius = 7
        view.clipsToBounds = true
        view.textAlignment = .center
        view.backgroundColor = .ykn_seconarySeparator
        return view
    }()
    
    lazy var bottomGradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.opacity = 1
        layer.frame = CGRect.init(x: 0, y: videoImageView.height - 40, width: videoImageView.width, height: 40)
        layer.startPoint = CGPoint.init(x: 0, y: 0.0)
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)
        
        let clr1 = UIColor.clear.cgColor
        let clr2 = UIColor.black.withAlphaComponent(0.4).cgColor
        layer.colors = [clr1, clr2]
        
        return layer
    }()
    
    lazy var dayLabel: UILabel = {
        let view = UILabel()
        view.textColor = .white
        view.font = UIFont.systemFont(ofSize: 12)
        return view
    }()
    
    lazy var gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.opacity = 1
        layer.frame = CGRect.init(x: 0, y: 0, width: self.width, height: 200)
        layer.startPoint = CGPoint.init(x: 0, y: 0.0)
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)
        
        return layer
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        initSubviews()
    }
    
    required init?(coder: NSCoder) {
        super.init(coder: coder)
        
        initSubviews()
    }
    
    func initSubviews() {
        self.layer.addSublayer(gradientLayer)
        
        addSubview(titleContainer)
        titleContainer.addSubview(numLabel)
        titleContainer.addSubview(titleLabel)
        
        addSubview(bgLayer2)
        addSubview(bgLayer1)
        addSubview(videoImageView)
        videoImageView.layer.addSublayer(bottomGradientLayer)
        videoImageView.addSubview(dayLabel)
        
        addSubview(moreButton)
        
        bgLayer1.frame = CGRect.init(x: 0, y: 0, width: videoImageView.width * 0.9, height: 40)
        bgLayer2.frame = CGRect.init(x: 0, y: 0, width: videoImageView.width * 0.8, height: 60)
        bgLayer1.centerX = videoImageView.centerX
        bgLayer1.bottom = videoImageView.bottom + 5
        bgLayer2.centerX = videoImageView.centerX
        bgLayer2.bottom = bgLayer1.bottom + 5
        
        self.clipsToBounds = true
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
    }
    
    func fillData(_ model: Item12152Model) {
        numLabel.text = "\(model.number)"
        numLabel.sizeToFit()
        numLabel.left = 7
        
        titleLabel.text = model.title
        titleLabel.sizeToFit()
        titleLabel.left = numLabel.right + 3
        titleContainer.width = titleLabel.right + 7
        titleContainer.height = numLabel.height
        
        titleLabel.centerY = numLabel.centerY + 2
        titleContainer.centerX = self.width / 2
        titleContainer.bottom = videoImageView.top - 2
        
        dayLabel.text = model.desc
        dayLabel.sizeToFit()
        dayLabel.left = 9
        dayLabel.bottom = videoImageView.height - 9
        
        moreButton.text = model.moreText
        videoImageView.ykn_setImage(withURLString: XCDNSTRING(model.img),
                                    module: "home",
                                    imageSize: CGSize.zero,
                                    parameters: nil,
                                    completed: nil)
    
        updateGradientLayer()

        //color
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: model.scene?.sceneTitleColor() )
        self.backgroundColor = sceneUtil(UIColor.ykn_elevatedPrimaryBackground, sceneColor: model.scene?.sceneCardFooterBgColor())
        
        //埋点
        Service.action.bind(model.action, self)
    }
    
    func updateGradientLayer() {
        self.gradientLayer.colors = [gradientColor().cgColor, UIColor.clear.cgColor]
    }
    
    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        updateGradientLayer()
    }
    
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
    
    func gradientColor() -> UIColor {
        return isDark() ? UIColor.createColorWithHexRGB(colorStr: "#1D62AA").withAlphaComponent(0.2) : UIColor.createColorWithHexRGB(colorStr: "#00A9F5").withAlphaComponent(0.2)
    }
}

class Item12166ContentView: Item12152ContentView {
    
    override func fillData(_ model: Item12152Model) {
        super.fillData(model)
        self.moreButton.font = YKNFont.button_text_weight(.medium)
        self.backgroundColor = sceneUtil(UIColor.ykn_tertiaryFill, sceneColor: model.scene?.sceneCardFooterBgColor())
    }
}
