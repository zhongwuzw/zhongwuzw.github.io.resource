//
//  ItemCard15046HeaderView.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/9/20.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource

class ItemCard15046HeaderView: AccessibilityView {

    weak var item:IItem?
    
    //MARK: Property
    lazy var titleLabel:UILabel = {
        let label = UILabel(frame:CGRect.init(x: 12.0, y: 8.0, width: 48.0, height: 30.0))
        label.backgroundColor = .clear
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 12, weight: .regular)
        label.textColor = UIColor.ykn_primaryInfo
        return label
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.titleLabel)
        self.layer.cornerRadius = 15.0
        self.clipsToBounds = true
        NotificationCenter.default.addObserver(self, selector: #selector(selectItemChanged), name: NSNotification.Name("item.sel.index.changed"), object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(item: IItem?, component: IComponent?, clickCallback:(()->Void)?) {
        self.item = item
        guard let item = item, let itemModel = item.model as? BaseItemModel else {
            return
        }
        guard let compModel = component?.model as? BaseComponentModel else {
            return
        }
        refreshSelectItem()
        self.titleLabel.text = itemModel.title
        titleLabel.sizeToFit()
        self.width = titleLabel.width + 24.0

        // action
        Service.statistics.bind(itemModel.action?.report, self, .Defalut)
        weak var weakself = self
        self.whenTapped {
            if weakself?.isItemSelected() == true {
                return
            }
            if weakself?.isItemSelected() == false {
                if let item = weakself?.item {
                    // 滚动到中间
                    if let component = item.getComponent()?.getComponentDelegate() as? ComponentCard15046Header {
                        component.newReuseView?.scrollToItem(at: item.index)
                    }
                    compModel.extraExtend["item.select.index"] = item.index
                    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "item.sel.index.changed"), object: nil, userInfo: nil)
                }
            }
            
            component?.getCard()?.changeMultiTabCardIndex(item.index)
        
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "card.15046.subcard.changed"), object: nil, userInfo: nil)

            clickCallback?()
        }
    }

    func isItemSelected() -> Bool {
        guard let item = self.item else {
            return ((self.item?.index) ?? 0) == 0
        }
        if let componentModel = item.getComponent()?.model as? BaseComponentModel {
            if let selIndex = componentModel.extraExtend["item.select.index"] as? Int {
                return (selIndex == item.index)
            }
        }
        return ((self.item?.index) ?? 0) == 0
    }
    
    func refreshSelectItem() {
        
        var selectColor = UIColor.ykn_brandInfo
        if let scene = item?.getPage()?.model?.style {
            if let headerColor = scene["sceneChildCardHeaderTitleColor"] as? String {
                selectColor = UIColor.createColorWithHexRGB(colorStr: headerColor)
            }
        }
        
        if isItemSelected() {
            titleLabel.textColor = selectColor
            self.backgroundColor = .ykn_co_15
        } else {
            titleLabel.textColor = .ykn_primaryInfo
            self.backgroundColor = .ykn_tertiaryFill
        }
    }
    
    @objc func selectItemChanged() {
        refreshSelectItem()
    }
    
}

class ItemCard15046Header: NSObject, ItemDelegate {
    
    var itemWrapper: ItemWrapper?
    
    func itemDidInit() {
        
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 30.0
    }
    
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = ItemCard15046HeaderView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }
    
    func reuseView(itemView: UIView) {
        guard let itemView = itemView as? ItemCard15046HeaderView else {
            return
        }
        itemView.fillData(item:self.item, component:self.item?.getComponent(), clickCallback: {
            
        })
    }
    
    func loadEventHandlers() -> [ItemEventHandler]? {
        return nil
    }

}
