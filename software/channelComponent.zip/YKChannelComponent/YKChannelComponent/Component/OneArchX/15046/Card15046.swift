//
//  Card15046.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/9/20.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import OneArch
import OneArchSupport4Youku

class Card15046ComponentJsonExtracter: DefaultComponentJsonExtracter {

    override public init() {
        super.init()
    }

    // MARK: - 原始数据加工

    override public func getComponentsJson(cardJson: [String : Any]?, card: ICard?) -> Result<[[String : Any]], Error> {
        guard let subCardsJson = cardJson?["nodes"] as? [[String: Any]] else {
            return .success([[String : Any]]()) //允许没有组件列表
        }
        var componentJson = [String:Any]()
        componentJson["type"] = "15046.multitab.header"
        var itemsJson = [[String:Any]]()
        for subCard in subCardsJson {
            var itemJson = [String:Any]()
            itemJson["type"] = "15046.multitab.header.item"
            itemJson["data"] = subCard["data"]
            itemsJson.append(itemJson)
        }
        componentJson["nodes"] = itemsJson
        
        // 如果上面就是轮播图的话需要组件上间距
        let sliders = ["14016", "14049", "14052", "14076", "14204", "14298", "14336"]
        if let cardCount = card?.getPage()?.getCards()?.count, cardCount > 0, let compModel = card?.getPage()?.getCards()?.last?.getComponents()?.first?.compModel, let type = compModel.type, sliders.contains(type) {
            let newExtraExtend = ["needMarginTop": true]
            if let data = componentJson["data"] as? [String: Any], var extraExtend = data["extraExtend"] as? [String:Any]  {
                extraExtend.merge(newExtraExtend) { (_, new) in new }
            }
            componentJson["data"] = ["extraExtend": newExtraExtend]
        }
        
        return .success([componentJson])
    }
}

class Card15046: BaseCardDelegate {

    override func enableMultiTabCard() -> Bool {
        return true
    }

    /// component数据解析格式代理
    override func getComponentJsonExtracter() -> ComponentJsonExtracter? {
        return Card15046ComponentJsonExtracter.init()
    }
}

class Card15047: Card10004 {

    /// component数据解析格式代理
    override func getComponentJsonExtracter() -> ComponentJsonExtracter? {
        return Card10004ComponentJsonExtracter.init()
    }
    
    open override func isShowHeader() -> Bool {
        return false
    }
    
    override func ignorePreferredCardSpacingTopValue() -> Bool {
        return true
    }
}

