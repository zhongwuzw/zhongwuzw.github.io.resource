//
//  ComponentCard15046Header.swift
//  YKChannelComponent
//
//  Created by tonggui on 2024/9/20.
//  Copyright © 2024 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import YKResponsiveLayout
import OneArchSupport4Youku
import PromptControl
import YKChannel

class ComponentCard15046Header2View: CardHeaderBaseView {
    
    lazy var scrollView: UIScrollView = {
        let view = UIScrollView(frame:self.bounds)
        view.contentInset = UIEdgeInsets.init(top: 0, left: 0, bottom: 0, right: 0)
        view.showsHorizontalScrollIndicator = false
        view.isScrollEnabled = true
        return view
    }()
    
    lazy var itemViews: [ItemCard15046HeaderView] = {
        var result = [ItemCard15046HeaderView]()
        var x = 0.0
        let itemWidth:CGFloat = 72
        for i in 0..<7 {
            let itemView = ItemCard15046HeaderView.init(frame: CGRect.init(x: x, y: 0, width: itemWidth, height: 30))
            x = x + itemWidth + 6.0
            self.scrollView.addSubview(itemView)
            result.append(itemView)
        }
        return result
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.addSubview(self.scrollView)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func fillData(component: IComponent?) {
        super.fillData(component)
                
        guard let items = component?.getItems() else {
            return
        }

        var x:CGFloat = 0
        for i in 0..<self.itemViews.count {
            self.itemViews[i].isHidden = (i >= items.count)
            if i < items.count {
                self.itemViews[i].fillData(item: items[i], component: component) { }
                self.itemViews[i].left = x
                x += self.itemViews[i].width + 6.0
            }
        }
        self.scrollView.contentSize = CGSize.init(width: x, height: 30.0)
        
        // scene
        self.backgroundColor = sceneUtil(.ykn_primaryBackground, sceneColor: component?.compModel?.scene?.sceneBgColor())
    }
    
    func scrollToItem(at index: Int) {
        guard index >= 0 && index < self.itemViews.count else { return }
        
        let itemView = self.itemViews[index]
        
        var offsetX = itemView.frame.origin.x - (self.scrollView.frame.width / 2) + (itemView.frame.width / 2)
        
        offsetX = max(0, min(offsetX, self.scrollView.contentSize.width - self.scrollView.frame.width))
        
        UIView.animate(withDuration: 0.3) {
            self.scrollView.contentOffset = CGPoint(x: offsetX, y: 0)
        }
    }
    
}

class ComponentCard15046Header: NSObject, ComponentDelegate {

    var componentWrapper: OneArch.ComponentWrapper?
    
    weak var newReuseView: ComponentCard15046Header2View?
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: 9.0, right: YKNGap.youku_margin_right())
        if let isSlider = self.component?.compModel?.extraExtend["needMarginTop"] as? Bool, isSlider {
            config.preferredCardSpacingTop = YKNGap.youku_module_margin_top()
        }
        return config
    }

    func componentDidInit() {
    }
    
    
    func layoutType() -> OneArch.ComponentLayoutType {
        return .custom
    }
    
    func loadEventHandlers() -> [OneArch.ComponentEventHandler]? {
        return nil
    }
    
    
    func reuseId() -> String? {
        let addressString = self.description
        return "card15046header" + addressString
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        return 30.0
    }

    /// 初始化item view
    func createView(_ itemSize: CGSize) -> UIView {
        let frame = CGRect.init(x: 0, y: 0, width: itemSize.width, height: itemSize.height)
        let view = ComponentCard15046Header2View.init(frame:frame)
        newReuseView = view
        
        return view
    }

    /// 复用
    func reuseView(itemView: UIView) {
        guard let view = itemView as? ComponentCard15046Header2View else {
            return
        }
        self.newReuseView = view
        view.fillData(component: self.component)
    }

}

