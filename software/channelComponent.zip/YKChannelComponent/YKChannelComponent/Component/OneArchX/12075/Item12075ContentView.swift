//
//  Item12075ContentView.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/25.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import OneArch

class Item12075ContentView: AccessibilityView,PlayerIconViewable {

    //MARK: Property
    weak var model: BaseItemModel?
    weak var layout: LayoutModel?
    
    lazy var topBgView: UIImageView = {
        let view = UIImageView()
        var image = UIImage.init(named: "big_feed_top_bg")
        let size = image?.size ?? CGSize.init(width: 38, height: 40)
        image = image?.resizableImage(withCapInsets: UIEdgeInsets.init(top: 2, left: size.width * 0.8, bottom: size.height, right: size.width * 0.8 + 1), resizingMode: UIImage.ResizingMode.tile)
        view.image = image
//        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
//        view.clipsToBounds = true
        return view
    }()
    
    lazy var bgView: UIView = {
        let view = UIView()
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.clipsToBounds = true
        return view
    }()
    
    lazy var imageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.backgroundColor = UIColor.ykn_elevatedPrimaryBackground
        view.contentMode = .scaleAspectFill
        view.isUserInteractionEnabled = true
        view.clipsToBounds = true
        return view
    }()
    
    lazy var playIconView: PlayerIconPreviewView = {
        let view = PlayerIconPreviewView()
        return view
    }()
    
    lazy var bottomView: Item12075BottomViewV2 = {
        let view = Item12075BottomViewV2()

        return view
    }()
    
    lazy var bottomBgView: UIImageGIFView = {
        
        let view = UIImageGIFView()
//        var image = UIImage.init(named: "feedBg0615")
//        view.image = image
        view.contentMode = .scaleAspectFill
        view.clipsToBounds = true
        return view
    }()
    
    //MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        createSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        createSubviews()
    }
    
    //MARK: -
    func createSubviews() {
        layer.masksToBounds = true
        layer.cornerRadius = 6.0
        layer.borderColor = UIColor.ykn_hideAbleSeparator.cgColor
        layer.borderWidth = 0.5
        backgroundColor = UIColor.ykn_secondaryGroupedBackground

        addSubview(bgView)
        bgView.addSubview(imageView)
//        bgView.addSubview(playIconView)
        
        bgView.addSubview(bottomBgView)
        bgView.addSubview(bottomView)
//        bottomView.sendSubviewToBack(bottomBgView)
        bottomView.layer.masksToBounds = false
        
        imageView.addSubview(self.topBgView)
        self.topBgView.addSubview(bottomView.subtitleLabel)
    }
    
    func fillModel(_ model: BaseItemModel?) {
        guard let model = model else { return  }
        self.model = model
        self.layout = model.layout
        if let img = XCDNSTRING(model.img), !img.isEmpty {
            let url = URL.init(string: img)
            let coverSize = Item12075ContentView.coverImageViewSize(width: bounds.width)
            imageView.frame = CGRect.init(x: 0, y: 0, width: coverSize.width, height: coverSize.height)
            imageView.sd_setImage(with: url) { (image:TBAnimatedImage?, error:Error?, type:SDImageCacheType, url:URL?) in
            
            }
        }
         
        updateBottomBgView()
        
        //先布局 然后加载bottomView
        self.customLayout(model)
        
        bottomView.fillModel(model)
    
        let layout = model.layout
        
        Service.action.bind(model.action, self) {
            self.addTransitionParams(model: model)
        } didAction: {
        }
        
        if let sceneBgImagePath = model.scene?.sceneBgImagePath(), !sceneBgImagePath.isEmpty {
        } else {
            Service.summary.attach(model.summary, toView: imageView, layout: layout.summary)
            Service.lbTexts.attach(model.lbTexts, toView: imageView, layouts: layout.lbTexts)
        }
        
        imageView.insertSubview(self.topBgView, at: 0)
    }
    
    func showBottomBGView(_ show: Bool) {
        guard let model = model else { return  }
        if let bottomBgImgLight = model.bottomBgImgLight,let bottomBgImgDark = model.bottomBgImgDark {
            self.bottomBgView.isHidden = !show
        }
    }
    
    func updateBottomBgView() {
        guard let model = model else { return  }
        bottomBgView.isHidden = true
        ///优先读取cms下发的img,然后才是氛围下发的img
        if let bottomBgImgLight = model.bottomBgImgLight,let bottomBgImgDark = model.bottomBgImgDark {
            bottomBgView.isHidden = false
            var url = URL.init(string: bottomBgImgLight)
            if isDark() {
                url = URL.init(string: bottomBgImgDark)
            }
            bottomBgView.sd_setImage(with: url) { (image:TBAnimatedImage?, error:Error?, type:SDImageCacheType, url:URL?) in
                
            }
        } else {
            if let sceneBgImagePath = model.scene?.sceneBgImagePath(), !sceneBgImagePath.isEmpty {
                bottomBgView.isHidden = false
                let url = URL.init(string: sceneBgImagePath)
                bottomBgView.sd_setImage(with: url) { (image:TBAnimatedImage?, error:Error?, type:SDImageCacheType, url:URL?) in
                    
                }
                self.backgroundColor = .ykn_secondaryGroupedBackground
            } else {
                self.backgroundColor = sceneUtil(.ykn_secondaryGroupedBackground, sceneColor: model.scene?.sceneCardFooterBgColor())
            }
        }
    }
        
    func customLayout(_ model: BaseItemModel?) {
        guard let itemModel = model else {
            return
        }
    
        bgView.frame = bounds
        
        let coverSize = Item12075ContentView.coverImageViewSize(width: bounds.width)
        imageView.frame = CGRect.init(x: 0, y: 0, width: coverSize.width, height: coverSize.height)
        playIconView.frame = CGRect.init(x: 0, y: 0, width: coverSize.width, height: coverSize.height)
                
        topBgView.frame = CGRect.init(x: 0, y: 0, width: self.width, height: 40)
        var subtitleSize:CGSize = self.layout?.subtitle?.renderRect.size ?? CGSize.zero
        
        //...
        let width = self.width
        let height = width * (101.0 / 345.0)
        bottomBgView.frame = CGRect.init(x: 0, y: self.height - height, width: width, height: height)

        if itemModel.mark == nil {
            subtitleSize = CGSize.init(width: self.width - YKNGap.dim_7()*2, height: subtitleSize.height)
        }

        bottomView.subtitleLabel.frame = CGRect.init(x: YKNGap.dim_7(), y: YKNGap.dim_5(), width: subtitleSize.width, height: subtitleSize.height)
    
        bottomView.frame = CGRect.init(x: 0, y: imageView.bottom, width: bounds.width, height: self.height - imageView.bottom)
    }
    
    func didClickPlayerIcon() {
        self.playIconView.isHidden = !self.playIconView.isHidden
    }
    
    public class func coverImageViewSize(width: CGFloat) -> CGSize {
        return CGSize.init(width: width, height: ceil(width * 9.0 / 16.0))
    }
    
    public class func estimatedLayout(width: CGFloat, model: BaseItemModel, layoutModel: LayoutModel)  {
        
        //bottom prelayout
        Item12075BottomViewV2.estimatedLayout(width: width, model: model, layoutModel: layoutModel)
        
        //content
        let bottomH = Item12075BottomViewV2.itemViewHeight(width: width, model: model, layoutModel: layoutModel)
        let coverImageH = self.coverImageViewSize(width: width).height
        
        let contentRect = CGRect.init(x: 0, y: 0, width: width, height: coverImageH + bottomH)
        layoutModel.renderRect = contentRect
    }
    
    /// 暗黑变化回调
    public override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        super.ykn_themeDidChange(by: manager, identifier: identifier, theme: theme)
        self.updateBottomBgView()
    }
    public override func traitCollectionDidChange(_ previousTraitCollection: UITraitCollection?) {
        self.updateBottomBgView()
    }
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
}

