//
//  Item12075.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/25.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport
import OneArchSupport4Youku
import YoukuResource
import YKResponsiveLayout
import YoukuAnalytics

class Item12075:NSObject, ItemDelegate,PlayerToolsEventHandlerDelegate {
    
    var itemWrapper: ItemWrapper?
    var itemView: Item12075ContentView?
    
    lazy var playerToolsEventHandler:PlayerToolsEventHandler = {
        let handler = PlayerToolsEventHandler()
        handler.delegate = self
        return handler
    }()
    
    static func create() -> ItemDelegate {
        return Item12075.init()
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseItemModel.self as? T.Type
    }
    
    func layoutType() -> ComponentLayoutType {
        return .columnAverage
    }
    
    func columnCount() -> CGFloat {
        return 2.0
    }
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {        
        self.estimatedLayout(itemWidth)
        
        guard let itemHeight = item?.layout?.renderRect.height else {
            return 0
        }
        return itemHeight
    }
    func createView(_ itemSize: CGSize) -> UIView {
        return UIView.init()
    }
    
    func reuseView(itemView: UIView) {
        
    }
    func loadEventHandlers() -> [ItemEventHandler]? {
        return [PlayerScrollEndItemEventHandler(),
                self.playerToolsEventHandler,
                ItemPlayerProgressEventHandler(),
                LongPressPreviewItemEventHandler()]
    }
    
    func itemDidInit() {
        if let title = item?.itemModel?.title, title.count > 0 {
            let paragraphStyle = NSMutableParagraphStyle()
            paragraphStyle.lineSpacing = 3.0
            paragraphStyle.lineBreakMode = .byTruncatingTail
            let attributedTitle = NSAttributedString.init(string: title, attributes: [.paragraphStyle: paragraphStyle])
            item?.itemModel?.attributedTitle = attributedTitle
        }
   
        if let itemModel = item?.itemModel {
            if itemModel.follow != nil {
                let followActionModel = ActionFactoryV2(itemModel, spmDExt: "_sub")
                let unfollowActionModel = ActionFactoryV2(itemModel, spmDExt: "_unsub")
                
                if followActionModel != nil {
                    itemModel.extraExtend["followActionModel"] = followActionModel
                }
                
                if unfollowActionModel != nil {
                    itemModel.extraExtend["unfollowActionModel"] = unfollowActionModel
                }
            }
            
            if itemModel.reserveModel != nil {
                let reserveActionModel = ActionFactoryV2(itemModel, spmDExt: "_reserve")
                let unReserveActionModel = ActionFactoryV2(itemModel, spmDExt: "_unreserve")
                
                if reserveActionModel != nil {
                    itemModel.extraExtend["reserveActionModel"] = reserveActionModel
                }
                
                if unReserveActionModel != nil {
                    itemModel.extraExtend["unreserveActionModel"] = unReserveActionModel
                }
            }
            
            let followActionModel = ActionFactoryV2(itemModel, spmDExt: "_watching")
            
            let unfollowActionModel = ActionFactoryV2(itemModel, spmDExt: "_cancelwatching")
            
            if followActionModel != nil {
                itemModel.extraExtend["collectActionModel"] = followActionModel
            }
            
            if unfollowActionModel != nil {
                itemModel.extraExtend["uncollectActionModel"] = unfollowActionModel
            }
        }
        
        if let reasons = item?.itemModel?.reasons {
            for (index, reason) in reasons.enumerated() {
                if index == 1, let img = reason.img, img.isEmpty == false {
                    item?.itemModel?.reasons?[index].imgEnabled = true
                }
            }
        }
        
        let itemModel = item?.itemModel
        if TransitionSwitch.enable12075DifferentPlayIdTransition(model: itemModel) {
            TransitionSwitch.enablePlayerTransition(model: itemModel)
        } else {
            TransitionSwitch.disablePlayerTransition(model: itemModel)
        }
        
        SelectionCardFeedAdUtil.bindAdGrayIdIfNeeded(item)
    }
    
    // MARK: 坑位布局计算
    
    func estimatedLayout(_ itemWidth: CGFloat) {

        guard let itemModel = self.item?.itemModel else {
            return
        }
        let width = itemWidth
        let height = width * 9.0 / 16.0
        
        Item12075ContentView.estimatedLayout(width: width, model: itemModel, layoutModel: itemModel.layout)
        
        
        if let mark = itemModel.mark {
            let layout = Service.mark.estimatedLayout(mark, toViewSize: CGSize.init(width: width, height: height))
            itemModel.layout.mark = layout
        }

        if let lbTexts = itemModel.lbTexts {
            itemModel.layout.lbTexts = Service.lbTexts.estimatedLayout(lbTexts, toViewSize: CGSize.init(width: width, height: height))
        }

        if let summary = itemModel.summary {
            if itemModel.layout.summary == nil {
                itemModel.layout.summary = Service.summary.estimatedLayout(summary, toViewSize: CGSize.init(width: width, height: height))
            }
        }
    }

    //MARK:PlayerToolsEventHandlerDelegate
    func didPlayerStart(_ playerModel: PlayerModel?) {
        let delegate = self.item?.getComponent()?.getComponentDelegate() as? Component12075
        let itemView = delegate?.itemView as? Item12075ContentView
        itemView?.showBottomBGView(false)
        self.itemView?.showBottomBGView(false)
    }
    
    func didPlayerStop(_ playerModel: PlayerModel?) {
        let delegate = self.item?.getComponent()?.getComponentDelegate() as? Component12075
        let itemView = delegate?.itemView as? Item12075ContentView
        itemView?.showBottomBGView(true)
    }
}
