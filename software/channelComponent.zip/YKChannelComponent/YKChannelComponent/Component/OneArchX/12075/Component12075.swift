//
//  Component12075.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/25.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku

class Component12075:NSObject, ComponentDelegate {
    weak var itemView: Item12075ContentView?
    var itemModel:BaseItemModel? {
        return self.component?.getItems()?.first?.itemModel
    }
    var item:IItem? {
        return self.component?.getItems()?.first
    }
    
    static func create() -> ComponentDelegate {
        return Component12075.init()
    }
    
    func layoutType() -> ComponentLayoutType {
        return .custom
    }
    
    func layoutConfig() -> ComponentLayoutConfig {
        var config = ComponentLayoutConfig()
        config.columnSpacing = YKNGap.youku_column_spacing()
        config.rowSpacing = YKNGap.youku_line_spacing()
        config.padding = UIEdgeInsets.init(top: 0, left: YKNGap.youku_margin_left(), bottom: YKNGap.youku_comp_margin_bottom() , right: YKNGap.youku_margin_right())
        config.preferredCardSpacingTop = 9.0
        config.headerBottomMargin = 9.0
        config.footerTopMargin = 18.0
        config.preferredRowHeight = 0.0 //100
        config.responsiveAdjustableMinColumnCount = 1.0
        return config
    }
    
    func getModelClass<T>() -> T.Type? where T : NodeModel {
        return BaseComponentModel.self as? T.Type
    }
    
    func columnCount() -> CGFloat {
        return 1
    }
    
    func loadEventHandlers() -> [ComponentEventHandler]? {
        let playerEvent = PlayerScrollEndCompEventHandler()
        return [playerEvent]
    }
    
    func componentDidInit() {
        
    }
    
    var componentWrapper: ComponentWrapper?
    
    func itemHeight(itemWidth: CGFloat) -> CGFloat {
        guard let item = self.component?.getItems()?.first else { return 0 }
        guard let itemDelegate = item.getItemDelegate() else { return 0 }
        return itemDelegate.itemHeight(itemWidth: itemWidth)
    }
    func createView(_ itemSize: CGSize) -> UIView {
        let itemView = Item12075ContentView(frame: CGRect(x: 0, y: 0, width: itemSize.width, height: itemSize.height))
        return itemView
    }

    func reuseView(itemView: UIView) {
        self.item?.itemModel?.dataCenterMap["dataIsBinded"] = true
        guard let itemView = itemView as? Item12075ContentView else {
            return
        }
        guard let itemModel = self.itemModel else {
            return
        }
        let itemLayout = itemModel.layout
       
        self.itemView = itemView

        // 角标
        Service.mark.attach(itemModel.mark, toView: itemView.imageView, layout: itemLayout.mark)

        //阴影+圆角
        if let sceneBgImagePath = itemModel.scene?.sceneBgImagePath(), !sceneBgImagePath.isEmpty {
            itemView.yk_addBorderAndShadow(sceneBorderColor:nil)
        } else {
            itemView.yk_addBorderAndShadow(sceneBorderColor:itemModel.scene?.sceneCardFooterBgColor())
        }
        
        
//        player
        if let playerModel = itemModel.playerModel {

            if playerModel.canPlay {
                itemView.playIconView.isHidden = false
            } else {
                itemView.playIconView.isHidden = true
            }
            let size = Item12075ContentView.coverImageViewSize(width: itemView.width)

            Service.player.attach(playerModel,
                                  toView: itemView.bgView,
                                  displayFrame: CGRect.init(origin: CGPoint.zero, size: size))
        }
    
        //负反馈
        weak var weakself = self
        weak var weakComponent = self.component
        itemModel.feedbackModel?.feedbackFinished = {
            if let weakself = weakself,
               let component = weakComponent
               {
                deleteComponentWithAnimation(component)
            }
        }
        
        //setModel
        itemView.fillModel(itemModel)
    }
}
