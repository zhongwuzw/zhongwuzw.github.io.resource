//
//  Item12075ContentViewTransition.swift
//  YKChannelComponent
//
//  Created by Kenneth on 2022/11/14.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import OneArch
import OneArchSupport4Youku
import OneTransition
import OneTransitionCore
import orange

extension Item12075ContentView {
    private func getTransitionImageView(itemModel: BaseItemModel) -> UIView? {
        let playerControl = PlayerControlManagerV2.instance
        let imageFrame = self.imageView.frame
        guard let playingModel = playerControl.currentPlayerModel,
              let currentModel = itemModel.playerModel,
              playingModel.isEqual(currentModel),
              let playerView = playerControl.currentPlayerView?.embedPlayerView,
              playerControl.playerState == .Playing,
              let corePlayerView = getSubview(className: "AXPCorePlayerView", in: playerView)
        else {
            let imgView = UIImageView(frame: imageFrame)
            imgView.ykn_setImage(withURLString: itemModel.img ?? "",
                                        module: "home",
                                        imageSize: CGSize.zero,
                                        parameters: nil,
                                        completed: nil)
            return imgView
        }
        
        
        return corePlayerView.snapshotView(afterScreenUpdates: false)
    }
    
    func addTransitionItem(itemModel: BaseItemModel) -> String? {
        if TransitionSwitch.enable12075DifferentPlayIdTransition(model: itemModel) {
            return addTransitionItemForDifferentPlayId(itemModel: itemModel)
        }

        guard let itemView = itemModel.playerModel?.itemView
        else { return nil }
        
        let item = OTTransitionItem()
        item.viewContainer = itemView
        item.originRect = self.imageView.convert(self.imageView.frame, to: nil)
        item.normalView = self.getTransitionImageView(itemModel: itemModel)
        
        let enable = Orange.getConfigByGroupName("OneTransition", key: "enableManualRemoveNormalView", defaultConfig: "1", isDefault: nil) as? String ?? "1"
        if enable == "1" {
            item.autoRemoveNormalViewWhenPushFinished = false
        }
        
        item.needTransitionBack = false
        item.transitionType = .view
        let transitionId = OTTransitionMonitor.sharedInstance.addTransitionItem(item: item)
        return transitionId
    }
    
    func addTransitionItemForDifferentPlayId(itemModel: BaseItemModel) -> String? {
        guard let itemView = itemModel.playerModel?.itemView,
              let playId = itemModel.playerModel?.playerId
        else { return nil }
        
        let item = OTTransitionItem()
        item.playId = playId
        item.viewContainer = itemView
        item.originRect = self.imageView.convert(self.imageView.frame, to: nil)
        item.needTransitionBack = false
        item.transitionType = .player
        item.isDifferentPlayId = true
        if PlayerControlManagerV2.enablePlayerPause {
            item.extraData["differentPlayIdPause"] = true
            item.extraData["placeholder"] = getTransitionImageView(itemModel: itemModel)
        }
        let transitionId = OTTransitionMonitor.sharedInstance.addTransitionItem(item: item)
        return transitionId
    }
                
    func addTransitionParams(model: BaseItemModel) {
        if TransitionSwitch.enable12075Transition(model: model) {
            // 设置无缝参数
            let transitionId = self.addTransitionItem(itemModel: model)
            let transitionKey = "onetransition_native_params"
            var transitionParams: [String: Any] = [
                "ot_transition_ids": [transitionId]
            ]
            
            if TransitionSwitch.enable12075DifferentPlayIdTransition(model: model) {
                if let preview = model.preview {
                    transitionParams["ot_preview_dict"] = preview
                }
                transitionParams["is_different_play_id"] = true
                transitionParams["source_play_id"] = model.playerModel?.playerId
            }
            
            model.action?.routeParams.yk_set(transitionKey, transitionParams)
            let isDifferentPlayId = TransitionSwitch.enable12075DifferentPlayIdTransition(model: model)
            if transitionId != nil && isDifferentPlayId {
                if PlayerControlManagerV2.enablePlayerPause {
                    if let curPlayerModel = PlayerControlManagerV2.shareInstance().currentPlayerView?.model, let itemPlayerModel = model.playerModel {
                        if curPlayerModel == itemPlayerModel {
                            model.playerModel?.stopNeedCapture = true
                            PlayerControlManagerV2.shareInstance().addStopCaptureView(model.playerModel)
                        }
                    }
                }
            }
        }
    }
}
