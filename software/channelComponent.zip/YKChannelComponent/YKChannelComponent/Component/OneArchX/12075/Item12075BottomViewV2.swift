//
//  Item12075BottomViewV2.swift
//  YKChannelComponent
//
//  Created by CC on 2021/10/25.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import SDWebImage
import YKResponsiveLayout
import YoukuResource
import YKHome
import OneArchSupport
import OneArchSupport4Youku
import OneArch

class Item12075BottomViewV2: AccessibilityView,ReserveButtonDelegate {
    static var bottomHeight = CGFloat(0)
    static var imageHeight = CGFloat(0)

    var feedbackBtn: UIView?
    weak var model: BaseItemModel?
    
    //MARK: Property
    lazy var imageView: UIImageGIFView = {
        let view = UIImageGIFView()
        view.backgroundColor = .clear
        view.contentMode = .scaleAspectFill
        view.layer.cornerRadius = 4.0
        view.clipsToBounds = true
        view.isUserInteractionEnabled = true
        
        return view
    }()
    
    lazy var titleLabel: UILabel = {
        let label = UILabel()
        label.font = YKNFont.posteritem_maintitle_weight(YKNFontWeight.semibold)
        label.textAlignment = .left
        label.textColor = .ykn_primaryInfo
        label.numberOfLines = 2
        label.lineBreakMode = .byTruncatingTail
        return label
    }()
    
    lazy var subtitleLabel: MarginLabel = {
        let label = MarginLabel()
        label.font = YKNFont.posteritem_maintitle()
        label.textAlignment = .left
        label.textColor = .ykn_primaryBackground
        label.numberOfLines = 2
        label.lineBreakMode = .byTruncatingTail
        return label
    }()
    
    //MARK: Property
    lazy var favorBtn: TrackShowButton = {
        let view = TrackShowButton.init(frame: CGRect.init(x: 0, y: 0, width: 60, height: 30))
        view.whenTapped {
            self.favorAction()
        }
        view.isHidden = true
        return view
    }()
    
    lazy var reserveBtn: ReserveBorderButton = {
        let view = ReserveBorderButton()
        let w = 60 * 1.0
        let h = w * 0.5
        view.frame = CGRect.init(x: 0, y: 0, width: w, height: h)
        view.layer.cornerRadius = h / 2.0
        
        view.delegate = self
        view.isHidden = true
        return view
    }()
    
    lazy var playBtn: UIButton = {
        let view = UIButton()
        view.backgroundColor = .clear
        view.clipsToBounds = true
        view.titleLabel?.font = YKNFont.posteritem_subhead()
        view.layer.borderWidth = 1
        view.layer.borderColor = UIColor.ykn_border.cgColor
        view.isUserInteractionEnabled = true
        view.setTitle("播放", for: UIControl.State.normal)
        var titleColor = UIColor.ykn_brandInfo
        view.setTitleColor(titleColor, for: UIControl.State.normal)
        view.layer.borderColor = UIColor.ykn_brandInfo.withAlphaComponent(0.5).cgColor
        view.layer.cornerRadius = 15
        view.isUserInteractionEnabled = false
        
        view.isHidden = true
        return view
    }()
    
    //MARK: - Init
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleAddCollectSuccessNotication), name: NSNotification.Name.init("kBSAddCollectSuccess"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleCancelCollectSuccessNotication), name: NSNotification.Name.init("kBSCancelCollectSuccess"), object: nil)
        
        createSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        createSubviews()
    }
    
    //MARK: -
    func createSubviews() {
//        backgroundColor = UIColor.ykn_elevatedPrimaryBackground
        
        addSubview(imageView)
        addSubview(titleLabel)
//        addSubview(subtitleLabel)
        addSubview(favorBtn)
        addSubview(reserveBtn)
        addSubview(playBtn)
    }
    
    var sceneTitleColor: UIColor?
    var sceneThemeColor: UIColor?
    var sceneButtonSelectBgColor: UIColor?
    func customLayout(_ model: BaseItemModel?) {

        let imageH = Item12075BottomViewV2.imageHeight
        let imageW = ceil(imageH * 3.0 / 4.0);
        let top = CGFloat(9)
        let left = CGFloat(9)
        
        self.sceneTitleColor = model?.scene?.sceneTitleColor()
        self.sceneThemeColor = model?.scene?.sceneThemeColor()
        self.sceneButtonSelectBgColor = model?.scene?.sceneButtonSelectBgColor()
        // 加追布局
        self.favorBtnLayout()
        // 预约按钮布局,与加追按钮一致
        self.reserveBtnLayout()
        
        let layout = model?.layout
        imageView.frame = CGRect.init(x: left, y: top, width: imageW, height: imageH)
        
        let titleMaxWidth = favorBtn.left - imageView.right - 6 - 2
        if let renderRect = layout?.title?.renderRect, !renderRect.equalTo(.zero) {
            titleLabel.frame = CGRect.init(x: renderRect.origin.x, y: renderRect.origin.y, width: (titleMaxWidth < renderRect.width) ? titleMaxWidth : renderRect.width, height: renderRect.height)
        } else {
            titleLabel.frame = CGRect.init(x: imageView.right + 6, y: 9, width: titleMaxWidth, height: YKNFont.height(with: titleLabel.font, lineNumber: 1))
        }
        
//        subtitleLabel.frame = layout?.subtitle?.renderRect ?? CGRect.zero
        
        let w = Double(16 + YKNGap.dim_5() * 2)
        let h = w
        let x = Double(self.width) - w
        let y = Double(self.height) - h - 3
                
        playBtn.frame = CGRect.init(x: self.right - 33 - 59, y: 12, width: 59, height: 30)

        Service.reasons.attach(model?.reasons, toView: self, layouts: model?.layout.reasons)
        Service.reasons.move(to: CGPoint.init(x: titleLabel.left, y: titleLabel.bottom + 3), inView: self)
        
        if let feedMore = self.feedbackBtn {
            feedMore.right = self.width - 2
            feedMore.bottom = self.bottom - 2
        }
    }
    
    func fillModel(_ model: BaseItemModel?) {

        self.model = model
        guard let model = model else { return }
        
        if let img = model.verticalImg, !img.isEmpty {
            let imageH = Item12075BottomViewV2.imageHeight
            let imageW = ceil(imageH * 3.0 / 4.0);
            let top = CGFloat(9)
            let left = CGFloat(9)
            imageView.frame = CGRect.init(x: left, y: top, width: imageW, height: imageH)

            let url = URL.init(string: img)
            imageView.sd_setImage(with: url) { (image:TBAnimatedImage?, error:Error?, type:SDImageCacheType, url:URL?) in
            
            }
        }
        titleLabel.text = model.title
        
        let isNewMode = model.data?["isNewMode"] as? Bool ?? false
        if isNewMode, let attriString = PlayerToolsViewV2.topAttributeString(model) {
            subtitleLabel.height = YKNFont.height(with: subtitleLabel.font, lineNumber: 2)
            subtitleLabel.numberOfLines = 2
            subtitleLabel.text = nil
            subtitleLabel.attributedText = attriString
        } else {
            subtitleLabel.height = YKNFont.height(with: subtitleLabel.font, lineNumber: 1)
            subtitleLabel.numberOfLines = 1
            subtitleLabel.attributedText = nil
            subtitleLabel.text = model.subtitle
        }

        //action
        Service.action.bind(model.titleAction, self, .OnlyClick)
        
        if model.trackShow != nil {
            bindStatisticsService()
            favorBtn.isHidden = false
            reserveBtn.isHidden = true
            playBtn.isHidden = true
        } else if model.reserveModel != nil {
            favorBtn.isHidden = true
            reserveBtn.isHidden = false
            reserveBtn.refresh(reserveModel: model.reserveModel, scene: model.scene)
            playBtn.isHidden = true

        } else {
            favorBtn.isHidden = true
            reserveBtn.isHidden = true
            playBtn.isHidden = false

            //color
            let defaultColor = UIColor.ykn_brandInfo
            playBtn.layer.borderColor = sceneUtil(defaultColor.withAlphaComponent(0.5), sceneColor: model.scene?.sceneThemeColor())?.cgColor
            playBtn.setTitleColor(sceneUtil(defaultColor, sceneColor: model.scene?.sceneThemeColor()), for: UIControl.State.normal)
        }
        
        self.feedbackBtn = self.superview?.superview?.viewWithTag(999998)
        
        self.fillFavorBtn(model)
        
        self.customLayout(model)

        //color
        self.titleLabel.textColor = sceneUtil(.ykn_primaryInfo, sceneColor: model.scene?.sceneTitleColor())

        if let sceneBgImagePath = model.scene?.sceneBgImagePath(), !sceneBgImagePath.isEmpty {
            self.subtitleLabel.textColor = .white
        } else {
            self.subtitleLabel.textColor = sceneUtil(.white, sceneColor: model.scene?.sceneSubTitleColor())
        }
        if let bottomBgImgLight = model.bottomBgImgLight,let bottomBgImgDark = model.bottomBgImgDark {
            self.titleLabel.textColor = .ykn_primaryInfo
            self.subtitleLabel.textColor = .white
        }
        
        //无障碍适配
        if (UIAccessibility.isVoiceOverRunning) {
            favorBtn.isHidden = true
            reserveBtn.isHidden = true
        }
    }
    func reserveBtnLayout() {
        if let feedMore = self.feedbackBtn {
            reserveBtn.right = feedMore.left - 2
        } else {
            reserveBtn.right = self.width - YKNGap.dim_6()
        }
        reserveBtn.top = YKNGap.dim_7()
    }
    func favorBtnLayout() {
        if let feedMore = self.feedbackBtn {
            favorBtn.right = feedMore.left - 2
        } else {
            favorBtn.right = self.width - YKNGap.dim_6()
        }
        favorBtn.top = YKNGap.dim_7()
    }
    
    func bindStatisticsService() {
        guard let trackShow = model?.trackShow else {
            return
        }
        
        if let isFavor = trackShow.isFavor, isFavor == true {
            let actionModel =  self.model?.extraExtend["uncollectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        } else {
            let actionModel = self.model?.extraExtend["collectActionModel"] as? ActionModel
            Service.statistics.bind(actionModel?.report, self.favorBtn, .OnlyClick)
        }
    }
    
    func favorAction() {
        guard let favor = model?.trackShow,
              let isFavor = favor.isFavor
        else {
            return
        }
        
        var params = [String : Any]()
        params["isFavor"] = isFavor
        params["id"] = favor.favorId ?? ""
        
        print("[LJ] 3 favorAction:", params)
    
        NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channel.function.adaptor.zhuiju"), object: nil, userInfo: params)
    }
    
    ///MARK:ReserveButtonDelegate
    func didUpdateReserveButtonFrame() {
        self.reserveBtnLayout()
//        self.reserveBtn.top = self.headIcon.top + 24
//        self.reserveBtn.right = self.width
    }
    
    @objc func handleAddCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: true)
    }
    
    @objc func handleCancelCollectSuccessNotication(notification: Notification) {
        handleNotication(notification: notification, favored: false)
    }
    
    func handleNotication(notification: Notification, favored: Bool) {
        guard let userInfo = notification.userInfo,
              let targetId = userInfo["targetId"] as? String
        else {
            return
        }
        
        print("[LJ] 3 userInfo:", userInfo)
        
        guard let favor = model?.trackShow,
              let currentId = favor.favorId
        else {
            return

        }
        
        guard currentId == targetId else {
            return
        }
        favor.isFavor = favored
        favor.count = favor.count + (favored ? 1 : -1)
        
        let trackShowBtnLayout = TrackShowButton.estimatedLayout(favor)
        model?.layout.extendExtra?["trackShowButton"] = trackShowBtnLayout
        
        fillFavorBtn(model)
        favorBtnLayout()
        bindStatisticsService()
    }
    
    public class func estimatedLayout(width: CGFloat, model: BaseItemModel, layoutModel: OneArchSupport4Youku.LayoutModel)  {
        
        layoutModel.title = TextLayoutModel()
        layoutModel.title?.font = YKNFont.posteritem_maintitle()

        layoutModel.subtitle = TextLayoutModel()
        layoutModel.subtitle?.font = YKNFont.posteritem_maintitle()

        let top = CGFloat(9.0)
        let titleH = YKNFont.height(with: layoutModel.title?.font, lineNumber: 1)
        let subtitleH = YKNFont.height(with: layoutModel.subtitle?.font, lineNumber: 1)
        var reasonH = YKNFont.height(with: YKNFont.tertiary_auxiliary_text(), lineNumber: 1)

        var trackShowBtnWidth : CGFloat = 0
        if let trackShow = model.trackShow {
            let trackShowBtnLayout = TrackShowButton.estimatedLayout(trackShow)
            if layoutModel.extendExtra == nil {
                layoutModel.extendExtra = [String: Any]()
            }
            layoutModel.extendExtra?["trackShowButton"] = trackShowBtnLayout
            trackShowBtnWidth = trackShowBtnLayout.totalSize.width
        }
        
        //image pre layout
        let imageX = CGFloat(9.0)
        var imageH = titleH
        //不在有副标题
//        imageH += subtitleH
        imageH += reasonH + 3
        imageHeight = imageH
        let imageW = imageH * 3.0 / 4.0
        
        //title pre layout
        let favorW = trackShowBtnWidth == 0 ? CGFloat(59) : trackShowBtnWidth
        let feedMore = 30.0
        let titleLeft = imageX + imageW + 6.0
        let titleW = width - titleLeft - favorW - 2 - feedMore
        layoutModel.title?.renderRect = CGRect.init(x: titleLeft, y: top, width: titleW, height: titleH)
        
        //reasons pre layout
        if let reasons = model.reasons {
            let boundsWidth = trackShowBtnWidth == 0 ? (width - 6 - 50 - 9 - 100 - 9) : titleW
            let reasonLayouts = Service.reasons.estimatedLayout(reasons, boundingSize: CGSize.init(width: boundsWidth, height: 30))
            layoutModel.reasons = reasonLayouts
            if let layout = reasonLayouts.first {
                reasonH = layout.renderRect.height
            }
        }
        
        //subtitle pre layout
        let subtitleY = top + titleH
        let subtitleLeft = YKNGap.dim_7()
        layoutModel.subtitle?.renderRect = CGRect.init(x: subtitleLeft, y: subtitleY, width: width - 56 - 3 - subtitleLeft, height: subtitleH)
        
        //reason pre layout
//        let reasonY = subtitleY + subtitleH + 6
        //副标题去掉后 reason上移
        let reasonY = top + titleH + 3

        //content
        let bottomH = reasonY + reasonH + 9
        bottomHeight = bottomH
    }
    
    public class func itemViewHeight(width: CGFloat, model: BaseItemModel, layoutModel: OneArchSupport4Youku.LayoutModel) -> CGFloat {
        
        return bottomHeight
    }
    
    // MARK: - 加追按钮
    private func fillFavorBtn(_ model: BaseItemModel?) {
        guard let model = model, let favor = model.trackShow, !favorBtn.isHidden else {
            return
        }
        
        if let sceneTitleColor = model.scene?.sceneTitleColor(), let sceneThemeColor = model.scene?.sceneThemeColor()  {
            favorBtn.selectTextColor = sceneTitleColor
            favorBtn.selectBgColor = .clear
            favorBtn.selectBorderWidth = 1.0
            favorBtn.selectBorderColor = sceneTitleColor.withAlphaComponent(0.3)
            
            favorBtn.unselectTextColor = .ykn_brandInfo
            favorBtn.unselectBgColor = .ykn_border
            favorBtn.unselectBorderWidth = 1.0
            favorBtn.unselectBorderColor = .clear
            favorBtn.canShowGradientLayer = true
        } else {
            favorBtn.canShowGradientLayer = true
            favorBtn.selectTextColor = .ykn_tertiaryInfo
            favorBtn.selectBgColor = .ykn_seconarySeparator
            favorBtn.selectBorderWidth = 0.0
            favorBtn.selectBorderColor = .clear
            
            favorBtn.unselectTextColor = .ykn_brandInfo
            favorBtn.unselectBgColor = .ykn_border
            favorBtn.unselectBorderWidth = 1.0
            favorBtn.unselectBorderColor = .clear
        }
        if let layModel = model.layout.extendExtra?["trackShowButton"] as? TrackShowButtonLayoutModel {
            self.favorBtn.fillModel(favor, layoutModel: layModel)
        } else {
            self.favorBtn.fillModel(favor)
        }
    }
}
