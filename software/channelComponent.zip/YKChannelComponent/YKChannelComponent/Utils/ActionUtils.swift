//
//  ActionUtils.swift
//  YKChannelComponent
//
//  Created by wustlj on 2021/4/6.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import YKSCBase
import YKChannelBase

func ActionFactory(event: YKSCEvent, compContext: YKSCComponentContext) -> ActionModel? {
    return ActionFactory(event: event, compContext: compContext, spmDExt: nil)
}

func ActionFactory(event: YKSCEvent, compContext: YKSCComponentContext, spmDExt: String?) -> ActionModel? {
    guard let itemInfo = event.params?.scDictionary(forKey: "itemInfo") as? [String:Any] else {
        return nil
    }
    
    guard let dataInfo = itemInfo["data"] as? [String:Any] else {
        return nil
    }
    
    guard var actionInfo = dataInfo["action"] as? [String:Any] else {
        return nil
    }
    
    if var reportInfo = actionInfo["report"] as? [String:Any] {
        if let spmD = reportInfo["spmD"] as? String, let spmDExt = spmDExt {
            reportInfo["spmD"] = spmD + spmDExt
            actionInfo["report"] = reportInfo
        }
    }
    return buildActionModel(actionInfo, compContext: compContext)
}

func ActionFactory(event: YKSCEvent, compContext: YKSCComponentContext, spmD: String) -> ActionModel? {
    guard let itemInfo = event.params?.scDictionary(forKey: "itemInfo") as? [String:Any] else {
        return nil
    }
    
    guard let dataInfo = itemInfo["data"] as? [String:Any] else {
        return nil
    }
    
    guard var actionInfo = dataInfo["action"] as? [String:Any] else {
        return nil
    }
    
    if var reportInfo = actionInfo["report"] as? [String:Any] {
        reportInfo["spmD"] = spmD
        actionInfo["report"] = reportInfo
    }
    return buildActionModel(actionInfo, compContext: compContext)
}

