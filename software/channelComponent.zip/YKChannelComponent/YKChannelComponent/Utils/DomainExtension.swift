//
//  DomainExtension.swift
//  YKChannelComponent
//
//  Created by better on 2022/12/9.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import OneArch
import OneArchSupport4Youku
import OneArchSupport
import YKHome
import orange

extension IItem {
    func isPageInPreload() -> Bool {
        return private_isPageInPreload(self.getPage())
    }
    
    func isPageInActive() -> Bool {
        return self.pageContext?.isPageActive() ?? false
    }
}

extension IComponent {
    func isPageInPreload() -> Bool {
        return private_isPageInPreload(self.getPage())
    }
    
    func isPageInActive() -> Bool {
        return self.pageContext?.isPageActive() ?? false
    }
}

extension ICard {
    func isPageInPreload() -> Bool {
        return private_isPageInPreload(self.getPage())
    }
    
    func isPageInActive() -> Bool {
        return self.pageContext?.isPageActive() ?? false
    }
}

extension IPage {
    func isPageInPreload() -> Bool {
        return private_isPageInPreload(self)
    }
    
    func isPageInActive() -> Bool {
        return self.pageContext?.isPageActive() ?? false
    }
}

private func private_isPageInPreload(_ page: IPage?) -> Bool {
    guard let pageModel = page?.pageModel else {
        return false
    }
    if pageModel.dataState != .network {
        return true
    }
    return false
}

func isPageInThemeMode(_ page: IPage?) -> Bool {
    guard let pageContext = page?.pageContext else {
        return false
    }
    let pageItem = pageContext.concurrentDataMap["pageInitInfo.cmsPageItem"] as? CMSPageItem
    if pageItem?.theme != nil && (pageItem?.theme.navTintColor != nil || pageItem?.theme.identifier != nil) {
        return true
    }
    
    // 老主题样式
    if ((HomeSkinConfige.sharedInstance()?.isThemeStyle() ?? false) == true) {
        return true
    }
    return false
}

func isSelectionPagePullDrawerMode() -> Bool {
    return UserDefaults.standard.bool(forKey: "home.NewSectionPage.CurrentPullRefreshDrawerMode")
}

func disableSecondFloorCompChange() -> Bool {
    let orangeInfo = Orange.getGroupConfig(byGroupName: "yksc_config")
    return orangeInfo?.yk_bool_opt("disableSecondFloorCompChange") ?? false
}
