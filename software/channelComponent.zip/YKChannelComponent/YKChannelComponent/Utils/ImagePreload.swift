//
//  ImagePreload.swift
//  YKChannelComponent
//
//  Created by better on 2021/8/4.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit

func preloadImage(width: CGFloat, height: CGFloat, url: String?) {
//20210817 暂时不上线
//    guard let url = url else {
//        return
//    }
//
//    var params = [String : Any]()
//    params["width"] = width
//    params["height"] = height
//    params["url"] = url
//
//    print("[jbp] image preload:", params)
//
//    NotificationCenter.default.post(name: NSNotification.Name(rawValue: "yk.channel.function.adaptor.imagePreload"), object: nil, userInfo: params)
}


extension UIImage {
    func YKChannelComponent_imageWithTintColor(_ tintColor: UIColor?) -> UIImage? {
        UIGraphicsBeginImageContextWithOptions(self.size, false, self.scale)

        guard let context = UIGraphicsGetCurrentContext(), let cgImage = self.cgImage else {
            return self
        }

        context.translateBy(x: 0, y: self.size.height)
        context.scaleBy(x: 1.0, y: -1.0)
        context.setBlendMode(.normal)
        let rect = CGRect(x: 0, y: 0, width: self.size.width, height: self.size.height)
        context.clip(to: rect, mask: cgImage)
        tintColor?.setFill()
        context.fill(rect)

        let newImage = UIGraphicsGetImageFromCurrentImageContext()

        UIGraphicsEndImageContext()

        return newImage
    }
}

func resize(_ image: UIImage, _ targetSize: CGSize, _ scale: CGFloat = UIScreen.main.scale) -> UIImage? {
 let size = image.size
 let widthRatio = targetSize.width / size.width
 let heightRatio = targetSize.height / size.height
 let scaleFactor = min(widthRatio, heightRatio)
 let newSize = CGSize(width: size.width * scaleFactor, height: size.height * scaleFactor)
        
 UIGraphicsBeginImageContextWithOptions(newSize, false, scale)
    image.draw(in: CGRect(origin: CGPoint.zero, size: newSize))
 let newImage = UIGraphicsGetImageFromCurrentImageContext()
 UIGraphicsEndImageContext()
        
 return newImage
}
