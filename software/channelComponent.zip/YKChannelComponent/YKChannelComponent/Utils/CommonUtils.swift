//
//  CommonUtils.swift
//  YKChannelComponent
//
//  Created by better on 2021/4/1.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import YoukuResource
import YKSCBase
import YKAdSDK
import YKChannelBase
import NovelAdSDK
import SDWebImage

func calcStringSize(_ string: String?, font: UIFont?, size: CGSize) -> CGSize {
    guard let string = string as NSString? else {
        return CGSize.zero
    }
    
    guard let font = font else {
        return CGSize.zero
    }
    
    var fitSize: CGSize = string.boundingRect(with: size,
                                              options: .usesFontLeading,
                                              attributes: [.font : font],
                                              context: nil).size
    
    fitSize = CGSize(width: ceil(fitSize.width),
                     height: ceil(fitSize.height))
    
    return fitSize
}

// 计算文本高度时 设置height需要额外加3-5px 不然展示不开
func calcStringHeight(_ text: String?, font: UIFont, limitSize: CGSize) -> CGFloat {
    guard let text = text else {
        return .zero
    }

    var fitSize = NSString(string: text).boundingRect(with: limitSize,
                                                      options: 
                                                        [.usesLineFragmentOrigin, .truncatesLastVisibleLine],
                                                      attributes: [.font: font],
                                                      context: nil).size
    fitSize = CGSize(width: ceil(fitSize.width), height: ceil(fitSize.height))
    return fitSize.height
}

func calStringLimitedLineHeight(_ text: String?, font: UIFont, limitWidth: CGFloat, limitLine: Int) -> CGFloat {
    guard let text = text else {
        return .zero
    }

    let limitSize = CGSize.init(width: limitWidth, height: CGFloat.greatestFiniteMagnitude)
    let fitSize = NSString(string: text).boundingRect(with: limitSize,
                                                      options: [.usesLineFragmentOrigin, .truncatesLastVisibleLine],
                                                      attributes: [.font: font],
                                                      context: nil).size
    let fitLineH = YKNFont.height(with: font, lineNumber: limitLine)
    return min(fitSize.height, fitLineH)
}

func calAttributeStringSize(_ string: NSAttributedString?, size: CGSize) -> CGSize {
    guard let string = string else {
        return CGSize.zero
    }
    
    var fitSize: CGSize = string.boundingRect(with: size,
                                              options: [.usesLineFragmentOrigin, .usesFontLeading],
                                              context: nil).size
    
    fitSize = CGSize(width: ceil(fitSize.width),
                     height: ceil(fitSize.height))
    
    return fitSize
}

func createPartRadius(view: UIView, cornerRadius: CGSize, corner: UIRectCorner) {
    let maskPath = UIBezierPath.init(roundedRect: view.bounds, byRoundingCorners: corner, cornerRadii: cornerRadius)
    let maskLayer = CAShapeLayer()
    maskLayer.frame = view.bounds
    maskLayer.path = maskPath.cgPath
    view.layer.mask = maskLayer
}

func createVideoImageView() -> UIImageGIFView {
    let view = UIImageGIFView()
    view.contentMode = .scaleAspectFill
    view.clipsToBounds = true
    return view
}

func createMoreButton() -> UIButton {
    let button = UIButton.init(frame: CGRect.init(x: 0, y: 0, width: 30, height: 30))
    button.setImage(UIImage.init(named: "double_feed_more")?.withRenderingMode(.alwaysTemplate), for: .normal)
    button.setImage(UIImage.init(named: "double_feed_more")?.withRenderingMode(.alwaysTemplate), for: .highlighted)
    button.imageView?.tintColor = UIColor.ykn_quaternaryInfo
    return button
}

func deleteComponentWithAnimation(_ compContext: YKSCComponentContext) {
    guard let cardContext = compContext.scCardContext else {
        return
    }
    let index = compContext.scInteger(forKey: YKSCComponentDataLayoutLastItemIndex)
    if index >= 0 {
        //从数据源中移除
        cardContext.scFireEvent(YKSCCardEventUpdateCardModule,
                                params: ["type" : "delete", "componentContexts": [compContext]])
        //刷新
        cardContext.scFireEvent(YKSCCardEventRefreshCardModule,
                                params: ["animated":true,
                                         "type":"delete",
                                         "componentDeleteItemIndex":index,
                                         "componentContexts":[compContext]])
    }
}

func createUCAdFeedbackModel(_ itemContext: YKSCItemContext, dataInfo: [String: Any]) -> FeedbackModel {
    let feedbackModel: FeedbackModel = FeedbackModel()
    
    var defalutTitle = "就是不感兴趣"
    if let defaultFeedbackText = dataInfo["defaultFeedbackText"] as? String {
       defalutTitle = defaultFeedbackText
    }
    feedbackModel.reasons = [FeedbackItemModel.init(["title":defalutTitle, "reason":"I"])]
    
    feedbackModel.report = itemContext.model.action?.report
    feedbackModel.scene = itemContext.scene()
    
    let ucAdModel = YKAdResponseModel.init()
    let seatBid = YKAdResponseSeatBid.init()
    var bidModel: YKAdResponseBid?
    if let json = dataInfo["bid"] as? [String:Any] {
        bidModel = YKAdResponseBid.adResponseModel(withJSONObject: json)
    }
    if let bidModel = bidModel {
        seatBid.bid = [bidModel]
    }
    ucAdModel.seatBid = [seatBid]
    
    let ucExtra = (dataInfo["extend"] as? [String:Any])?["ucExtra"] as? [String:Any]
    if let bidid = ucExtra?["bidid"] as? String {
        ucAdModel.bidId = bidid
    }
    if let dmpid = ucExtra?["dmpid"] as? String {
        ucAdModel.dmpId = dmpid
    }
    if let id = ucExtra?["id"] as? String {
        ucAdModel.resId = id
    }
    
    feedbackModel.ucAdModel = ucAdModel
    
    itemContext.model.feedbackModel = feedbackModel
    
    return feedbackModel
}

func createNovelAdFeedbackModel(_ itemContext: YKSCItemContext, nadApi: NadAPI, unifyAdData: [String: Any]) -> FeedbackModel {
    let feedbackModel: FeedbackModel = FeedbackModel()
    
    let defalutTitle = "就是不感兴趣"
    feedbackModel.reasons = [FeedbackItemModel.init(["title":defalutTitle, "reason":"I"])]
    feedbackModel.report = itemContext.model.action?.report
    feedbackModel.scene = itemContext.scene()
    
    let novelAdModel = nadApi.createAdModel(from: unifyAdData)
    
    feedbackModel.novelAdModel = novelAdModel
    
    itemContext.model.feedbackModel = feedbackModel
    
    return feedbackModel
}

func isSameobject(object1:AnyObject?, object2:AnyObject?) -> Bool {
    guard let object1 = object1, let object2 = object2 else {
        return false
    }
    let ptr1 = Unmanaged<AnyObject>.passUnretained(object1).toOpaque()
    let ptr2 = Unmanaged<AnyObject>.passUnretained(object2).toOpaque()
    if ptr1 == ptr2 {
        return true
    }
    return false
}

// 发通知
func postNotification(_ name: String, _ object: Any? , _ userInfo: [AnyHashable : Any]? = nil) {
    NotificationCenter.default.post(name: NSNotification.Name.init(name), object: object, userInfo: userInfo)
}

/// label添加描边配置
func drawOutlineAttributedString(string: String?,
                                 font: UIFont,
                                 textColor: UIColor,
                                 strokeColor: UIColor,
                                 strokeWidth: CGFloat) -> NSAttributedString {
    let paragraph = NSMutableParagraphStyle()
    paragraph.alignment = .left
    let dic = [NSAttributedString.Key.font:font,
               NSAttributedString.Key.paragraphStyle: paragraph,
               NSAttributedString.Key.foregroundColor: textColor,
               NSAttributedString.Key.strokeWidth: (-strokeWidth),
               NSAttributedString.Key.strokeColor: strokeColor] as [NSAttributedString.Key : Any]
    return NSMutableAttributedString.init(string: string ?? "", attributes: dic)
}

func drawShadowAttributedString(string: String?,
                                shadowBilurRadius: CGFloat,
                                shadowOffset: CGSize,
                                 shadowColor: UIColor) -> NSAttributedString {
    let shadow = NSShadow.init()
    shadow.shadowBlurRadius = shadowBilurRadius
    shadow.shadowOffset = shadowOffset
    shadow.shadowColor = shadowColor
    
    let dic = [NSAttributedString.Key.shadow: shadow] as [NSAttributedString.Key : Any]
    return NSMutableAttributedString.init(string: string ?? "", attributes: dic)
}

func XCDNSTRING(_ string: String?) -> String? {
    return TBImageUtility.convertUrlString(toXcdnStr: string)
}

func calcInterpolationValue(p1: CGFloat, p1Value: CGFloat, p2: CGFloat, p2Value:CGFloat, x: CGFloat) -> CGFloat {
    if abs(p1 - p2) < 0.00001 {
        return p1Value
    }
    return (x - p1) * (p1Value - p2Value) / (p1 - p2) + p1Value
}

func getSubview(className: String, in view: UIView) -> UIView? {
    guard let cls = NSClassFromString(className),
          view.subviews.count > 0
    else { return nil }
    
    var foundView: UIView? = nil
    for subview in view.subviews {
        if subview.isKind(of: cls) {
            foundView = subview
            break
        }
        
        foundView = getSubview(className: className, in: subview)
        
        if foundView != nil {
            break
        }
    }
    
    return foundView
}

//获取当前日期
func currentDateString(dateFormat:String = "yyyyMMdd") -> String {
    let curDate = Date()
    let formatter = DateFormatter()
    formatter.dateFormat = dateFormat
    let date = formatter.string(from: curDate)
    return date
}

func isDarkMode() -> Bool {
    let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
    return (theme == YKNThemeIdentifierDark)
}

func downloadImage(url: String?, callback:@escaping (_ image: UIImage?) -> Void) {
    SDWebImageManager.shared()?.downloadImage(with: URL.init(string: url ?? ""), progress: nil) { (image, error, type, finished, url) in
        callback(image)
    }
}

extension UIImageGIFView {
    
    func setImage(url: String?) {
        guard let url = url else {
            return
        }
        self.ykn_setImage(withURLString: url, module: "", imageSize: .zero, parameters: nil, completed: nil)
    }
    
}

//"yyyy-MM-dd"
func timeIntervalToDateString(timeInterval: Int) -> String {
    let date:Date = Date.init(timeIntervalSince1970: Double(timeInterval))
    let formatter = DateFormatter.init()
    formatter.dateFormat = "yyyy-MM-dd"
    return formatter.string(from: date as Date)
}

func runCodeWithoutAnimate(block:()->Void) {
    CATransaction.begin()
    CATransaction.setDisableActions(true)
    block()
    CATransaction.commit()
}
