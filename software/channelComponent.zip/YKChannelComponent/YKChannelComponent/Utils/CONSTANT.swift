//
//  CONSTANT.swift
//  YKChannelComponent
//
//  Created by better on 2022/11/10.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit

class CONSTANT {

    /**轮播图大卡**/
    public static let LUNBO_BIGCARD_EXTEND_TOP = 75.0
    public static let LUNBO_BIGCARD_EXTEND_BOTTOM = 15.0

}
