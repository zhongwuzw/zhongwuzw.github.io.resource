//
//  OutlineLabel.swift
//  YKChannelComponent
//
//  Created by better on 2022/11/3.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit

/*
 用Label形式偶现描边偏移，建议采用attributestring绘制
class OutlineLabel: UILabel {
    
    var stroke_color: UIColor?
    var stroke_width: CGFloat = 1.0
    
    override func drawText(in rect: CGRect) {
        if let c = UIGraphicsGetCurrentContext() {
            let shadowOffset = self.shadowOffset
            let textColor = self.textColor

            c.setLineWidth(self.stroke_width)
            c.setLineJoin(.round)
            c.setTextDrawingMode(.stroke)
            self.textColor = self.stroke_color ?? UIColor.white
            super.drawText(in: rect)
            
            c.setTextDrawingMode(.fill)
            self.textColor = textColor
            self.shadowOffset = CGSize(width: CGFloat(0), height:CGFloat(0))
            super.drawText(in: rect)
            self.shadowOffset = shadowOffset
        } else {
            super.drawText(in: rect)
        }
    }
}
*/

func defaultShadowOutlineAttributedString(string: String?,
                                          font: UIFont,
                                          textColor: UIColor) -> NSAttributedString {
    let borderColor = UIColor.createColorWithHexRGB(colorStr: "#222222")
    let shadowColor = UIColor.createColorWithHexRGB(colorStr: "#000000")

    return shadowOutlineAttributedString(string: string,
                                         font: font,
                                         textColor: textColor,
                                         strokeColor: borderColor.withAlphaComponent(0.8),
                                         strokeWidth: 0.5,
                                         shadowColor: shadowColor.withAlphaComponent(0.8),
                                         shadowRadius: 3,
                                         shadowOffset: CGSize.init(width: 0, height: 0))
}

func shadowOutlineAttributedString(string: String?,
                                   font: UIFont,
                                   textColor: UIColor,
                                   strokeColor: UIColor,
                                   strokeWidth:CGFloat,
                                   shadowColor: UIColor,
                                   shadowRadius: CGFloat,
                                   shadowOffset: CGSize) -> NSAttributedString {
    let paragraph = NSMutableParagraphStyle()
    paragraph.alignment = .left

    let shadow = NSShadow.init()
    shadow.shadowColor = shadowColor
    shadow.shadowOffset = shadowOffset
    shadow.shadowBlurRadius = shadowRadius

    let dic = [NSAttributedString.Key.font:font,
               NSAttributedString.Key.paragraphStyle: paragraph,
               NSAttributedString.Key.foregroundColor: textColor,
//               NSAttributedString.Key.strokeWidth: (-strokeWidth),
//               NSAttributedString.Key.strokeColor: strokeColor,
               NSAttributedString.Key.shadow:shadow] as [NSAttributedString.Key : Any]

    return NSMutableAttributedString.init(string: string ?? "", attributes: dic)
}
