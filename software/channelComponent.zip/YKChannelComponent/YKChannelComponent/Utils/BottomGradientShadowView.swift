//
//  BottomGradientShadowView.swift
//  YKChannelComponent
//
//  Created by better on 2022/11/3.
//  Copyright © 2022 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import OneArchSupport
import OneArchSupport4Youku
import YKUIComponent
import OneArch
import SDWebImage
import YKAdSDK

class BottomGradientShadowView: UIView {
    var shadowHeight: CGFloat = 0.0

    init(frame: CGRect, shadowHeight:CGFloat) {
        super.init(frame: frame)
        self.shadowHeight = shadowHeight
        self.contentMode = .scaleAspectFill
        self.layer.masksToBounds = true
        NotificationCenter.default.addObserver(self, selector: #selector(refreshTheme), name: Notification.Name(rawValue: "YKNThemeDidChangeNotification"), object: nil)
    }
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var gradientLayerView: UIView = {
        let view = UIView.init();
        self.addSubview(view)
        view.backgroundColor = UIColor.clear
        view.frame = self.bounds
        view.height = self.shadowHeight
        view.bottom = self.height
        return view
    }()

    lazy var gradientLayer: CAGradientLayer = {
        let layer = CAGradientLayer.init()
        layer.locations = [NSNumber.init(value: 0.0), NSNumber.init(value: 30.0/51.0), NSNumber.init(value: 44.0/51.0), NSNumber.init(value: 1.0)]  //0 30 44 51
        layer.startPoint = CGPoint.init()
        layer.endPoint = CGPoint.init(x: 0, y: 1.0)

        self.gradientLayerView.layer.insertSublayer(layer, at: 0)
        layer.colors = gradientColors()
        layer.frame = self.gradientLayerView.bounds
        return layer
    }()
    
    func refreshFrame(frame:CGRect) {
        self.frame = frame
        //shadow
        self.gradientLayer.width = self.width
        self.gradientLayerView.width = self.width
        self.gradientLayerView.bottom = self.height
    }

    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        self.gradientLayer.colors = gradientColors()
    }
    
    @objc func refreshTheme() {
        self.gradientLayer.colors = gradientColors()
    }
    
    func gradientColors() -> [CGColor] {
        
        //0 55 90 100
        
        let clr1 = UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0).cgColor
        let clr2 = UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0.55).cgColor
        let clr3 = UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(0.9).cgColor
        let clr4 = UIColor.createColorWithHexRGB(colorStr: "#16161a").withAlphaComponent(1).cgColor

        let clr11 = UIColor.white.withAlphaComponent(0).cgColor
        let clr12 = UIColor.white.withAlphaComponent(0.55).cgColor
        let clr13 = UIColor.white.withAlphaComponent(0.9).cgColor
        let clr14 = UIColor.white.withAlphaComponent(1).cgColor
        
        return isDark() ? [clr1, clr2, clr3, clr4] : [clr11, clr12, clr13, clr14]
    }
    
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
}

