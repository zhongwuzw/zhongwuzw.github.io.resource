//
//  AccessibilityView.swift
//  YKChannelComponent
//
//  Created by better on 2021/8/9.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKUIComponent

class AccessibilityView: UIView {

    override var isAccessibilityElement: Bool {
        get {
            return true
        }
        set {
            
        }
    }
        
    override var accessibilityLabel: String? {
        get {
            return YKHomeAccessbilityHelperView.accessibilityLabel(with: self)
        }
        set {
            
        }
    }

}
