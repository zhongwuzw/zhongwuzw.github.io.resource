//
//  TitleRankView.swift
//  YKChannelComponent
//
//  Created by better on 2021/5/26.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YoukuResource

class TitleRankModel {
    var rank = 0
    var font: UIFont = YKNFont.akrobatFont(ofSize: YKNFont.carditem_maintitle().pointSize)
    lazy var color: UIColor = {
        if rank > 0, rank < 4 {
            if rank == 3 {
                return UIColor.createColorWithHexRGB(colorStr: "#fff4df")
            } else if rank == 2 {
                return UIColor.createColorWithHexRGB(colorStr: "#ffe5df")
            } else {
                return UIColor.createColorWithHexRGB(colorStr: "#ffe2fe")
            }
        } else {
            return UIColor.createColorWithHexRGB(colorStr: "#eaeaea")
        }
    }()
    lazy var textColor: UIColor = {
        if rank > 0, rank < 4 {
            if rank == 3 {
                return UIColor.createColorWithHexRGB(colorStr: "#ff9100")
            } else if rank == 2 {
                return UIColor.createColorWithHexRGB(colorStr: "#ff4f34")
            } else {
                return UIColor.ykn_brandInfo
            }
        } else {
            return UIColor.createColorWithHexRGB(colorStr: "#777777")
        }
    }()
    var size: CGSize = CGSize()
    
    init(rank: Int) {
        self.rank = rank
        
        let fontHeight = max(YKNFont.height(with: self.font, lineNumber: 1) - 2, 17)
        var size = calcStringSize(String(rank), font: self.font, size: CGSize.init(width: 1000, height: fontHeight))
        size.height = fontHeight
        size.width = size.width + 10
        
        self.size.width = max(size.width, 17)
        self.size.height = fontHeight
    }
}

class TitleRankView: UILabel {
    
    func refresh(model: TitleRankModel, pos: CGPoint ) {
        self.text = String(model.rank)
        self.textColor = model.textColor
        self.textAlignment = .center
        self.font = model.font
        self.backgroundColor = model.color
        self.frame = CGRect.init(x: pos.x, y: pos.y, width: model.size.width, height: model.size.height)
        self.layer.cornerRadius = YKNCorner.radius_small()
        self.clipsToBounds = true
    }
}

/// 菱形榜单视图
class DiamondRankView: TitleRankView {
    
    class func renderSize(with rankIndex: Int) -> CGSize {
        let fixedHeight: CGFloat = 17.0
        
        if (rankIndex > 99) {
            return CGSize.init(width: 36.0, height: fixedHeight)
        } else if (rankIndex > 9) {
            return CGSize.init(width: 28.0, height: fixedHeight)
        } else {
            return CGSize.init(width: 20.0, height: fixedHeight)
        }
    }
    
    func fill(with rankIndex: Int) {
        let model = TitleRankModel.init(rank: rankIndex)
        
        self.text = String(model.rank)
        self.textColor = model.textColor
        self.textAlignment = .left
        self.font = model.font
        self.backgroundColor = model.color
        
        model.size = DiamondRankView.renderSize(with: rankIndex)
        self.width = model.size.width
        self.height = model.size.height
        
        addDiamondShape(model: model, pos: .zero)
    }
    
    override func refresh(model: TitleRankModel, pos: CGPoint) {
        super.refresh(model: model, pos: pos)
        self.layer.cornerRadius = 0;
        
        addDiamondShape(model: model, pos: pos)
    }
    
    func addDiamondShape(model: TitleRankModel, pos: CGPoint) {
        let size = model.size
        let topX = size.width * 0.2
        let bottomX = size.width - topX
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = diamondPath(topX: topX, bottomX: bottomX, size: size).cgPath
        shapeLayer.fillColor = model.color.cgColor
        shapeLayer.strokeColor = UIColor.clear.cgColor
        self.layer.mask = shapeLayer
    }
    
    func diamondPath(topX: CGFloat, bottomX: CGFloat, size: CGSize) -> UIBezierPath {
        let path = UIBezierPath()
        path.move(to: CGPoint(x: topX, y: 0))
        path.addLine(to: CGPoint(x: 0, y: size.height))
        path.addLine(to: CGPoint(x: bottomX, y: size.height))
        path.addLine(to: CGPoint(x: size.width, y: 0))
        path.close()
        return path
    }
}
