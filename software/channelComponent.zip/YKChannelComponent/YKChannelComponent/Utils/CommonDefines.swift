//
//  CommonDefines.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/2/22.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import DYKIOSCategory
import YKResponsiveLayout
import YoukuResource
import OneServiceSwift
import OneArch

let SCREEN_WIDTH = UIScreen.main.portraitBounds().size.width
let SCREEN_HEIGHT = UIScreen.main.portraitBounds().size.height
let STATUSBAR_HEIGHT = YKStatusBarHeight()
let RATIO_9_16 = 0.5625
let PAD_NEW_HOME_MarginLeft = YKNGap.youku_margin_left()
let PAD_NEW_HOME_MarginRight = YKNGap.youku_margin_right()
let PAD_NEW_HOME_ColumnSpacing = YKNGap.youku_column_spacing()
let PAD_NEW_HOME_LineSpacing = YKNGap.youku_column_spacing()

let PAD_NEW_HOME_CornerRadius = 10.0
let PAD_NEW_HOME_TextLeftMagin = YKNGap.youku_picture_title_spacing() //文本框左边距
let PAD_NEW_HOME_TextRightMagin = YKNGap.youku_picture_title_spacing() //文本框右边距
let PAD_NEW_HOME_textColumnSpacing = YKNGap.youku_maintitle_subtitle_spacing() //文本框上边距
let PAD_NEW_HOME_bottomViewBottomSpacing = YKNGap.youku_module_margin_bottom()//bottomView据底

func YKRLScreenWidth() -> CGFloat {
    if !ykrl_isResponsiveLayout() {
        let width = YKRLLayoutManager.sharedInstance()?.screenSize.width ?? UIScreen.main.bounds.width
        let height = YKRLLayoutManager.sharedInstance()?.screenSize.height ?? UIScreen.main.bounds.height
        return min(width, height)
    }
    
    return YKRLLayoutManager.sharedInstance()?.screenSize.width ?? UIScreen.main.bounds.width
}

func YKRLScreenHeight() -> CGFloat {
    if !ykrl_isResponsiveLayout() {
        let width = YKRLLayoutManager.sharedInstance()?.screenSize.width ?? UIScreen.main.bounds.width
        let height = YKRLLayoutManager.sharedInstance()?.screenSize.height ?? UIScreen.main.bounds.height
        return max(width, height)
    }
    
    return YKRLLayoutManager.sharedInstance()?.screenSize.height ?? UIScreen.main.bounds.height
}

///

/// 传入phone屏幕列数，返回pad当前屏幕下（全屏、分屏）列数；
/// - Parameters:
///   - phoneColumn: phone列数
///   - containerWidth: 当前容器宽度，不设置则默认屏幕宽度；推荐设置
/// - Returns: pad当前合适列数
func YKRLFitColumnCount(_ phoneColumn: CGFloat, _ containerWidth: CGFloat = 0) -> CGFloat {
    let result = YKRLCompLayoutManager.sharedInstance().columnCount(forOriginalCount: phoneColumn, adjustingColumnCountMin: phoneColumn, containerWidth: containerWidth)
    print("[响应式] column:\(phoneColumn) 新column:\(result)")
    return min(4, max(1, result))
}

func getAppleAdServerRatio(_ component: IComponent?) -> CGFloat {
//    if let ratio = component?.compModel?.extraExtend["yksc.data.page.appleAD.parseRatio"] as? CGFloat, ratio > 0 {
    if let ratio = (component?.compModel as? HomeComponentModel)?.appleADParseRatio, ratio > 0 {
        return ratio
    }
    
    return ykrl_isResponsiveLayout() ? 3.141 : 1.995
}

func getCGFloatValue(_ value: Any?) -> CGFloat? {
    if let value1 = value as? CGFloat {
        return value1
    } else if let value2 = value as? String {
        if let doubleV = Double(value2) {
            return CGFloat(doubleV)
        }
    }
    
    return nil
}

class YKCCUtil {
    static func getIntValue(_ value: Any?) -> Int? {
        if let intValue = value as? Int {
            return intValue
        } else  if let stringValue = value as? String, stringValue.isEmpty == false {
            return Int(stringValue)
        }
        return nil
    }
    
    static func getDoubleValue(_ value: Any?) -> Double? {
        if let dValue = value as? Double {
            return dValue
        } else  if let stringValue = value as? String, stringValue.isEmpty == false {
            return Double(stringValue)
        } else  if let iValue = value as? Int {
            return Double(iValue)
        }
        return nil
    }
    
    static func getCGFloatValue(_ value: Any?) -> CGFloat? {
        if let value = value as? CGFloat {
            return value
        } else if let value = value as? Double {
            return CGFloat(value)
        } else if let value = value as? Int {
            return CGFloat(value)
        }  else  if let stringValue = value as? String, stringValue.isEmpty == false, 
                        let doubleValue = Double(stringValue) {
            return CGFloat(doubleValue)
        }
        
        return nil
    }
    
    static func getBoolValue(_ value: Any?) -> Bool? {
        if let boolValue = value as? Bool {
            return boolValue
        } else  if let stringValue = value as? String, stringValue.isEmpty == false {
            return (stringValue == "true" || stringValue == "TRUE" || stringValue == "1")
        } else if let intValue = value as? Int, (intValue == 1 || intValue == 0) {
            return intValue == 1
        }
        return nil
    }
    
    static func isValidString(_ string: String?) -> Bool {
        if let string = string, string.isEmpty == false {
            return true
        }
        
        return false
    }
    
    static func runOnMainThread(task: @escaping () -> Void) {
        if Thread.isMainThread {
            task()
            return
        }
        
        DispatchQueue.main.async {
            task()
        }
    }
    
    static func runOnSubThread(task: @escaping () -> Void) {
        if !Thread.isMainThread {
            task()
            return
        }
        
        DispatchQueue.global().async {
            task()
        }
    }
    
    static func isSameObj(object1:AnyObject?, object2:AnyObject?) -> Bool {
        guard let object1 = object1, let object2 = object2 else {
            return false
        }
        
        let ptr1 = Unmanaged<AnyObject>.passUnretained(object1).toOpaque()
        let ptr2 = Unmanaged<AnyObject>.passUnretained(object2).toOpaque()
        if ptr1 == ptr2 {
            return true
        }
        
        return false
    }
    
    static func objAddress(_ obj: AnyObject) -> String {
        let unmanaged = Unmanaged.passUnretained(obj)
        let ptr = unmanaged.toOpaque()
        return "\(ptr)"
    }
    
    static func getObjAddress(_ obj: AnyObject?) -> String {
        if let obj = obj {
            return objAddress(obj)
        }
        
        return "none"
    }
    
    static func calImgSize(_ imgSize: CGSize, _ targetSize: CGSize) -> CGSize {
        var calH: CGFloat = imgSize.height
        var calW: CGFloat = imgSize.width
        
        let targetW = targetSize.width
        let targetH = targetSize.height
        
        guard  imgSize.width > 0 && imgSize.height > 0 else {
            return targetSize
        }
        
        let block: ((CGSize) -> CGSize) = { imgSize in
            if imgSize.width <= targetW && imgSize.height <= targetH {

            } else if imgSize.width >= targetW && imgSize.height <= targetH {
                calW = targetW
                calH = ceil(calW * imgSize.height / imgSize.width)
            } else if imgSize.width <= targetW && imgSize.height >= targetH {
                calH = targetH
                calW = ceil(calH * imgSize.width / imgSize.height)
            } else if imgSize.width >= targetW && imgSize.height >= targetH {
                calH = targetH
                calW = ceil(calH * imgSize.width / imgSize.height)
            }
            
            let newSize = CGSize.init(width: calW, height: calH)
            return newSize
        }
        
        let newSize = block(imgSize)
        if newSize.width <= targetW && newSize.height <= targetH {
            return newSize
        } else {
            return block(newSize)
        }
    }
    
    // 找b中a之后的部分
    static func substringAfter(_ a: String, in b: String) -> String? {
        if let range = b.range(of: a) {
            let startIndex = range.upperBound
            let substringAfterA = b[startIndex..<b.endIndex]
            return String(substringAfterA)
        }
        return nil
    }

}

extension UILabel {
    
    func sizeToFitWithMaxWidth(_ maxWidth: CGFloat) {
        self.sizeToFit()
        
        if maxWidth > 0 && self.width > maxWidth {
            self.width = maxWidth
        }
    }
}
