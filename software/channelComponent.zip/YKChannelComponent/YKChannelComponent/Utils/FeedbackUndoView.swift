//
//  FeedbackUndoView.swift
//  YKChannelComponent
//
//  Created by better on 2021/4/7.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import YKChannelBase

class FeedbackUndoView: UIView {

    var undo: (() -> Void)?
    static let tag = 999997
   
    lazy var topView: UIView = {
        let view = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 300, height: 17 + YKNGap.dim_6() + 30))

        //icon
        let icon = UIImageView.init(frame: CGRect.init(x: Double(view.width/2.0 - 15), y: 0, width: 30, height: 30))
        icon.image = UIImage.init(named: "ic_home_feedback_face")
        view.addSubview(icon)

        //title
        let label = UILabel.init(frame: CGRect.init(x: 0, y: view.height - 17, width: view.width, height: 17))
        label.textAlignment = .center
        label.text = "将减少此类内容推荐"
        label.textColor = .white
        label.font = YKNFont.posteritem_subhead()
        view.addSubview(label)

        addSubview(view)
        return view
    }()

    lazy var topBlurView: UIVisualEffectView = {
        let blurEffect = UIBlurEffect(style: .light)
        let effectView = UIVisualEffectView(effect: blurEffect)
        effectView.frame = .zero
        effectView.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        effectView.clipsToBounds = true
        self.addSubview(effectView)
        return effectView
    }()

    lazy var bottomBgView: UIView = {
        let view = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 0, height: 0))
        view.backgroundColor = UIColor.ykn_primaryBackground
        addSubview(view)
        return view
    }()

    lazy var bottomIconBgView: UIView = {
        let view = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 0, height: 39))
        view.backgroundColor = UIColor.ykn_secondaryBackground
        view.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        view.addSubview(bottomIconView)
        addSubview(view)
        return view
    }()

    lazy var bottomIconView: UIView = {
        let view = UIView.init(frame: CGRect.init(x: 0, y: 0, width: 12 + YKNGap.dim_1() + 26, height: 12))
        let icon = UIImageView.init(frame: CGRect.init(x: 0, y: 0, width: 12, height: 12))
        icon.image = UIImage.init(named: "ic_home_feedback_undo")
        view.addSubview(icon)
        view.addSubview(self.undoTextLabel)
        self.undoTextLabel.centerY = icon.centerY
        self.undoTextLabel.left = icon.right + YKNGap.dim_1()
        return view
    }()
    
    lazy var undoTextLabel: UILabel = {
        //title
        let label = UILabel.init(frame: CGRect.init(x: 0, y: 0, width: 28, height: 15))
        label.textAlignment = .center
        label.text = "撤销"
        label.textColor = UIColor.ykn_secondaryInfo
        label.font = YKNFont.posteritem_subhead()
        return label
    }()
    
    static func addFeedbackUndoView(_ prentView: UIView?, itemContext: YKSCItemContext, undo: @escaping () -> Void,  noUndoView:Bool = false) {
        
        guard let parentView = prentView else {
            return
        }

        var undoView = parentView.viewWithTag(tag) as? FeedbackUndoView
        if undoView == nil {
            undoView = FeedbackUndoView.init()
            if let undoView = undoView {
                parentView.addSubview(undoView)
                undoView.tag = tag
                
                //空点击，防止跳转
                undoView.whenTapped {
                    //do nothing
                }
            }
        }
        if let undoView = undoView {
            undoView.undo = undo
            undoView.frame = parentView.bounds
            
            let imageWidth = Double(parentView.width)
            let imageViewHeight = imageWidth * RATIO_9_16
            undoView.topBlurView.frame = CGRect.init(x: 0, y: 0, width: imageWidth, height: imageViewHeight)
            undoView.topView.center = CGPoint.init(x: imageWidth/2.0, y: imageViewHeight/2.0)
            undoView.bottomBgView.frame = CGRect.init(x: 0, y: imageViewHeight, width: imageWidth, height: Double(undoView.height) - imageViewHeight)
            undoView.bottomIconBgView.width = undoView.width
            undoView.bottomIconBgView.top = CGFloat(imageViewHeight) + YKNGap.dim_6()
            undoView.bottomIconView.center = CGPoint.init(x: undoView.bottomIconBgView.width/2.0, y: undoView.bottomIconBgView.height/2.0)
            
            undoView.bottomIconBgView.whenTapped {
                undo()
            }
            if noUndoView {
                undoView.bottomIconBgView.isHidden = true
            }
        }

        //color
        undoView?.bottomBgView.backgroundColor = sceneUtil(.ykn_primaryBackground, sceneColor: itemContext.sceneBgColor())
        undoView?.bottomIconBgView.backgroundColor = sceneUtil(.ykn_secondaryBackground, sceneColor: itemContext.sceneCardFooterBgColor())
        undoView?.undoTextLabel.textColor = sceneUtil(.ykn_secondaryInfo, sceneColor: itemContext.sceneCardFooterTitleColor())
    }
    
    static func removeFeedbackUndoView(_ parentView: UIView?) {
        if let undoView = parentView?.viewWithTag(tag) {
            undoView.removeFromSuperview()
        }
    }
}
