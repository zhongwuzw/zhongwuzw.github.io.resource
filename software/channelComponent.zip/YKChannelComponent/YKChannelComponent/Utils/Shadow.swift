//
//  ShadowView.swift
//  YKChannelComponent
//
//  Created by better on 2021/3/31.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YoukuResource
import YKChannelBase
import YKDowngradeSDK

extension UIView {
    
    /// 添加包框及阴影， 适用View：组件渲染reuseView
    func yk_addBorderAndShadow(sceneBorderColor: UIColor?) {

        //add border
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        self.layer.borderWidth = 0.5
        self.layer.borderColor = sceneUtil(.ykn_separator, sceneColor: sceneBorderColor)?.cgColor

         let tag = 999999
         self.superview?.clipsToBounds = false
         
         //有氛围色不要描边
         if let _ = sceneBorderColor {
             if let shadow = self.viewWithTag(tag) {
                 shadow.removeFromSuperview()
             }
             return
         }
        
        if YKDowngradeManager.canDowngradeFunction("46") {
            return
        }
         
        if let shadow = self.viewWithTag(tag) {
            shadow.frame = self.bounds
            shadow.layer.shadowPath = UIBezierPath.init(rect: self.bounds).cgPath
            shadow.backgroundColor = (sceneBorderColor != nil) ? .clear : .ykn_secondaryGroupedBackground
            return
        }
        let shadowView = ShadowView.init(frame: self.bounds)
        shadowView.backgroundColor = (sceneBorderColor != nil) ? .clear : .ykn_secondaryGroupedBackground
        shadowView.tag = tag
        shadowView.layer.zPosition = -100
        self.addSubview(shadowView)
        self.sendSubviewToBack(shadowView)
    }
    
    func yk_addShadowAndCorner() {
        
        //add border
        self.layer.cornerRadius = YKNCorner.radius_secondary_medium()
        self.layer.borderWidth = 0.5
        self.layer.borderColor = UIColor.ykn_separator.cgColor
        
        let tag = 999999
        self.superview?.clipsToBounds = false
        
        if YKDowngradeManager.canDowngradeFunction("46") {
            return
        }
         
        if let shadow = self.viewWithTag(tag) {
            shadow.frame = self.bounds
            shadow.layer.shadowPath = UIBezierPath.init(rect: self.bounds).cgPath
            shadow.backgroundColor = .clear// .ykn_secondaryGroupedBackground//.clear
            return
        }
        let shadowView = ShadowView.init(frame: self.bounds)
        shadowView.backgroundColor = .clear// .ykn_secondaryGroupedBackground//.clear
        shadowView.tag = tag
        shadowView.layer.zPosition = -100
        self.addSubview(shadowView)
        self.sendSubviewToBack(shadowView)
    }
    
    func yk_removeShadowAndCorner() {
        let tag = 999999
        if let shadow = self.viewWithTag(tag) {
            shadow.removeFromSuperview()
        }
        
        self.layer.cornerRadius = 0
        self.layer.borderWidth = 0
        self.layer.borderColor = nil
    }
    
    /// 设置阴影
    /// - Parameters:
    ///   - color: 阴影颜色
    ///   - offset: 阴影偏移量
    ///   - opacity: 阴影透明度
    ///   - radius: 阴影半径
    fileprivate func yk_addShadow(color: UIColor, offset:CGSize, opacity:Float, radius:CGFloat) {
        self.clipsToBounds = false
        self.layer.shadowColor = color.cgColor
        self.layer.shadowOffset = offset
        self.layer.shadowOpacity = opacity
        self.layer.shadowRadius = radius
        self.layer.shadowPath = UIBezierPath.init(rect: self.bounds).cgPath
    }
}

private class ShadowView: UIView {
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
        let radius = ykrl_isResponsiveLayout() ? PAD_NEW_HOME_CornerRadius : YKNCorner.radius_secondary_medium()
        self.layer.cornerRadius = radius
        self.layer.borderWidth = 0.5
        self.layer.borderColor = isDark() ? UIColor.ykn_hideAbleSeparator.cgColor : UIColor.clear.cgColor
        self.superview?.clipsToBounds = false
        self.yk_addShadow(color: UIColor.wvColor(withHex: 0xEAEAEA),
                          offset: isDark() ? CGSize.init(width: 0, height: 2) : CGSize.init(width: 0, height: 1) ,
                          opacity: isDark() ? 0.1 : 1.0,
                          radius: 5)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.superview?.clipsToBounds = false
        self.superview?.superview?.clipsToBounds = false
    }

    override func ykn_themeDidChange(by manager: YKNThemeManager, identifier: NSCopying & NSObjectProtocol, theme: NSObject) {
        self.layer.shadowOffset = isDark() ? CGSize.init(width: 0, height: 2) : CGSize.init(width: 0, height: 1)
        self.layer.shadowOpacity = isDark() ? 0.1 : 1.0
        self.layer.borderColor = isDark() ? UIColor.ykn_hideAbleSeparator.cgColor : UIColor.clear.cgColor
    }
    
    func isDark() -> Bool {
        let theme = YKNThemeManager.sharedInstance().currentThemeIdentifier as? String
        return (theme == YKNThemeIdentifierDark)
    }
}
