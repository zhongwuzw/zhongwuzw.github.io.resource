//
//  ChannelSubtractMask.swift
//  YKChannelComponent
//
//  Created by better on 2021/6/3.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import QuartzCore
import YoukuResource

func createEyeglassHollow(parentView: UIView) -> UIView {

    let backgroundView = UIView(frame: parentView.bounds)
    backgroundView.backgroundColor = .white

    let maskLayer = CAShapeLayer()
    maskLayer.fillRule = CAShapeLayerFillRule.evenOdd
    let basicPath = UIBezierPath(rect: parentView.bounds)
    let width = (parentView.width - YKNGap.youku_column_spacing())/2.0
    let maskPath = UIBezierPath.init(roundedRect: CGRect(x: 0, y: 0, width: width, height: parentView.height), cornerRadius: YKNCorner.radius_medium())
    basicPath.append(maskPath)
    let maskPath2 = UIBezierPath(roundedRect: CGRect(x: width + YKNGap.youku_column_spacing(), y: 0, width: width, height: parentView.height), cornerRadius: YKNCorner.radius_medium())
    basicPath.append(maskPath2)

    maskLayer.path = basicPath.cgPath
    backgroundView.layer.mask = maskLayer
    
    return backgroundView
}

func createHollow(view: UIView?) {
    guard let view = view else {
        return
    }

    let maskLayer = CAShapeLayer()
    maskLayer.fillRule = CAShapeLayerFillRule.evenOdd
    let basicPath = UIBezierPath(rect: view.bounds)
    let maskPath = UIBezierPath.init(roundedRect: view.bounds, cornerRadius: YKNCorner.radius_medium())
    basicPath.append(maskPath)

    maskLayer.path = basicPath.cgPath
    view.layer.mask = maskLayer
}

func createEyeglassHollowOfView(_ view: UIView?, topMargin: CGFloat) {
    guard let view = view else {
        return
    }

    let maskLayer = CAShapeLayer()
    maskLayer.fillRule = CAShapeLayerFillRule.evenOdd
    let basicPath = UIBezierPath(rect: view.bounds)
    let width = (view.width - 0 - YKNGap.youku_column_spacing())/2.0
    let height = view.height - topMargin * 2
    let maskPath = UIBezierPath.init(roundedRect: CGRect(x: 0, y: topMargin, width: width, height: height), cornerRadius: YKNCorner.radius_medium())
    basicPath.append(maskPath)
    let maskPath2 = UIBezierPath(roundedRect: CGRect(x: width + 0 + YKNGap.youku_column_spacing(), y: topMargin, width: width, height: height), cornerRadius: YKNCorner.radius_medium())
    basicPath.append(maskPath2)

    maskLayer.path = basicPath.cgPath
    view.layer.mask = maskLayer
}
