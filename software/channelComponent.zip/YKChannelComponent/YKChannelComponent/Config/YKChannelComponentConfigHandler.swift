//
//  YKChannelComponentLayoutConfigHandler.swift
//  YKChannelComponent
//
//  Created by better on 2020/11/30.
//  Copyright © 2020 Youku. All rights reserved.
//

/*
 
 分发场景组件一览表：
 https://yuque.antfin-inc.com/ykappdev/iyyaa0/gsc9bs
 
 */

import UIKit
import YKSCBase.YKSCConfigHandlerProtocol
import OneArchBridge

@objc(YKChannelComponentConfigHandler)
class YKChannelComponentConfigHandler: NSObject, YKSCConfigHandlerProtocol {

    ///插件定义
    func scPluginDefines() -> [Any]! {
        return [
            // MARK: - <通用功能插件>
            
            /*
             
             通用插件定义
             
             说明：
             （1）每一个功能用一个 “mark: XXX” 作为分隔，功能内不要使用 mark:
             
             */
            
            // MARK: 双列轮播
            
//            ["name":    "yksc.plugin.comp.doubleFeed.lunboAdaptor.swift",
//             "class":   "YKChannelComponent.ComponentPluginDoubleFeedLunboAdaptor",
//             "desc":    "双列Feed轮播能力"],
            
            // MARK: 播放器预览
//            [
//                "name":     "yksc.plugin.item.ItemPluginPlayerABTest",
//                "class":    "YKChannelComponent.ItemPluginPlayerABTest",
//                "desc":     "播放器预览 坑位插件 ABTest",
//            ],
//            [
//                "name":     "yksc.plugin.item.PlayerToolsParse",
//                "class":    "ItemPluginPlayerToolsParser",
//                "desc":     "播放器预览 坑位插件 业务工具栏",
//            ],
//            [
//                "name":     "yksc.plugin.item.playerControl.scrollEnd.swift",
//                "class":    "ItemPluginPlayerScrollEnd",
//                "desc":     "播放器预览 坑位插件 滚动停止播放",
//            ],
//            [
//                "name":     "yksc.plugin.comp.playerControl.scrollEnd.swift",
//                "class":    "CompPluginPlayerScrollEnd",
//                "desc":     "播放器预览 组件插件 滚动停止播放",
//            ],
//            [
//                "name":     "yksc.plugin.item.ItemPlayerProgress",
//                "class":    "ItemPlayerProgressPlugin",
//                "desc":     "播放器预览 坑位插件 播放进度 断点续播",
//            ],
            
//            // MARK: 苹果广告
//            [   "name":     "yksc.plugin.comp.content.appleAD.parser.swift",
//                "class":    "YKChannelComponent.YKSCComponentPluginAppleADParser",
//                "desc":     "苹果广告组件",
//            ],
//            [
//                "name":     "yksc.plugin.comp.content.appleAD.swift",
//                "class":    "YKChannelComponent.YKSCComponentPluginAppleAD",
//                "desc":     "苹果广告组件",
//            ],
//            [
//                "name":     "yksc.plugin.comp.content.appleAD.adaptor.lunboO.swift",
//                "class":    "YKChannelComponent.YKSCCompPluginAppleADSliderAdaptor",
//                "desc":     "轮播N苹果广告适配",
//            ],
//            [
//                "name":     "yksc.plugin.comp.content.appleAD.adaptor.lunboR.swift",
//                "class":    "YKChannelComponent.YKSCCompPluginAppleAD14049Adaptor",
//                "desc":     "轮播R苹果广告适配",
//            ],
//

            
            // MARK: - <组件插件>
            
            [
                "name":     "yksc.plugin.item.baseVideo.swift",
                "class":    "YKChannelComponent.ItemPluginBaseVideo",
                "desc":     "PHONE_BASE_A/B/C 坑位样式插件",
            ],

            
            /*
             
             组件插件定义。
             
             说明：
             （1）⚠️严格按组件编号排序，严禁穿插⚠️，每一个组件用 “mark：编号（空格）组件名称或说明” 作为分隔
             
             */
            

//            // MARK: 12075 首页改版  片单横滑
//            [
//                "name":     "yksc.plugin.comp.adaptor.12075",
//                "class":    "YKChannelComponent.CompPlugin12075Adaptor",
//                "desc":     "12075 组件适配插件",
//            ],
//
//            [
//                "name":     "yksc.plugin.item.12075",
//                "class":    "YKChannelComponent.ItemPlugin12075",
//                "desc":     "12075 坑位样式插件",
//            ],
            
//            // MARK: 12076 O短大卡
//            [
//                "name":     "yksc.plugin.comp.adaptor.12076",
//                "class":    "YKChannelComponent.CompPlugin12076Adaptor",
//                "desc":     "12076 组件适配插件",
//            ],
//            [
//                "name":     "yksc.plugin.item.12076",
//                "class":    "YKChannelComponent.ItemPlugin12076",
//                "desc":     "12076 坑位插件",
//            ],
            
//            [
//                "name":     "yksc.plugin.item.ItemPluginActionExtraParams",
//                "class":    "YKChannelComponent.ItemPluginActionExtraParams",
//                "desc":     "跳转假卡参数拼接插件",
//            ],
//
//            // MARK: 12073 O长大卡
//            [
//                "name":     "yksc.plugin.comp.adaptor.12073",
//                "class":    "YKChannelComponent.CompPlugin12073Adaptor",
//                "desc":     "12073 组件适配插件",
//            ],
//
//            [
//                "name":     "yksc.plugin.item.12073",
//                "class":    "YKChannelComponent.ItemPlugin12073",
//                "desc":     "12073 坑位插件",
//            ],
            
//            // MARK: 12074 o短小卡
//            [
//                "name":     "yksc.plugin.item.12074",
//                "class":    "YKChannelComponent.ItemPlugin12074",
//                "desc":     "12074 坑位插件",
//            ],
//
//            // MARK: 12077 o短广告
//            [
//                "name":     "yksc.plugin.item.12077",
//                "class":    "YKChannelComponent.ItemPlugin12077",
//                "desc":     "12077 坑位插件",
//            ],
//
//            // MARK: 12078 广告大卡
//            [
//                "name":     "yksc.plugin.comp.adaptor.12078",
//                "class":    "YKChannelComponent.CompPlugin12076Adaptor",
//                "desc":     "12078 组件适配插件",
//            ],
//            [
//                "name":     "yksc.plugin.item.12078",
//                "class":    "YKChannelComponent.ItemPlugin12078",
//                "desc":     "12078 坑位插件",
//            ],
//
//            // MARK: 12086
//            [
//                "name":     "yksc.plugin.comp.adaptor.12086",
//                "class":    "YKChannelComponent.CompPlugin12076Adaptor",
//                "desc":     "12086 组件适配插件",
//            ],
//            [
//                "name":     "yksc.plugin.item.12086",
//                "class":    "YKChannelComponent.ItemPlugin12086",
//                "desc":     "12086 坑位插件",
//            ],
            /*
            // MARK: 12092
            [
                "name":     "yksc.plugin.comp.adaptor.12092",
                "class":    "YKChannelComponent.CompPlugin12092",
                "desc":     "12092 组件适配插件",
            ],
             */
            [
                "name":     "yksc.plugin.comp.adaptor.12092.sceneAdaptor",
                "class":    "YKChannelComponent.CompPlugin12092SceneAdaptor",
                "desc":     "12092 组件氛围插件",
            ],
                        
//            // MARK: 14013 PHONE_IMG_A
//            [
//                "name":     "yksc.plugin.comp.adaptor.14013.swift",
//                "class":    "YKChannelComponent.CompPlugin14013Adaptor",
//                "desc":     "14013 组件适配插件",
//            ],
//            [
//                "name":     "yksc.plugin.item.14013.swift",
//                "class":    "YKChannelComponent.ItemPlugin14013",
//                "desc":     "14013 坑位样式插件",
//            ],
//            [
//                "name":     "yksc.plugin.item.14013.adaptor.scene.swift",
//                "class":    "YKChannelComponent.ItemPlugin14013SceneAdaptor",
//                "desc":     "14013 氛围适配插件",
//            ],
            
            // MARK: 14027 正在看
            [
                "name":     "yksc.plugin.comp.14027.swift",
                "class":    "YKChannelComponent.CompPlugin14027",
                "desc":     "14027 组件适配插件",
            ],
            
            // MARK: 14197 正在看
            [
                "name":     "yksc.plugin.comp.14197.swift",
                "class":    "YKChannelComponent.CompPlugin14197",
                "desc":     "14197 组件适配插件",
            ],
            
            // MARK: 14918 正在看
            [
                "name":     "yksc.plugin.comp.14918.swift",
                "class":    "YKChannelComponent.CompPlugin14918",
                "desc":     "14918 组件适配插件",
            ],
            
            // MARK: 14030 横滑 PHONE_BASE_E（封面图16:9）
            [
                "name":     "yksc.plugin.comp.adaptor.14030.swift",
                "class":    "YKChannelComponent.CompPlugin14030Adaptor",
                "desc":     "14030 组件适配插件",
            ],
            [
                "name":     "yksc.plugin.item.14030.swift",
                "class":    "YKChannelComponent.ItemPlugin14030",
                "desc":     "14030 坑位适配插件",
            ],
            [
                "name":     "yksc.plugin.item.13002.swift",
                "class":    "YKChannelComponent.ItemPlugin14030More",
                "desc":     "13002 坑位适配插件",
            ],
            
            // MARK: 14031 横滑 PHONE_DEFALT_SCROLL_C（封面图4:3）
            [
                "name":     "yksc.plugin.comp.adaptor.14031.swift",
                "class":    "YKChannelComponent.CompPlugin14031Adaptor",
                "desc":     "14031 组件适配插件",
            ],
            [
                "name":     "yksc.plugin.item.14031.swift",
                "class":    "YKChannelComponent.ItemPlugin14031",
                "desc":     "14031 坑位适配插件",
            ],
            [
                "name":     "yksc.plugin.item.13003.swift",
                "class":    "YKChannelComponent.ItemPlugin14031More",
                "desc":     "13003 坑位适配插件",
            ],
            
            // MARK: 14045
            [
                "name":     "yksc.plugin.comp.adaptor.14045.swift",
                "class":    "YKChannelComponent.CompPlugin14045Adaptor",
                "desc":     "14045 坑位样式插件",
            ],
            [
                "name":     "yksc.plugin.item.14045.swift",
                "class":    "YKChannelComponent.ItemPlugin14045",
                "desc":     "14045 组件适配插件",
            ],

            // MARK: 14112 左图右文
            [
                "name":     "yksc.plugin.comp.adaptor.14112",
                "class":    "YKChannelComponent.CompPlugin14112Adaptor",
                "desc":     "14112 组件适配插件",
            ],
            [
                "name":     "yksc.plugin.item.14112",
                "class":    "YKChannelComponent.ItemPlugin14112",
                "desc":     "14112 坑位样式插件",
            ],
            [
                "name":     "yksc.plugin.item.14112.adaptor.scene",
                "class":    "YKChannelComponent.ItemPlugin14112SceneAdaptor",
                "desc":     "14112 氛围适配插件",
            ],
            
//            // MARK: 14151 酷头条组件
//            [
//                "name":     "yksc.plugin.comp.adaptor.14151.swift",
//                "class":    "YKChannelComponent.YKSCComponentPlugin14151",
//                "desc":     "14151酷头条组件",
//            ],
            
//            // MARK: 14171 榜单广场横滑组件
//            [
//                "name":     "yksc.plugin.comp.adaptor.14171",
//                "class":    "YKChannelComponent.CompPlugin14171Adaptor",
//                "desc":     "14171 组件适配插件",
//            ],
//            [
//                "name":     "yksc.plugin.item.14171",
//                "class":    "YKChannelComponent.ItemPlugin14171",
//                "desc":     "14171 坑位样式插件",
//            ],
            
            // MARK: 14174 【头部组件】全网热点榜
            [
                "name":     "yksc.plugin.item.14174",
                "class":    "YKChannelComponent.ItemPlugin14174",
                "desc":     "14174 坑位样式插件",
            ],
            [
                "name":     "yksc.plugin.item.adaptor.14174.immersionBackground",
                "class":    "YKChannelComponent.ItemPlugin14174ImmersionBackgroundAdaptor",
                "desc":     "14174沉浸式背景适配插件",
            ],
            

            
            //model 坑位解析插件
            [
                "name":     "yksc.plugin.item.model.home.parser.adaptor",
                "class":    "YKChannelComponent.HomeItemPluginModelParserAdaptor",
                "desc":     "model 坑位解析插件",
            ],
            [
                "name":     "yksc.plugin.item.model.parser.adaptor.v2",
                "class":    "YKChannelComponent.ItemPluginModelParserAdaptorV2",
                "desc":     "model 坑位解析插件v2",
            ],
            
            
            // MARK: 14179 猜你在追二级页空白组件
            [
                "name":     "yksc.plugin.comp.adaptor.14179",
                "class":    "YKChannelComponent.CompPlugin14179Adaptor",
                "desc":     "14179 组件适配插件",
            ],
            [
                "name":     "yksc.plugin.item.14179",
                "class":    "YKChannelComponent.ItemPlugin14179",
                "desc":     "14179 坑位样式插件",
            ],
            
            // MARK: 14194
            [
                "name":     "yksc.plugin.comp.content.14194",
                "class":    "YKChannelComponent.CompPlugin14194Adaptor",
                "desc":     "14194 组件适配插件",
            ],
            [
                "name":     "yksc.plugin.item.14194",
                "class":    "YKChannelComponent.ItemPlugin14194",
                "desc":     "14194 坑位插件",
            ],
            /*
            // MARK: 14193 筛选器组件
            [
                "name":     "yksc.plugin.comp.content.14193",
                "class":    "YKChannelComponent.CompPlugin14193",
                "desc":     "14193 组件样式插件",
            ],
            [
                "name":     "yksc.plugin.item.14193",
                "class":    "YKChannelComponent.ItemPlugin14193",
                "desc":     "14193 坑位样式插件",
            ],
            */
            // MARK: 14195 追剧横滑组件
//            [
//                "name":     "yksc.plugin.comp.adaptor.14195",
//                "class":    "YKChannelComponent.CompPlugin14195Adaptor",
//                "desc":     "14195 组件样式插件",
//            ],
//            [
//                "name":     "yksc.plugin.item.14195",
//                "class":    "YKChannelComponent.ItemPlugin14195",
//                "desc":     "14195 坑位样式插件",
//            ],
            
            // MARK: 14196 预约横滑组件
//            [
//                "name":     "yksc.plugin.comp.adaptor.14196",
//                "class":    "YKChannelComponent.CompPlugin14196Adaptor",
//                "desc":     "14196 组件样式插件",
//            ],
//            [
//                "name":     "yksc.plugin.item.14196",
//                "class":    "YKChannelComponent.ItemPlugin14196",
//                "desc":     "14196 坑位样式插件",
//            ],
            
            // MARK: 50104
            [
                "name":     "yksc.plugin.comp.adaptor.50104.swift",
                "class":    "YKChannelComponent.CompPlugin50104Adaptor",
                "desc":     "50104 组件适配插件",
            ],
            [
                "name":     "yksc.plugin.item.50104.swift",
                "class":    "YKChannelComponent.ItemPlugin50104",
                "desc":     "50104 坑位样式插件",
            ],
            
            // MARK: 50108
            [
                "name":     "yksc.plugin.comp.adaptor.50108.swift",
                "class":    "YKChannelComponent.CompPlugin50108Adaptor",
                "desc":     "50108 组件适配插件",
            ],
            [
                "name":     "yksc.plugin.item.50108.swift",
                "class":    "YKChannelComponent.ItemPlugin50108",
                "desc":     "50108 坑位样式插件",
            ],
           
            [
                "name":     "yksc.plugin.item.jump.component",      //跳转到指定组件，频道页通用能力
                "class":    "YKChannelComponent.CompJumpPlugin",
                "desc":     " 坑位插件",
            ],
            
            
            [
                "name":     "yksc.plugin.comp.adaptor.15004.swift",
                "class":    "YKChannelComponent.CompPlugin15004",
                "desc":     "15004 坑位插件",
            ],

        ]
    }

    
    ///插件组定义
    func scPluginGroupDefines() -> [AnyHashable : Any]! {
        return [
            // MARK: - <通用功能插件组>
            
            /*
             
             通用插件组定义
             
             说明：
             （1）每一个功能用一个 “mark: XXX” 作为分隔，功能内不要使用 mark:
             
             */
            
            //首页Model 数据解析
            "yksc.config.group.item.model.home.parser.adaptor":
            [
                "yksc.plugin.item.model.home.parser.adaptor",
                "yksc.config.group.item.model.parser.adaptor",
            ],
            
            // MARK: 视频预览
//            "yksc.config.group.item.player.playerControl.common":
//            [
//                "yksc.config.group.item.player.playerControl.swift",
//                "yksc.plugin.item.ItemPlayerProgress",
//            ],
//
//            "yksc.config.group.comp.player.playerControl.common":
//            [
//                "yksc.config.group.comp.player.playerControl.swift",
//                "yksc.plugin.item.ItemPlayerProgress",
//            ],
            
//            "yksc.config.group.comp.player.playerControl.swift":
//            [
//                "yksc.plugin.comp.playerControl.scrollEnd.swift",
//                "yksc.plugin.comp.activeState",
//                "yksc.config.group.item.player.playerControl.swift",
//            ],
//
//            "yksc.config.group.item.player.playerControl.swift":
//            [
//                "yksc.plugin.item.playerControl.scrollEnd.swift",
//                "yksc.plugin.item.activeState",
//                "yksc.plugin.item.ItemPluginPlayerABTest"
//            ],
//
//            "yksc.config.group.comp.feedAd.expose":
//            [
//                "yksc.plugin.item.activeState",
//                "yksc.plugin.comp.content.feedAd.expose"
//            ],
            
            // MARK: - <组件插件组>
            
            /*
             
             组件插件组定义。
             
             说明：
             （1）⚠️严格按组件编号排序，严禁穿插⚠️，每一个组件用 “mark：编号（空格）组件名称或说明” 作为分隔
             （2）有OC版本 需要放量的插件组后面加.swift
             （3）只有swift版本的不需要加.swift
             
             */
            
//            // MARK: 12075 O长大卡
//            "yksc.config.group.comp.content.12075":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.comp.adaptor.12075",               //组件布局适配
//                "yksc.plugin.comp.layoutCache.columnAverage",   //组件布局计算-多列均分
//                "yksc.config.group.comp.model.parser.adaptor",
//                //临时用OC版
//                "yksc.config.group.comp.doublefeed.negativeFeedback", //负反馈
//                "yksc.plugin.item.bridge.feed.feedModelV2",
//                "yksc.config.group.comp.player.playerControl.common",
//                "yksc.plugin.comp.adaptor.12092.sceneAdaptor",
//            ], type: "12075"),
//
//            "yksc.config.group.item.12075.12075":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.12075",
//                "yksc.config.group.item.tap.route",
//                "yksc.plugin.item.responselayout.rule",         //响应式插件
////                "yksc.config.group.item.model.parser.adaptor",
//                "yksc.config.group.item.model.home.parser.adaptor",
//                //视频预览
//                "yksc.config.group.item.player.playerControl.common",
//                "yksc.plugin.item.PlayerToolsParse",
//            ], type: "12075"),
//            
//            // MARK: 12073 O长小卡
//            "yksc.config.group.comp.content.12073":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.comp.adaptor.12073",
//                "yksc.plugin.comp.recAdaptor",
//                "yksc.plugin.comp.rec.request",
//                "yksc.plugin.comp.requestEngine.multithread",
//                "yksc.plugin.comp.layoutCache.columnAverage",
//                "yksc.config.group.comp.model.parser.adaptor",
//                "yksc.plugin.comp.layoutPaging",                //组件元数据布局分页
//
//                // 视频预览
//                "yksc.config.group.comp.player.playerControl.common",
//                //广告卡片 曝光
//                "yksc.config.group.comp.feedAd.expose"
//            ], type: "12073"),
//
//            "yksc.config.group.item.12073.12073":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.12073",
//                "yksc.plugin.item.ItemPluginActionExtraParams",
//                "yksc.config.group.item.model.parser.adaptor",
//
//                // 视频预览
//                "yksc.config.group.item.player.playerControl.common",
//            ], type: "12073"),

////            // MARK: 12074 o短小卡
//            "yksc.config.group.item.12073.12074":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.12074",
//                "yksc.plugin.item.ItemPluginActionExtraParams",
//                "yksc.config.group.item.model.parser.adaptor",
//
//                // 视频预览
//                "yksc.config.group.item.player.playerControl.common",
//            ], type: "12074"),
//
//            // MARK: 12076 O短大卡
//            "yksc.config.group.comp.content.12076":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.comp.adaptor.12076",
//                "yksc.plugin.comp.recAdaptor",
//                "yksc.plugin.comp.rec.request",
//                "yksc.plugin.comp.requestEngine.multithread",
//                "yksc.plugin.comp.layoutCache.columnAverage",
//                "yksc.config.group.comp.model.parser.adaptor",
//
//                // 视频预览
//                "yksc.config.group.comp.player.playerControl.common",
//            ], type: "12076"),
//
//            "yksc.config.group.item.12076.12076":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.ItemPluginActionExtraParams",
//                "yksc.plugin.item.12076",
//                "yksc.config.group.item.model.parser.adaptor",
//
//                // 视频预览
//                "yksc.config.group.item.player.playerControl.common",
//                "yksc.plugin.item.PlayerToolsParse",
//                "yksc.config.group.item.mark.v2",   //角标服务
//            ], type: "12076"),
//
////            // MARK: 12077 o短广告
//            "yksc.config.group.item.12073.12077":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.12077",
//                "yksc.config.group.item.model.parser.adaptor",
//
//                // 视频预览
//                "yksc.config.group.item.player.playerControl.common",
//                "yksc.plugin.item.PlayerToolsParse",
//            ], type: "12077"),
//            // MARK: 12077 o短广告
//            "yksc.config.group.item.12073.12087":OneArchBridgeABTest.componentPluginGroupControl(
//            [
//                "yksc.config.group.item.12086.12086"
//            ]),
            
//            // MARK: 12078 广告大卡
//            "yksc.config.group.comp.content.12078":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.comp.adaptor.12078",
//                "yksc.plugin.comp.layoutCache.columnAverage",
//                "yksc.config.group.comp.model.parser.adaptor",
//
//                // 视频预览
//                "yksc.config.group.comp.player.playerControl.common",
//                //广告卡片 曝光
//                "yksc.plugin.comp.content.feedAd.expose",
//            ], type: "12078"),
//            "yksc.config.group.item.12078.12078":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.12078",
//                "yksc.config.group.item.model.parser.adaptor",
//
//                // 视频预览
//                "yksc.config.group.item.player.playerControl.common",
//                "yksc.plugin.item.PlayerToolsParse",
//            ], type: "12078"),
            
//            // 12086 大卡广告
//            "yksc.config.group.comp.content.12086":
//            [
//                "yksc.plugin.comp.adaptor.12086",
//                "yksc.plugin.comp.layoutCache.columnAverage",
//                "yksc.config.group.comp.model.parser.adaptor",
//
//                // 视频预览
//                "yksc.config.group.comp.player.playerControl.common",
//                //广告卡片 曝光
//                "yksc.plugin.comp.content.feedAd.expose",
//            ],
//            "yksc.config.group.item.12086.12086":
//            [
//                "yksc.plugin.item.12086",
//                "yksc.config.group.item.model.parser.adaptor",
//
//                // 视频预览
//                "yksc.config.group.item.player.playerControl.common",
//                "yksc.plugin.item.PlayerToolsParse",
//            ],
            /*
            // MARK: 12092 feed宠爱场景卡
            "yksc.config.group.comp.content.12092":OneArchBridgeABTest.componentPluginGroupRemoveControl(
            [
                "yksc.plugin.comp.adaptor.12092",
                "yksc.plugin.comp.adaptor.12092.sceneAdaptor",
                "yksc.plugin.comp.layoutCache.custom",
                "yksc.config.group.comp.model.parser.adaptor",
            ], type: "12092"),
            "yksc.config.group.item.12092.12092":OneArchBridgeABTest.componentPluginGroupRemoveControl(
            [
                "yksc.config.group.item.model.parser.adaptor",
                "yksc.plugin.item.baseVideo.swift",
            ], type: "12092"),
            */
            
            
//            // MARK: 14013 PHONE_IMG_A
//            "yksc.config.group.comp.content.14013.swift":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.comp.adaptor.14013.swift",               //组件布局适配
//                "yksc.plugin.comp.layoutCache.columnAverage",   //组件布局计算-多列均分
//            ], type:"14013"),
//            
//            "yksc.config.group.item.14013.14013.swift":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.14013.swift",
//                "yksc.config.group.item.tap.route",
//            ], type:"14013"),
//            
//            "yksc.config.group.item.14013.14013.scene.swift":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.14013.adaptor.scene.swift",         //氛围
//                "yksc.config.group.scene.v2",
//            ], type:"14013"),
            
            // MARK: 14027 猜你在追
            "yksc.config.group.comp.content.14027.swift":OneArchBridgeABTest.componentPluginGroupRemoveControl(
            [
                "yksc.plugin.comp.14027.swift",          //组件布局适配
                "yksc.plugin.comp.layoutCache.custom",   //组件布局计算-自定义
                "yksc.plugin.comp.model.parser.adaptor",
            ], type: "14027"),
            "yksc.config.group.item.14027.14027.swift":OneArchBridgeABTest.componentPluginGroupRemoveControl(
            [
                "yksc.plugin.item.model.parser.adaptor",
            ], type: "14027"),
            
            // MARK: 14197 猜你在追
            "yksc.config.group.comp.content.14197":OneArchBridgeABTest.componentPluginGroupRemoveControl(
            [
                "yksc.plugin.comp.14197.swift",          //组件布局适配
                "yksc.plugin.comp.layoutCache.custom",   //组件布局计算-自定义
                "yksc.plugin.comp.model.parser.adaptor",
            ], type: "14197"),
            
            "yksc.config.group.item.14197.14197":OneArchBridgeABTest.componentPluginGroupRemoveControl(
            [
                "yksc.plugin.item.model.parser.adaptor",
            ], type: "14197"),
            
            // MARK: 14918 猜你在追
            "yksc.config.group.comp.content.14918":
            [
                "yksc.plugin.comp.14918.swift",          //组件布局适配
                "yksc.plugin.comp.layoutCache.custom",   //组件布局计算-自定义
                "yksc.plugin.comp.model.parser.adaptor",
            ],
            "yksc.config.group.item.14918.14918":
            [
                "yksc.plugin.item.model.parser.adaptor",
            ],
            
            // MARK: 14030 横滑 PHONE_BASE_E （封面图16:9）
            "yksc.config.group.comp.content.14030.swift":
            [
                "yksc.plugin.comp.adaptor.14030.swift",                 //组件布局适配
                "yksc.plugin.comp.layoutCache.custom",                  //组件布局计算-自定义
                "yksc.plugin.comp.content.horizontal",                  //横滑
                "yksc.config.group.comp.scrollDirectionLock",           //滑动方向冲突
                "yksc.plugin.comp.responselayout.rule",                 //响应式规则
            ],

            "yksc.config.group.item.14030.14030.swift":
            [
                "yksc.plugin.item.baseVideo.swift",                     //坑位样式
                "yksc.plugin.item.14030.swift",                         //坑位样式(附加)
                "yksc.config.group.item.rank.v2",                       //排行角标
                "yksc.plugin.item.responselayout.rule",                 //响应式插件
                "yksc.plugin.item.model.parser.adaptor",
            ],

            "yksc.config.group.item.14030.13002.swift":
            [
                "yksc.plugin.item.13002.swift",                         //坑位样式（附加）
                "yksc.plugin.item.responselayout.rule",                 //响应式插件
                "yksc.plugin.item.model.parser.adaptor",
            ],

            // MARK: 14031 横滑 PHONE_DEFALT_SCROLL_C（封面图4:3）
            "yksc.config.group.comp.content.14031.swift":
            [
                "yksc.plugin.comp.adaptor.14031.swift",                 //组件布局适配
                "yksc.plugin.comp.layoutCache.custom",                  //组件布局计算-自定义
                "yksc.plugin.comp.content.horizontal.homeCache",        //横滑
                "yksc.config.group.comp.scrollDirectionLock",           //滑动方向冲突
                "yksc.plugin.comp.responselayout.rule",                 //响应式规则
            ],

            "yksc.config.group.item.14031.14031.swift":
            [
                "yksc.plugin.item.baseVideo.swift",                     //坑位样式
                "yksc.plugin.item.14031.swift",                         //坑位样式（附加）
                "yksc.config.group.item.rank.v2",                       //排行角标
                "yksc.plugin.item.responselayout.rule",                 //响应式插件
                "yksc.plugin.item.model.parser.adaptor",
            ],

            "yksc.config.group.item.14031.13003.swift":
            [
                "yksc.plugin.item.13003.swift",                         //坑位样式（附加）
                "yksc.plugin.item.responselayout.rule",                 //响应式插件
                "yksc.plugin.item.model.parser.adaptor",
            ],
                        
            // MARK: 14037 MULTI_TAB_B
            //14037 - 主组件、尾部组件 (在YKSCChannel，保持使用OC版本)
            //14037 - 附加组件
            "yksc.config.group.comp.content.14037A.swift":
            [
                "yksc.config.group.comp.content.14031.swift",
                "yksc.plugin.comp.secondplay.report",               //秒播
            ],
            
            "yksc.config.group.item.14037A.14037.swift":
            [
                "yksc.config.group.item.14031.14031.swift",
                "yksc.config.group.item.rank.v2",
            ],
            
            "yksc.config.group.item.14037A.13003.swift":
            [
                "yksc.plugin.item.13003.swift",                     //坑位样式
                "yksc.plugin.item.responselayout.rule",             //响应式插件
                "yksc.plugin.item.model.parser.adaptor",
            ],
            
            // MARK: 14038 MULTI_TAB_C
            //14038 - 主组件、尾部组件 (在YKSCChannel，保持使用OC版本)
            //14038 - 附加组件
            "yksc.config.group.comp.content.14038A.swift":
            [
                "yksc.config.group.comp.content.14031.swift",
            ],
            
            "yksc.config.group.item.14038A.14038.swift":
            [
                "yksc.config.group.item.14037A.14037.swift",
            ],
            
            "yksc.config.group.item.14038A.13003.swift":
            [
                "yksc.config.group.item.14037A.13003.swift",
            ],
            
            // MARK: 14053 MULTI_TAB_A
            //14053 - 主组件、尾部组件 (在YKSCChannel，保持使用OC版本)
            //14053 - 附加组件
            "yksc.config.group.comp.content.14053A.swift":
            [
                "yksc.config.group.comp.content.14031.swift",
            ],
            
            "yksc.config.group.item.14053A.14053.swift":
            [
                "yksc.config.group.item.14037A.14037.swift",
            ],
            
            "yksc.config.group.item.14053A.13003.swift":
            [
                "yksc.config.group.item.14037A.13003.swift",
            ],

            
            // MARK: 14045 [全部场景] 我的场景组件
            "yksc.config.group.comp.content.14045.swift":
            [
                "yksc.plugin.comp.adaptor.14045.swift",
                "yksc.plugin.comp.content.horizontal",
                "yksc.plugin.comp.layoutCache.custom",
            ],
            
            "yksc.config.group.item.14045.14045.swift":
            [
                "yksc.plugin.item.14045.swift",
                "yksc.config.group.item.tap.route",
            ],
            
            // MARK: 14112 左图右文
            "yksc.config.group.comp.content.14112":
            [
                "yksc.plugin.comp.adaptor.14112",
                "yksc.plugin.comp.layoutCache.columnAverage",
            ],
            
            "yksc.config.group.item.14112.14112":
            [
                "yksc.plugin.item.14112",                       //坑位样式
                "yksc.config.group.item.tap.route",             //单击路由事件
                "yksc.plugin.item.rank.dataParserV2",           //排行
                "yksc.config.group.item.summary.v2"             //角标
            ],
            
            "yksc.config.group.item.14112.14112.scene":
            [
                "yksc.plugin.item.14112.adaptor.scene",
                "yksc.config.group.scene.v2",
            ],
            
////             MARK: 14151 酷头条组件
//            "yksc.config.group.comp.content.14151.swift":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.comp.adaptor.14151.swift",
//                "yksc.plugin.comp.layoutCache.custom",
//                "yksc.config.group.roundStyle",
//                "yksc.plugin.comp.roundStyle.home.padding",
//            ], type: "14151"),
//
//            "yksc.config.group.item.14151.14151.swift":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.model.parser.adaptor",
//            ], type: "14151"),
            
//            // MARK: 14171 榜单广场横滑组件
//            "yksc.config.group.comp.content.14171":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.comp.adaptor.14171",
//                "yksc.plugin.comp.layoutCache.custom",          //组件布局计算-自定义
//                "yksc.plugin.comp.content.horizontal",          //横滑
//                "yksc.config.group.comp.scrollDirectionLock",   //滑动方向冲突
//            ], type: "14171"),
//
//            "yksc.config.group.item.14171.14171":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.14171",
//                "yksc.plugin.item.model.parser.adaptor",
//            ], type: "14171"),
//
            // MARK: 14174 【头部组件】全网热点榜
            "yksc.config.group.comp.content.14174":
            [
                "yksc.plugin.comp.layoutCache.columnAverage",
            ],
            
            "yksc.config.group.item.14174.14174":
            [
                "yksc.plugin.item.14174",
            ],
            
            "yksc.config.group.item.14174.14174.immersionBackground":
            [
                "yksc.plugin.item.adaptor.14174.immersionBackground",
            ],

            // MARK: 14179 猜你在追二级页空白组件
            "yksc.config.group.comp.content.14179":
            [
                "yksc.plugin.comp.adaptor.14179",
                "yksc.plugin.comp.layoutCache.columnAverage",
                "yksc.plugin.comp.model.parser.adaptor",
            ],
            
            "yksc.config.group.item.14179.14179":
            [
                "yksc.plugin.item.14179",
                "yksc.plugin.item.model.parser.adaptor",
            ],
  
            // MARK: 14194 电影日历组件
            "yksc.config.group.comp.content.14194":
            [
                "yksc.plugin.comp.content.14194",
                "yksc.plugin.comp.model.parser.adaptor",
                "yksc.plugin.comp.layoutCache.columnAverage",
            ],
            "yksc.config.group.item.14194.14194":
            [
                "yksc.plugin.item.14194",                        //坑位样式（附加）
                "yksc.plugin.item.model.parser.adaptor.v2",
                "yksc.config.group.item.tap.route", //绑定点击事件
            ],
            /*
		// MARK: 14193 筛选器组件
            "yksc.config.group.comp.content.14193":OneArchBridgeABTest.componentPluginGroupRemoveControl(
            [
                "yksc.plugin.comp.content.14193",
                "yksc.plugin.comp.layoutCache.custom",              //组件布局计算-自定义
                "yksc.plugin.comp.model.parser.adaptor",
                "yksc.plugin.comp.activeState",
            ], type: "14193"),

            "yksc.config.group.item.14193.14193":OneArchBridgeABTest.componentPluginGroupRemoveControl(
            
                "yksc.plugin.item.14193",
                "yksc.plugin.item.model.parser.adaptor",
            ], type: "14193"),
            */
            // MARK: 14195 追剧横滑组件
//            "yksc.config.group.comp.content.14195":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.comp.adaptor.14195",
//                "yksc.plugin.comp.layoutCache.custom",                  //组件布局计算-自定义
//                "yksc.plugin.comp.content.horizontal.homeCache",        //横滑
//                "yksc.config.group.comp.scrollDirectionLock",           //滑动方向冲突
//            ], type: "14195"),
//
//            "yksc.config.group.item.14195.14195":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.14195",
//                "yksc.plugin.item.model.parser.adaptor",
//                "yksc.plugin.item.responselayout.rule",         //响应式插件
//            ], type: "14195"),
            
            // MARK: 14196 预约横滑组件
//            "yksc.config.group.comp.content.14196":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.comp.adaptor.14196",
//                "yksc.plugin.comp.layoutCache.custom",                  //组件布局计算-自定义
//                "yksc.plugin.comp.content.horizontal.homeCache",        //横滑
//                "yksc.config.group.comp.scrollDirectionLock",           //滑动方向冲突
//            ], type: "14196"),
//
//            "yksc.config.group.item.14196.14196":OneArchBridgeABTest.componentPluginGroupRemoveControl(
//            [
//                "yksc.plugin.item.14196",
//                "yksc.plugin.item.model.parser.adaptor",
//                "yksc.plugin.item.responselayout.rule",         //响应式插件
//            ], type: "14196"),
            
            // MARK: 50104
            "yksc.config.group.comp.content.50104.swift":
            [
                "yksc.config.group.comp.model.parser.adaptor",
                "yksc.plugin.comp.adaptor.50104.swift",             //组件布局适配
                "yksc.plugin.comp.layoutCache.onePlusN",            //组件布局计算-多列均分
                "yksc.plugin.comp.layoutPaging.onePlusN",           //组件元数据布局分页
            ],
            
            "yksc.config.group.item.50104.50104.swift":
            [
                "yksc.config.group.item.model.parser.adaptor",
                "yksc.plugin.item.50104.swift",
            ],
            
            // MARK: 50108
            "yksc.config.group.comp.content.50108.swift":
            [
                "yksc.config.group.comp.model.parser.adaptor",
                "yksc.plugin.comp.adaptor.50108.swift",             //组件布局适配
                "yksc.plugin.comp.layoutCache.onePlusN",            //组件布局计算-多列均分
                "yksc.plugin.comp.layoutPaging.onePlusN",           //组件元数据布局分页
            ],
            
            "yksc.config.group.item.50108.50108.swift":
            [
                "yksc.config.group.item.model.parser.adaptor",
                "yksc.plugin.item.50108.swift",
            ],
            
            "yksc.config.group.comp.content.15004.swift":
            [
                "yksc.config.group.comp.model.parser.adaptor",             //组件布局适配
                "yksc.plugin.comp.adaptor.15004.swift",
                "yksc.plugin.comp.layoutCache.custom",
                "yksc.plugin.comp.gesture.tap",
                "yksc.plugin.comp.visiblePercent",
            ],
        ]
    }
}
