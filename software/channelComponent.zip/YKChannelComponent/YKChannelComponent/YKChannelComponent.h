//
//  YKChannelComponent.h
//  YKChannelComponent
//
//  Created by better on 2020/11/23.
//

#import <Foundation/Foundation.h>

//! Project version number for YKChannelComponent.
FOUNDATION_EXPORT double YKChannelComponentVersionNumber;

//! Project version string for YKChannelComponent.
FOUNDATION_EXPORT const unsigned char YKChannelComponentVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <YKChannelComponent/PublicHeader.h>


