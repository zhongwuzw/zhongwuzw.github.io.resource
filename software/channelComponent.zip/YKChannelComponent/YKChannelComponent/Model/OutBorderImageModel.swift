//
//  OutBorderImageModel.swift
//  YKChannelComponent
//
//  Created by chao chen on 2023/4/3.
//  Copyright © 2023 Youku. All rights reserved.
//

import Foundation

public class OutBorderImageModel {
    
    /// 人物图/底图 上部分
    var bgTopImg:String?
    
    /// 人物图/底图 下部分
    var bgBottomImg:String?
    
    /// logo图
    var bgLogoImg:String?
    
    public init() {}
    
    public init(_ json: [String: Any]) {
        bgTopImg = json["bgTopImg"] as? String
        bgBottomImg = json["bgBottomImg"] as? String
        bgLogoImg = json["logoImg"] as? String
    }
}
