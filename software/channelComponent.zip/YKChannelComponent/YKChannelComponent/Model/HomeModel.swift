//
//  HomeModel.swift
//  YKChannelComponent
//
//  Created by CC on 2021/6/4.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation

public class HomeItemModelV1 {
    
    public var exampleTitle: String?
    
    public var popularity: PopularityModel?
    
    public var showRecommend: ShowRecommendModel?
    
    public var rankInvolved: Bool = false
    
    public var updateTime: Int = -1
    
    public var extraExtend: [String : Any]?
    
    public init(){}
}
