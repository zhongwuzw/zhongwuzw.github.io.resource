//
//  PopularityModel.swift
//  YKChannelComponent
//
//  Created by CC on 2021/6/10.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation

public class PopularityModel {
    
    /// 热度指数
    var count:String?
    
    /// 文本
    var text:String?
    
    /// 图标
    var icon:String?
    
    /// 描述
    var desc:String?
    
    public init() {}
    
    public init(_ json: [String: Any]) {
        count = json["count"] as? String
        text = json["text"] as? String
        icon = json["icon"] as? String
        desc = json["desc"] as? String
    }
}
