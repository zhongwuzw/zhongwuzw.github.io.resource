//
//  ShowRecommendModel.swift
//  YKChannelComponent
//
//  Created by dylanlai on 2021/12/15.
//  Copyright © 2021 Youku. All rights reserved.
//

import UIKit
import YKChannelBase

public class ShowRecommendModel {

    public var title: String?
    
    public var subtitle: String?
    
    public var desc: String?
    
    public var descIsHighLighted: Bool = false
    
    public var img: String?
    
    public var mark: MarkModel?
    
    public var reason: ReasonModel?
}
