//
//  ModelExtension.swift
//  YKChannelComponent
//
//  Created by CC on 2021/6/4.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import YKChannelBase

extension BaseItemModel {
    public var homeModel:HomeItemModelV1? {
        get {
            return self.extModelHome as? HomeItemModelV1
        }
    }
}
