//
//  HomeItemPluginModelParserAdaptor.swift
//  YKChannelComponent
//
//  Created by CC on 2021/6/4.
//  Copyright © 2021 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKSCBase
import YKChannelBase

@objcMembers
class HomeItemPluginModelParserAdaptor : YKSCItemPlugin {
    
    // MARK:事件映射定义
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventParseData,
                "selector":     "receiveParseDataEvent:",
                "priority":     800
            ]
        ]
    }

    // MARK:事件响应方法
    func receiveParseDataEvent(_ event: YKSCEvent) {
        guard let scItemContext = scItemContext,
              let itemInfo = event.params?["itemInfo"] as? [String: Any]
        else {
            return
        }
        
        
        let homeModel = HomeItemModelV1()
        homeModel.exampleTitle = "exampleTitle"
        
        let data = itemInfo["data"] as? [String: Any]
        
        if let popularityInfo = data?["popularity"] as? [String: Any] {
            let popularity = PopularityModel()
            popularity.text = popularityInfo["text"] as? String
            popularity.count = popularityInfo["count"] as? String
            popularity.icon = popularityInfo["icon"] as? String
            
            homeModel.popularity = popularity
        }
        
        if let showRecommendInfo = data?["showRecommend"] as? [String: Any] {
            let showRecommend = ShowRecommendModel.init()
            showRecommend.title = showRecommendInfo["title"] as? String
            showRecommend.subtitle = showRecommendInfo["subtitle"] as? String
            showRecommend.desc = showRecommendInfo["desc"] as? String
            showRecommend.descIsHighLighted = showRecommendInfo["descIsHighLighted"] as? Bool ?? false
            showRecommend.img = showRecommendInfo["img"] as? String
//            showRecommend.reason = ReasonModel.newModel(showRecommendInfo, compContext: scComponentContext)
            if let reasonInfo = showRecommendInfo["reason"] as? [String: Any] {
                let action = reasonInfo["action"] as? [String: Any]
                let reason = ReasonModel.newModel(text: reasonInfo, action: action, compContext: scComponentContext)
                showRecommend.reason = reason
            }
            
            showRecommend.mark = MarkModel.newModel(showRecommendInfo)
            
            homeModel.showRecommend = showRecommend
        }
        
        if let rankInvolved = data?["rankInvolved"] as? Bool {
            homeModel.rankInvolved = rankInvolved
        }
        
        scItemContext.model.extModelHome = homeModel
        
        //v2
        self.scItemContext?.modelV2.setup(itemInfo)
    }
}

