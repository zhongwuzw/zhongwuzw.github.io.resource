//
//  ItemPluginModelParserAdaptorV2.swift
//  YKChannelComponent
//
//  Created by CC on 2022/6/27.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKSCBase
import OneArchSupport4Youku

@objcMembers
class ItemPluginModelParserAdaptorV2 : YKSCItemPlugin {
    
    // MARK:事件映射定义
    override class func scEventHandlerInfo() -> [Any]! {
        return [
            [
                "event":        YKSCItemEventParseData,
                "selector":     "receiveParseDataEvent:",
                "priority":     900
            ]
        ]
    }

    // MARK:事件响应方法
    func receiveParseDataEvent(_ event: YKSCEvent) {
        guard let scItemContext = scItemContext,
              let itemInfo = event.params?["itemInfo"] as? [String: Any]
        else {
            return
        }
        
        scItemContext.modelV2.setup(itemInfo)
    }
}
