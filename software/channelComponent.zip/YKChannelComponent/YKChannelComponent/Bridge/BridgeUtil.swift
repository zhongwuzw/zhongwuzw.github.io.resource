//
//  BridgeUtil.swift
//  YKChannelComponent
//
//  Created by CC on 2022/6/23.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKChannelBase
import OneArchSupport
import OneArchSupport4Youku

func bridgeTextLayoutModelToV2(_ layout:YKChannelBase.TextLayoutModel?) -> OneArchSupport4Youku.TextLayoutModel? {
    guard let layout = layout else {
        return nil
    }
 
    let layoutv2 = OneArchSupport4Youku.TextLayoutModel.init()
    layoutv2.boundingSize = layout.boundingSize
    layoutv2.renderRect = layout.renderRect
    layoutv2.font = layout.font
    layoutv2.lineNumber = layout.lineNumber
    return layoutv2
}

func bridgeTextLayoutModelsToV2(_ layouts:[YKChannelBase.TextLayoutModel]?) -> [OneArchSupport4Youku.TextLayoutModel]? {
    guard let layouts = layouts else {
        return nil
    }

    var v2Models = [OneArchSupport4Youku.TextLayoutModel]()
    for model in layouts {
        if let v2Model = bridgeTextLayoutModelToV2(model) {
            v2Models.append(v2Model)
        }
    }
    return v2Models
}

func bridgeTextLayoutModelsToV1(_ layouts:[OneArchSupport4Youku.TextLayoutModel]?) -> [YKChannelBase.TextLayoutModel]? {
    guard let layouts = layouts else {
        return nil
    }
    var v1Models = [YKChannelBase.TextLayoutModel]()
    for model in layouts {
        if let v1Model = bridgeTextLayoutModelToV1(model) {
            v1Models.append(v1Model)
        }
    }
    return v1Models
}

func bridgeTextLayoutModelToV1(_ layout:OneArchSupport4Youku.TextLayoutModel?) -> YKChannelBase.TextLayoutModel? {
    guard let layout = layout else {
        return nil
    }
    let layoutv1 = YKChannelBase.TextLayoutModel.init()
    layoutv1.boundingSize = layout.boundingSize
    layoutv1.renderRect = layout.renderRect
    layoutv1.font = layout.font
    layoutv1.lineNumber = layout.lineNumber
    return layoutv1
}
