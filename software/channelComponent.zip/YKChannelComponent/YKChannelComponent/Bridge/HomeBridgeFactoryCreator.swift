//
//  HomeBridgeFactoryCreator.swift
//  YKChannelComponent
//
//  Created by CC on 2022/7/8.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import OneArchBridge
import YKSCBase

@objc class HomeBridgeFactoryCreator: NSObject, IBridgeFactoryCreator {

    
    func getPageNameSpaces() -> [String]? {
        return [
            "cms.home.selection.swift",
            "cms.home.channel.swift"
        ]
    }

    func getWhiteComponentList(_ pageNameSpace: String?) -> [String]? {
        guard let pageNameSpace = pageNameSpace else {
            return nil
        }
        let selectionComponentList = ComponentBridgeConfig.getWhiteComponentList()
        let channelComponentList = ComponentBridgeConfig.getChannelWhiteComponentList()
        if pageNameSpace == "cms.home.selection.swift" {
            return selectionComponentList
        } else if pageNameSpace == "cms.home.channel.swift" {
            return channelComponentList
        } else {
            return nil
        }
    }
    
    func getV1ToV2ItemCustomEventHandlerInfo() -> [Any]? {
        return [
            [
            "event":        "yksc.event.item.layout.customEvent",
            "selector":     "receiveCustomEvent:",
            "priority":     300
            ],
        ]
    }
    
    func getV1ToV2ComponentCustomEventHandlerInfo() -> [Any]? {
        return [
            [
            "event":        "yksc.event.comp.feed.tab.didDeactive",
            "selector":     "receiveCustomEvent:",
            "priority":     300
            ],
        ]
    }
    
    func getV2ToV1PageCustomEventName() -> [String]? {
        return ["yksc.event.page.npz.checkItem.v2",
                "yksc.event.page.doublefeed.feedback.customshow"]
    }
}
