//
//  File.swift
//  YKChannelComponent
//
//  Created by CC on 2022/6/24.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKChannelBase
import OneArchSupport
import OneArchSupport4Youku

class BridgeLTopServiceImp:YKChannelBase.LTopService {
    
    func attach(_ model: YKChannelBase.LTopModel?, toView view: UIView?) {
        guard let model = model else {
            detach(fromView: view)
            return
        }

        var ltop = OneArchSupport4Youku.LTopModel.init()
        ltop.type = model.type
        ltop.img = model.img
        OneArchSupport.Service.lTop.attach(ltop, toView: view)
    }

    func detach(fromView view: UIView?) {
        OneArchSupport.Service.lTop.detach(fromView: view)
    }
}
