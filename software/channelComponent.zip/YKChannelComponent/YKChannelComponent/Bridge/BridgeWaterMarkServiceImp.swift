//
//  BridgeWaterMarkServiceImp.swift
//  YKChannelComponent
//
//  Created by CC on 2022/6/24.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKChannelBase
import OneArchSupport
import OneArchSupport4Youku

public class BridgeWaterMarkServiceImp: YKChannelBase.WaterMarkService {

    public func attach(_ model: YKChannelBase.WaterMarkModel?, toView view: UIView?) {
        guard let model = model else {
            detach(fromView: view)
            return
        }

        var markModel = OneArchSupport4Youku.WaterMarkModel.newModel()
        markModel.imageURL = model.imageURL
        markModel.x = model.x
        markModel.y = model.y
        markModel.w = model.w
        markModel.h = model.h
        markModel.g = model.g
        OneArchSupport.Service.waterMark.attach(markModel, toView: view)
    }

    public func detach(fromView view: UIView?) {
        OneArchSupport.Service.waterMark.detach(fromView: view)
    }
}
