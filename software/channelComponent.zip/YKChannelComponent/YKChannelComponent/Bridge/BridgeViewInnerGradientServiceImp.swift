//
//  BridgeViewInnerGradientServiceImp.swift
//  YKChannelComponent
//
//  Created by CC on 2022/6/24.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKChannelBase
import OneArchSupport
import OneArchSupport4Youku

public struct BridgeViewInnerGradientServiceImp: YKChannelBase.ViewInnerGradientService {
    
    public func attach(_ side: YKChannelBase.ViewInnerGradientSide, toView view: UIView?) {
        attach(side, toView: view, scope: nil, startColor: nil, endColor: nil)
    }
    
    public func attach(_ side: YKChannelBase.ViewInnerGradientSide, toView view: UIView?, scope: CGFloat?) {
        attach(side, toView: view, scope: nil, startColor: nil, endColor: nil)
    }
    
    public func attach(_ side: YKChannelBase.ViewInnerGradientSide, toView view: UIView?, scope: CGFloat?, startColor: UIColor?, endColor: UIColor?) {
        let sideV2 = OneArchSupport4Youku.ViewInnerGradientSide.init(rawValue: side.rawValue) ?? .bottom
        
        OneArchSupport.Service.viewInnerGradient.attach(sideV2, toView: view, scope: scope, startColor: startColor, endColor: endColor)
    }
    
    public func detach(_ side: YKChannelBase.ViewInnerGradientSide, fromView view: UIView?) {
        let sideV2 = OneArchSupport4Youku.ViewInnerGradientSide.init(rawValue: side.rawValue) ?? .bottom
        OneArchSupport.Service.viewInnerGradient.detach(sideV2, fromView: view)
    }
    
}

