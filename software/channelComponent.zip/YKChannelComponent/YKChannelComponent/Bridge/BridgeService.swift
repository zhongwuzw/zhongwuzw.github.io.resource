//
//  BridgeService.swift
//  YKChannelComponent
//
//  Created by CC on 2022/6/17.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import YKChannelBase

extension YKChannelBase.Service {
    
    /**
     * 角标服务
     */
    public static let mark: MarkService = BridgeMarkServiceImp.init()
    
    /**
     * 水印服务，展示在坑位图左上角
     */
    public static let waterMark: WaterMarkService = BridgeWaterMarkServiceImp.init()


    /**
     * 腰封服务
     */
    public static let summary: SummaryService = BridgeSummaryServiceImp.init()

    /**
     * 封面图左下角文案服务
     */
    public static let lbTexts: LBTextsService = BridgeLBTextsServiceImp.init()

    /**
     * 封面图左上角文案服务
     */
    public static let lTop: LTopService = BridgeLTopServiceImp.init()


    /**
     * 视图内渐变服务
     */
    public static let viewInnerGradient: ViewInnerGradientService = BridgeViewInnerGradientServiceImp.init()
}
