//
//  BridgeMarkServiceImp.swift
//  YKChannelComponent
//
//  Created by CC on 2022/6/23.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKChannelBase
import OneArchSupport
import OneArchSupport4Youku

struct BridgeMarkServiceImp: YKChannelBase.MarkService {
    public func estimatedLayout(_ model: YKChannelBase.MarkModel, toViewSize viewSize: CGSize) -> YKChannelBase.TextLayoutModel {
   
        let markModel = self.bridgeMarkModelToV2(model)
        let layout = OneArchSupport.Service.mark.estimatedLayout(markModel, toViewSize: viewSize)
        let layoutv1 = bridgeTextLayoutModelToV1(layout)
        return layoutv1 ?? YKChannelBase.TextLayoutModel.init()
    }
    
    public func attach(_ model: YKChannelBase.MarkModel?, toView view: UIView?) {
        attach(model, toView: view, layout: nil)
    }

    public func attach(_ model: YKChannelBase.MarkModel?, toView view: UIView?, layout: YKChannelBase.TextLayoutModel?) {
        guard let model = model else {
            detach(fromView: view)
            return
        }

        let markModel = self.bridgeMarkModelToV2(model)
        let layoutv2 = bridgeTextLayoutModelToV2(layout)
        Service.mark.attach(markModel, toView: view, layout: layoutv2)
    }
    public func detach(fromView view: UIView?) {
        OneArchSupport.Service.mark.detach(fromView: view)
    }
    
    func bridgeMarkModelToV2(_ model:YKChannelBase.MarkModel) -> OneArchSupport4Youku.MarkModel {
    
        var markModel = OneArchSupport4Youku.MarkModel.newModel()
            
        markModel.text = model.text
        markModel.type = OneArchSupport4Youku.MarkType.init(rawValue: model.type.rawValue) ?? .custom
        markModel.imageURL = model.imageURL
        markModel.colors = model.colors
        return markModel
    }
}
