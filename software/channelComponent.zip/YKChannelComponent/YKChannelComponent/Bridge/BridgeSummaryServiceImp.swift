//
//  BridgeSummaryServiceImp.swift
//  YKChannelComponent
//
//  Created by CC on 2022/6/24.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKChannelBase
import OneArchSupport4Youku
import OneArchSupport

struct BridgeSummaryServiceImp: YKChannelBase.SummaryService {
    
    public func estimatedLayout(_ model: YKChannelBase.SummaryModel, toViewSize viewSize: CGSize) -> YKChannelBase.TextLayoutModel {
        let v2Model = self.bridgeModelToV2(model)
        let v2Layout = OneArchSupport.Service.summary.estimatedLayout(v2Model, toViewSize: viewSize)
        return bridgeTextLayoutModelToV1(v2Layout) ?? YKChannelBase.TextLayoutModel.init()
    }
    
    public func attach(_ model: YKChannelBase.SummaryModel?, toView view: UIView?) {
        attach(model, toView: view, layout: nil)
    }

    public func attach(_ model: YKChannelBase.SummaryModel?, toView view: UIView?, layout: YKChannelBase.TextLayoutModel? = nil) {
        guard let model = model else {
            self.detach(fromView: view)
            return
        }
        let v2Model = self.bridgeModelToV2(model)
        let v2Layout = bridgeTextLayoutModelToV2(layout)
        OneArchSupport.Service.summary.attach(v2Model, toView: view, layout: v2Layout)
    }
    
    public func detach(fromView view: UIView?) {
        OneArchSupport.Service.summary.detach(fromView: view)
    }
    
    public func bridgeModelToV2(_ model: YKChannelBase.SummaryModel) -> OneArchSupport4Youku.SummaryModel {
        let v2Model = OneArchSupport4Youku.SummaryModel.init()
        v2Model.text = model.text
        let textTypeRaw = model.textType.rawValue
        v2Model.textType = OneArchSupport4Youku.SummaryType.init(rawValue: textTypeRaw) ?? .pureText
        
        v2Model.textFont = model.textFont
        return v2Model
    }
}

