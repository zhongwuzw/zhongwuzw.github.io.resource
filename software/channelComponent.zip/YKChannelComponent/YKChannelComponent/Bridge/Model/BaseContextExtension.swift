//
//  BaseContextExtension.swift
//  YKChannelComponent
//
//  Created by CC on 2022/6/27.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import YKSCBase
import OneArchSupport4Youku

extension BaseItemModel {
    public var homeModel:HomeItemModelV1? {
        get {
            return self.extModelHome as? HomeItemModelV1
        }
    }
}

extension YKSCItemContext {
    private struct AssociatedKey {
        static var model = ""
        static var layoutModel = ""
    }
    public var modelV2: OneArchSupport4Youku.BaseItemModel {
        get {
            let obj = objc_getAssociatedObject(self, &AssociatedKey.model) as? BaseItemModel
            if obj == nil {
                let newObj = BaseItemModel()
                objc_setAssociatedObject(self, &AssociatedKey.model, newObj, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
                return newObj
            } else {
                return obj!
            }
        }
    }
    public var layoutModelV2:LayoutModel {
        get {
            let obj = objc_getAssociatedObject(self, &AssociatedKey.layoutModel) as? LayoutModel
            if obj == nil {
                let newObj = LayoutModel()
                objc_setAssociatedObject(self, &AssociatedKey.layoutModel, newObj, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
                return newObj
            } else {
                return obj!
            }
        }
    }
}

extension YKSCComponentContext {
    private struct AssociatedKey {
        static var model = ""
        static var layoutModel = ""
    }
    public var modelV2: BaseComponentModel {
        get {
            let obj = objc_getAssociatedObject(self, &AssociatedKey.model) as? BaseComponentModel
            if obj == nil {
                let newObj = BaseComponentModel()
                objc_setAssociatedObject(self, &AssociatedKey.model, newObj, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
                return newObj
            } else {
                return obj!
            }
        }
    }
    public var layoutModelV2:LayoutModel {
        get {
            let obj = objc_getAssociatedObject(self, &AssociatedKey.layoutModel) as? LayoutModel
            if obj == nil {
                let newObj = LayoutModel()
                objc_setAssociatedObject(self, &AssociatedKey.layoutModel, newObj, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
                return newObj
            } else {
                return obj!
            }
        }
    }
}

extension YKSCCardContext {
    private struct AssociatedKey {
        static var model = ""
    }
    public var modelV2: BaseCardModel {
        get {
            let obj = objc_getAssociatedObject(self, &AssociatedKey.model) as? BaseCardModel
            if obj == nil {
                let newObj = BaseCardModel()
                objc_setAssociatedObject(self, &AssociatedKey.model, newObj, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
                return newObj
            } else {
                return obj!
            }
        }
    }
}

extension YKSCPageContext {
    private struct AssociatedKey {
        static var model = ""
    }
    public var modelV2: BasePageModel {
        get {
            let obj = objc_getAssociatedObject(self, &AssociatedKey.model) as? BasePageModel
            if obj == nil {
                let newObj = BasePageModel()
                objc_setAssociatedObject(self, &AssociatedKey.model, newObj, .OBJC_ASSOCIATION_RETAIN_NONATOMIC)
                return newObj
            } else {
                return obj!
            }
        }
    }
}
