//
//  BridgeLBTextsServiceImp.swift
//  YKChannelComponent
//
//  Created by CC on 2022/6/24.
//  Copyright © 2022 Youku. All rights reserved.
//

import Foundation
import UIKit
import YKChannelBase
import OneArchSupport
import OneArchSupport4Youku

struct BridgeLBTextsServiceImp: YKChannelBase.LBTextsService {
    
    public func estimatedLayout(_ models: [YKChannelBase.LBTextModel], toViewSize viewSize: CGSize) -> [YKChannelBase.TextLayoutModel] {
        let v2Models = self.lbtextModelsToV2(models)
        let v2Layouts = OneArchSupport.Service.lbTexts.estimatedLayout(v2Models, toViewSize: viewSize)
        return bridgeTextLayoutModelsToV1(v2Layouts) ?? []
    }
    
    public func attach(_ models: [YKChannelBase.LBTextModel]?, toView view: UIView?) {
        attach(models, toView: view, layouts: nil)
    }
    
    public func attach(_ models: [YKChannelBase.LBTextModel]?, toView view: UIView?, layouts: [YKChannelBase.TextLayoutModel]? = nil) {
        guard let models = models else {
            detach(fromView: view)
            return
        }

        let v2Models = self.lbtextModelsToV2(models)
        let v2Layouts = bridgeTextLayoutModelsToV2(layouts)
        
        OneArchSupport.Service.lbTexts.attach(v2Models, toView: view, layouts: v2Layouts)
    }
    
    public func detach(fromView view: UIView?) {
        OneArchSupport.Service.lbTexts.detach(fromView: view)
    }
    
    private func validLayouts(_ layouts: [YKChannelBase.TextLayoutModel]?, forModels models: [YKChannelBase.LBTextModel]?) -> [YKChannelBase.TextLayoutModel]? {
        guard let layouts = layouts else {
            return nil
        }
        
        guard let models = models else {
            return nil
        }
        
        if layouts.count != models.count {
            return nil
        }
        
        return layouts
    }
    
    func lbtextModelsToV2(_ models:[YKChannelBase.LBTextModel]) -> [OneArchSupport4Youku.LBTextModel] {
        var v2Models = [OneArchSupport4Youku.LBTextModel]()
        for model in models {
            var v2Model = OneArchSupport4Youku.LBTextModel.init()
            v2Model.textColorStr = model.textColorStr
            v2Model.title = model.title
            v2Models.append(v2Model)
            
        }
        return v2Models
    }
}
