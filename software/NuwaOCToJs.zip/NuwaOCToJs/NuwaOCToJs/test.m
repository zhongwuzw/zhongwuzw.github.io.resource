//
//  test.m
//  NuwaOCToJs
//
//  Created by zhangxing on 2019/11/29.
//  Copyright © 2019 zhangxing. All rights reserved.
//

#import "test.h"

@implementation test
//    nuwa(before);
//    if([self useSql]) {
//        NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
//        NSNumber *lastUseSql = [defaults objectForKey:@"ykdb_userSql"];
//        [self setUseSql:[lastUseSql boolValue]];
//    }
    
//    if(![self dbInited]){
//        NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
//        NSNumber *lastUseSql = [defaults objectForKey:@"ykdb_userSql"];
//        [self setUseSql:[lastUseSql boolValue]];
//    }
//    nuwa(before);
//    nuwa(replace);
//    [self performSelector:@selector(test) withObject:nil];
//    nuwa(callback);
//    NSColor *xx = [NSColor redColor];
//    nuwa(replace);
//
//
////    NSColor *xx = [NSColor redColor];
////    NSView*view = [[NSView alloc]init];
////    bool s = [view allowsVibrancy];
////    [super viewDidLoad];
//
//
//
//
//
//
//    // Do any additional setup after loading the view.
//    //    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    //    NSString *supportFile = paths.firstObject;
//
//    //    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
//    //    NSString *path = [defaults objectForKey:@"/Users/zhangxing/Documents/work/NuwaOCToJs/NuwaOCToJs/ViewController.m"];

@end
