//
//  DragDropTextView.h
//  NuwaOCToJs
//
//  Created by zhangxing on 2019/12/3.
//  Copyright © 2019 zhangxing. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@protocol DragDropViewDelegate;

@interface DragDropTextView : NSImageView
@property (assign) IBOutlet id<DragDropViewDelegate> delegate;
@end

@protocol DragDropViewDelegate <NSObject>
-(void)dragDropViewFileList:(NSArray*)fileList;
@end

NS_ASSUME_NONNULL_END
