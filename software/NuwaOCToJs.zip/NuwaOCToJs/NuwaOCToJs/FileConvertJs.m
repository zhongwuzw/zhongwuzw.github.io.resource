//
//  FileConvertJs.m
//  NuwaOCToJs
//
//  Created by zhangxing on 2019/12/3.
//  Copyright © 2019 zhangxing. All rights reserved.
//

#import "FileConvertJs.h"

@interface FileConvertJs()
@property (nonatomic,strong) NSMutableArray *inParamArr;
@end

@implementation FileConvertJs

- (NSString *)convert:(NSString*)file {    
    NSString *oldContentStr= [NSString stringWithContentsOfFile:file encoding:NSUTF8StringEncoding error:nil];
    NSString * newContentStr = @"";
    
    NSArray *nuwaArr = [oldContentStr componentsSeparatedByString:@"yknuwa"];
    for (int i = 0; i < nuwaArr.count; i++) {
        if (i + 1 == nuwaArr.count) {
            break;
        }
        self.inParamArr = [NSMutableArray new];
        
        //nuwaClass
        NSString *nuwaLeft = nuwaArr[0];
        NSString *impRight = [nuwaLeft componentsSeparatedByString:@"@implementation"][1];
        NSString *nuwaClass = [impRight componentsSeparatedByString:@"\n"][0];//ViewController
        nuwaClass = [nuwaClass stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        
        //nuwaSymbol
        NSString *nuwaSymbol = @"";
        NSString *methodSentence = [nuwaArr[i] componentsSeparatedByString:@"\n"].lastObject;
        if ([methodSentence containsString:@"-"]) {
            nuwaSymbol = @"-";
        } else {
            nuwaSymbol = @"+";
        }
        
        //param
        bool isFirst = true;
        NSArray *arr = [methodSentence componentsSeparatedByString:@" "];
        for (int k = 0; k < arr.count; k++) {
            if ([arr[k] containsString:@")"]) {
                if(isFirst) {
                    isFirst = false;
                    continue;
                }
                [self.inParamArr addObject:[arr[k] componentsSeparatedByString:@")"][1]];
            }
        }
        
        //nuwaMethod
        isFirst = true;
        NSString *nuwaMethod = @"";
        arr = [methodSentence componentsSeparatedByString:@":"];
        for (int k = 0; k < arr.count; k++) {
            if (arr.count != 1 && k + 1 == arr.count) {
                break;
            }
            if ([arr[k] containsString:@")"]) {
                if(isFirst) {
                    NSString *methodWord = [arr[k] componentsSeparatedByString:@")"].lastObject;
                    methodWord = [methodWord stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    nuwaMethod = [NSString stringWithFormat:@"%@%@",nuwaMethod,methodWord];
                    isFirst = false;
                } else {
                    NSString *methodWord = [arr[k] componentsSeparatedByString:@" "].lastObject;
                    methodWord = [methodWord stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
                    nuwaMethod = [NSString stringWithFormat:@"%@%@",nuwaMethod,methodWord];
                }
                
                if (arr.count != 1) {
                    nuwaMethod = [NSString stringWithFormat:@"%@:",nuwaMethod];
                }
            }
        }
        
        //methodImp
        NSString *methodImp = nuwaArr[i + 1];
        if ([[methodImp componentsSeparatedByString:@"nuwa(before);"] count] == 3) {
            NSString *methodBeforeImp = [methodImp componentsSeparatedByString:@"nuwa(before);"][1];
            methodBeforeImp = [self AspectOptions:methodBeforeImp];
            newContentStr = [NSString stringWithFormat:@"%@f('%@', '%@%@', 2, function(instance, originInvocation, originArguments) {%@});",newContentStr,nuwaClass,nuwaSymbol,nuwaMethod,methodBeforeImp];
        } else if ([[methodImp componentsSeparatedByString:@"nuwa(after);"] count] == 3) {
            NSString *methodAfterImp = [methodImp componentsSeparatedByString:@"nuwa(after);"][1];
            methodAfterImp = [self AspectOptions:methodAfterImp];
            newContentStr = [NSString stringWithFormat:@"%@f('%@', '%@%@', 0, function(instance, originInvocation, originArguments) {%@})",newContentStr,nuwaClass,nuwaSymbol,nuwaMethod,methodAfterImp];
        } else if ([[methodImp componentsSeparatedByString:@"nuwa(replace);"] count] == 3) {
            NSString *methodReplaceImp = [methodImp componentsSeparatedByString:@"nuwa(replace);"][1];
            methodReplaceImp = [self AspectOptions:methodReplaceImp];
            newContentStr = [NSString stringWithFormat:@"%@f('%@', '%@%@', 1, function(instance, originInvocation, originArguments) {%@})",newContentStr,nuwaClass,nuwaSymbol,nuwaMethod,methodReplaceImp];
        }
        newContentStr = [NSString stringWithFormat:@"%@;",newContentStr];
    }
    newContentStr = [newContentStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
    newContentStr = [newContentStr stringByReplacingOccurrencesOfString:@"$left$" withString:@"["];
    newContentStr = [newContentStr stringByReplacingOccurrencesOfString:@"$right$" withString:@"]"];
    newContentStr = [newContentStr stringByReplacingOccurrencesOfString:@"@\"" withString:@"'"];
    newContentStr = [newContentStr stringByReplacingOccurrencesOfString:@"\"" withString:@"'"];
    NSLog(@"%@",newContentStr);
    return newContentStr;
}

- (NSString*) AspectOptions:(NSString*)methodImp{
    NSString * newContentStr = @"";
    NSString *methodImpNoBrace = methodImp;
    methodImpNoBrace = [methodImpNoBrace stringByReplacingOccurrencesOfString:@"{" withString:@";"];
    methodImpNoBrace = [methodImpNoBrace stringByReplacingOccurrencesOfString:@"}" withString:@";"];
    //sentenceArr
    NSArray *sentenceArr = [methodImpNoBrace componentsSeparatedByString:@";"];
    for (NSString *sentenceStr in sentenceArr) {
        //leftTerms oldRightTerms
        NSString *oldRightTerms = @"";
        NSString *sentenceFilterStr = [sentenceStr componentsSeparatedByString:@"//"].firstObject;
        oldRightTerms = sentenceFilterStr;
        sentenceFilterStr = [sentenceFilterStr stringByReplacingOccurrencesOfString:@"\n" withString:@""];
        sentenceFilterStr = [sentenceFilterStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        if ([sentenceFilterStr isEqualToString:@""]) {
            continue;
        }else if ([sentenceFilterStr isEqualToString:@"nuwa(callback)"]) {
            newContentStr = [NSString stringWithFormat:@"%@e(originInvocation);",newContentStr];
            continue;
        }
        
        if ([sentenceFilterStr containsString:@"=="]) {
        }
        else if ([sentenceFilterStr containsString:@"="]) {
            NSString *varValid = [sentenceFilterStr componentsSeparatedByString:@"="][0];
            varValid = [varValid stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            if ([varValid componentsSeparatedByString:@" "].count > 1) {
                NSString *leftTerms = @"";
                if ([sentenceFilterStr containsString:@"*"]) {
                    leftTerms = [sentenceFilterStr componentsSeparatedByString:@"*"].firstObject;
                    leftTerms = [NSString stringWithFormat:@"%@*",leftTerms];
                } else {
                    leftTerms = [sentenceFilterStr componentsSeparatedByString:@" "].firstObject;
                    leftTerms = [NSString stringWithFormat:@"%@ ",leftTerms];
                }
                if ([leftTerms containsString:@"{"]) {
                    leftTerms = [leftTerms componentsSeparatedByString:@"{"].lastObject;
                }
                sentenceFilterStr = [sentenceFilterStr stringByReplacingOccurrencesOfString:leftTerms withString:@"var "];
                methodImp = [methodImp stringByReplacingOccurrencesOfString:leftTerms withString:@"var "];
                oldRightTerms = [sentenceFilterStr componentsSeparatedByString:@"="][1];
            }
        } else {
        }
        //newRightTerms
        NSString *newRightTerms = oldRightTerms;
        while (true) {
             NSString *rightWordFilterStr = [newRightTerms componentsSeparatedByString:@"]"].firstObject;
             rightWordFilterStr = [rightWordFilterStr componentsSeparatedByString:@"["].lastObject;//UIView alloc
             NSString *oldRightWordStr = [NSString stringWithFormat:@"[%@]",rightWordFilterStr];
            
            NSString *classStr = @"";
            NSString *methodStr = @"";
            NSString *params = @"";
            NSArray *wordArr = [rightWordFilterStr componentsSeparatedByString:@" "];
            for (int i = 0; i < [wordArr count]; i++) {
                if ([wordArr[i] isEqualToString:@""]) {
                    continue;
                } else if (i == 0) {
                    classStr = wordArr[i];//classStr
                    if ([self.inParamArr containsObject:classStr]) {
                        for (int i = 0; i < self.inParamArr.count; i++) {
                            if ([self.inParamArr[i] isEqual:classStr]) {
                                classStr = [NSString stringWithFormat:@"originArguments$left$%d$right$",i];
                                break;
                            }
                        }
                    }
                } else if (![wordArr[i] containsString:@":"]) {
                    methodStr = wordArr[i];
                } else {
                    methodStr = [NSString stringWithFormat:@"%@%@:",methodStr,[wordArr[i] componentsSeparatedByString:@":"][0]];
                    NSString *rightParam = [wordArr[i] componentsSeparatedByString:@":"][1];
                    if ([rightParam containsString:@"NSClassFromString"]) {
                        rightParam = [rightParam stringByReplacingOccurrencesOfString:@"NSClassFromString(" withString:@""];
                        rightParam = [rightParam substringWithRange:NSMakeRange(0, rightParam.length - 1)];
                    }
                    if ([rightParam containsString:@"@"]) {
                        rightParam = [rightParam substringWithRange:NSMakeRange(2, rightParam.length - 3)];
                        params = [NSString stringWithFormat:@"%@,'%@'",params,rightParam];
                    } else if ([self.inParamArr containsObject:rightParam]) {
                        for (int i = 0; i < self.inParamArr.count; i++) {
                            if ([self.inParamArr[i] isEqual:rightParam]) {
                                params = [NSString stringWithFormat:@"%@,originArguments$left$%d$right$",params,i];
                                break;
                            }
                        }
                    } else {
                        params = [NSString stringWithFormat:@"%@,%@",params,rightParam];
                    }
                }
            }
            if (params.length > 0) {
                params =[NSString stringWithFormat:@",new Array(%@)",[params substringFromIndex:1]];
            }
            
            if ([classStr isEqualToString:@"super"]) {
                classStr = @"instance";
                methodStr = [NSString stringWithFormat:@"s_%@",methodStr];
            } else if ([classStr isEqualToString:@"self"]) {
                classStr = @"instance";
            }
             Class class = NSClassFromString([classStr stringByReplacingOccurrencesOfString:@"UI" withString:@"NS"]);
             NSString *newRightWordStr =@"";
             if (class) {
                 newRightWordStr = [NSString stringWithFormat:@"c('%@','%@'%@) ",classStr,methodStr,params];
             } else {
                newRightWordStr = [NSString stringWithFormat:@"i(%@,'%@'%@) ",classStr,methodStr,params];
             }
             newRightTerms = [newRightTerms stringByReplacingOccurrencesOfString:oldRightWordStr withString:newRightWordStr];
             if (![newRightTerms containsString:@"["]) {
                 break;
             }
        }
        if ([newRightTerms containsString:@"nil"]) {
            newRightTerms = [newRightTerms stringByReplacingOccurrencesOfString:@"nil" withString:@"null"];
        }
        if ([newRightTerms containsString:@"NO"]) {
            newRightTerms = [newRightTerms stringByReplacingOccurrencesOfString:@"NO" withString:@"false"];
        }
        if ([newRightTerms containsString:@"YES"]) {
            newRightTerms = [newRightTerms stringByReplacingOccurrencesOfString:@"YES" withString:@"true"];
        }
        if ([newRightTerms containsString:@"return"]) {
            NSString *newRightWord = [newRightTerms stringByReplacingOccurrencesOfString:@"return " withString:@""];
            newRightWord = [newRightWord stringByReplacingOccurrencesOfString:@";" withString:@""];
            newRightWord = [newRightWord stringByReplacingOccurrencesOfString:@"\n" withString:@""];
            newRightWord = [newRightWord stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            if ([self.inParamArr containsObject:newRightWord]) {
                for (int i = 0; i < self.inParamArr.count; i++) {
                    if ([self.inParamArr[i] isEqual:newRightWord]) {
                        newRightWord = [NSString stringWithFormat:@"originArguments$left$%d$right$",i];
                        break;
                    }
                }
            }
            newRightTerms = [NSString stringWithFormat:@"r(originInvocation,%@);",newRightWord];
        }
        
        methodImp = [methodImp stringByReplacingOccurrencesOfString:oldRightTerms withString:newRightTerms];
    }
    return methodImp;
}

@end
