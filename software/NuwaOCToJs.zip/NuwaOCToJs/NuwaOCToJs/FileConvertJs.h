//
//  FileConvertJs.h
//  NuwaOCToJs
//
//  Created by zhangxing on 2019/12/3.
//  Copyright © 2019 zhangxing. All rights reserved.
//

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface FileConvertJs : NSObject
- (NSString *)convert:(NSString*)file;
@end

NS_ASSUME_NONNULL_END
