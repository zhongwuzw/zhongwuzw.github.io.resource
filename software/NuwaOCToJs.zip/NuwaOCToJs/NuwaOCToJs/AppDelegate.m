//
//  AppDelegate.m
//  NuwaOCToJs
//
//  Created by zhangxing on 2019/11/21.
//  Copyright © 2019 zhangxing. All rights reserved.
//

#import "AppDelegate.h"
#import "FileConvertJs.h"
#import <JavaScriptCore/JavaScriptCore.h>

@interface AppDelegate ()
@property (nonatomic,strong) NSWindow *window;
@property (nonatomic,strong) NSTextView *customView;
@end

@implementation AppDelegate
@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
    // Insert code here to initialize your application
    NSApplication *app = [NSApplication sharedApplication];
    window = app.mainWindow;
    window.title = @"请点击窗口或拖拽多个文件到窗口，以进行脚本转换";
    window.contentView.layer.backgroundColor = [NSColor whiteColor].CGColor;
    [window setFrame:CGRectMake(100, 100, 470, 494) display:NO];
    window.movableByWindowBackground =YES;
    [window center];
    
    self.drapDropTextView = [[DragDropTextView alloc] init];
    self.drapDropTextView.layer.backgroundColor = [NSColor redColor].CGColor;
    self.drapDropTextView.frame = CGRectMake(0, 0, window.frame.size.width, window.frame.size.height);
    self.drapDropTextView.delegate = self;
    [window.contentView addSubview:self.drapDropTextView];
}

- (NSTextView*)customView{
    if (!_customView) {
        NSView *contentView = [window contentView];
        _customView = [[NSTextView alloc] initWithFrame:[contentView bounds]];
        [_customView setAutoresizingMask:NSViewWidthSizable|NSViewHeightSizable];
        [contentView addSubview:_customView];
    }
    return _customView;
}

-(void)dragDropViewFileList:(NSArray *)fileList{
    //如果数组不存在或为空直接返回不做处理（这种方法应该被广泛的使用，在进行数据处理前应该现判断是否为空。）
    if(!fileList || [fileList count] <= 0)return;
    NSString *contentResult = @"";
    //在这里我们将遍历这个数字，输出所有的链接，在后台你将会看到所有接受到的文件地址
    for (int n = 0 ; n < [fileList count] ; n++) {
        NSLog(@">>> %@",[fileList objectAtIndex:n]);
        NSString *str = [[FileConvertJs new] convert:[fileList objectAtIndex:n]];
        contentResult = [NSString stringWithFormat:@"%@%@",contentResult,str];
    }
    
    [self valid:contentResult];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        NSAttributedString* attr = [[NSAttributedString alloc] initWithString:contentResult];
        [[self.customView textStorage] appendAttributedString:attr];
        NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
        [pasteboard clearContents];  //必须清空，否则setString会失败。
        [pasteboard setString:contentResult forType:NSStringPboardType];
        [self setbutton];
        if (isPass) {
            self.window.title = @"转换完成并已复制,请review是否正确并粘贴到orange";
        } else {
            self.window.title = @"js语法有误，请检查";
        }
    });
}

-(void)setbutton{
    NSButton *button = [[NSButton alloc]init];
    button.frame=CGRectMake(10, 20, window.frame.size.width - 20, 25);
    button.wantsLayer = true;
    button.layer.borderWidth = 1;
    [button setBezelStyle:NSBezelStyleRegularSquare];
    button.layer.borderColor = [NSColor darkGrayColor].CGColor;
    [button setAutoresizingMask:NSViewWidthSizable];
    [button setTitle:@"点我再次校验"];
    [button setBordered:false];
    [button setTarget:self];
    [button setAction:@selector(buttonClick)];
    NSView *contentView = [window contentView];
    [contentView addSubview:button];
    
}
-(void)buttonClick{
    [self valid:self.customView.attributedString.string];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        if (isPass) {
            self.window.title = @"转换完成并已复制,请review是否正确并粘贴到orange";
        } else {
            self.window.title = @"js语法有误，请再次检查";
        }
        NSPasteboard *pasteboard = [NSPasteboard generalPasteboard];
        [pasteboard clearContents];  //必须清空，否则setString会失败。
        [pasteboard setString:self.customView.attributedString.string forType:NSStringPboardType];
    });
}

- (JSContext *)yg_c {
    static JSContext *yg_c = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        yg_c = [[JSContext alloc] init];
    });
    return yg_c;
}

- (BOOL)valid:(NSString*)str {
    JSContext *yg_c = [self yg_c];
    NSString *f = @"f";
    NSString *e = @"e";
    NSString *c = @"c";
    NSString *i = @"i";
    NSString *o = @"o";
    NSString *a = @"a";
    NSString *r = @"r";
    NSString *l = @"l";
    NSString *p = @"p";
    NSString *m = @"m";
    NSString *da = @"da";
    NSString *dam = @"dam";
    NSString *dag = @"dag";
    yg_c[f] = ^(NSString *i, NSString *a, AspectOptions o, JSValue *j) {
        
    };
        
    yg_c[e] = ^id(NSInvocation *i) {
        return nil;
    };
        
    yg_c[c] = ^id(NSString *c, NSString *s, NSArray *a) {
        return nil;
    };
        
    yg_c[i] = ^id(id i, NSString *s, NSArray *a) {
        return nil;
    };
        
    yg_c[a] = ^(NSInvocation *i, NSArray *a) {

    };
        
    yg_c[o] = ^(NSInvocation *i, NSArray *a,NSInteger k) {
    };
        
    yg_c[r] = ^(NSInvocation *i, id r) {

    };
        
    yg_c[l] = ^(NSString *c) {
    };
        
    yg_c[p] = ^(NSString *s) {

    };
        
    yg_c[m] = ^(NSString *c, NSString *s) {
    };
            
    yg_c[da] = ^(double t, JSValue *j) {
        
    };
        
    yg_c[dam] = ^(JSValue *j) {
        
    };
        
    yg_c[dag] = ^(JSValue *j) {
    };
    isPass = false;
    yg_c[@"test"] = ^() {
        isPass = true;
    };
        
    NSString *test = [NSString stringWithFormat:@"%@test();",str];
    [yg_c evaluateScript:test];
    return isPass;
}

bool isPass =false;

typedef NS_OPTIONS(NSUInteger, AspectOptions) {
    AspectPositionAfter   = 0,            /// Called after the original implementation (default)
    AspectPositionInstead = 1,            /// Will replace the original implementation.
    AspectPositionBefore  = 2,            /// Called before the original implementation.
    
    AspectOptionAutomaticRemoval = 1 << 3 /// Will remove the hook after the first execution.
};

@end
