//
//  ViewController.m
//  NuwaOCToJs
//
//  Created by zhangxing on 2019/11/21.
//  Copyright © 2019 zhangxing. All rights reserved.
//

#import "ViewController.h"
#import <Cocoa/Cocoa.h>

@implementation ViewController

- (void)schemePlayer:(id)sender videoSizeSwitchTo:(CGSize)videoSize yknuwa{
    
    nuwa(after);
    [self setGravity:[self gravity]];
    nuwa(after);
}
//NSString *sortKey = useSql?@"createAt":@"createdAt";
+ (NSArray *)sortArrayWithCreatedAtAesc:(NSArray *)array yknuwa{
    nuwa(replace);
    if([array count] == 0) {
        return nil;
    }
    BOOL useSql = NO;
    if([[array firstObject] isKindOfClass:NSClassFromString(@"YKDownloadShow")] ||
       [[array firstObject] isKindOfClass:NSClassFromString(@"YKDownloadVideo")]) {
        useSql = YES;
    }
    NSString *sortKey2 = useSql?@"createAt":@"createdAt";
    NSString *sortKey = @"";
    if (useSql) {
        sortKey = @"createAt";
    } else {
        sortKey = @"createdAt";
    }
    
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:sortKey ascending:YES];
    if(!sortDescriptor) {
        return nil;
    }
    NSMutableArray *arr = [[NSMutableArray alloc] init];
    [arr addObject:sortDescriptor];
    NSArray *sorted = [array sortedArrayUsingDescriptors:arr];
    if(!sorted) {
        return array;
    }
    return sorted;
    nuwa(replace);
}

- (NSString *)view:(NSView *)view stringForToolTip:(NSToolTipTag)tag point:(NSPoint)point userData:(void *)data yknuwa{
    
    nuwa(before);
    [self setView:view];
    nuwa(before);
    
    return @"";
}

- (void)viewDidLoad yknuwa
{
    [super viewDidLoad];
    nuwa(replace);
    if([self useSql]) {
        NSUserDefaults * defaults = [NSUserDefaults standardUserDefaults];
        NSNumber *lastUseSql = [defaults objectForKey:@"ykdb_userSql"];
        [self setUseSql:[lastUseSql boolValue]];
    }
    nuwa(replace);
}

- (void)viewWillAppear {
    [super viewWillAppear];
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];
    // Update the view, if already loaded.
}


@end
