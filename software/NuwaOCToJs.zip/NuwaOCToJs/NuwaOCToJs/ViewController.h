//
//  ViewController.h
//  NuwaOCToJs
//
//  Created by zhangxing on 2019/11/21.
//  Copyright © 2019 zhangxing. All rights reserved.
//

#import <Cocoa/Cocoa.h>

#define yknuwa __attribute__((annotate("")))
#define nuwa(...) {}

@interface ViewController : NSViewController

@property (nonatomic,assign) NSInteger gravity;
@property (nonatomic,assign) bool useSql;
@property (nonatomic,strong) NSTextField *text;

@end

